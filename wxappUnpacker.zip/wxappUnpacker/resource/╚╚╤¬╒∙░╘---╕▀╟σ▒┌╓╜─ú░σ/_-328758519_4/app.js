App({
    appid: "wx6e2369071fcbd58a",
    domain: "https://luotuoyou.cn",
    ewmdomain: "https://luotuoyou.cn",
    wx_name: "热血争霸",
    token: "rxzb1543908387",
    key_tunnel: wx.getExtConfigSync().key + "_tunnel",
    key_login: wx.getExtConfigSync().key + "_login_info",
    key_sign: wx.getExtConfigSync().key + "_sign_info",
    key_huodong: wx.getExtConfigSync().key + "_huodong_info",
    share_title: wx.getExtConfigSync().share_title,
    commit_id: 4362,
    is_login: !1,
    book_arr: null,
    book_count: 8,
    book_page: 1,
    history_arr: null,
    record_arr: [],
    record_count: 8,
    record_page: 1,
    collect_arr: [],
    product_arr: [],
    product_count: 8,
    product_page: 1,
    product_null: !1,
    product_tips: "",
    data: {},
    unit_id: null,
    has_form_id: !1,
    collect_page: 1,
    collect_count: 8,
    collect_isnull: !1,
    sign_days: -1,
    has_sign: !1,
    play_num: 0,
    my_uid: null,
    your_uid: null,
    userinfo: null,
    host: null,
    game_info: null,
    zbsqpage_info: null,
    kf_id: null,
    tab_bar: [ {
        title: "首页",
        icon: "icon-home",
        source: 0
    }, {
        title: "我玩过的",
        icon: "icon-gamepad",
        source: 1
    }, {
        title: "任务",
        icon: "icon-briefcase",
        source: 2
    }, {
        title: "我的",
        icon: "icon-user",
        source: 3
    } ],
    onLaunch: function(e) {
        var o = this.getTimeStampss(new Date());
        console.log(3333333333333, o), console.log("commit_id", this.commit_id), console.log("appid", this.appid), 
        console.log("token", this.token);
    },
    getTodayRecord: function(e) {
        var o = this;
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=Mwxaapi&a=game_experience_list&session_3rd=" + this.data.session_3rd,
            success: function(t) {
                if (console.log("getTodayRecord----------", t), 1001 == t.data.status) {
                    var n = t.data.data;
                    n.length > 0 && (o.play_num = n.length), e && e();
                } else o.play_num = 0, e && e();
            }
        });
    },
    getRecord: function(e, o, t) {
        var n = this;
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=Mwxaapi&a=game_history_list&session_3rd=" + this.data.session_3rd + "&page=" + e + "&count=" + o,
            success: function(e) {
                if (1001 == e.data.status) {
                    var o = n.record_arr;
                    n.record_arr = o.concat(e.data.data), t && t(e);
                } else t && t("fail");
            }
        });
    },
    getCollect: function(e, o, t) {
        var n = this;
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=Mwxaapi&a=game_collect_list&session_3rd=" + this.data.session_3rd + "&page=" + e + "&count=" + o,
            success: function(e) {
                if (1001 == e.data.status) {
                    n.collect_arr = n.collect_arr.concat(e.data.data);
                    var o = n.collect_page;
                    o++, n.collect_page = o, n.getCollect(n.collect_page, n.collect_count, t);
                } else n.collect_arr.length > 0 ? t && t(e) : n.collect_arr.length <= 0 && (n.collect_isnull = !0, 
                t && t("fail"));
            }
        });
    },
    add_record: function(e, o) {
        wx.request({
            url: e,
            success: function(e) {
                console.log("add_record", e), o && o(e);
            }
        });
    },
    getxcx: function(e) {
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=Mwxaapi&a=wxa_goto&appid=" + this.appid + "&token=" + this.token,
            success: function(o) {
                e && e(o);
            }
        });
    },
    getAuditStatus: function(e) {
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=Wxa&a=get_audit_status&id=" + this.commit_id + "&token=" + this.token,
            success: function(o) {
                e && e(o);
            }
        });
    },
    add_count: function(e, o, t, n, s) {
        var a = this, i = 0, c = 0, r = wx.getStorageSync(e + "member"), d = wx.getStorageSync(e + "IP");
        console.log("id...................", e), r || (i = 1, wx.setStorageSync(e + "member", 1)), 
        d || (c = 1, wx.setStorageSync(e + "IP", 1));
        var l = null;
        l = n ? a.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_wxa_game&token=" + a.token + "&source=" + n : a.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_wxa_game&token=" + a.token, 
        s ? wx.request({
            url: l,
            method: "get",
            data: {
                pv: o,
                member: i,
                IP: c,
                fiction_game_id: e,
                click_pic: t
            },
            success: function(e) {
                console.log("get_wxa_game", e);
            }
        }) : wx.request({
            url: l,
            method: "get",
            data: {
                pv: o,
                member: i,
                IP: c,
                id: e,
                click_pic: t
            },
            success: function(e) {
                console.log("get_wxa_game", e);
            }
        });
    },
    wxLogin: function(e) {
        var o = this;
        wx.login({
            success: function(t) {
                o.sendSession(t.code, e);
            }
        });
    },
    sendSession: function(e, o) {
        var t = this;
        wx.request({
            url: t.domain + "/index.php?g=Wap&m=Wxaapi&a=login&token=" + t.token + "&code=" + e,
            success: function(e) {
                console.log("login", e);
                var n = e.data.session_3rd;
                t.data.session_3rd = n, t.is_login = !0, 1001 == e.data.status ? wx.request({
                    url: t.domain + "/index.php?g=Wap&m=WxaBook&a=zbsq_test_login&session_3rd=" + e.data.session_3rd + "&token=" + t.token,
                    data: "",
                    header: {},
                    method: "GET",
                    dataType: "json",
                    responseType: "text",
                    success: function(e) {
                        o && o(e, "test_login_success");
                    },
                    fail: function(e) {
                        o && o(e, "test_login_fail");
                    }
                }) : (t.is_login = !1, wx.showModal({
                    title: "提示",
                    content: "登录失败",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm ? console.log("用户点击确定") : e.cancel && console.log("用户点击取消");
                    }
                }));
            },
            fail: function(e) {
                console.log("err", e), o && o(e, "login_fail");
            }
        });
    },
    nowLogin: function(e) {
        var o = this;
        wx.login({
            success: function(t) {
                console.log(t.code);
                var n = t.code;
                wx.request({
                    url: o.domain + "/index.php?g=Wap&m=Wxaapi&a=login&token=" + o.token + "&code=" + n,
                    success: function(t) {
                        if (1001 == t.data.status) {
                            if (wx.request({
                                url: o.domain + "/index.php?g=Wap&m=WxaBook&a=zbsq_test_login&session_3rd=" + t.data.session_3rd + "&token=" + o.token,
                                data: "",
                                header: {},
                                method: "GET",
                                dataType: "json",
                                responseType: "text",
                                success: function(e) {},
                                fail: function(e) {}
                            }), console.log("user_info", t), o.session_3rd = t.data.session_3rd, t.data.userinfo && t.data.userinfo.wecha_id) return o.host = t.data.userinfo, 
                            o.host.name && (o.host.wechaname = o.host.name), o.host.wechaname && (o.host.name = o.host.wechaname), 
                            wx.setStorage({
                                key: "user_info",
                                data: {
                                    session_3rd: o.session_3rd,
                                    host: o.host
                                }
                            }), void (e && e("olduser"));
                            wx.getUserInfo({
                                success: function(t) {
                                    console.log("---------", t);
                                    var n = {
                                        name: t.userInfo.nickName,
                                        portrait: t.userInfo.avatarUrl,
                                        unionid: "",
                                        wecha_id: "",
                                        province: t.userInfo.province,
                                        city: t.userInfo.city,
                                        sex: t.userInfo.gender
                                    };
                                    o.host = n, wx.getUserInfo({
                                        withCredentials: !0,
                                        success: function(t) {
                                            console.log("userInfo_withCr", t), o.encryptedData = t.encryptedData, o.iv = t.iv, 
                                            o.getUserBySession(e);
                                        }
                                    });
                                },
                                fail: function(o) {
                                    e && e("fail");
                                }
                            });
                        }
                    }
                });
            }
        });
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var o = e.getFullYear(), t = e.getMonth() + 1, n = e.getDate(), s = e.getHours(), a = e.getMinutes(), i = e.getSeconds(), c = e.getTime();
        return t = t < 10 ? "0" + t : t, n = n < 10 ? "0" + n : n, s = s < 10 ? "0" + s : s, 
        a = a < 10 ? "0" + a : a, i = i < 10 ? "0" + i : i, o + "-" + t + "-" + n + " " + s + ":" + a + ":" + i + ":" + c;
    },
    getUserBySession: function(e) {
        var o = this;
        o.session_3rd && o.encryptedData && o.iv && wx.request({
            url: o.domain + "/index.php?g=Wap&m=Wxaapi&a=getunionid",
            method: "GET",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                session_3rd: o.session_3rd,
                encrypted: o.encryptedData,
                iv: o.iv
            },
            success: function(t) {
                t.data && t.data.wecha_id ? (o.host.unionid = t.data.unionid, o.host.wecha_id = t.data.wecha_id, 
                console.log(o.host), wx.setStorage({
                    key: "user_info",
                    data: {
                        session_3rd: o.session_3rd,
                        host: o.host
                    }
                }), e && e("newuser")) : e && e("fail");
            }
        });
    }
});