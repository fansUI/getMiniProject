var o = getApp(), n = require("../../../tools/wxParse/wxParse.js");

Page({
    data: {
        book_info: null
    },
    goback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    gettext: function(o) {},
    onLoad: function(t) {
        var a = this;
        wx.request({
            url: o.domain + "/index.php?g=Wap&m=Mwxaapi&a=course_info&token=" + o.token,
            data: {
                id: t.book_id
            },
            success: function(o) {
                if (console.log(o), 200 == o.statusCode) {
                    var t = o.data.data;
                    a.setData({
                        book_info: t
                    });
                    var e = "";
                    e += t.content, n.wxParse("article", "html", e, a, 15);
                }
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});