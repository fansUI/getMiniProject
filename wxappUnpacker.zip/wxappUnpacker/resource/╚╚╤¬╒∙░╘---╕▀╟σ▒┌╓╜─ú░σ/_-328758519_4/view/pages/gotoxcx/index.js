var e = getApp(), a = [];

Page({
    data: {
        session: "",
        read: {},
        book: {},
        chapter_id: "",
        newsData: {},
        formIds: [],
        is_auth: !1,
        options: {},
        gotoimg: "",
        appId: "",
        path: "",
        id: 0
    },
    onLoad: function(e) {
        var a = e.id;
        this.setData({
            options: e,
            id: e.id
        }), this.gobackxcx(a), console.log("options", e), this.add_count(a, 1, 0), this.add_count(0, 1, 0);
    },
    gobackxcx: function(a) {
        var o = this;
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_id_wxa_goto&id=" + a,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                1001 == e.data.status ? (e.data.data.image && o.setData({
                    gotoimg: e.data.data.image
                }), o.data.appId = e.data.data.C_appid, o.data.path = e.data.data.C_puth, console.log("gobackxcx,success", e)) : (console.log("res.data.status:", e.data.status), 
                wx.redirectTo({
                    url: "../news/index"
                }));
            }
        });
    },
    gotoxcx: function() {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.appId,
            path: e.data.path,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(a) {
                console.log("gotoxcx,success", a), e.add_count(e.data.id, 0, 1), wx.redirectTo({
                    url: "../news/index"
                });
            },
            fail: function(e) {
                console.log("fail", e), wx.redirectTo({
                    url: "../news/index"
                });
            }
        });
    },
    add_count: function(a, o, t) {
        var d = 0, s = 0, n = wx.getStorageSync(a + "member"), i = wx.getStorageSync(a + "IP");
        console.log(a), n || (d = 1, wx.setStorageSync(a + "member", 1)), i || (s = 1, wx.setStorageSync(a + "IP", 1)), 
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_wxa_game&token=" + e.token,
            method: "get",
            data: {
                pv: o,
                member: d,
                IP: s,
                id: a,
                click_pic: t
            },
            success: function(e) {
                console.log("get_wxa_game", e);
            }
        });
    },
    collectFormId: function(o) {
        var t = o.detail.formId;
        console.log("eeeeeeeeeeeeeee", o, o.detail.formId), t && "the formId is a mock one" != t && e.data.session_3rd && (a.push(t), 
        this.sendFormId());
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var o = this;
        console.log("2"), setTimeout(function() {
            if (a.length) {
                console.log("3");
                var t = {
                    form_id: a,
                    appid: e.appid,
                    time: o.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", t), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: t,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(e) {
                        console.log("sendFormId res", e), a = [];
                    }
                });
            }
        }, 500);
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var a = e.getFullYear(), o = e.getMonth() + 1, t = e.getDate(), d = e.getHours(), s = e.getMinutes(), n = e.getSeconds();
        return o = o < 10 ? "0" + o : o, t = t < 10 ? "0" + t : t, d = d < 10 ? "0" + d : d, 
        s = s < 10 ? "0" + s : s, n = n < 10 ? "0" + n : n, a + "-" + o + "-" + t + " " + d + ":" + s + ":" + n;
    }
});