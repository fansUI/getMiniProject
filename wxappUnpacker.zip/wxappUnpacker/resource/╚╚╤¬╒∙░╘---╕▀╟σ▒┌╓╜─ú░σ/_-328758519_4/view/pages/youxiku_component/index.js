var a = getApp();

Component({
    externalClasses: [ "icon-star" ],
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        },
        data_null: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        banner_index: -1,
        music_index: -1,
        page: 1,
        count: 6,
        data_null: !1,
        label0: [ "休闲", "中国", "全球", "其他" ],
        label1: [ "休闲", "中国", "其他" ],
        label2: [ "休闲", "全球", "其他" ],
        label3: [ "休闲", "中国", "全球" ]
    },
    methods: {
        lower: function() {
            console.log(1), this.getBooks();
        },
        getBooks: function() {
            if (console.log(this.data.data_null), !this.data.data_null) {
                var t = this, e = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token, n = this.data.page + 1, o = this.data.count, i = {
                    page: n,
                    count: o
                };
                wx.showLoading({
                    title: "加载中"
                }), wx.request({
                    url: a.domain + e,
                    data: i,
                    success: function(a) {
                        wx.hideLoading(), console.log("res", a.data.data);
                        var e = a.data.data;
                        if (t.setData({
                            page: n
                        }), e) {
                            var o = t.data.book_arr;
                            o = o.concat(e), console.log(o), t.setData({
                                book_arr: o
                            });
                        } else t.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        goToRead: function(a) {
            var t = a.currentTarget.dataset.id, e = a.currentTarget.dataset.music, n = a.currentTarget.dataset.index, o = a.currentTarget.dataset.name, i = a.currentTarget.dataset.img, s = a.currentTarget.dataset.mode;
            if (console.log(e, this.data.music_index, n), e) {
                var r = /.mp3/;
                console.log("是否是MP3", r.test(e));
                var d = r.test(e);
                if (n == this.data.music_index && "list" == s || n == this.data.banner_index && "banner" == s && d) {
                    this.setData({
                        music_index: -1,
                        banner_index: -1
                    });
                    wx.pauseBackgroundAudio({}), console.log("暂停播放");
                } else d ? ("list" == s ? this.setData({
                    music_index: n,
                    banner_index: -1
                }) : this.setData({
                    music_index: -1,
                    banner_index: n
                }), wx.playBackgroundAudio({
                    dataUrl: e,
                    title: o,
                    coverImgUrl: i
                })) : d || wx.navigateTo({
                    url: "../videopage/index?book_id=" + t
                });
            } else wx.navigateTo({
                url: "../newsdetail2/index?book_id=" + t,
                fail: function(a) {}
            });
        }
    },
    created: function() {
        console.log("book_arr:", this.data.book_arr);
    }
});