var e = getApp(), o = [], a = 0, t = 0;

Page({
    data: {
        hidden: "",
        ad_alert: null,
        ad_float: null,
        session_3rd: "",
        token: "",
        back_to: 0
    },
    collectFormId: function(t) {
        if (e.has_form_id && 0 == this.data.back_to) return this.setData({
            back_to: 1
        }), void setTimeout(function() {
            wx.navigateBack({
                delta: 1
            });
        }, 4e3);
        if (!e.has_form_id || 0 == this.data.back_to) {
            var n = t.detail.formId;
            console.log("eeeeeeeeeeeeeee", t, t.detail.formId), n && "the formId is a mock one" != n && e.data.session_3rd && (o.push(n), 
            a += 1, this.sendFormId());
        }
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var n = this;
        console.log("2"), setTimeout(function() {
            if (o.length) {
                console.log("3");
                var s = {
                    form_id: o,
                    appid: e.appid,
                    time: n.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", s), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: s,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(s) {
                        console.log("sendFormId res", s), o = [], e.has_form_id = !0, t += 1, console.log("new_form_number", a), 
                        console.log("end_form_numb", t), a == t && n.templet_for_game();
                    }
                });
            }
        }, 500);
    },
    templet_for_game: function() {
        console.log(0x9a3298afb5ac7000), wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=templet_msg_for_game&appid=" + e.appid + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    pay_rule: function(o) {
        var a = this;
        wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=WxaBook&a=get_charge_rule&token=" + e.token + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("res", e), e.data.appid ? (console.log("pay_type", o), a.pay_type(o)) : (console.log("appid", o), 
                a.callpay(o));
            }
        });
    },
    pay_type: function(o) {
        wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=pay_type_kf&token=" + e.token + "&session_3rd=" + e.data.session_3rd + "&orderid=" + o.orderId + "&appid=" + e.appid,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {}
        });
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var o = e.getFullYear(), a = e.getMonth() + 1, t = e.getDate(), n = e.getHours(), s = e.getMinutes(), d = e.getSeconds();
        return a = a < 10 ? "0" + a : a, t = t < 10 ? "0" + t : t, n = n < 10 ? "0" + n : n, 
        s = s < 10 ? "0" + s : s, d = d < 10 ? "0" + d : d, o + "-" + a + "-" + t + " " + n + ":" + s + ":" + d;
    },
    onLoad: function(o) {
        console.log("options:", o), console.log("wecha_id:", e.wecha_id), this.getAdver_float(), 
        this.pay_rule(o);
    },
    callpay: function(e) {
        var o = this;
        console.log(e);
        var a = e.package;
        a = a.indexOf("prepay_id") >= 0 ? a : "prepay_id=" + e.package, console.log("packegestr", a), 
        wx.requestPayment({
            timeStamp: e.timestamp,
            nonceStr: e.nonceStr,
            package: a,
            signType: e.signType,
            paySign: unescape(e.paySign),
            success: function(e) {
                o.setData({
                    hidden: "11"
                }), wx.showModal({
                    title: "充值成功",
                    content: "点击继续游戏？",
                    confirmText: "继续游戏",
                    showCancel: !1,
                    success: function(e) {
                        o.setData({
                            hidden: "11"
                        });
                    },
                    fail: function(e) {
                        console.log("pay_back", e), o.setData({
                            hidden: "11"
                        });
                    }
                });
            },
            fail: function(e) {
                console.log("aaaa", e), o.setData({
                    hidden: "11"
                });
            }
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {},
    getAdver_float: function(o) {
        var a = this;
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_ad&place_id=4&token=" + e.token,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("float", e);
                var o = "";
                1001 == e.data.status && (o = e.data.set) && a.setData({
                    ad_alert: o[0]
                });
            }
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});