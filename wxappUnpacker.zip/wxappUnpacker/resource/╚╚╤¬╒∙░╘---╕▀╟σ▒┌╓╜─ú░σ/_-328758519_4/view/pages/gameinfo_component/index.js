var a = getApp();

require("../../../tools/wxParse/wxParse.js");

Component({
    externalClasses: [ "icon-heart", "icon-share" ],
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        },
        data_null: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        banner_index: -1,
        music_index: -1,
        page: 1,
        count: 6,
        data_null: !1
    },
    methods: {
        lower: function() {
            console.log(1), this.getBooks();
        },
        getBooks: function() {
            if (!this.data.data_null) {
                var t = this, e = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token, o = this.data.page + 1, n = this.data.count, r = {
                    page: o,
                    count: n
                };
                wx.showLoading({
                    title: "加载中"
                }), wx.request({
                    url: a.domain + e,
                    data: r,
                    success: function(a) {
                        wx.hideLoading(), console.log("res", a.data.data);
                        var e = a.data.data;
                        if (t.setData({
                            page: o
                        }), e) {
                            var n = t.data.book_arr;
                            n = n.concat(e), console.log(n), t.setData({
                                book_arr: n
                            });
                        } else t.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        goToRead: function(a) {
            var t = a.currentTarget.dataset.id;
            wx.navigateTo({
                url: "../newsdetail2/index?book_id=" + t,
                fail: function(a) {}
            });
        }
    },
    created: function() {}
});