getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        },
        data_null: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        screenNum: 0,
        currentNum: "",
        storage: 0,
        operator: "",
        off: !1,
        title: "计算器"
    },
    methods: {
        compute: function(a) {
            console.log(a);
            var t = a.target.dataset.val, r = this;
            if (isNaN(t)) switch (t) {
              case "+":
              case "-":
              case "*":
              case "/":
              case "=":
                0 == r.data.storage ? (r.data.storage = r.data.currentNum, r.data.operator = t) : (1 != r.data.off && ("+" == r.data.operator ? r.data.currentNum = Number(r.data.storage) + Number(r.data.currentNum) : "-" == r.data.operator ? r.data.currentNum = Number(r.data.storage) - Number(r.data.currentNum) : "*" == r.data.operator ? r.data.currentNum = Number(r.data.storage) * Number(r.data.currentNum) : "/" == r.data.operator && (r.data.currentNum = Number(r.data.storage) / Number(r.data.currentNum))), 
                r.data.storage = r.data.currentNum, r.data.operator = t), r.data.off = !0;
                break;

              case "clear":
                r.data.storage = 0, r.data.currentNum = "0", r.data.operator = "";
                break;

              case "back":
                r.data.currentNum = r.data.currentNum.slice(0, -1), "" == r.data.currentNum && (r.data.currentNum = "0");
                break;

              case ".":
                -1 == r.data.currentNum.indexOf(".") && (r.data.currentNum += t);
            } else 1 == r.data.off && (r.data.currentNum = "", r.data.off = !1), r.data.currentNum += t, 
            r.data.currentNum = Number(r.data.currentNum), r.data.currentNum = r.data.currentNum.toString();
            r.setData({
                screenNum: r.data.currentNum
            });
        },
        changeTitle: function() {
            var a = this;
            wx.setNavigationBarTitle({
                title: a.data.title
            });
        }
    },
    ready: function(a) {
        this.changeTitle();
    }
});