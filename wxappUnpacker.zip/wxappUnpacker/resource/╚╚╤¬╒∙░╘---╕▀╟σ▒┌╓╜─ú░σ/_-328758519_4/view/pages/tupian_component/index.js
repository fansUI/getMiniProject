getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        }
    },
    data: {
        top_index: 0,
        img: []
    },
    methods: {
        changTop: function(t) {
            var a = t.currentTarget.dataset.index;
            console.log(t), this.data.top_index != t.currentTarget.dataset.index && this.getImg(a);
        },
        getImg: function(t) {
            var a = this;
            this.setData({
                top_index: t
            });
            var e = [], r = this.data.book_arr[t].content;
            console.log("news_detail", r);
            var o = new RegExp("https.*?jpg", "g"), n = [];
            r.match(o) && (n = r.match(o));
            var o = new RegExp("https.*?jpeg", "g"), g = [];
            r.match(o) && (g = r.match(o)), e = n.concat(g);
            var o = new RegExp("https.*?png", "g"), i = [];
            r.match(o) && (i = r.match(o)), e = e.concat(i), console.log(e), a.setData({
                img: e
            });
        },
        getbigpic: function(t) {
            var a = t.currentTarget.dataset.index, e = this.data.img[a];
            wx.previewImage({
                urls: [ e ]
            });
        }
    },
    ready: function() {
        var t = this;
        console.log(t.data.book_arr[0]), t.getImg(0);
    }
});