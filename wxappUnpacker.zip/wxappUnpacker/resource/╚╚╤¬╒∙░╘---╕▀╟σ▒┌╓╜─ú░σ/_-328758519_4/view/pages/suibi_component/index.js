var t = getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        }
    },
    data: {
        page: 1,
        count: 4,
        music_index: -1,
        data_null: !1,
        music_dis: "none",
        play_dis: "block",
        stop_dis: "none"
    },
    methods: {
        listenerButtonPause: function() {
            var t = this;
            wx.pauseBackgroundAudio({}), t.setData({
                play_dis: "none",
                stop_dis: "block"
            }), console.log("暂停播放");
        },
        goToMusic: function(t) {
            var e = this;
            t.currentTarget.dataset.id;
            console.log(t);
            var a = {};
            a.music = t.currentTarget.dataset.music, a.title = t.currentTarget.dataset.name, 
            a.content = t.currentTarget.dataset.content, e.listenerButtonPlay(a);
            var o = a.music, n = /.mp3/.test(o);
            console.log(n), n && e.setData({
                music_dis: "block",
                music_url: t.currentTarget.dataset.music,
                music_tile: t.currentTarget.dataset.name,
                play_dis: "block",
                stop_dis: "none"
            });
        },
        listenerButtonPlay: function(t) {
            console.log(t);
            var e = t.music, a = /.mp3/, o = /.mp4/;
            console.log(a.test(e));
            var n = a.test(e), i = o.test(e);
            n ? wx.playBackgroundAudio({
                dataUrl: t.music,
                title: t.title,
                coverImgUrl: t.image
            }) : i ? this.setData({
                playnow: !0,
                videosrc: t.music,
                videotitle: t.title,
                videocontent: t.content,
                video_mode: !0
            }) : this.setData({
                playnow: !0,
                videosrc: t.music,
                videotitle: t.title,
                videocontent: t.content,
                video_mode: !1
            });
        },
        close_video: function() {
            this.setData({
                playnow: !1
            });
        },
        lower: function() {
            this.getBooks();
        },
        getBooks: function() {
            if (!this.data.data_null) {
                var e = this, a = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + t.token, o = this.data.page + 1, n = this.data.count, i = {
                    page: o,
                    count: n
                };
                wx.showLoading({
                    title: "加载中"
                }), wx.request({
                    url: t.domain + a,
                    data: i,
                    success: function(t) {
                        wx.hideLoading(), console.log("res", t.data.data);
                        var a = t.data.data;
                        if (e.setData({
                            page: o
                        }), a) {
                            var n = e.data.book_arr;
                            n = n.concat(a), console.log(n), e.setData({
                                book_arr: n
                            });
                        } else e.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        goToRead: function(t) {
            var e = this.data.tunnel_id ? "&tunnel_id=" + this.data.tunnel_id : "", a = t.currentTarget.dataset.id;
            wx.navigateTo({
                url: "../newsdetail2/index?book_id=" + a + e,
                fail: function(t) {}
            });
        }
    },
    created: function() {}
});