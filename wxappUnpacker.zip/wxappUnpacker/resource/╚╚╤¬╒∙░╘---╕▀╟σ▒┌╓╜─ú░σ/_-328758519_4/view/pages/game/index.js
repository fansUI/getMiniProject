getApp();

Page({
    data: {
        recommendBook: [],
        Bigimg: "",
        session_3rd: ""
    },
    onLoad: function() {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(o) {
        return {
            title: "传世霸业OL",
            path: "/pages/game/index",
            success: function(o) {
                console.log("分享成功");
            },
            fail: function(o) {}
        };
    },
    previewReadBook: function(o) {
        console.log(o);
        var e = o.currentTarget.dataset.bookinfo;
        wx.navigateTo({
            url: "../previewreadbook/previewreadbook?bookId=" + e.bookId + "&title=" + e.title + "&author=" + e.author + "&coverUrl=" + e.coverUrl + "&isAuthor=1&reader= 0&hasLiked= " + e.hasLiked + "&pvCnt=" + e.pvCnt + "&likeCnt=" + e.likeCnt + "&commentCnt=" + e.commentCnt
        });
    },
    toufang_big_img: function() {
        var o = this;
        wx.request({
            url: "https://kohjxs.cn/index.php?g=Wap&m=Mwxaapi&a=wxa_goto&appid=wxe555d4d850f1d9da&token=wxe555d4d850f1d9da",
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "GET",
            dataType: "json",
            responseType: "text",
            success: function(e) {
                e.data.data.image && o.setData({
                    Bigimg: e.data.data.image
                });
            }
        });
    },
    bookListPage: function(o) {
        var e = o.currentTarget.dataset.type;
        wx.navigateTo({
            url: "../../pages/booklist/booklist?type=" + e
        });
    }
});