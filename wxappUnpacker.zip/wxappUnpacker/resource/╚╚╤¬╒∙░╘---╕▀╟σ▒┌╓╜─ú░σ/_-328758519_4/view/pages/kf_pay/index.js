var e = getApp(), o = [], t = 0, a = 0;

Page({
    data: {},
    onLoad: function(e) {
        this.getAdver_float(), this.pay_rule(e), console.log("time1", e.time1), console.log("time2", e.time2), 
        console.log("time3", new Date().getTime());
    },
    getAdver_float: function() {
        var o = this;
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_ad&place_id=4&token=" + e.token,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("float", e);
                var t = "";
                1001 == e.data.status && (t = e.data.set) && o.setData({
                    ad_alert: t[0]
                });
            }
        });
    },
    pay_rule: function(o) {
        var t = this;
        wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=WxaBook&a=get_charge_rule&token=" + e.token + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                t.pay_type(o);
            }
        });
    },
    pay_type: function(o) {
        wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=pay_type_kf&token=" + e.token + "&session_3rd=" + e.data.session_3rd + "&orderid=" + o.orderId + "&appid=" + e.appid,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {}
        });
    },
    collectFormId: function(a) {
        if (e.has_form_id && 0 == this.data.back_to) return this.setData({
            back_to: 1
        }), void setTimeout(function() {
            wx.navigateBack({
                delta: 1
            });
        }, 4e3);
        if (!e.has_form_id || 0 == this.data.back_to) {
            var n = a.detail.formId;
            console.log("eeeeeeeeeeeeeee", a, a.detail.formId), n && "the formId is a mock one" != n && e.data.session_3rd && (o.push(n), 
            t += 1, this.sendFormId());
        }
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var n = this;
        console.log("2"), setTimeout(function() {
            if (o.length) {
                console.log("3");
                var d = {
                    form_id: o,
                    appid: e.appid,
                    time: n.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", d), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: d,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(d) {
                        console.log("sendFormId res", d), o = [], e.has_form_id = !0, a += 1, console.log("new_form_number", t), 
                        console.log("end_form_numb", a), t == a && n.templet_for_game();
                    }
                });
            }
        }, 500);
    },
    templet_for_game: function() {
        console.log(0x9a3298afb5ac7000), wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=templet_msg_for_game&appid=" + e.appid + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var o = e.getFullYear(), t = e.getMonth() + 1, a = e.getDate(), n = e.getHours(), d = e.getMinutes(), s = e.getSeconds();
        return t = t < 10 ? "0" + t : t, a = a < 10 ? "0" + a : a, n = n < 10 ? "0" + n : n, 
        d = d < 10 ? "0" + d : d, s = s < 10 ? "0" + s : s, o + "-" + t + "-" + a + " " + n + ":" + d + ":" + s;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});