var o = require("../../../tools/wxParse/wxParse.js"), n = getApp();

Page({
    data: {
        video_title: "",
        video_src: "",
        video_content: "",
        is_mp4: !1
    },
    goback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onLoad: function(t) {
        console.log(t);
        var e = this;
        wx.request({
            url: n.domain + "/index.php?g=Wap&m=Mwxaapi&a=course_info&token=" + n.token,
            data: {
                id: t.book_id
            },
            success: function(n) {
                console.log(n);
                var t = n.data.data, a = t.music, i = /.mp4/;
                console.log("是否是MP4", i.test(a));
                var c = i.test(a);
                e.setData({
                    playnow: !0,
                    video_src: t.music,
                    video_title: t.title,
                    video_content: t.content,
                    is_mp4: c
                }), o.wxParse("article", "html", t.content, e, 5);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});