var a = getApp(), o = [];

Page({
    data: {
        bigimg: null,
        take_off: null,
        book_arr: [],
        history_arr: [],
        record_arr: [],
        collect_arr: [],
        moban: -1,
        tips: "",
        r_tips: "",
        is_login: !1,
        data_null: !1,
        r_data_null: !1,
        ad_alert: null,
        ad_float: null,
        ad_info: null,
        unit_id: null,
        options_id: null,
        mao_bigimg: null,
        checkbox_index: 0,
        kf_id: null,
        userinfo: null,
        session_3rd: null,
        systemInfo: null,
        token: null,
        unit_info: null,
        wv_url: null,
        share_img: null,
        share_title: null
    },
    getAdver_float: function(o, t) {
        var e = this;
        wx.request({
            url: a.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_ad&place_id=" + o + "&token=" + a.token,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(n) {
                console.log("float", n);
                var i = "";
                1001 == n.data.status && (2 == (i = n.data.set)[0].ad_type && (i[0].is_goto = 1), 
                3 == o ? i && (i[0].path = i[0].ad_path, e.setData({
                    ad_alert: i[0]
                })) : 4 == o ? i && (i[0].path = i[0].ad_path, e.setData({
                    ad_alert: i[0]
                })) : 6 == o && i && (e.setData({
                    unit_id: i[0].ad_desc,
                    kf_id: i[0].kf_id,
                    unit_info: i[0]
                }), a.unit_id = i[0].ad_desc, a.kf_id = i[0].kf_id, a.unit_info = i[0]), console.log("dddd", e.data.ad_alert)), 
                t && t();
            }
        });
    },
    login: function(o) {
        var t = this;
        a.nowLogin(function(e) {
            console.log("loginres", e, a.host, "fail" != e), "fail" != e && t.liebiao(o);
        });
    },
    onLoad: function(o) {
        var t = this;
        if (o.id && this.setData({
            options_id: o.id
        }), o.goto) {
            var e = o.goto;
            wx.request({
                url: a.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_id_wxa_goto&id=" + e,
                success: function(a) {
                    if (console.log("goto-------------", a), 1001 == a.data.status && a.data.data.image) {
                        var o = a.data.data;
                        t.setData({
                            mao_bigimg: o
                        });
                    }
                }
            });
        }
        a.wxLogin(function(o, e) {
            console.log(o), a.getAuditStatus(function(o) {
                console.log("111111111", o), t.setData({
                    take_off: o.data.datas,
                    moban: o.data.templet,
                    wv_url: o.data.url,
                    share_img: o.data.erweima_url,
                    share_title: o.data.game_name
                });
                var e = "", n = "";
                "3003" == o.data.datas ? (e = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token, 
                n = "/index.php?g=Wap&m=Mwxaapi&a=course_pic&pic=image&token=" + a.token, t.getHistory(n, 1, 3)) : "5001" == o.data.datas ? t.getAdver_float(6, function() {}) : "6001" == o.data.datas && (0 != o.data.close_ios && wx.getSystemInfo({
                    success: function(a) {
                        console.log("systemInfo", a), t.setData({
                            systemInfo: a
                        }), "ios" == a.platform && t.getAdver_float(3);
                    }
                }), t.setData({
                    session_3rd: a.data.session_3rd,
                    token: a.token
                })), a.book_arr ? t.setData({
                    book_arr: a.book_arr,
                    collect_arr: a.collect_arr,
                    history_arr: a.history_arr
                }) : "3003" == o.data.datas && t.getBooks(e, a.book_page, a.book_count);
            });
        });
    },
    maoBigimgs: function() {
        var o = this, t = o.data.mao_bigimg;
        t.image = null;
        var e = t.C_appid, n = t.C_puth;
        wx.navigateToMiniProgram({
            appId: e,
            path: n,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function() {
                var e = t.id;
                a.add_count(e, 0, 1), o.setData({
                    mao_bigimg: t
                });
            },
            fail: function() {
                o.setData({
                    mao_bigimg: t
                });
            }
        });
    },
    Bigimgs: function() {
        var a = this, o = a.data.bigimg || a.data.ad_info;
        a.goToXcx(o);
    },
    goToXcx: function(o) {
        var t = this, e = o.B_appid, n = o.B_puth;
        wx.navigateToMiniProgram({
            appId: e,
            path: n,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function() {
                var e = t.data.options_id || o.id;
                a.add_count(e, 0, 1);
            }
        });
    },
    collectFormId: function(t) {
        if (!a.has_form_id) {
            var e = t.detail.formId;
            console.log("eeeeeeeeeeeeeee", t, t.detail.formId), e && "the formId is a mock one" != e && a.data.session_3rd && (o.push(e), 
            this.sendFormId());
        }
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var t = this;
        console.log("2"), setTimeout(function() {
            if (o.length) {
                console.log("3");
                var e = {
                    form_id: o,
                    appid: a.appid,
                    time: t.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", e), wx.request({
                    method: "POST",
                    url: a.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + a.data.session_3rd,
                    data: e,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(t) {
                        console.log("sendFormId res", t), o = [], a.has_form_id = !0;
                    }
                });
            }
        }, 500);
    },
    getTimeStampss: function(a) {
        console.log("dddddddddd");
        var o = a.getFullYear(), t = a.getMonth() + 1, e = a.getDate(), n = a.getHours(), i = a.getMinutes(), r = a.getSeconds();
        return t = t < 10 ? "0" + t : t, e = e < 10 ? "0" + e : e, n = n < 10 ? "0" + n : n, 
        i = i < 10 ? "0" + i : i, r = r < 10 ? "0" + r : r, o + "-" + t + "-" + e + " " + n + ":" + i + ":" + r;
    },
    getBooks: function(o, t, e) {
        n = this;
        if (!this.data.data_null) {
            var n = this;
            this.setData({
                tips: "加载中..."
            }), wx.request({
                url: a.domain + o,
                method: "get",
                data: {
                    page: t,
                    count: e
                },
                success: function(o) {
                    if (1001 == o.data.status) if (o.data.data) {
                        var e = n.data.book_arr, i = o.data.data;
                        if (5 == n.data.moban) {
                            console.log("book_arr", i);
                            for (p = 0; p < i.length; p++) {
                                var r = "";
                                if (i[p].desc) {
                                    var s = i[p].desc.split("\n");
                                    r = s[0], s.shift();
                                    for (var l = [], d = null, c = null, _ = 0; _ < s.length; _++) {
                                        var g = s[_].split(",");
                                        g[1] = 1 * g[1], d ? (g[1] > d && (d = g[1]), g[1] < c && (c = g[1])) : (d = g[1], 
                                        c = g[1]), l.push({
                                            name: g[0],
                                            price: g[1]
                                        });
                                    }
                                    i[p].price = l, i[p].big_price = d, i[p].small_price = c, i[p].desc = r;
                                }
                            }
                            console.log(i);
                        }
                        if (3 != n.data.moban || "5001" != n.data.take_off || a.collect_isnull) {
                            if (console.log("表单为空或者非moban3"), console.log("无收藏", a.collect_isnull), i = e.concat(i), 
                            n.setData({
                                book_arr: i,
                                tips: ""
                            }), a.book_arr = i, "5001" == n.data.take_off) {
                                for (var u = [], e = n.data.book_arr, p = 0; p < e.length; p++) e[p].picture && u.push(e[p]);
                                if (u.length < 3) {
                                    var f = "/index.php?g=Wap&m=Mwxaapi&a=configure_list&token=" + a.token, h = a.book_page, m = a.book_count;
                                    h++, a.book_page = h, n.getBooks(f, h, m);
                                }
                                console.log("history_arr_console", u, "page", t), n.setData({
                                    history_arr: u
                                }), a.history_arr = u;
                            }
                        } else if (console.log("有收藏", a.collect_isnull), a.collect_arr.length < 1) console.log("第一次获取收藏表单"), 
                        a.getCollect(a.collect_page, a.collect_count, function(o) {
                            console.log("app.collect_res", o), console.log("app.collect_arr", a.collect_arr), 
                            n.setData({
                                collect_arr: a.collect_arr
                            });
                            for (l = 0; l < i.length; l++) {
                                var e = a.collect_arr.findIndex(function(a, o, t) {
                                    return a.id == i[l].id;
                                });
                                i[l].has_collect = e >= 0;
                            }
                            s = n.data.book_arr;
                            if (i = s.concat(i), n.setData({
                                book_arr: i,
                                tips: ""
                            }), a.book_arr = i, "5001" == n.data.take_off) {
                                for (var r = [], s = n.data.book_arr, l = 0; l < s.length; l++) s[l].picture && r.push(s[l]);
                                if (r.length < 3) {
                                    var d = "/index.php?g=Wap&m=Mwxaapi&a=configure_list&token=" + a.token, c = a.book_page, _ = a.book_count;
                                    c++, a.book_page = c, n.getBooks(d, c, _);
                                }
                                console.log("history_arr_console", r, "page", t), n.setData({
                                    history_arr: r
                                }), a.history_arr = r;
                            }
                        }); else {
                            console.log("已获取所有收藏表单");
                            for (p = 0; p < i.length; p++) {
                                var k = a.collect_arr.findIndex(function(a, o, t) {
                                    return a.id == i[p].id;
                                });
                                i[p].has_collect = k >= 0;
                            }
                            if (i = e.concat(i), n.setData({
                                book_arr: i,
                                tips: ""
                            }), a.book_arr = i, "5001" == n.data.take_off) {
                                for (var u = [], e = n.data.book_arr, p = 0; p < e.length; p++) e[p].picture && u.push(e[p]);
                                if (u.length < 3) {
                                    var f = "/index.php?g=Wap&m=Mwxaapi&a=configure_list&token=" + a.token, h = a.book_page, m = a.book_count;
                                    h++, a.book_page = h, n.getBooks(f, h, m);
                                }
                                console.log("history_arr_console", u, "page", t), n.setData({
                                    history_arr: u
                                }), a.history_arr = u;
                            }
                        }
                    } else n.setData({
                        data_null: !0,
                        tips: "- 以上为全部资讯 -"
                    });
                }
            });
        }
    },
    getHistory: function(o, t, e) {
        var n = this;
        wx.request({
            url: a.domain + o,
            method: "get",
            data: {
                page: t,
                count: e
            },
            success: function(o) {
                1001 == o.data.status && (n.setData({
                    history_arr: o.data.data
                }), a.history_arr = o.data.data);
            }
        });
    },
    goToMall: function() {
        wx.navigateTo({
            url: "../mall/index"
        });
    },
    goToComplain: function() {
        wx.navigateTo({
            url: "../complain/index"
        });
    },
    goToRecord: function() {
        wx.navigateTo({
            url: "../record/index"
        });
    },
    onReady: function() {},
    onShow: function() {
        "5001" == this.data.take_off && 3 == this.data.moban && this.setData({
            userinfo: a.userinfo
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    swiper0Lower: function() {
        var o = "/index.php?g=Wap&m=Mwxaapi&a=configure_list&token=" + a.token, t = a.book_page, e = a.book_count;
        t++, a.book_page = t, this.getBooks(o, t, e);
    },
    swiper1Lower: function() {
        var o = this;
        if (0 == this.data.checkbox_index) {
            if (this.data.r_data_null) return;
            var t = a.record_count, e = a.record_page;
            e++, a.record_page = e, this.setData({
                r_tips: "加载中"
            }), a.getRecord(e, t, function(t) {
                "fail" == t ? o.setData({
                    r_tips: "- 以上为全部资讯 -",
                    r_data_null: !0
                }) : o.setData({
                    r_tips: "",
                    record_arr: a.record_arr
                });
            });
        }
    },
    onReachBottom: function() {
        if (3 != this.data.moban || "5001" != this.data.take_off) {
            if ("5001" == this.data.take_off) o = "/index.php?g=Wap&m=Mwxaapi&a=configure_list&token=" + a.token; else var o = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token;
            var t = a.book_page, e = a.book_count;
            t++, a.book_page = t, this.getBooks(o, t, e);
        }
    },
    onShareAppMessage: function() {
        return console.log("分享标题：", this.data.share_title), {
            title: this.data.share_title,
            path: "/view/pages/news/index",
            imageUrl: this.data.share_img,
            success: function(a) {
                console.log("分享成功");
            },
            fail: function(a) {}
        };
    }
});