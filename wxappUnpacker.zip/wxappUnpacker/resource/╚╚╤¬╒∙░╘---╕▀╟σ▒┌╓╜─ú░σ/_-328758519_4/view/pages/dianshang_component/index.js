getApp();

Component({
    externalClasses: [ "icon-class" ],
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        }
    },
    data: {
        aaa: 111
    },
    methods: {
        onLoad: function() {}
    },
    created: function() {}
});