var e = getApp(), o = [], a = 0, n = 0, t = 5;

Page({
    data: {
        ad_alert: null,
        place_id: 5
    },
    onLoad: function(o) {
        var a = this;
        o.place_id && (t = o.place_id), wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_ad&place_id=" + t + "&token=" + e.token,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("float", e);
                var o = "";
                1001 == e.data.status && (o = e.data.set) && a.setData({
                    ad_alert: o[0]
                });
            }
        });
    },
    goToXcx: function() {
        var e = this.data.ad_alert;
        1 != e.ad_type && 2 != e.ad_type || wx.navigateToMiniProgram({
            appId: e.appid,
            path: e.ad_path,
            envVersion: "release",
            success: function() {}
        });
    },
    goBack: function() {
        wx.navigateTo({
            url: "../news/index"
        });
    },
    collectFormId: function(n) {
        if (!e.has_form_id) {
            var t = n.detail.formId;
            console.log("eeeeeeeeeeeeeee", n, n.detail.formId), t && "the formId is a mock one" != t && e.data.session_3rd && (o.push(t), 
            a += 1, this.sendFormId());
        }
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var t = this;
        console.log("2"), setTimeout(function() {
            if (o.length) {
                console.log("3");
                var d = {
                    form_id: o,
                    appid: e.appid,
                    time: t.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", d), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: d,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(d) {
                        console.log("sendFormId res", d), o = [], e.has_form_id = !0, n += 1, console.log("new_form_number", a), 
                        console.log("end_form_numb", n), a == n && t.templet_for_game();
                    }
                });
            }
        }, 500);
    },
    templet_for_game: function() {
        console.log(0x9a3298afb5ac7000), wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=templet_msg_for_game&appid=" + e.appid + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {}
        });
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var o = e.getFullYear(), a = e.getMonth() + 1, n = e.getDate(), t = e.getHours(), d = e.getMinutes(), s = e.getSeconds();
        return a = a < 10 ? "0" + a : a, n = n < 10 ? "0" + n : n, t = t < 10 ? "0" + t : t, 
        d = d < 10 ? "0" + d : d, s = s < 10 ? "0" + s : s, o + "-" + a + "-" + n + " " + t + ":" + d + ":" + s;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});