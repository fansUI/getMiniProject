var a = getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        }
    },
    data: {
        news_list: [],
        news_page: 1,
        data_null: !1,
        top_index: 1,
        adv_list: [],
        column: []
    },
    methods: {
        getcolumn: function() {
            var t = this;
            wx.request({
                url: a.domain + "/index.php?g=Wap&m=Mwxaapi&a=article_class",
                success: function(a) {
                    t.setData({
                        column: a.data.data
                    });
                }
            });
        },
        getNews: function() {
            if (!this.data.data_null) {
                var t = this, e = a.domain + "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token, n = {
                    count: 20,
                    page: this.data.news_page
                };
                wx.request({
                    url: e,
                    method: "get",
                    data: n,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(e) {
                        if (e.data.data) {
                            for (var n = t.data.news_list, s = 0; s < e.data.data.length; s++) e.data.data[s].clazz == t.data.top_index && n.push(e.data.data[s]);
                            if (n.length > 0) t.setData({
                                news_list: n
                            }), a.news_list = n; else {
                                var i = t.data.news_page;
                                t.setData({
                                    news_page: i + 1
                                }), t.getNews();
                            }
                        } else t.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        changTop: function(a) {
            console.log(a.currentTarget.dataset.index), this.data.top_index != a.currentTarget.dataset.index && (this.setData({
                top_index: a.currentTarget.dataset.index,
                news_list: [],
                news_page: 1,
                data_null: !1
            }), this.getNews());
        },
        goToRead: function(a) {
            var t = a.currentTarget.dataset.id;
            wx.navigateTo({
                url: "../newsdetail2/index?book_id=" + t,
                fail: function(a) {}
            });
        }
    },
    created: function() {
        this.getNews(), this.getcolumn();
    }
});