var e = getApp(), a = [], o = 0, t = 0;

Page({
    data: {},
    onLoad: function(e) {
        console.log(e), this.getAdver_float(), this.pay_rule(e);
    },
    getAdver_float: function() {
        var a = this;
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_ad&place_id=4&token=" + e.token,
            method: "get",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("float", e);
                var o = "";
                1001 == e.data.status && (o = e.data.set) && a.setData({
                    ad_alert: o[0]
                });
            }
        });
    },
    pay_rule: function(a) {
        var o = this;
        wx.request({
            url: e.domain + "/index.php?g=Home&m=GameOauth&a=get_payment&pay_type=xcx_pay&id=" + a.id,
            success: function(e) {
                if (console.log("支付信息", e), 1001 == e.data.status) {
                    var a = JSON.parse(e.data.data);
                    console.log("支付信息转换后", a), o.callpay(a);
                } else wx.showToast({
                    title: "支付错误，请重新申请支付",
                    success: function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        });
    },
    callpay: function(e) {
        var a = this, o = e.package;
        o = o.indexOf("prepay_id") >= 0 ? o : "prepay_id=" + e.package, console.log("packegestr", o), 
        wx.requestPayment({
            timeStamp: e.timeStamp,
            nonceStr: e.nonceStr,
            package: o,
            signType: e.signType,
            paySign: unescape(e.paySign),
            success: function(e) {
                a.setData({
                    hidden: "11"
                }), wx.showModal({
                    title: "充值成功",
                    content: "点击继续游戏？",
                    confirmText: "继续游戏",
                    showCancel: !1,
                    success: function(e) {
                        a.setData({
                            hidden: "11"
                        });
                    },
                    fail: function(e) {
                        console.log("pay_back", e), a.setData({
                            hidden: "11"
                        });
                    }
                });
            },
            fail: function(e) {
                console.log("aaaa", e), a.setData({
                    hidden: "11"
                });
            }
        });
    },
    collectFormId: function(t) {
        if (e.has_form_id && 0 == this.data.back_to) return this.setData({
            back_to: 1
        }), void setTimeout(function() {
            wx.navigateBack({
                delta: 1
            });
        }, 4e3);
        if (!e.has_form_id || 0 == this.data.back_to) {
            var n = t.detail.formId;
            console.log("eeeeeeeeeeeeeee", t, t.detail.formId), n && "the formId is a mock one" != n && e.data.session_3rd && (a.push(n), 
            o += 1, this.sendFormId());
        }
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var n = this;
        console.log("2"), setTimeout(function() {
            if (a.length) {
                console.log("3");
                var s = {
                    form_id: a,
                    appid: e.appid,
                    time: n.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", s), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: s,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(s) {
                        console.log("sendFormId res", s), a = [], e.has_form_id = !0, t += 1, console.log("new_form_number", o), 
                        console.log("end_form_numb", t), o == t && n.templet_for_game();
                    }
                });
            }
        }, 500);
    },
    templet_for_game: function() {
        console.log(0x9a3298afb5ac7000), wx.request({
            method: "POST",
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=templet_msg_for_game&appid=" + e.appid + "&session_3rd=" + e.data.session_3rd,
            data: "",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var a = e.getFullYear(), o = e.getMonth() + 1, t = e.getDate(), n = e.getHours(), s = e.getMinutes(), i = e.getSeconds();
        return o = o < 10 ? "0" + o : o, t = t < 10 ? "0" + t : t, n = n < 10 ? "0" + n : n, 
        s = s < 10 ? "0" + s : s, i = i < 10 ? "0" + i : i, a + "-" + o + "-" + t + " " + n + ":" + s + ":" + i;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});