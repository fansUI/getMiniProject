var e = getApp();

Page({
    data: {
        wx_name: null,
        complainname: null,
        complainnum: 0,
        complainimgnum: 0,
        complaincontent: "",
        complainimg: [],
        successimg: [],
        getimgend: !1
    },
    goback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    refer: function() {
        if (this.data.complaincontent) {
            var n = e.domain + "/index.php?g=Wap&m=WxaBook&a=report&session_3rd=" + e.data.session_3rd + "&token=" + e.token, t = this.data.successimg;
            t = t.join(",");
            var a = {
                reason: this.data.complaincontent,
                type: this.data.complainname,
                other: t
            };
            console.log(a), wx.request({
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                url: n,
                method: "POST",
                data: a,
                success: function(e) {
                    console.log(e), wx.navigateTo({
                        url: "../complainend/index"
                    });
                }
            });
        } else wx.showToast({
            title: "投诉内容不能空",
            icon: "success",
            duration: 1500
        });
    },
    addimg: function() {
        var n = this, t = [];
        wx.chooseImage({
            count: 4,
            sizeType: [ "compressed" ],
            sourceType: [ "album" ],
            success: function(a) {
                wx.showLoading({
                    title: "数据加载中...",
                    mask: !0
                });
                a.tempFilePaths;
                for (var o = 0; o < a.tempFilePaths.length; o++) {
                    var i = a.tempFilePaths[o];
                    wx.uploadFile({
                        url: e.domain + "/index.php?g=Wap&m=Wxa&a=get_upload_tousu&session_3rd=" + e.data.session_3rd + "&token=" + e.token,
                        filePath: i,
                        name: "path",
                        formData: {
                            user: "test"
                        },
                        success: function(o) {
                            console.log(o);
                            var i = JSON.parse(o.data);
                            i = (i = i.data).replace(/^\./, ""), i = e.domain + i, t.push(i), n.setData({
                                successimg: t
                            }), t.length == a.tempFilePaths.length && (n.setData({
                                getimgend: !0
                            }), console.log(t), n.setData({
                                complainimg: a.tempFilePaths,
                                complainimgnum: a.tempFilePaths.length
                            }), setTimeout(function() {
                                wx.hideLoading();
                            }, 100));
                        }
                    });
                }
            }
        });
    },
    contentchange: function(e) {
        var n = this;
        if (e.detail.cursor >= 140) return e.detail.value = this.data.complaincontent, void (e.detail.cursor = 140);
        n.setData({
            complainnum: e.detail.cursor,
            complaincontent: e.detail.value
        });
    },
    onLoad: function(n) {
        this.setData({
            complainname: n.title,
            wx_name: e.wx_name
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});