var e = getApp();

Page({
    data: {
        scene: null,
        price: 0,
        orderid: null,
        pay_data: [],
        hidden: !0
    },
    onLoad: function(a) {
        var n = this, o = decodeURIComponent(a.scene), t = e.getTimeStampss(new Date());
        console.log(3333333333333, t), e.wxLogin(function(a, t) {
            console.log(a);
            var i = a.data.wecha_id;
            console.log(e.data.session_3rd), "test_login_success" == t && wx.request({
                url: e.domain + "?g=Home&m=GameOauth&a=pay_third&session_3rd=" + e.data.session_3rd + "&id=" + o + "&wecha_id=" + i,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(a) {
                    var o = JSON.parse(a.data.data);
                    a.data.orderid && n.getTitle();
                    var t = e.getTimeStampss(new Date());
                    console.log(3333333333333, t), n.setData({
                        price: a.data.price,
                        orderid: a.data.orderid,
                        pay_data: o
                    }), console.log(a), n.callpay(o);
                }
            });
        });
    },
    pay: function() {
        this.callpay(this.data.pay_data);
    },
    callpay: function(a) {
        var n = this;
        console.log(a);
        var o = e.getTimeStampss(new Date());
        console.log(3333333333333, o);
        var t = a.package;
        t = t.indexOf("prepay_id") >= 0 ? t : "prepay_id=" + a.package, console.log(t), 
        wx.requestPayment({
            timeStamp: a.timeStamp,
            nonceStr: a.nonceStr,
            package: t,
            signType: a.signType,
            paySign: a.paySign,
            success: function(e) {
                wx.showModal({
                    title: "充值成功",
                    content: "点击继续游戏？",
                    confirmText: "继续游戏",
                    showCancel: !1,
                    success: function(e) {
                        n.setData({
                            hidden: !1
                        });
                    },
                    fail: function(e) {
                        console.log("pay_back", e), n.setData({
                            hidden: !0
                        });
                    }
                });
            },
            fail: function(e) {
                console.log("not pay:", e), n.setData({
                    hidden: "11"
                });
            }
        });
    },
    getTitle: function() {
        wx.setNavigationBarTitle({
            title: "支付页面"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1,
            success: function(e) {
                console.log("返回上一页面", e);
            },
            fail: function(e) {
                console.log("返回失败", e);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});