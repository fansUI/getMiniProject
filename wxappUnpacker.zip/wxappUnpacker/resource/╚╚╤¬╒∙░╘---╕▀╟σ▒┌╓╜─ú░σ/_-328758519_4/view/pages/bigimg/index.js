var e = getApp(), o = [];

Page({
    data: {
        Bigimg: ""
    },
    onLoad: function(o) {
        var n = this, t = o.id;
        n.add_count(0, 1, 0), n.add_count(t, 1, 0), wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=configure_info&id=" + t,
            data: "",
            header: {},
            method: "GET",
            dataType: "json",
            responseType: "text",
            success: function(e) {
                console.log("成功：", e);
                var o = e.data.data;
                n.goToXcx(o), n.setData({
                    Bigimg: o
                });
            },
            fail: function(e) {},
            complete: function(e) {}
        });
    },
    Bigimgs: function(e) {
        var o = this, n = o.data.Bigimg;
        o.goToXcx(n);
    },
    getAuth: function() {
        e.wxLogin();
    },
    goToXcx: function(e) {
        var o = this, n = e.appid, t = e.path;
        wx.navigateToMiniProgram({
            appId: n,
            path: t,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(n) {
                o.add_count(e.id, 0, 1), console.log("自动跳转成功", n), wx.redirectTo({
                    url: "../news/index",
                    success: function(e) {},
                    fail: function(e) {},
                    complete: function(e) {}
                });
            },
            fail: function(e) {
                console.log("自动跳转失败", e);
            }
        });
    },
    add_count: function(o, n, t) {
        var a = 0, i = 0, d = wx.getStorageSync(o + "member"), s = wx.getStorageSync(o + "IP");
        console.log(o), d || (a = 1, wx.setStorageSync(o + "member", 1)), s || (i = 1, wx.setStorageSync(o + "IP", 1)), 
        wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=get_wxa_game&token=" + e.token,
            method: "get",
            data: {
                pv: n,
                member: a,
                IP: i,
                id: o,
                click_pic: t
            },
            success: function(e) {
                console.log("get_wxa_game", e);
            }
        });
    },
    collectFormId: function(n) {
        var t = n.detail.formId;
        console.log("eeeeeeeeeeeeeee", n, n.detail.formId), t && "the formId is a mock one" != t && e.data.session_3rd && (o.push(t), 
        this.sendFormId());
    },
    sendFormId: function() {
        console.log("sendFormId-----------------");
        var n = this;
        console.log("2"), setTimeout(function() {
            if (o.length) {
                console.log("3");
                var t = {
                    form_id: o,
                    appid: e.appid,
                    time: n.getTimeStampss(new Date())
                };
                console.log("4"), console.log("sendFormId", t), wx.request({
                    method: "POST",
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=save_form_id&session_3rd=" + e.data.session_3rd,
                    data: t,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(e) {
                        console.log("sendFormId res", e), o = [];
                    }
                });
            }
        }, 500);
    },
    getTimeStampss: function(e) {
        console.log("dddddddddd");
        var o = e.getFullYear(), n = e.getMonth() + 1, t = e.getDate(), a = e.getHours(), i = e.getMinutes(), d = e.getSeconds();
        return n = n < 10 ? "0" + n : n, t = t < 10 ? "0" + t : t, a = a < 10 ? "0" + a : a, 
        i = i < 10 ? "0" + i : i, d = d < 10 ? "0" + d : d, o + "-" + n + "-" + t + " " + a + ":" + i + ":" + d;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});