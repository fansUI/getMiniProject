getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        }
    },
    data: {
        year: "",
        month: "",
        day: "",
        weekArr: [ "日", "一", "二", "三", "四", "五", "六" ],
        dateArr: [],
        firstDay: "",
        lastDay: "",
        height: 0,
        width: 0,
        clockNum: 3,
        dateCurrent: null
    },
    methods: {
        getDate: function() {
            var t = new Date(), a = t.getFullYear(), e = t.getMonth() + 1;
            this.data.year = a, this.data.month = e, this.data.day = t.getDate();
            var s = new Date(a, e - 1, 1);
            this.data.firstDay = s.getDay();
            var i = new Date(a, e, 0);
            this.data.lastDay = i.getDate(), this.setData({
                year: this.data.year,
                month: this.data.month,
                day: this.data.day,
                firstDay: this.data.firstDay,
                lastDay: this.data.lastDay
            }), console.log("今天：" + this.data.day);
        },
        setDate: function() {
            for (var t = 1; t < this.data.lastDay + 1; t++) this.data.dateArr.push(t);
            this.setData({
                dateArr: this.data.dateArr,
                firstDay: this.data.firstDay
            });
        },
        checkDate: function(t) {
            t && (console.log(t.currentTarget), this.setData({
                dateCurrent: t.currentTarget.dataset.index
            }));
        },
        getTitle: function() {
            wx.setNavigationBarTitle({
                title: "动态标题"
            });
        },
        prevMonth: function() {
            var t = "", a = "";
            1 == this.data.month ? (a = this.data.year - 1, this.data.month = 12, t = this.data.month) : (a = this.data.year, 
            t = this.data.month - 1);
            var e = new Date(a, t - 1, 1);
            this.data.firstDay = e.getDay();
            var s = new Date(a, t, 0);
            this.data.lastDay = s.getDate(), this.setData({
                month: t,
                year: a,
                firstDay: this.data.firstDay,
                lastDay: this.data.lastDay
            }), this.data.dateArr = [];
            for (var i = 1; i < this.data.lastDay + 1; i++) this.data.dateArr.push(i);
            this.setData({
                dateArr: this.data.dateArr
            });
        },
        nextMonth: function() {
            var t = "", a = "";
            12 == this.data.month ? (this.data.month = 0, t = this.data.month, a = this.data.year + 1) : (t = this.data.month + 1, 
            a = this.data.year);
            var t = this.data.month + 1, e = new Date(a, t - 1, 1);
            this.data.firstDay = e.getDay();
            var s = new Date(a, t, 0);
            this.data.lastDay = s.getDate(), this.setData({
                month: t,
                year: a,
                firstDay: this.data.firstDay,
                lastDay: this.data.lastDay
            });
            var i = wx.getSystemInfoSync();
            console.log(i), this.setData({
                height: i.windowHeight / 12,
                width: i.windowWidth / 7
            }), this.data.dateArr = [];
            for (var r = 1; r < this.data.lastDay + 1; r++) this.data.dateArr.push(r);
            this.setData({
                dateArr: this.data.dateArr
            });
        }
    },
    ready: function() {
        var t = this;
        t.getDate(), t.setDate();
        var a = wx.getSystemInfoSync();
        console.log(a), t.setData({
            height: a.windowHeight / 12,
            width: a.windowWidth / 7
        }), console.log(t.data.height, t.data.width, t.data.firstDay);
    },
    created: function() {}
});