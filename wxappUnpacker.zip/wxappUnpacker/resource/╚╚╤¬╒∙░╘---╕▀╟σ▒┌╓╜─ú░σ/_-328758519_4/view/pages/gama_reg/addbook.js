getApp();

Page({
    callback: {},
    data: {},
    onLoad: function(n) {
        console.log(n), this.add_n_token(n.wecha_id);
    },
    add_n_token: function(n) {
        n = n;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});