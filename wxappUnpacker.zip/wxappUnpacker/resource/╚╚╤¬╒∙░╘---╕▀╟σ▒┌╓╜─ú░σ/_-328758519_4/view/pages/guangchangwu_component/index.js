var t = getApp();

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        }
    },
    data: {
        playnow: !1,
        videosrc: "",
        videotitle: "",
        videocontent: "",
        page: 1,
        count: 4,
        music_index: -1,
        data_null: !1,
        music_dis: "none",
        play_dis: "block",
        stop_dis: "none"
    },
    methods: {
        listenerButtonPause: function() {
            var t = this;
            wx.pauseBackgroundAudio({}), t.setData({
                play_dis: "none",
                stop_dis: "block"
            }), console.log("暂停播放");
        },
        goToMusic: function(t) {
            var e = this;
            t.currentTarget.dataset.id;
            console.log(t);
            var a = {};
            a.music = t.currentTarget.dataset.music, a.title = t.currentTarget.dataset.name, 
            a.content = t.currentTarget.dataset.content, e.listenerButtonPlay(a);
            var o = a.music, i = /.mp3/.test(o);
            console.log(i), i && e.setData({
                music_dis: "block",
                music_url: t.currentTarget.dataset.music,
                music_tile: t.currentTarget.dataset.name,
                play_dis: "block",
                stop_dis: "none"
            });
        },
        listenerButtonPlay: function(t) {
            console.log(t);
            var e = t.music, a = /.mp4/, o = /.mp3/.test(e), i = a.test(e);
            o ? wx.playBackgroundAudio({
                dataUrl: t.music,
                title: t.title,
                coverImgUrl: t.image
            }) : i ? this.setData({
                playnow: !0,
                videosrc: t.music,
                videotitle: t.title,
                videocontent: t.content,
                video_mode: !0
            }) : this.setData({
                playnow: !0,
                videosrc: t.music,
                videotitle: t.title,
                videocontent: t.content,
                video_mode: !1
            }), console.log(this.data.video_mode);
        },
        close_video: function() {
            this.setData({
                playnow: !1
            });
        },
        lower: function() {
            this.getBooks();
        },
        getBooks: function() {
            if (!this.data.data_null) {
                var e = this, a = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + t.token, o = this.data.page + 1, i = this.data.count, n = {
                    page: o,
                    count: i
                };
                wx.showLoading({
                    title: "加载中"
                }), wx.request({
                    url: t.domain + a,
                    data: n,
                    success: function(t) {
                        wx.hideLoading(), console.log("res", t.data.data);
                        var a = t.data.data;
                        if (e.setData({
                            page: o
                        }), a) {
                            var i = e.data.book_arr;
                            i = i.concat(a), console.log(i), e.setData({
                                book_arr: i
                            });
                        } else e.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        goToRead: function(t) {
            var e = this.data.tunnel_id ? "&tunnel_id=" + this.data.tunnel_id : "", a = t.currentTarget.dataset.id;
            wx.navigateTo({
                url: "../newsdetail2/index?book_id=" + a + e,
                fail: function(t) {}
            });
        }
    },
    created: function() {}
});