var a = getApp(), t = require("../../../tools/wxParse/wxParse.js");

Component({
    properties: {
        book_arr: {
            type: Array,
            value: []
        },
        history_arr: {
            type: Array,
            value: []
        },
        tunnel_id: {
            type: String,
            value: ""
        },
        data_null: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        banner_index: -1,
        music_index: -1,
        page: 1,
        count: 6,
        data_null: !1
    },
    methods: {
        lower: function() {
            console.log(1), this.getBooks();
        },
        getBooks: function() {
            if (!this.data.data_null) {
                var t = this, e = "/index.php?g=Wap&m=Mwxaapi&a=course_list&token=" + a.token, n = this.data.page + 1, r = this.data.count, o = {
                    page: n,
                    count: r
                };
                wx.showLoading({
                    title: "加载中"
                }), wx.request({
                    url: a.domain + e,
                    data: o,
                    success: function(a) {
                        wx.hideLoading(), console.log("res", a.data.data);
                        var e = a.data.data;
                        if (t.setData({
                            page: n
                        }), e) {
                            var r = t.data.book_arr;
                            r = r.concat(e), console.log(r), t.setData({
                                book_arr: r
                            });
                        } else t.setData({
                            data_null: !0
                        });
                    }
                });
            }
        },
        goToRead: function(a) {
            var e = a.currentTarget.dataset.id, n = a.currentTarget.dataset.info, r = a.currentTarget.dataset.music, o = a.currentTarget.dataset.index, i = a.currentTarget.dataset.name, s = a.currentTarget.dataset.img, d = a.currentTarget.dataset.mode;
            if (console.log(r, this.data.music_index, o), r) {
                var l = /.mp3/;
                console.log("是否是MP3", l.test(r));
                var u = l.test(r);
                if (o == this.data.music_index && "list" == d || o == this.data.banner_index && "banner" == d && u) {
                    this.setData({
                        music_index: -1,
                        banner_index: -1
                    });
                    wx.pauseBackgroundAudio({}), console.log("暂停播放");
                } else u ? ("list" == d ? this.setData({
                    music_index: o,
                    banner_index: -1
                }) : this.setData({
                    music_index: -1,
                    banner_index: o
                }), wx.playBackgroundAudio({
                    dataUrl: r,
                    title: i,
                    coverImgUrl: s
                })) : u || wx.navigateTo({
                    url: "../videopage/index?book_id=" + e
                });
            } else {
                var c = n.content;
                t.wxParse("article[" + o + "]", "html", c, this, 15);
            }
        }
    },
    created: function() {}
});