var e = require("../../utils/xd_wxgame.js");

getApp();

Page({
    data: {
        banner_List: null,
        game_list: null,
        video_list: null,
        list_cunfang: null,
        video_ul: [ 0 ],
        videoIndex: null,
        indicatorDots: !0,
        vertical: !1,
        autoplay: !0,
        current: 0,
        circular: !0,
        interval: 5e3,
        duration: 500,
        previousMargin: 0,
        nextMargin: 0,
        swiperH: "",
        coverW: "",
        coverH: "",
        systemH: null,
        ishidden: "none",
        liuliang: "false",
        liuliangshow: "false",
        cishu: "2",
        isshowbanner: "false",
        shuliang: null,
        isfirstload: "true",
        jxurl: null,
        zhuan_url: null,
        istiaozhuan: !1,
        ispass: null,
        ispass1: null,
        isshow_video: !1
    },
    onShareAppMessage: function(e) {
        var o = this;
        console.log("button" === e.from), console.log("menu" === e.from);
        var t = o.data.share_title, a = o.data.share_image;
        return console.log(o.data.share_image), console.log(o.data.share_title), "button" === e.from ? (console.log(e.target), 
        {
            title: t,
            path: "/pages/index/index",
            imageUrl: a,
            success: function(e) {
                console.log("成功了");
            },
            fail: function(e) {
                console.log("失败了");
            }
        }) : "menu" === e.from ? (console.log("6"), {
            title: t,
            path: "pages/index/index",
            imageUrl: a,
            success: function(e) {
                console.log("4");
                var o = e.shareTickets;
                if (0 == o.length) return !1;
                wx.getShareInfo({
                    shareTicket: o[0],
                    success: function(e) {
                        e.encryptedData, e.iv;
                        console.log("1");
                    }
                });
            },
            fail: function(e) {
                console.log("12");
            }
        }) : void 0;
    },
    onLoad: function(o) {
        var t = this, a = getApp().globalData.app_id, _ = wx.getSystemInfoSync().windowWidth, n = wx.getSystemInfoSync().windowHeight;
        console.log(_);
        var s = _ * (438 / 1080);
        console.log(s);
        var i = _ * (493 / 1080), l = i / (493 / 394);
        wx.request({
            url: "https://d.fire2333.com/wxvideobox/getBoxConfig?box_app_id=" + a,
            success: function(e) {
                console.log(e), t.setData({
                    swiperH: s + "px",
                    systemH: n + "px",
                    coverW: i + "px",
                    coverH: l + "px"
                });
                var o = e.data.data.open_type.type, a = e.data.data.open_type.appid;
                wx.setStorageSync("xd_to_source", a), wx.setStorageSync("xd_open_type", o);
                wx.setStorageSync("xd_isskip");
                if (2 == parseInt(e.data.data.open_type.type)) {
                    var _ = e.data.data.open_type.wx_app_id;
                    console.log(_);
                    e.data.data.open_type.wx_path;
                }
            }
        }), wx.request({
            url: "https://d.fire2333.com/wxvideobox/getBoxVideoList?box_app_id=" + a + "&pageIndex=1",
            success: function(e) {
                console.log(e);
                var o = e.data.data;
                console.log(o), getApp().globalData.video_list = o, wx.setStorageSync("video_list", o), 
                t.setData({
                    banner_List: o
                });
            }
        }), wx.request({
            url: "https://d.fire2333.com/wxvideobox/getBoxVideoList?box_app_id=" + a + "&pageIndex=2",
            success: function(e) {
                if (console.log(e), 0 != e.data.data.length) {
                    var o = e.data.data;
                    t.setData({
                        video_list: o
                    });
                }
            }
        }), wx.request({
            url: "https://d.fire2333.com/wxbox/getIsLandingPage?box_app_id=" + a,
            success: function(e) {
                console.log(e), 0 == e.data ? t.setData({
                    ispass: !0,
                    ispass1: !1
                }) : 1 == e.data && t.setData({
                    ispass: !1,
                    ispass1: !0
                });
            }
        }), e.xdLoginWithNoAuth(function(e) {
            var o = e.wx_openid;
            wx.setStorageSync("xd_openid", o);
        });
    },
    webtiaozhuan: function(e) {
        var o = e.currentTarget.dataset.source, t = this;
        wx.navigateTo({
            url: "../lots/lots?zhuan_url=" + o
        }), t.setData({
            zhuan_url: o,
            istiaozhuan: !0
        });
    },
    play: function(e) {
        var o = this, t = e.currentTarget.dataset.button, a = e.currentTarget.dataset.vid, _ = e.currentTarget.dataset.source, n = e.currentTarget.dataset.type;
        console.log(a), console.log(_), console.log(t), console.log(o.data.video_list), 
        null != a && "" != a ? wx.request({
            url: "https://vv.video.qq.com/getinfo?vid=" + a + "&platform=101001&charge=0&otype=json",
            method: "get",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                var t = (e.data.replace(/QZOutputJson=/, "") + "qwe").replace(/;qwe/, ""), a = JSON.parse(t), _ = a.vl.vi[0].ul.ui[0].url.replace(/http/, "https") + a.vl.vi[0].fn + "?vkey=" + a.vl.vi[0].fvkey;
                o.setData({
                    jxurl: _
                }), console.log(_);
            }
        }) : o.setData({
            jxurl: _
        }), wx.getNetworkType({
            success: function(e) {
                if (console.log("返回网络类型, 有效值：", e), "none" != e.networkType) if ("wifi" == e.networkType) if (console.log("3434"), 
                o.data.videoIndex) {
                    wx.createVideoContext("video" + o.data.videoIndex).stop(), o.setData({
                        videoIndex: t,
                        liuliang: "true",
                        liuliangshow: "none"
                    });
                    s = wx.createVideoContext("video" + t);
                    if (1 == n) {
                        _ = wx.createVideoContext("banner_vd");
                        console.log("____________________________________________11"), o.setData({
                            isshow_video: !0,
                            liuliang: "true",
                            liuliangshow: "none",
                            ispass1: !1
                        }), _.play();
                    } else s.play();
                } else {
                    o.setData({
                        videoIndex: t,
                        liuliang: "true",
                        liuliangshow: "none"
                    });
                    var a = wx.createVideoContext("video" + t);
                    if (1 == n) {
                        var _ = wx.createVideoContext("banner_vd");
                        console.log("____________________________________________11"), o.setData({
                            isshow_video: !0,
                            liuliang: "true",
                            liuliangshow: "none",
                            ispass1: !1
                        }), _.play();
                    } else a.play();
                } else {
                    var s = wx.createVideoContext("video" + t);
                    console.log(s), wx.showModal({
                        title: "提示",
                        content: "您正在使用移动网络，继续播放将消耗流量?",
                        success: function(e) {
                            if (console.log(e), e.confirm) if (o.setData({
                                videoIndex: t
                            }), 1 == n) {
                                var a = wx.createVideoContext("banner_vd");
                                console.log("____________________________________________11"), o.setData({
                                    isshow_video: !0,
                                    liuliang: "true",
                                    liuliangshow: "none",
                                    ispass1: !1
                                }), a.play();
                            } else s.play(); else e.cancel && (s.pause(), console.log("用户点击取消"));
                        }
                    });
                }
            }
        }), wx.onNetworkStatusChange(function(e) {
            if ("wifi" == e.networkType) if (console.log("3434"), o.data.videoIndex) {
                wx.createVideoContext("video" + o.data.videoIndex).stop(), o.setData({
                    videoIndex: t,
                    liuliang: "true",
                    liuliangshow: "none"
                });
                s = wx.createVideoContext("video" + t);
                if (1 == n) {
                    _ = wx.createVideoContext("banner_vd");
                    console.log("____________________________________________11"), o.setData({
                        isshow_video: !0,
                        liuliang: "true",
                        liuliangshow: "none",
                        ispass1: !1
                    }), _.play();
                } else s.play();
            } else {
                o.setData({
                    videoIndex: t,
                    liuliang: "true",
                    liuliangshow: "none"
                });
                var a = wx.createVideoContext("video" + t);
                if (1 == n) {
                    var _ = wx.createVideoContext("banner_vd");
                    console.log("____________________________________________11"), o.setData({
                        isshow_video: !0,
                        liuliang: "true",
                        liuliangshow: "none",
                        ispass1: !1
                    }), _.play();
                } else a.play();
            } else {
                var s = wx.createVideoContext("video" + t);
                wx.showModal({
                    title: "提示",
                    content: "您正在使用移动网络，继续播放将消耗流量?",
                    success: function(e) {
                        if (e.confirm) if (o.setData({
                            videoIndex: t
                        }), 1 == n) {
                            var a = wx.createVideoContext("banner_vd");
                            console.log("____________________________________________11"), o.setData({
                                isshow_video: !0,
                                liuliang: "true",
                                liuliangshow: "none",
                                ispass1: !1
                            }), a.play();
                        } else s.play(); else e.cancel && (s.pause(), console.log("用户点击取消"));
                    }
                });
            }
        });
    },
    swipclick: function(e) {
        var o = e.currentTarget.dataset.banner, t = this;
        wx.navigateTo({
            url: "../lots/lots?zhuan_url=" + o
        }), t.setData({
            zhuan_url: o,
            istiaozhuan: !0
        });
    },
    changevideo: function(e) {
        console.log(e);
        var o = this, t = wx.createVideoContext("banner_vd");
        o.setData({
            isshow_video: !1
        }), t.exitFullScreen(), t.stop();
    },
    onReachBottom: function(e) {
        var o = this, t = getApp().globalData.app_id;
        console.log(t), wx.showLoading({
            title: "玩命加载中"
        });
        var a = parseInt(o.data.cishu);
        a += 1, console.log(a), o.setData({
            cishu: a
        }), wx.request({
            url: "https://d.fire2333.com/wxvideobox/getBoxVideoList?box_app_id=" + t + "&pageIndex=" + a,
            success: function(e) {
                if (console.log("dd"), console.log(e), "" == e.data.data) wx.showToast({
                    title: "没有更多了",
                    icon: "success",
                    duration: 1e3
                }); else {
                    e.data.data;
                    var t = o.data.video_list, a = o.data.game_list;
                    console.log(a), console.log(t), console.log(t.length);
                    for (s = 0; s < e.data.data.length; s++) t.push(e.data.data[s]);
                    for (var _ = [], n = [], s = 0; s < t.length; s++) n.push(t[s]), (0 != s && (s + 1) % 6 == 0 || s == t.length - 1) && (_.push(n), 
                    n = []);
                    console.log(_), console.log(_.length);
                    for (s = 0; s < _.length; s++) _[s].push(a[s]);
                    console.log(_);
                    var i = [].concat.apply([], _);
                    console.log(i), setTimeout(function() {
                        o.setData({
                            video_list: i
                        }), console.log(o.data.video_list), wx.hideLoading();
                    }, 1e3);
                }
            }
        });
    },
    bannerclick: function(e) {
        var o = this.data.video_list[e.currentTarget.dataset.jiange];
        console.log("fa"), console.log(o), 1 == o.type ? wx.previewImage({
            urls: [ o.wx_code_image ]
        }) : 2 == o.type && wx.navigateToMiniProgram({
            appId: o.wx_app_id,
            path: o.wx_path,
            success: function(e) {
                console.log(e);
            }
        });
    },
    formSubmit: function(e) {
        var o = getApp().globalData.app_id;
        console.log(o), console.log(e), console.log(e.detail.formId);
        var t = e.detail.formId;
        console.log("form发生了submit事件，携带数据为：", e.detail.value);
        var a = wx.getStorageSync("xd_openid");
        console.log(a), wx.request({
            url: "https://d.fire2333.com/wxbox/formLog?wx_app_id=" + o + "&wx_open_id=" + a + "&wx_form_id=" + t
        });
    },
    entergame: function(e) {
        var o = getApp().globalData.type;
        console.log(o);
        wx.getStorageSync("xd_game_openid"), getApp().globalData.app_id;
        console.log(o.type), console.log(o.wx_path), console.log(o.wx_app_id), console.log("跳转"), 
        wx.navigateToMiniProgram({
            appId: o.wx_app_id,
            path: o.wx_path,
            success: function(e) {
                console.log(e);
            }
        });
    }
});