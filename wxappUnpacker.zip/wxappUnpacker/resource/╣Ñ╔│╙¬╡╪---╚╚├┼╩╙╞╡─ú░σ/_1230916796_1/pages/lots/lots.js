Page({
    web_url: "",
    data: {
        zhuan_url: null,
        title: "测试内嵌分享",
        url: "",
        web_src: ""
    },
    onLoad: function(n) {
        var o = this;
        console.log(n), console.log(n.zhuan_url);
        var e = n.zhuan_url;
        o.setData({
            zhuan_url: e
        });
        var t = getCurrentPages(), a = t[t.length - 1], l = decodeURIComponent(a.options.return_url || encodeURIComponent(e));
        this.web_url = l, this.setData({
            web_src: l
        }, function() {});
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(n) {
        console.log(n.webViewUrl);
        var o = this, e = n.webViewUrl, t = "/pages/lots/lots?shareUrl=" + e;
        return {
            title: o.data.title,
            path: t,
            success: function(n) {
                o.web_url = e, wx.showToast({
                    title: "转发成功",
                    icon: "success",
                    duration: 2e3
                });
            },
            fail: function(n) {}
        };
    },
    bindmessage: function(n) {
        console.log(n.detail.data);
    }
});