require("utils/xd_wxgame.js");

App({
    data: {},
    onLaunch: function(a) {},
    globalData: {
        app_id: "wx602982fbd2e8f85f",
        cishu: "1"
    }
});