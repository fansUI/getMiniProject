var o, e, n, t, r, l = {
    startNetwork: function(o) {
        this.network(), wx.getNetworkType({
            success: function(o) {
                console.log("返回网络类型, 有效值：", o), "none" != o.networkType && (r = !0);
            }
        }), wx.onNetworkStatusChange(function(o) {
            console.log("当前是否有网络连接", o.isConnected), console.log(o.networkType), r = o.isConnected;
        });
    },
    network: function(l) {
        console.log("开始下载");
        var c = this;
        if (e = new Date().getTime(), !r) return c.networkCallback({
            networkType: 3,
            networkContent: "没有网络，请检查网络连接"
        }), void (t = setTimeout(function() {
            c.network();
        }, 1e3));
        (o = wx.downloadFile({
            url: "下载地址",
            success: function(o) {
                (n = new Date().getTime()) - e > 200 ? (console.log("网络差"), c.networkCallback({
                    networkType: 0,
                    networkContent: "网络较差"
                })) : n - e > 100 ? (console.log("网络一般"), c.networkCallback({
                    networkType: 1,
                    networkContent: "网络一般"
                })) : (console.log("网络好"), c.networkCallback({
                    networkType: 2,
                    networkContent: "网络良好"
                })), t = setTimeout(function() {
                    c.network();
                }, 1e3);
            },
            fail: function(o) {
                console.log("网络差"), c.networkCallback({
                    networkType: 0,
                    networkContent: "网络较差"
                }), t = setTimeout(function() {
                    c.network();
                }, 1e3);
            }
        })).onProgressUpdate(function(o) {
            o.progress < 100 && (n = new Date().getTime()) - e > 200 && (console.log("网络差"), 
            c.networkCallback({
                networkType: 0,
                networkContent: "网络较差"
            }));
        });
    },
    stopNetwork: function(e) {
        console.log("关闭网络测速"), clearTimeout(t), o.abort();
    },
    networkCallback: function(o) {}
};

module.exports = l;