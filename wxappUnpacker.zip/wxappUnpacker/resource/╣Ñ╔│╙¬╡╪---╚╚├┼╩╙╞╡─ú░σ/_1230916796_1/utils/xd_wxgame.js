module.exports.xdInit = function(e, o, t) {
    console.log("this is xd_wxgamebox init 1.0.0830"), console.log(o), wx.setStorageSync("xd_isskip", 0), 
    o.scene && wx.setStorageSync("xd_game_scene", o.scene);
    try {
        var n = "", s = "";
        void 0 != o.to_wx_appid ? (n = o.to_wx_appid, s = o.to_pt) : (n = o.query.to_wx_appid, 
        s = o.query.to_pt), console.log(n), "" != n && void 0 != n && (wx.setStorageSync("xd_isskip", 1), 
        wx.navigateToMiniProgram({
            appId: n,
            path: "?pt=" + s,
            extraData: {
                pt: s
            },
            success: function(e) {}
        }));
    } catch (e) {}
    wx.request({
        url: "https://d.fire2333.com/wxbox/getBoxConfig?box_app_id=" + e,
        success: function(e) {
            console.log(e), t(e);
        }
    });
}, exports.xdLoginWithNoAuth = function(e) {
    return new Promise(function(o, t) {
        wx.login({
            success: function(o) {
                var t = getApp().globalData.app_id, n = wx.getStorageSync("xd_game_pt"), s = wx.getStorageSync("xd_game_scene"), c = wx.getStorageSync("xd_open_type"), a = wx.getStorageSync("xd_to_source"), r = getApp().globalData.from_source;
                console.log("login pt:" + n + " scene：" + s);
                var i = o.code;
                console.log("login code:" + i), console.log(c);
                var g = "https://d.fire2333.com/wxbox/index?box_app_id=" + t;
                wx.request({
                    url: g,
                    data: {
                        code: i,
                        ad: n,
                        adposition: n,
                        pt: n,
                        scene: s,
                        open_type: c,
                        from_source: r,
                        to_source: a
                    },
                    success: function(o) {
                        e(o.data), console.log(o);
                    }
                });
            }
        });
    });
}, exports.xdPreviewImage = function(e, o) {
    return new Promise(function(t, n) {
        var s = "https://d.fire2333.com/xdpt/weixinminigame/previewImage/" + e;
        wx.request({
            url: s,
            success: function(e) {
                console.log(e.data), o(e.data);
            }
        });
    });
}, exports.xdShare = function(e, o, t, n) {
    return new Promise(function(s, c) {
        wx.showShareMenu();
        var a = wx.getStorageSync("xd_game_pt");
        (a = parseInt(a)) < 1e7 && (a = 1e7 + parseInt(a));
        var r = "pt=" + a;
        n && (r = r + "&" + n), console.log("ext:" + r), wx.shareAppMessage({
            title: e,
            query: r,
            imageUrl: o,
            success: function(e) {
                console.log("转发成功" + e), t({
                    code: 0,
                    message: "share success"
                });
            },
            fail: function(e) {
                t({
                    code: -1,
                    message: "share fail"
                }), console.log("转发失败");
            },
            complete: function(e) {}
        });
    });
}, exports.xdonShare = function(e, o, t, n, s) {
    return new Promise(function(c, a) {
        wx.showShareMenu();
        var r = wx.getStorageSync("xd_game_pt");
        (r = parseInt(r)) < 1e7 && (r = 1e7 + parseInt(r));
        var i = "pt=" + r;
        n && (i = i + "&" + n), console.log("ext:" + i), wx.onShareAppMessage(function() {
            return s && s(), {
                title: e,
                query: i,
                imageUrl: o,
                success: function(e) {
                    console.log("转发成功" + e), t({
                        code: 0,
                        message: "share success"
                    });
                },
                fail: function(e) {
                    t({
                        code: -1,
                        message: "share fail"
                    }), console.log("转发失败");
                },
                complete: function(e) {}
            };
        });
    });
};