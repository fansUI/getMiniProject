module.exports = {
    safe_add: function(t, i) {
        var h = (65535 & t) + (65535 & i);
        return (t >> 16) + (i >> 16) + (h >> 16) << 16 | 65535 & h;
    },
    bit_rol: function(t, i) {
        return t << i | t >>> 32 - i;
    },
    md5_cmn: function(t, i, h, s, d, _) {
        return this.safe_add(this.bit_rol(this.safe_add(this.safe_add(i, t), this.safe_add(s, _)), d), h);
    },
    md5_ff: function(t, i, h, s, d, _, m) {
        return this.md5_cmn(i & h | ~i & s, t, i, d, _, m);
    },
    md5_gg: function(t, i, h, s, d, _, m) {
        return this.md5_cmn(i & s | h & ~s, t, i, d, _, m);
    },
    md5_hh: function(t, i, h, s, d, _, m) {
        return this.md5_cmn(i ^ h ^ s, t, i, d, _, m);
    },
    md5_ii: function(t, i, h, s, d, _, m) {
        return this.md5_cmn(h ^ (i | ~s), t, i, d, _, m);
    },
    binl_md5: function(t, i) {
        t[i >> 5] |= 128 << i % 32, t[14 + (i + 64 >>> 9 << 4)] = i;
        var h, s, d, _, m, r = 1732584193, n = -271733879, f = -1732584194, e = 271733878;
        for (h = 0; h < t.length; h += 16) s = r, d = n, _ = f, m = e, r = this.md5_ff(r, n, f, e, t[h], 7, -680876936), 
        e = this.md5_ff(e, r, n, f, t[h + 1], 12, -389564586), f = this.md5_ff(f, e, r, n, t[h + 2], 17, 606105819), 
        n = this.md5_ff(n, f, e, r, t[h + 3], 22, -1044525330), r = this.md5_ff(r, n, f, e, t[h + 4], 7, -176418897), 
        e = this.md5_ff(e, r, n, f, t[h + 5], 12, 1200080426), f = this.md5_ff(f, e, r, n, t[h + 6], 17, -1473231341), 
        n = this.md5_ff(n, f, e, r, t[h + 7], 22, -45705983), r = this.md5_ff(r, n, f, e, t[h + 8], 7, 1770035416), 
        e = this.md5_ff(e, r, n, f, t[h + 9], 12, -1958414417), f = this.md5_ff(f, e, r, n, t[h + 10], 17, -42063), 
        n = this.md5_ff(n, f, e, r, t[h + 11], 22, -1990404162), r = this.md5_ff(r, n, f, e, t[h + 12], 7, 1804603682), 
        e = this.md5_ff(e, r, n, f, t[h + 13], 12, -40341101), f = this.md5_ff(f, e, r, n, t[h + 14], 17, -1502002290), 
        n = this.md5_ff(n, f, e, r, t[h + 15], 22, 1236535329), r = this.md5_gg(r, n, f, e, t[h + 1], 5, -165796510), 
        e = this.md5_gg(e, r, n, f, t[h + 6], 9, -1069501632), f = this.md5_gg(f, e, r, n, t[h + 11], 14, 643717713), 
        n = this.md5_gg(n, f, e, r, t[h], 20, -373897302), r = this.md5_gg(r, n, f, e, t[h + 5], 5, -701558691), 
        e = this.md5_gg(e, r, n, f, t[h + 10], 9, 38016083), f = this.md5_gg(f, e, r, n, t[h + 15], 14, -660478335), 
        n = this.md5_gg(n, f, e, r, t[h + 4], 20, -405537848), r = this.md5_gg(r, n, f, e, t[h + 9], 5, 568446438), 
        e = this.md5_gg(e, r, n, f, t[h + 14], 9, -1019803690), f = this.md5_gg(f, e, r, n, t[h + 3], 14, -187363961), 
        n = this.md5_gg(n, f, e, r, t[h + 8], 20, 1163531501), r = this.md5_gg(r, n, f, e, t[h + 13], 5, -1444681467), 
        e = this.md5_gg(e, r, n, f, t[h + 2], 9, -51403784), f = this.md5_gg(f, e, r, n, t[h + 7], 14, 1735328473), 
        n = this.md5_gg(n, f, e, r, t[h + 12], 20, -1926607734), r = this.md5_hh(r, n, f, e, t[h + 5], 4, -378558), 
        e = this.md5_hh(e, r, n, f, t[h + 8], 11, -2022574463), f = this.md5_hh(f, e, r, n, t[h + 11], 16, 1839030562), 
        n = this.md5_hh(n, f, e, r, t[h + 14], 23, -35309556), r = this.md5_hh(r, n, f, e, t[h + 1], 4, -1530992060), 
        e = this.md5_hh(e, r, n, f, t[h + 4], 11, 1272893353), f = this.md5_hh(f, e, r, n, t[h + 7], 16, -155497632), 
        n = this.md5_hh(n, f, e, r, t[h + 10], 23, -1094730640), r = this.md5_hh(r, n, f, e, t[h + 13], 4, 681279174), 
        e = this.md5_hh(e, r, n, f, t[h], 11, -358537222), f = this.md5_hh(f, e, r, n, t[h + 3], 16, -722521979), 
        n = this.md5_hh(n, f, e, r, t[h + 6], 23, 76029189), r = this.md5_hh(r, n, f, e, t[h + 9], 4, -640364487), 
        e = this.md5_hh(e, r, n, f, t[h + 12], 11, -421815835), f = this.md5_hh(f, e, r, n, t[h + 15], 16, 530742520), 
        n = this.md5_hh(n, f, e, r, t[h + 2], 23, -995338651), r = this.md5_ii(r, n, f, e, t[h], 6, -198630844), 
        e = this.md5_ii(e, r, n, f, t[h + 7], 10, 1126891415), f = this.md5_ii(f, e, r, n, t[h + 14], 15, -1416354905), 
        n = this.md5_ii(n, f, e, r, t[h + 5], 21, -57434055), r = this.md5_ii(r, n, f, e, t[h + 12], 6, 1700485571), 
        e = this.md5_ii(e, r, n, f, t[h + 3], 10, -1894986606), f = this.md5_ii(f, e, r, n, t[h + 10], 15, -1051523), 
        n = this.md5_ii(n, f, e, r, t[h + 1], 21, -2054922799), r = this.md5_ii(r, n, f, e, t[h + 8], 6, 1873313359), 
        e = this.md5_ii(e, r, n, f, t[h + 15], 10, -30611744), f = this.md5_ii(f, e, r, n, t[h + 6], 15, -1560198380), 
        n = this.md5_ii(n, f, e, r, t[h + 13], 21, 1309151649), r = this.md5_ii(r, n, f, e, t[h + 4], 6, -145523070), 
        e = this.md5_ii(e, r, n, f, t[h + 11], 10, -1120210379), f = this.md5_ii(f, e, r, n, t[h + 2], 15, 718787259), 
        n = this.md5_ii(n, f, e, r, t[h + 9], 21, -343485551), r = this.safe_add(r, s), 
        n = this.safe_add(n, d), f = this.safe_add(f, _), e = this.safe_add(e, m);
        return [ r, n, f, e ];
    },
    binl2rstr: function(t) {
        var i, h = "";
        for (i = 0; i < 32 * t.length; i += 8) h += String.fromCharCode(t[i >> 5] >>> i % 32 & 255);
        return h;
    },
    rstr2binl: function(t) {
        var i, h = [];
        for (h[(t.length >> 2) - 1] = void 0, i = 0; i < h.length; i += 1) h[i] = 0;
        for (i = 0; i < 8 * t.length; i += 8) h[i >> 5] |= (255 & t.charCodeAt(i / 8)) << i % 32;
        return h;
    },
    rstr_md5: function(t) {
        return this.binl2rstr(this.binl_md5(this.rstr2binl(t), 8 * t.length));
    },
    rstr_hmac_md5: function(t, i) {
        var h, s, d = this.rstr2binl(t), _ = [], m = [];
        for (_[15] = m[15] = void 0, d.length > 16 && (d = this.binl_md5(d, 8 * t.length)), 
        h = 0; h < 16; h += 1) _[h] = 909522486 ^ d[h], m[h] = 1549556828 ^ d[h];
        return s = this.binl_md5(_.concat(this.rstr2binl(i)), 512 + 8 * i.length), this.binl2rstr(this.binl_md5(m.concat(s), 640));
    },
    rstr2hex: function(t) {
        var i, h, s = "";
        for (h = 0; h < t.length; h += 1) i = t.charCodeAt(h), s += "0123456789abcdef".charAt(i >>> 4 & 15) + "0123456789abcdef".charAt(15 & i);
        return s;
    },
    str2rstr_utf8: function(t) {
        return unescape(encodeURIComponent(t));
    },
    raw_md5: function(t) {
        return this.rstr_md5(this.str2rstr_utf8(t));
    },
    hex_md5: function(t) {
        return this.rstr2hex(this.raw_md5(t));
    },
    raw_hmac_md5: function(t, i) {
        return this.rstr_hmac_md5(this.str2rstr_utf8(t), this.str2rstr_utf8(i));
    },
    hex_hmac_md5: function(t, i) {
        return this.rstr2hex(this.raw_hmac_md5(t, i));
    },
    md5: function(t, i, h) {
        return i ? h ? this.raw_hmac_md5(i, t) : this.hex_hmac_md5(i, t) : h ? this.raw_md5(t) : this.hex_md5(t);
    }
};