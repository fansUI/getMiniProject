var o = null, e = function() {
    console.log("webSocket--\x3e连接成功");
}, n = function(o) {
    var e = o.data;
    console.log("webSocket--\x3eonMessage::" + e);
}, c = function() {
    console.log("webSocket--\x3eonClose::");
};

module.exports = {
    connectSocket: function(t) {
        o && o.close(), (o = wx.connectSocket(t)).onOpen(e), o.onMessage(n), o.onClose(c);
    },
    send: function(e) {
        o && o.send({
            data: e
        });
    }
};