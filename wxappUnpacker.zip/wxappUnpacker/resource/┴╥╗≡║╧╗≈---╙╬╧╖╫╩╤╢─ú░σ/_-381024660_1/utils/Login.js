var o = getApp(), n = require("BmHttp.js");

module.exports = {
    test: function() {
        console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~" + o.globalData.code);
    },
    _cb: null,
    wxLogin: function(n, e) {
        console.log(n);
        var t = this;
        this._cb = n, wx.login({
            success: function(n) {
                if (console.log("xxxxxxxxx" + n.code), n.code) {
                    o.globalData.code = n.code;
                    var e = wx.getSystemInfoSync() || "";
                    o.globalData.wxSystemInfo = e, o.globalData.launchOptions = wx.getLaunchOptionsSync(), 
                    t.login(), console.log(n.code);
                } else console.log("登录失败！" + n.errMsg);
            },
            fail: function(o) {
                console.log("登录失败！" + o.errMsg);
            }
        });
    },
    login: function() {
        var o = this;
        o.getUserInfo(function() {
            o.sendLogin();
        });
    },
    sendLogin: function() {
        var e = {
            weixinData: o.globalData,
            boxid: o.boxid
        }, t = this;
        n.login(e, function(n) {
            o.openid = n.openid, n.share && "" != n.share && (o.shareInfo = n.share), console.log("openid::::" + o.openid), 
            t._cb && t._cb(n);
        }, function(o) {
            t._cb && t._cb(o);
        });
    },
    isAuthUserInfo: function(o) {
        wx.getSetting({
            success: function(n) {
                console.log("scope.userInfo" + n.authSetting["scope.userInfo"]), o(n.authSetting["scope.userInfo"] ? 1 : 0);
            }
        });
    },
    getUserInfo: function(o) {
        var n = this;
        wx.getUserInfo({
            withCredentials: !0,
            success: function(e) {
                console.log(JSON.stringify(e));
                var t = e.userInfo;
                console.log(t), t ? (n.getUserInfoSucc(e), o && o(1)) : o && o(0);
            },
            fail: function(n) {
                o && o(0);
            }
        });
    },
    getUserInfoSucc: function(n) {
        o.globalData.rawData = n.rawData || "", o.globalData.userInfo = n.userInfo || {}, 
        o.globalData.signature = n.signature || "", o.globalData.encryptedData = encodeURIComponent(n.encryptedData) || "", 
        o.globalData.iv = encodeURIComponent(n.iv) || "";
    }
};