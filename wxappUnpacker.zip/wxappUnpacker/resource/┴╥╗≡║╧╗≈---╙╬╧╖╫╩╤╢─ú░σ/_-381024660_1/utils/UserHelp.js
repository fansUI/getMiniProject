var o = [], e = [ {
    name: "青铜",
    color: "#B79729"
}, {
    name: "黄金",
    color: "#B79729"
}, {
    name: "铂金",
    color: "#B79729"
}, {
    name: "钻石",
    color: "#B79729"
}, {
    name: "星耀",
    color: "#B79729"
} ];

module.exports = {
    getDataDw: function(a) {
        for (var n = 0; n < e.length; n++) a.name == e.name[n] && o.push(e[n]);
    }
};