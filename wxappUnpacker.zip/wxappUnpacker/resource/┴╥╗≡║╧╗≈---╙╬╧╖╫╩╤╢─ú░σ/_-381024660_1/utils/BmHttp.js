var o = getApp(), e = function(e, t, n, a, s) {
    void 0 != n && null != n || (n = {}), n.vs = o.vs, o.openid && (n.openid = o.openid);
    var i = {};
    i[t] = n;
    var c = JSON.stringify(i);
    console.log("body::" + c), c = encodeURIComponent(c);
    var l = e;
    console.log("pUrl::" + l), wx.request({
        data: c,
        method: "POST",
        url: l,
        success: function(o) {
            if (200 == o.statusCode) {
                var e = o.data;
                console.log("request com data::::" + JSON.stringify(e)), 1 == e.code ? a && a(e) : s && s(e);
            } else s && console.log("连接失败：：：：");
        }
    });
};

module.exports = {
    login: function(o, t, n) {
        new e("https://api-h5.7me.com/webchat/login", "param", o, t, n);
    },
    pay: function(o, t, n, a) {
        new e("https://api-xcx.7mwan.com/pay/values/" + o, "order", t, n, a);
    },
    getDetails: function(o, t, n) {
        new e("https://api-h5.7me.com/webchat/detail", "param", {
            id: o
        }, t, n);
    }
};