var t = getApp().globalData.Http;

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        isIphoneX: {
            type: Boolean,
            value: !1
        },
        scene: {
            type: Boolean,
            value: 1
        },
        gameTitle: {
            type: String,
            value: "神手游戏"
        }
    },
    data: {
        title: "神手游戏"
    },
    methods: {
        backPage: function(e) {
            t.navigateback(e);
        },
        updateData: function(t) {
            this.setData({
                title: t
            });
        },
        getformid: function(e) {
            var a = e.detail.formId, o = e.currentTarget.dataset.type;
            console.log(a);
            var i = {
                uid: wx.getStorageSync("uid"),
                formId: a,
                type: o
            };
            t.request("formidadd", i);
        },
        _navigateBack: function(t) {
            this.triggerEvent("confirmEvent");
        }
    }
});