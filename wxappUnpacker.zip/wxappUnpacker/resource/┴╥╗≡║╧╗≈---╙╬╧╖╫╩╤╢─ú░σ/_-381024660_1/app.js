function a(a, e, t) {
    return e in a ? Object.defineProperty(a, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[e] = t, a;
}

var e;

App((e = {
    onLaunch: function(a) {
        console.log("[onLaunch] 场景值:", a.scene);
        var e = wx.getStorageSync("logs") || [];
        e.unshift(Date.now()), wx.setStorageSync("logs", e);
    },
    globalData: {
        code: "",
        wxSystemInfo: "",
        rawData: "",
        userInfo: {},
        signature: "",
        encryptedData: "",
        iv: "",
        query: "",
        scene: ""
    },
    boxid: 15,
    info: "",
    pageData: {},
    fighTrank: {},
    myinFo: {},
    myData: {},
    navigateData: {},
    shareInfo: {},
    ranking: {},
    appName: "",
    payData: null,
    payExtraData: null,
    openid: [],
    jumpData: null,
    paySuccessUrl: "",
    contentId: "",
    onShow: function(a) {
        if (console.log(JSON.stringify(a)), a && a.query) {
            var e = this.copyMap(a.query);
            if (this.globalData.query = e, e.qrUrl && "" != e.qrUrl) return void wx.navigateBack({
                delta: 1
            });
        }
        a.referrerInfo.appId;
        var t = a.referrerInfo.extraData;
        t && t.gameId && (this.payExtraData = t), t && t.jumpData && (this.jumpData = t.jumpData);
    },
    getJumpData: function() {
        return {
            appId: "wx79ade44c39cefc7f",
            gameName: "传奇来了",
            gameIcon: "https://static-product.7me.com/uploads/box/20180917/20180917134447.gif",
            extraData: {
                ddd: 1
            }
        };
    },
    getPayExtraData: function() {
        var a = {};
        return a.outorderno = "tdsfds5656213fdd", a.roleId = "10111", a.gameId = "1", a.serverId = 1, 
        a.money = .01, a.gold = 1e3, a.goldsName = "元宝", a.gameName = "八秒对战", a.areaName = "微信1服", 
        a.roleName = "胡鹏", a.gameKey = "5b674670792fd96c", a;
    },
    copyMap: function(a) {
        var e = "";
        for (var t in a) "" == e && (e = {}), e[t] = a[t];
        return e;
    },
    iden: 1,
    vs: "104",
    iden1: "",
    url: "https://api-xcx.7me.com/Landing/Values/LandPage",
    url1: "https://api-xcx.7me.com/Landing/Values/Detail"
}, a(e, "globalData", {
    userInfo: null
}), a(e, "openId", null), a(e, "appId", ""), a(e, "flName", ""), a(e, "extraData", ""), 
a(e, "gameName", ""), a(e, "path", ""), a(e, "pushWxNew", function(a, e) {
    console.log("type::::::" + e), wx.request({
        url: "https://api-xcx.7me.com/Landing/Values/MessagePush",
        data: JSON.stringify({
            type: e,
            iden: this.iden,
            openid: this.openId,
            form_id: a,
            vs: this.vs
        }),
        method: "POST"
    });
}), e));