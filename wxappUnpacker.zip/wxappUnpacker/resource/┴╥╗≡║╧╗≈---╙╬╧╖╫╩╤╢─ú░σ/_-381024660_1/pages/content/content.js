var t = getApp();

Page({
    data: {
        fhicon: "<"
    },
    onLoad: function(a) {
        this.send(a), wx.setNavigationBarTitle({
            title: t.gameName
        });
    },
    onReady: function() {},
    onShow: function() {
        console.log(t.url1);
    },
    send: function(a) {
        var e = this;
        wx.request({
            url: t.url1,
            data: JSON.stringify({
                param: {
                    id: a.id
                }
            }),
            method: "POST",
            success: function(t) {
                if (200 == t.statusCode) {
                    var a = require("../../wxParse/wxParse.js"), n = t.data;
                    a.wxParse("dkcontent", "html", n.data, e, 5);
                }
            },
            fail: function() {}
        });
    }
});