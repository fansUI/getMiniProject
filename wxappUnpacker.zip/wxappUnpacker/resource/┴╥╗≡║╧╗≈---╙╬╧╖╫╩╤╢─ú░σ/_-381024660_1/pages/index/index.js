function e(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

require("../../utils/Binding.js");

var t, n = require("../../utils/Login.js"), i = (require("../../utils/BmHttp.js"), 
getApp()), a = "0", s = "", o = [ "+", "-", "*", "/" ], r = !1;

Page((t = {
    data: {
        hasSelect: "../../assets/images/like2.png",
        noSelect: "../../assets/images/like.png",
        selectIndex: [],
        introduce: [],
        isxs: "none"
    },
    onLoad: function() {
        this.setData({
            info: "1"
        }), n.wxLogin(this._loginSuc.bind(this));
    },
    authUserInfo: function() {
        var e = this;
        n.isAuthUserInfo(function(t) {
            console.log(t), 1 == t ? (e.setData({
                info: "none"
            }), n.wxLogin(e._loginSuc.bind(this))) : e.setData({
                info: ""
            });
        });
    },
    toDetailPage: function() {
        wx.redirectTo({
            url: "../detail/detail"
        });
    },
    _loginSuc: function(e) {
        if (e.url && "" != e.url) console.log("url::::::" + e.url), wx.redirectTo({
            url: "../webView/webview?url=" + e.url + "&gameName=" + e.gamename
        }); else {
            var t = e.type;
            if (this.setData({
                type: t
            }), 2 == t) {
                var n = this;
                console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~11111111111"), wx.login({
                    success: function(e) {
                        e.code && n.send(e.code);
                    }
                });
            }
        }
    },
    send: function(e) {
        var t = this;
        wx.request({
            url: i.url,
            data: JSON.stringify({
                iden: i.iden,
                vs: i.vs,
                code: e
            }),
            method: "POST",
            success: function(e) {
                if (200 == e.statusCode) {
                    t.share = e.share;
                    var n = e.data;
                    i.openId = n.openid;
                    var a = JSON.stringify(n);
                    console.log("data::" + a), "1" == n.status && (n && (n.adimg = n.adimg), t.setData({
                        result: n
                    }), i.gameName = n.gameName, wx.setNavigationBarTitle({
                        title: n.gameName || "老司机带你玩回合制游戏"
                    }));
                }
            },
            fail: function() {}
        });
    },
    getUserInfo: function(e) {
        this.authUserInfo();
    },
    nrClick: function(e) {
        var t = e.target.dataset.index;
        i.contentId = this.data.introduce[t].id, console.log("点击第：" + this.data.introduce[t].id), 
        wx.navigateTo({
            url: "../content/content?user_id=1"
        });
    },
    selectRep: function(e) {
        var t = e.currentTarget.dataset.selectindex, n = this.data.selectIndex;
        console.log(n), n[t].sureid = !n[t].sureid, this.setData({
            selectIndex: n
        });
    },
    countClick: function(e) {
        var t = e.target.id;
        if ("" != s && "0" != a || (a = ""), console.log(t), t > -1 && t < 10) r && (a = ""), 
        a += "" + t, this.setData({
            result: a
        }); else {
            if ("AC" == t) return a = "0", s = "", void this.setData({
                result: a
            });
            if ("=" == t && -1 == o.indexOf(s) && "" != a) return a = wx.binding.eval(a), this.setData({
                result: a
            }), void (r = !0);
            "" != a && -1 == o.indexOf(s) && (a += t, this.setData({
                result: a
            }));
        }
        s = t, r = !1;
    },
    onShareAppMessage: function() {},
    djfz1: function() {
        wx.setClipboardData({
            data: "1517013943",
            success: function() {
                console.log("1517013943");
            }
        });
    },
    djfz2: function() {
        wx.setClipboardData({
            data: "1944938487",
            success: function() {
                console.log("1944938487");
            }
        });
    }
}, e(t, "nrClick", function(e) {
    var t = e.currentTarget.dataset.cid;
    console.log("id::::" + t), wx.navigateTo({
        url: "../content/content?id=" + t
    });
}), e(t, "formId", null), e(t, "formSubmit", function(e) {
    var t = e.detail.formId;
    console.log("formId::::" + t), i.pushWxNew(t, 0);
}), t));