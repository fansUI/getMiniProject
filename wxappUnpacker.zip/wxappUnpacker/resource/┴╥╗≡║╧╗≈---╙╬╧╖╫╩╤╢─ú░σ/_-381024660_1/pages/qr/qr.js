Page({
    data: {},
    onLoad: function(n) {
        console.log("qr_onLoad::" + JSON.stringify(n)), n.qrUrl && "" != n.qrUrl && setTimeout(function() {
            wx.previewImage({
                urls: [ n.qrUrl ]
            });
        }, 500);
    },
    onReady: function() {},
    onShow: function(n) {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});