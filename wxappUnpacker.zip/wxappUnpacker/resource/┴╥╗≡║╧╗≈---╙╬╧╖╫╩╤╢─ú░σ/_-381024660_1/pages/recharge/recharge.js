var a = getApp(), e = require("../../utils/BmHttp.js"), t = require("../../utils/md5.js"), o = require("../../utils/Login.js"), n = "", i = !1, r = !1, s = "";

Page({
    data: {},
    clickPay: function() {
        if (a.openid && "" != a.openid && a.payExtraData && !this.isDoOrder) {
            if (!r) return;
            if (a.payExtraData.contact) return;
            this.doOrder(a.payExtraData);
        }
        n.indexOf("qm_") > -1 && !this.isDoOrder && this.doQrQrder();
    },
    onLoad: function(e) {
        i = !1, e.scene ? n = decodeURIComponent(e.scene) : e.payData && (i = !0, console.log("h5paydata::" + decodeURIComponent(e.payData)), 
        a.payExtraData = JSON.parse(decodeURIComponent(e.payData)));
        var t = n.indexOf("qm_") > -1;
        a.payExtraData || t ? i ? (a.payExtraData.contact ? (a.payExtraData.showMessageCard = !0, 
        a.payExtraData.sendMessagePath = "/pages/index/index", a.payExtraData.sendMessageImg = "https://static-product.7me.com/wxgame/contactPay.png") : this.authUserInfo(), 
        this.setData(a.payExtraData)) : (wx.showLoading({
            title: "加载中"
        }), o.wxLogin(this._loginSuc.bind(this))) : this.clickHome();
    },
    authUserInfo: function() {
        var a = this;
        r = !0, wx.showLoading({
            title: "加载中"
        }), o.wxLogin(a._loginSuc.bind(a), !1);
    },
    getUserInfo: function(a) {
        this.authUserInfo();
    },
    _loginSuc: function() {
        a.payExtraData ? (this.setData(a.payExtraData), this.doOrder(a.payExtraData)) : n.indexOf("qm_") > -1 && this.doQrQrder();
    },
    clickHome: function() {
        wx.redirectTo({
            url: "../index/index"
        });
    },
    doQrQrder: function() {
        this.isDoOrder = !0;
        var a = this;
        e.pay("wxorder", {
            orderID: n
        }, function(e) {
            wx.setNavigationBarTitle({
                title: "支付中心"
            }), console.log("order::::" + JSON.stringify(e)), wx.hideLoading(), a.isDoOrder = !1, 
            a.setData(e);
            var t = {};
            t.timeStamp = e.timeStamp, t.nonceStr = e.nonceStr, t.package = e.package, t.signType = e.signType, 
            t.paySign = e.paySign, a.pay(t);
        }, function(e) {
            wx.hideLoading(), "-103" != e.code ? (a.isDoOrder = !1, console.log("order::fail::" + JSON.stringify(e)), 
            wx.showModal({
                title: "提示",
                content: e.msg + ":" + e.code,
                showCancel: !1,
                success: function(t) {
                    t.confirm ? (console.log("用户点击确定"), a.navigateBackMiniProgram(e)) : console.log("用户点击取消");
                }
            })) : a.clickHome();
        });
    },
    doOrder: function(o) {
        this.isDoOrder = !0;
        var n = o.gameId + "", i = o.roleId;
        o.gameKey && (s = o.gameKey, delete o.gameKey);
        var r = o.serverId, c = o.gold + "", d = o.outorderno, g = o.money, p = o.ramek || "", u = a.openid, l = n + c + g + d + u + p + i + r + s, f = t.md5(l);
        o.sign = f.toUpperCase(), o.openid = u;
        var y = this;
        e.pay("order", o, function(a) {
            wx.setNavigationBarTitle({
                title: "支付中心"
            }), console.log("order::::" + JSON.stringify(a)), wx.hideLoading(), y.isDoOrder = !1;
            var e = {};
            e.timeStamp = a.timeStamp, e.nonceStr = a.nonceStr, e.package = a.package, e.signType = a.signType, 
            e.paySign = a.paySign, y.pay(e);
        }, function(a) {
            wx.hideLoading(), "-103" != a.code ? (y.isDoOrder = !1, console.log("order::fail::" + JSON.stringify(a)), 
            wx.showModal({
                title: "提示",
                content: a.msg + ":" + a.code,
                showCancel: !1,
                success: function(e) {
                    e.confirm ? (console.log("用户点击确定"), y.navigateBackMiniProgram(a)) : console.log("用户点击取消");
                }
            })) : y.clickHome();
        });
    },
    paySuccess: function() {
        a.payExtraData = null;
        var e = this;
        wx.showToast({
            title: "支付成功",
            icon: "success",
            duration: 1e3
        }), setTimeout(function() {
            e.navigateBackMiniProgram({
                code: 1,
                msg: "success"
            });
        }, 1e3);
    },
    navigateBackMiniProgram: function(a) {
        i ? wx.navigateBack(a) : wx.navigateBackMiniProgram({
            extraData: a
        });
    },
    pay: function(a) {
        var e = this;
        a.success = function() {
            e.paySuccess();
        }, a.fail = function(a) {
            console.log("pay:fail:::" + JSON.stringify(a));
        }, wx.requestPayment(a);
    },
    buttonFh: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});