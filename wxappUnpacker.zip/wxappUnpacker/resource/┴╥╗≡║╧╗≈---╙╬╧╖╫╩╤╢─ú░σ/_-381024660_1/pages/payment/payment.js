Page({
    data: {},
    onLoad: function(a) {
        // if (a.payData) {
        if (1) {
            var t = JSON.parse(decodeURIComponent(a.payData));
            t.showMessageCard = !0, t.sendMessagePath = "/pages/index/index", t.sendMessageImg = "https://static-product.7me.com/wxgame/contactPay.png", 
            this.setData(t);
        } else this.clickFh();
    },
    onReady: function() {},
    onShow: function() {},
    clickFh: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    buttonFh: function() {
        wx.navigateBack({
            delta: 1
        });
    }
});