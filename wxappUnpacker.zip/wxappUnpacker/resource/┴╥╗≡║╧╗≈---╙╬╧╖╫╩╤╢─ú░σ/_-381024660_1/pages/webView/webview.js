var e = getApp();

Page({
    data: {},
    onLoad: function(e) {
        var n = decodeURIComponent(e.url), o = e.gameName;
        console.log(n), console.log(o), this.setData({
            gpageUrl: n,
            title: ""
        });
    },
    onReady: function() {},
    onShow: function() {
        getApp().paySuccessUrl;
        getApp().paySuccessUrl = "";
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        if (e.shareInfo) {
            var n = {};
            n.title = e.shareInfo.title, n.desc = e.shareInfo.desc, e.shareInfo.img && "" != e.shareInfo.img && (n.imageUrl = e.shareInfo.img);
            var o = this.toU(e.shareInfo);
            return n.path = "pages/index/index", o && "" != o && (n.path += "?" + o), n;
        }
        return {
            title: e.appName,
            desc: e.appName,
            path: "pages/index/index"
        };
    },
    toU: function(e) {
        var n = "";
        for (var o in e) {
            var a = o + "=" + e[o];
            n += "" == n ? a : "&" + a;
        }
        return n;
    }
});