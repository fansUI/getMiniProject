var e = require("../utils/util.js"), t = require("../config/api.js"), a = getApp();

Page({
    data: {
        show_loading: !1
    },
    onLoad: function(i) {
        var s = this, n = "", o = !1;
        setTimeout(function() {
            o || s.setData({
                show_loading: !0
            });
        }, 1e3), e.request(t.get_version_status).then(function(e) {
            o = !0, s.setData({
                show_loading: !1
            });
            var t = a.globalData.scene;
            n = 1 == e.status && 1006 == t ? "/pages/index/index" : "/pages/review/review", 
            wx.redirectTo({
                url: n
            });
        });
    },
    onShow: function() {}
});