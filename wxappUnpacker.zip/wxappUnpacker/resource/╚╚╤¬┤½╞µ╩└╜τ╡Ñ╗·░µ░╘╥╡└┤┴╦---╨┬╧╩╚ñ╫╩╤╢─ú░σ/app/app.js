require("/utils/util.js"), require("/config/api.js"), require("./utils/ald-stat.js");

App({
    onLaunch: function(e) {
        this.globalData.inviter_id = e.query.inviter_id ? e.query.inviter_id : 0, this.globalData.scene = e.scene;
        var t = wx.getUpdateManager();
        t.onUpdateReady(function() {
            t.applyUpdate();
        });
    },
    onPageNotFound: function(e) {
        wx.redirectTo({
            url: "/entry/entry"
        });
    },
    onShow: function(e) {
        var t = e.shareTicket;
        t && (this.globalData.shareTicket = t);
    },
    globalData: {}
});