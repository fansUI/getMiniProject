module.exports = {
    xcx_id: 2,
    version: "0.0.1"
};