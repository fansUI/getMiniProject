var a = require("../../utils/util.js"), t = require("../../config/api.js");

Page({
    data: {
        all_data: {}
    },
    onLoad: function(e) {
        var i = this;
        wx.setNavigationBarTitle({
            title: ""
        }), a.request(t.get_all_data).then(function(a) {
            i.setData({
                all_data: a.all_data
            });
        });
    },
    onShareAppMessage: function(a) {
        return {
            title: "好玩的小程序都在这里了，快来试试吧~",
            imageUrl: "/res/img/share.jpg",
            path: "/entry/entry"
        };
    }
});