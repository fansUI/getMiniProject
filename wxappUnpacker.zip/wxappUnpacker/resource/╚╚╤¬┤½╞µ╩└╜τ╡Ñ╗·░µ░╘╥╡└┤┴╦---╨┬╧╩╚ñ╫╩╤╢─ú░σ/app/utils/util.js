function n(r) {
    var u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, c = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET";
    return new Promise(function(a, s) {
        wx.request({
            url: r,
            data: u,
            method: c,
            header: {
                "Content-Type": "application/json",
                Token: wx.getStorageSync("token"),
                "XCX-ID": i.xcx_id,
                "XCX-VERSION": i.version
            },
            success: function(i) {
                if (200 == i.statusCode) {
                    if (401 == i.data.code) {
                        var f = null;
                        return e().then(function(n) {
                            return f = n.code, t();
                        }).then(function(e) {
                            var t = getApp();
                            n(o.login_url, {
                                code: f,
                                user_info: e,
                                inviter_id: t.globalData.inviter_id
                            }, "GET").then(function(e) {
                                0 === e.code ? (wx.setStorageSync("user_info", e.data.user_info), wx.setStorageSync("token", e.data.token), 
                                n(r, u, c).then(function(n) {
                                    0 === n.code ? a(n) : s(n);
                                })) : s(e);
                            }).catch(function(n) {
                                s(n);
                            });
                        }).catch(function(n) {
                            s(n);
                        });
                    }
                    a(i.data);
                } else s(i.errMsg);
            },
            fail: function(n) {
                s(n);
            }
        });
    });
}

function e() {
    return new Promise(function(n, e) {
        wx.login({
            success: function(t) {
                t.code ? n(t) : e(t);
            },
            fail: function(n) {
                e(n);
            }
        });
    });
}

function t() {
    return new Promise(function(n, e) {
        wx.getUserInfo({
            withCredentials: !0,
            success: function(e) {
                n(e);
            },
            fail: function(n) {
                var t = getCurrentPageUrlWithArgs();
                setTimeout(function() {
                    var n = "";
                    switch (wx.getStorageSync("xcx_info").code_type) {
                      case 1:
                        n = "/pages/v1/login/login";
                        break;

                      case 2:
                        n = "/pages/v2/login/login";
                        break;

                      default:
                        n = "/pages/v1/login/login";
                    }
                    wx.redirectTo({
                        url: n + "?callback_url=" + encodeURIComponent(t)
                    });
                }, 2e3), e(n);
            }
        });
    });
}

var o = require("../config/api.js"), i = require("../common.js");

module.exports = {
    request: n,
    login: e,
    getAuthSetting: function() {
        return new Promise(function(n, e) {
            wx.getSetting({
                complete: function(t) {
                    t.authSetting && t.authSetting["scope.userInfo"] ? n(!0) : e(!1);
                }
            });
        });
    },
    getUserInfo: t,
    empty: function(n) {
        return void 0 === n || "undefined" == n || null == n || "" == n;
    },
    get_json_length: function(n) {
        var e = 0;
        for (var t in n) e++;
        return e;
    },
    parse_scene: function(n) {
        for (var e = n.split("&"), t = [], o = 0; o < e.length; o++) {
            var i = e[o].split("=");
            t[i[0]] = i[1];
        }
        return t;
    },
    get_random_array_value: function(n) {
        return n[Math.floor(Math.random() * n.length + 1) - 1];
    }
};