var t = "https://s.h5cun.com";

module.exports = {
    get_all_data: t + "/cq2/get_all_data.php",
    get_version_status: t + "/cq2/get_version_status.php"
};