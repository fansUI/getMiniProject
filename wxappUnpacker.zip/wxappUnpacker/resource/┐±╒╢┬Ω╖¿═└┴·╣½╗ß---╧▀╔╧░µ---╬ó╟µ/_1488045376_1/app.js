var e = require("we7/resource/js/util.js"), a = require("rand/resource/js/groupUrl.js");

require("rand/pages/logic/wxb-sdk-1.0.0.js"), require("rand/pages/logic/logic.js"), 
require("/rand/utils/bmob.js");

App({
    globalData: {
        userInfo: null,
        userData: null,
        luckTimes: 0,
        is_complete_new_user_task: 1,
        scene: 0,
        share_title: "",
        share_path: "",
        share_imageUrl: "",
        encryptedData: "",
        iv: "",
        tg_id: 0,
        platform: "",
        is_need_auth: 0,
        openid: "",
        appid: "",
        is_show_mask: 1
    },
    onLaunch: function(e) {},
    onShow: function(e) {
        var a = this;
        if (wx.getSystemInfo({
            success: function(e) {
                a.globalData.platform = e.platform;
            }
        }), 1023 == e.scene && "android" == a.globalData.platform && (a.globalData.scene = e.scene), 
        1089 != e.scene && 1001 != e.scene || (a.globalData.scene = e.scene), e.shareTicket) {
            var s = e.shareTicket;
            wx.getShareInfo({
                shareTicket: s,
                success: function(e) {
                    a.globalData.iv = e.iv, a.globalData.encryptedData = e.encryptedData;
                }
            });
        }
        console.log(e), e.query && e.query.tg_id && (a.globalData.tg_id = e.query.tg_id);
    },
    onHide: function() {
        var e = this;
        console.log("app OnHide", e.globalData.is_need_auth, e.globalData.appid, e.globalData.openid), 
        e.globalData.is_need_auth;
    },
    onError: function(e) {
        console.log(e);
    },
    util: e,
    userInfo: {
        sessionid: null
    },
    saveJumpRecord: function(e) {
        this.util.request({
            url: a.saveJumpMinpUrl,
            data: {
                appid: e
            },
            method: "post",
            success: function(e) {
                console.log("show save data", e);
            }
        });
    },
    seturldata: function(e) {
        this.urldata = e;
    },
    siteInfo: require("siteinfo.js")
});