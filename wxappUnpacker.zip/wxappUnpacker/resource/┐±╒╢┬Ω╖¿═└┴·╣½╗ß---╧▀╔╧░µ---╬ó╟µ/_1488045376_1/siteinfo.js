var i = {
    uniacid: "637",
    acid: "637",
    multiid: "0",
    version: "1.7",
    siteroot: "https://hz.j6yx.com/app/index.php",
    design_method: "3",
    modul: "qy_gamebox"
};

module.exports = i;