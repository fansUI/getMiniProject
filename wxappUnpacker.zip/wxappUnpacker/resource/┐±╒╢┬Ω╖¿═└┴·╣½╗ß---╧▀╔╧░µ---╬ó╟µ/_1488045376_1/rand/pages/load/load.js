var a = getApp();

Page({
    data: {},
    onLoad: function(s) {
        a.util.request({
            url: "entry/wxapp/getSystemConf",
            method: "post",
            success: function(s) {
                console.log(s), 0 == s.data.errno ? (a.globalData.is_need_auth = s.data.data.is_need_auth, 
                a.globalData.is_show_mask = s.data.data.is_show_mask, console.log(s.data.data.is_show_mask), 
                0 == s.data.data.is_show_mask ? wx.reLaunch({
                    url: "/rand/pages/index/index"
                }) : wx.redirectTo({
                    url: "/rand/pages/mask/mask"
                })) : wx.redirectTo({
                    url: "/rand/pages/mask/mask"
                });
            }
        });
    }
});