var a = getApp(), t = require("../../resource/js/groupUrl.js"), e = require("../logic/logic.js");

require("../logic/wxb-sdk-1.0.0.js");

Page({
    data: {
        userInfo: null,
        hasUserInfo: !1,
        classData: [],
        classId: null,
        page: 1,
        isLoadingEnd: !1,
        userData: {
            gold: 0,
            money: 0
        },
        class_id: 0,
        style: "",
        h5_cur_mid: 0,
        is_need_auth: 1
    },
    onLoad: function(t) {
        var s = this, r = t.class_id, o = t.style;
        s.setData({
            class_id: r,
            style: o,
            is_need_auth: a.globalData.is_need_auth
        }), e.dologin(a, function(e) {
            s.getClassData(o, r, s.data.page), console.log("pageLoad", a.globalData.appid, a.globalData.openid, t);
        });
    },
    getClassData: function(e, s, r) {
        var o = this;
        a.util.request({
            url: t.getClassDataUrl,
            data: {
                style: e,
                class_id: s,
                page: r
            },
            method: "post",
            success: function(a) {
                console.log("rollback data", a);
                var t = o.data.classData;
                0 == a.data.errno ? (a.data.data.result.length < a.data.data.psize && o.setData({
                    isLoadingEnd: !0
                }), t = t.concat(a.data.data.result), o.setData({
                    classData: t
                })) : o.setData({
                    isLoadingEnd: !0
                }), wx.hideLoading();
            }
        });
    },
    onReachBottom: function() {
        var a = this;
        console.log("show loading", a.data.isLoadingEnd), 0 == a.data.isLoadingEnd && (wx.showLoading({
            title: "玩命加载中"
        }), a.data.page += 1, a.getClassData(a.data.style, a.data.class_id, a.data.page));
    },
    minp_click: function(t) {
        console.log(t);
        var e = t.currentTarget.dataset.is_show_erweima, s = t.currentTarget.dataset.erweima;
        console.log(s), 1 == e && wx.previewImage({
            urls: [ s ]
        });
        var r = t.currentTarget.dataset.mid;
        a.util.request({
            url: "entry/wxapp/minpclick",
            data: {
                mid: r
            },
            method: "post",
            success: function(a) {
                a.data.errno;
            }
        });
    },
    h5_click: function(a) {
        console.log(a);
        a.currentTarget.dataset.is_show_h5;
        var t = a.currentTarget.dataset.icon, e = a.currentTarget.dataset.title, s = a.currentTarget.dataset.replyKeyword, r = a.currentTarget.dataset.mid;
        this.setData({
            h5_keyword: s,
            h5_title: e,
            h5_reply: s,
            h5_icon: t,
            h5_modal_show: !0,
            h5_wxappcard: a.currentTarget.dataset.wxappCard,
            h5_cur_mid: r
        });
    },
    add_form_id: function(t) {
        var s = t.detail.formId;
        e.add_form_id(a, s);
    },
    client_prepare: function(t) {
        var s = t.detail.formId;
        e.add_form_id(a, s);
        var r = this.data.h5_cur_mid;
        console.log(r), a.util.request({
            url: "entry/wxapp/minpclick",
            data: {
                mid: r
            },
            method: "post",
            success: function(a) {
                console.log(a.data);
            }
        });
    },
    get_userinfo: function(t) {
        var e = this, s = t.detail;
        0 == e.data.hasUserInfo && (a.util.upadteUser(s, function(a) {}), e.setData({
            hasUserInfo: !0
        })), 1 == t.currentTarget.dataset.is_show_h5 ? e.h5_click(t) : e.minp_click(t);
    }
});