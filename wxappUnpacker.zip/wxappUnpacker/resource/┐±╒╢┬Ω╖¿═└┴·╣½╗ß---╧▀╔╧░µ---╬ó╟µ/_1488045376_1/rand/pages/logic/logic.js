var o = {
    dologin: function(o, e) {
        if (o.globalData.userInfo && o.globalData.userInfo.sessionid) s = o.userInfo.sessionid; else var s = "";
        s ? "function" == typeof e && e(o.globalData.userInfo) : wx.login({
            success: function(s) {
                o.util.getWe7User(function(s) {
                    console.log("userInfo", s), o.globalData.userInfo = s, o.globalData.openid = s.memberInfo.openid, 
                    o.userInfo = s, o.util.request({
                        url: "entry/wxapp/saveUserInfo",
                        method: "post",
                        data: {
                            iv: o.globalData.iv,
                            encryptedData: o.globalData.encryptedData,
                            tg_id: o.globalData.tg_id
                        },
                        success: function(o) {}
                    }), e(s);
                }, s.code);
            }
        });
    },
    add_form_id: function(o, e) {
        var s = o.userInfo.sessionid;
        console.log("form_id_session", s, e), o.util.request({
            url: "entry/wxapp/addFormId",
            method: "post",
            data: {
                form_id: e
            },
            success: function(o) {
                console.log(o);
            }
        });
    }
};

module.exports = o;