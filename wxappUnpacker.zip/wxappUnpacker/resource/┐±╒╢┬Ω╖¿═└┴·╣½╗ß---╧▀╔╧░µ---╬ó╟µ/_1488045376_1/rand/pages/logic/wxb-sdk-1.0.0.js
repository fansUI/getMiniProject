module.exports = {
    data: {
        wxb_version: "1.0.1",
        wxb_cid: 0,
        wxb_level: 0
    },
    getWxbData: function(e, o) {
        console.log("getWxbData:options", e);
        var t = this.data.wxb_cid, n = this.data.wxb_level;
        if (void 0 != e.query.wxb_level && void 0 != e.query.wxb_cid) t = e.query.wxb_cid, 
        n = e.query.wxb_level; else if (void 0 != e.query.scene && -1 != e.query.scene.indexOf("wxb")) {
            var a = decodeURIComponent(e.query.scene).split(",");
            t = a[1], n = a[2];
        } else "" !== wx.getStorageSync("WXB_CID_" + o) && "" !== wx.getStorageSync("WXB_LEVEL_" + o) && (t = wx.getStorageSync("WXB_CID_" + o), 
        n = wx.getStorageSync("WXB_LEVEL_" + o));
        return wx.setStorageSync("WXB_CID_" + o, t), wx.setStorageSync("WXB_LEVEL_" + o, n), 
        console.log("wxb_cid,wxb_level", {
            wxb_cid: t,
            wxb_level: n
        }), {
            wxb_cid: t,
            wxb_level: n
        };
    },
    launch: function(e, o, t) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var n = this.getWxbData(t, e);
        wx.setStorageSync("WXB_START", Date.now()), wx.request({
            url: "https://x.wxb.com/stat/launch",
            data: {
                appid: e,
                openid: o,
                wxb_cid: n.wxb_cid,
                wxb_level: n.wxb_level,
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("WXB上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    show: function(e, o, t) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var n = this.getWxbData(t, e);
        wx.setStorageSync("WXB_START", Date.now()), wx.request({
            url: "https://x.wxb.com/stat/show",
            data: {
                appid: e,
                openid: o,
                wxb_cid: n.wxb_cid,
                wxb_level: n.wxb_level,
                query: JSON.stringify(t),
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("WXB上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    pageLoad: function(e, o, t) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var n = this.getWxbCid(e), a = this.getWxbLocalLevel(e);
        e && o ? wx.request({
            url: "https://x.wxb.com/stat/pagelog",
            data: {
                appid: e,
                openid: o,
                wxb_cid: n,
                wxb_level: a,
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        }) : console.warn("请填写openid或appid");
    },
    hide: function(e, o) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var t = this.getWxbCid(e), n = this.getWxbLocalLevel(e), a = wx.getStorageSync("WXB_START");
        wx.request({
            url: "https://x.wxb.com/stat/close",
            data: {
                appid: e,
                openid: o,
                wxb_cid: t,
                wxb_level: n,
                total_time: a ? ((Date.now() - a) / 1e3).toFixed(0) : 0,
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    auth: function(e, o) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var t = this.getWxbCid(e), n = this.getWxbLocalLevel(e);
        wx.request({
            url: "https://x.wxb.com/stat/auth",
            data: {
                appid: e,
                openid: o,
                wxb_cid: t,
                wxb_level: n,
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    action: function(e, o, t) {
        e || console.warn("请填写appid"), o || console.warn("请填写openid");
        var n = this.getWxbCid(e), a = this.getWxbLocalLevel(e);
        wx.request({
            url: "https://x.wxb.com/stat/action",
            data: {
                appid: e,
                openid: o,
                wxb_cid: n,
                wxb_level: a,
                amount: t,
                wxb_version: this.data.wxb_version
            },
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                e.errcode ? console.log("上报失败") : console.log("WXB上报成功");
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    getWxbCid: function(e) {
        return "" !== wx.getStorageSync("WXB_CID_" + e) ? wx.getStorageSync("WXB_CID_" + e) : this.data.wxb_cid;
    },
    getWxbLevel: function(e) {
        var o = this.getWxbLocalLevel(e);
        return parseInt(o) + 1;
    },
    getWxbLocalLevel: function(e) {
        return "" !== wx.getStorageSync("WXB_LEVEL_" + e) ? wx.getStorageSync("WXB_LEVEL_" + e) : this.data.wxb_level;
    },
    setWxbStartTime: function() {
        wx.setStorageSync("WXB_START", Date.now());
    }
};