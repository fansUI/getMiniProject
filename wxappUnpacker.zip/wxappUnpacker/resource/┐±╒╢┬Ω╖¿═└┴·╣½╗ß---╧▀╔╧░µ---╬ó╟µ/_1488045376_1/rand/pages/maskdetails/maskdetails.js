Page({
    data: {
        key: 0
    },
    onLoad: function(o) {
        console.log("options", o), this.setData({
            key: o.key
        });
    }
});