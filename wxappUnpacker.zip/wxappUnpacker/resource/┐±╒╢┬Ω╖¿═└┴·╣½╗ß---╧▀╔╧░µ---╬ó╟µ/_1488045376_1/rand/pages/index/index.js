var a = getApp(), t = require("../../resource/js/groupUrl.js"), e = require("../logic/logic.js");

require("../logic/wxb-sdk-1.0.0.js");

Page({
    data: {
        userInfo: null,
        minpLists: [],
        userData: {
            gold: 0,
            money: 0
        },
        is_show_sign_pop: !1,
        hasUserInfo: !1,
        top_ad: null,
        bottom_ad: null,
        temp_version: 2,
        hot_list: [],
        best_list: [],
        finy_list: [],
        index_txt: "",
        is_need_auth: 1,
        is_show_mask: -1
    },
    onLoad: function(t) {
        var s = this;
        e.dologin(a, function(a) {
            s.getIndexData();
        });
    },
    getIndexData: function() {
        var e = this;
        a.util.request({
            url: t.getIndexDataUrl,
            method: "post",
            success: function(t) {
                0 == t.data.errno && (a.globalData.userData = t.data.data.userData, a.globalData.is_complete_new_user_task = t.data.data.is_complete_new_user_task, 
                a.globalData.share_title = t.data.data.share_title, a.globalData.share_path = t.data.data.share_path, 
                a.globalData.share_imageUrl = t.data.data.share_imageUrl, e.setData({
                    minpLists: t.data.data.classData,
                    userData: t.data.data.userData,
                    bottom_ad: t.data.data.bottom_ad,
                    top_ad: t.data.data.top_ad,
                    temp_version: t.data.data.temp_version,
                    hot_list: t.data.data.hot_list,
                    best_list: t.data.data.best_list,
                    finy_list: t.data.data.finy_list,
                    index_txt: t.data.data.index_txt
                }), wx.setNavigationBarTitle({
                    title: t.data.data.indexName
                }), e.setData({
                    is_need_auth: a.globalData.is_need_auth
                }), 0 == a.globalData.is_complete_new_user_task && a.globalData.scene > 0 && "" != a.globalData.userData.headimgurl && a.util.request({
                    url: "entry/wxapp/addDeskRecord",
                    method: "post",
                    data: {
                        scene: a.globalData.scene
                    },
                    success: function(a) {
                        console.log(a);
                    }
                }));
            }
        });
    },
    jumpLists: function(a) {
        var t = a.currentTarget.dataset.class_id;
        wx.navigateTo({
            url: "../list/list?class_id=" + t
        });
    },
    h5_click: function(a) {
        console.log(a);
        a.currentTarget.dataset.is_show_h5;
        var t = a.currentTarget.dataset.icon, e = a.currentTarget.dataset.title, s = a.currentTarget.dataset.replyKeyword, r = a.currentTarget.dataset.mid;
        this.setData({
            h5_keyword: s,
            h5_title: e,
            h5_reply: s,
            h5_icon: t,
            h5_modal_show: !0,
            h5_wxappcard: a.currentTarget.dataset.wxappCard,
            h5_cur_mid: r
        });
    },
    client_prepare: function(t) {
        console.log(t);
        var s = t.detail.formId;
        e.add_form_id(a, s);
        var r = this.data.h5_cur_mid;
        console.log("mid", r), a.util.request({
            url: "entry/wxapp/minpclick",
            data: {
                mid: r
            },
            method: "post",
            success: function(a) {
                console.log(a.data);
            }
        });
    },
    minp_click: function(t) {
        console.log("e is", t);
        var e = t.currentTarget.dataset.is_show_erweima, s = t.currentTarget.dataset.erweima;
        1 == e && wx.previewImage({
            urls: [ s ]
        });
        var r = t.currentTarget.dataset.mid;
        a.util.request({
            url: "entry/wxapp/minpclick",
            data: {
                mid: r
            },
            method: "post",
            success: function(a) {
                console.log(a.data);
            }
        });
        var i = t.currentTarget.dataset.appid;
        a.util.request({
            url: "entry/wxapp/saveJumpMinp",
            data: {
                appid: i
            },
            method: "post",
            success: function(a) {
                console.log(a.data);
            }
        });
    },
    more_minp: function(a) {
        var t = a.currentTarget.dataset.class_id, e = a.currentTarget.dataset.style;
        wx.navigateTo({
            url: "../list/list?style=" + e + "&class_id=" + t
        });
    },
    get_userinfo: function(t) {
        var e = this, s = t.detail;
        0 == e.data.hasUserInfo && (a.util.upadteUser(s, function(a) {
            console.log("update user", a);
        }), e.setData({
            hasUserInfo: !0
        })), 1 == t.currentTarget.dataset.is_show_h5 ? e.h5_click(t) : e.minp_click(t);
    },
    onShareAppMessage: function() {
        return console.log(a.globalData.share_title, a.globalData.share_path, a.globalData.share_imageUrl), 
        wx.showShareMenu({
            withShareTicket: !0
        }), {
            title: a.globalData.share_title,
            path: a.globalData.share_path,
            imageUrl: a.globalData.share_imageUrl
        };
    }
});