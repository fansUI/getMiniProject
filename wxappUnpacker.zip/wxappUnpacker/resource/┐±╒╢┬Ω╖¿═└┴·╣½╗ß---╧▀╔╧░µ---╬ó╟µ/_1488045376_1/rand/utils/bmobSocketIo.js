var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, e = "function" == typeof Symbol && "symbol" == t(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : t(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : t(e);
};

(function(t) {
    var n = "undefined" == typeof module ? {} : module.exports, o = {};
    exports.BmobSocketIo = o, function(t, e, n) {
        var o = t;
        o.version = "V1.0.0", o.JSON = JSON, o.protocol = 1, o.transports = [], o.j = [], 
        o.sockets = {}, o.connect = function(t, n) {
            var i, s, r = o.util.parseUri(t);
            e && e.location && (r.protocol = r.protocol || e.location.protocol.slice(0, -1), 
            r.host = r.host, r.port = r.port || e.location.port), i = o.util.uniqueUri(r);
            var c = {
                host: r.host,
                secure: "https" == r.protocol,
                port: "",
                query: r.query || ""
            };
            return o.util.merge(c, n), !c["force new connection"] && o.sockets[i] || (s = new o.Socket(c)), 
            !c["force new connection"] && s && (o.sockets[i] = s), console.log("connect"), (s = s || o.sockets[i]).of(r.path.length > 1 ? r.path : "");
        };
    }("object" === ("undefined" == typeof module ? "undefined" : e(module)) ? module.exports : this.io = {}, this), 
    function(t, e) {
        function n() {}
        t.EventEmitter = n, n.prototype.on = function(t, n) {
            return this.$events || (this.$events = {}), this.$events[t] ? e.util.isArray(this.$events[t]) ? this.$events[t].push(n) : this.$events[t] = [ this.$events[t], n ] : this.$events[t] = n, 
            this;
        }, n.prototype.addListener = n.prototype.on, n.prototype.once = function(t, e) {
            function n() {
                o.removeListener(t, n), e.apply(this, arguments);
            }
            var o = this;
            return n.listener = e, this.on(t, n), this;
        }, n.prototype.removeListener = function(t, n) {
            if (this.$events && this.$events[t]) {
                var o = this.$events[t];
                if (e.util.isArray(o)) {
                    for (var i = -1, s = 0, r = o.length; s < r; s++) if (o[s] === n || o[s].listener && o[s].listener === n) {
                        i = s;
                        break;
                    }
                    if (i < 0) return this;
                    o.splice(i, 1), o.length || delete this.$events[t];
                } else (o === n || o.listener && o.listener === n) && delete this.$events[t];
            }
            return this;
        }, n.prototype.removeAllListeners = function(t) {
            return void 0 === t ? (this.$events = {}, this) : (this.$events && this.$events[t] && (this.$events[t] = null), 
            this);
        }, n.prototype.listeners = function(t) {
            return this.$events || (this.$events = {}), this.$events[t] || (this.$events[t] = []), 
            e.util.isArray(this.$events[t]) || (this.$events[t] = [ this.$events[t] ]), this.$events[t];
        }, n.prototype.emit = function(t) {
            if (!this.$events) return !1;
            var n = this.$events[t];
            if (!n) return !1;
            var o = Array.prototype.slice.call(arguments, 1);
            if ("function" == typeof n) n.apply(this, o); else {
                if (!e.util.isArray(n)) return !1;
                for (var i = n.slice(), s = 0, r = i.length; s < r; s++) i[s].apply(this, o);
            }
            return !0;
        };
    }(void 0 !== n ? n : module.exports, void 0 !== n ? n : module.parent.exports), 
    function(t, o) {
        var i = (void 0 !== n ? n : module.exports).util = {}, s = /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/, r = [ "source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor" ];
        i.parseUri = function(t) {
            for (var e = s.exec(t || ""), n = {}, o = 14; o--; ) n[r[o]] = e[o] || "";
            return n;
        }, i.uniqueUri = function(t) {
            var e = t.protocol, n = t.host, i = t.port;
            return o ? (n = n || document.domain, i = i || ("https" == e && "https:" !== document.location.protocol ? 443 : document.location.port)) : (n = n || "localhost", 
            i || "https" != e || (i = 443)), (e || "http") + "://" + n + ":" + (i || 80);
        }, i.query = function(t, e) {
            var n = i.chunkQuery(t || ""), o = [];
            i.merge(n, i.chunkQuery(e || ""));
            for (var s in n) n.hasOwnProperty(s) && o.push(s + "=" + n[s]);
            return o.length ? "?" + o.join("&") : "";
        }, i.chunkQuery = function(t) {
            for (var e, n = {}, o = t.split("&"), i = 0, s = o.length; i < s; ++i) (e = o[i].split("="))[0] && (n[e[0]] = e[1]);
            return n;
        };
        var c = !1;
        i.load = function(t) {
            if (c) return t();
            i.on(o, "load", t, !1);
        }, i.on = function(t, e, n, o) {
            t.attachEvent ? t.attachEvent("on" + e, n) : t.addEventListener && t.addEventListener(e, n, o);
        }, "undefined" != typeof window && i.load(function() {
            c = !0;
        }), i.defer = function(t) {
            if (!i.ua.webkit || "undefined" != typeof importScripts) return t();
            i.load(function() {
                setTimeout(t, 100);
            });
        }, i.merge = function(t, n, o, s) {
            var r, c = s || [], a = void 0 === o ? 2 : o;
            for (r in n) n.hasOwnProperty(r) && i.indexOf(c, r) < 0 && ("object" === e(t[r]) && a ? i.merge(t[r], n[r], a - 1, c) : (t[r] = n[r], 
            c.push(n[r])));
            return t;
        }, i.mixin = function(t, e) {
            i.merge(t.prototype, e.prototype);
        }, i.inherit = function(t, e) {
            function n() {}
            n.prototype = e.prototype, t.prototype = new n();
        }, i.isArray = Array.isArray || function(t) {
            return "[object Array]" === Object.prototype.toString.call(t);
        }, i.intersect = function(t, e) {
            for (var n = [], o = t.length > e.length ? t : e, s = t.length > e.length ? e : t, r = 0, c = s.length; r < c; r++) ~i.indexOf(o, s[r]) && n.push(s[r]);
            return n;
        }, i.indexOf = function(t, e, n) {
            for (var o = t.length, n = n < 0 ? n + o < 0 ? 0 : n + o : n || 0; n < o && t[n] !== e; n++) ;
            return o <= n ? -1 : n;
        }, i.toArray = function(t) {
            for (var e = [], n = 0, o = t.length; n < o; n++) e.push(t[n]);
            return e;
        }, i.ua = {}, i.ua.hasCORS = "undefined" != typeof XMLHttpRequest && function() {
            try {
                var t = new XMLHttpRequest();
            } catch (t) {
                return !1;
            }
            return void 0 != t.withCredentials;
        }(), i.ua.webkit = "undefined" != typeof navigator && /webkit/i.test(navigator.userAgent), 
        i.ua.iDevice = "undefined" != typeof navigator && /iPad|iPhone|iPod/i.test(navigator.userAgent);
    }(0, this), function(t, e, n) {
        function o(t) {
            if (this.options = {
                port: 80,
                secure: !0,
                document: !1,
                resource: "socket.io",
                transports: e.transports,
                "connect timeout": 1e4,
                "try multiple transports": !0,
                reconnect: !0,
                "reconnection delay": 500,
                "reconnection limit": 1 / 0,
                "reopen delay": 3e3,
                "max reconnection attempts": 10,
                "sync disconnect on unload": !1,
                "auto connect": !0,
                "flash policy port": 10843,
                manualFlush: !1
            }, e.util.merge(this.options, t), this.connected = !1, this.open = !1, this.connecting = !1, 
            this.reconnecting = !1, this.namespaces = {}, this.buffer = [], this.doBuffer = !1, 
            this.options["sync disconnect on unload"] && (!this.isXDomain() || e.util.ua.hasCORS)) {
                var o = this;
                e.util.on(n, "beforeunload", function() {
                    o.disconnectSync();
                }, !1);
            }
            this.options["auto connect"] && this.connect();
        }
        t.Socket = o, e.util.mixin(o, e.EventEmitter), o.prototype.of = function(t) {
            return this.namespaces[t] || (this.namespaces[t] = new e.SocketNamespace(this, t), 
            "" !== t && this.namespaces[t].packet({
                type: "connect"
            })), this.namespaces[t];
        }, o.prototype.publish = function() {
            this.emit.apply(this, arguments);
            var t;
            for (var e in this.namespaces) this.namespaces.hasOwnProperty(e) && (t = this.of(e)).$emit.apply(t, arguments);
        }, o.prototype.handshake = function(t) {
            function n(e) {
                e instanceof Error ? (o.connecting = !1, o.onError(e.message)) : t.apply(null, e.split(":"));
            }
            var o = this, i = this.options;
            i.secure = !0;
            var s = [ "http" + (i.secure ? "s" : "") + ":/", i.host, i.resource, e.protocol, e.util.query(this.options.query, "t=" + +new Date()) ].join("/"), r = {}, c = JSON.stringify(r);
            wx.request({
                method: "GET",
                url: s,
                data: c,
                header: {
                    "content-type": "text/plain"
                },
                success: function(t) {
                    t.data && t.data.code ? console.log("request error") : 200 != t.statusCode ? console.log("request error") : n(t.data);
                },
                fail: function(t) {
                    console.log("request error");
                }
            });
        }, o.prototype.getTransport = function(t) {
            for (var n, o = t || this.transports, i = 0; n = o[i]; i++) if (n) return new e.Transport[n](this, this.sessionid);
            return null;
        }, o.prototype.connect = function(t) {
            if (this.connecting) return this;
            var n = this;
            return n.connecting = !0, this.handshake(function(o, i, s, r) {
                function c(t) {
                    if (n.transport && n.transport.clearTimeouts(), n.transport = n.getTransport(t), 
                    !n.transport) return n.publish("connect_failed");
                    n.transport.ready(n, function() {
                        n.connecting = !0, n.publish("connecting", n.transport.name), n.transport.open(), 
                        n.options["connect timeout"] && (n.connectTimeoutTimer = setTimeout(function() {
                            if (!n.connected && (n.connecting = !1, n.options["try multiple transports"])) {
                                for (var t = n.transports; t.length > 0 && t.splice(0, 1)[0] != n.transport.name; ) ;
                                t.length ? c(t) : n.publish("connect_failed2");
                            }
                        }, n.options["connect timeout"]));
                    });
                }
                n.sessionid = o, n.closeTimeout = 1e3 * s, n.heartbeatTimeout = 1e3 * i, n.transports || (n.transports = n.origTransports = r ? e.util.intersect(r.split(","), n.options.transports) : n.options.transports), 
                n.setHeartbeatTimeout(), c(n.transports), n.once("connect", function() {
                    clearTimeout(n.connectTimeoutTimer), t && "function" == typeof t && t();
                });
            }), this;
        }, o.prototype.setHeartbeatTimeout = function() {
            if (clearTimeout(this.heartbeatTimeoutTimer), !this.transport || this.transport.heartbeats()) {
                var t = this;
                this.heartbeatTimeoutTimer = setTimeout(function() {
                    t.transport.onClose();
                }, this.heartbeatTimeout);
            }
        }, o.prototype.packet = function(t) {
            return this.connected && !this.doBuffer ? this.transport.packet(t) : this.buffer.push(t), 
            this;
        }, o.prototype.setBuffer = function(t) {
            this.doBuffer = t, !t && this.connected && this.buffer.length && (this.options.manualFlush || this.flushBuffer());
        }, o.prototype.flushBuffer = function() {
            this.transport.payload(this.buffer), this.buffer = [];
        }, o.prototype.disconnect = function() {
            return (this.connected || this.connecting) && (this.open && this.of("").packet({
                type: "disconnect"
            }), this.onDisconnect("booted")), this;
        }, o.prototype.disconnectSync = function() {
            var t = e.util.request(), n = [ "http" + (this.options.secure ? "s" : "") + ":/", this.options.host + ":" + this.options.port, this.options.resource, e.protocol, "", this.sessionid ].join("/") + "/?disconnect=1";
            t.open("GET", n, !1), t.send(null), this.onDisconnect("booted");
        }, o.prototype.isXDomain = function() {
            return "";
        }, o.prototype.onConnect = function() {
            this.connected || (this.connected = !0, this.connecting = !1, this.doBuffer || this.setBuffer(!1), 
            this.emit("connect"));
        }, o.prototype.onOpen = function() {
            this.open = !0;
        }, o.prototype.onClose = function() {
            this.open = !1, clearTimeout(this.heartbeatTimeoutTimer);
        }, o.prototype.onPacket = function(t) {
            this.of(t.endpoint).onPacket(t);
        }, o.prototype.onError = function(t) {
            t && t.advice && "reconnect" === t.advice && (this.connected || this.connecting) && (this.disconnect(), 
            this.options.reconnect && this.reconnect()), this.publish("error", t && t.reason ? t.reason : t);
        }, o.prototype.onDisconnect = function(t) {
            var e = this.connected, n = this.connecting;
            this.connected = !1, this.connecting = !1, this.open = !1, (e || n) && (this.transport.close(), 
            this.transport.clearTimeouts(), e && (this.publish("disconnect", t), "booted" != t && this.options.reconnect && !this.reconnecting && this.reconnect()));
        }, o.prototype.reconnect = function() {
            function t() {
                if (n.connected) {
                    for (var t in n.namespaces) n.namespaces.hasOwnProperty(t) && "" !== t && n.namespaces[t].packet({
                        type: "connect"
                    });
                    n.publish("reconnect", n.transport.name, n.reconnectionAttempts);
                }
                clearTimeout(n.reconnectionTimer), n.removeListener("connect_failed", e), n.removeListener("connect", e), 
                n.reconnecting = !1, delete n.reconnectionAttempts, delete n.reconnectionDelay, 
                delete n.reconnectionTimer, delete n.redoTransports, n.options["try multiple transports"] = i;
            }
            function e() {
                if (n.reconnecting) return n.connected ? t() : n.connecting && n.reconnecting ? n.reconnectionTimer = setTimeout(e, 1e3) : void (n.reconnectionAttempts++ >= o ? n.redoTransports ? (n.publish("reconnect_failed"), 
                t()) : (n.on("connect_failed", e), n.options["try multiple transports"] = !0, n.transports = n.origTransports, 
                n.transport = n.getTransport(), n.redoTransports = !0, n.connect()) : (n.reconnectionDelay < s && (n.reconnectionDelay *= 2), 
                n.connect(), n.publish("reconnecting", n.reconnectionDelay, n.reconnectionAttempts), 
                n.reconnectionTimer = setTimeout(e, n.reconnectionDelay)));
            }
            this.reconnecting = !0, this.reconnectionAttempts = 0, this.reconnectionDelay = this.options["reconnection delay"];
            var n = this, o = this.options["max reconnection attempts"], i = this.options["try multiple transports"], s = this.options["reconnection limit"];
            this.options["try multiple transports"] = !1, this.reconnectionTimer = setTimeout(e, this.reconnectionDelay), 
            this.on("connect", e);
        };
    }(void 0 !== n ? n : module.exports, void 0 !== n ? n : module.parent.exports, this), 
    function(t, e) {
        function n(t, e) {
            this.socket = t, this.name = e || "", this.flags = {}, this.json = new o(this, "json"), 
            this.ackPackets = 0, this.acks = {};
        }
        function o(t, e) {
            this.namespace = t, this.name = e;
        }
        t.SocketNamespace = n, e.util.mixin(n, e.EventEmitter), n.prototype.$emit = e.EventEmitter.prototype.emit, 
        n.prototype.of = function() {
            return this.socket.of.apply(this.socket, arguments);
        }, n.prototype.packet = function(t) {
            return t.endpoint = this.name, this.socket.packet(t), this.flags = {}, this;
        }, n.prototype.send = function(t, e) {
            var n = {
                type: this.flags.json ? "json" : "message",
                data: t
            };
            return "function" == typeof e && (n.id = ++this.ackPackets, n.ack = !0, this.acks[n.id] = e), 
            this.packet(n);
        }, n.prototype.emit = function(t) {
            var e = Array.prototype.slice.call(arguments, 1), n = e[e.length - 1], o = {
                type: "event",
                name: t
            };
            return "function" == typeof n && (o.id = ++this.ackPackets, o.ack = "data", this.acks[o.id] = n, 
            e = e.slice(0, e.length - 1)), o.args = e, this.packet(o);
        }, n.prototype.disconnect = function() {
            return "" === this.name ? this.socket.disconnect() : (this.packet({
                type: "disconnect"
            }), this.$emit("disconnect")), this;
        }, n.prototype.onPacket = function(t) {
            function n() {
                o.packet({
                    type: "ack",
                    args: e.util.toArray(arguments),
                    ackId: t.id
                });
            }
            var o = this;
            switch (t.type) {
              case "connect":
                this.$emit("connect");
                break;

              case "disconnect":
                "" === this.name ? this.socket.onDisconnect(t.reason || "booted") : this.$emit("disconnect", t.reason);
                break;

              case "message":
              case "json":
                i = [ "message", t.data ], "data" == t.ack ? i.push(n) : t.ack && this.packet({
                    type: "ack",
                    ackId: t.id
                }), this.$emit.apply(this, i);
                break;

              case "event":
                var i = [ t.name ].concat(t.args);
                "data" == t.ack && i.push(n), this.$emit.apply(this, i);
                break;

              case "ack":
                this.acks[t.ackId] && (this.acks[t.ackId].apply(this, t.args), delete this.acks[t.ackId]);
                break;

              case "error":
                t.advice ? this.socket.onError(t) : "unauthorized" == t.reason ? this.$emit("connect_failed", t.reason) : this.$emit("error", t.reason);
            }
        }, o.prototype.send = function() {
            this.namespace.flags[this.name] = !0, this.namespace.send.apply(this.namespace, arguments);
        }, o.prototype.emit = function() {
            this.namespace.flags[this.name] = !0, this.namespace.emit.apply(this.namespace, arguments);
        };
    }(void 0 !== n ? n : module.exports, void 0 !== n ? n : module.parent.exports), 
    function(t, e) {
        function n(t, e) {
            this.socket = t, this.sessid = e;
        }
        t.Transport = n, e.util.mixin(n, e.EventEmitter), n.prototype.heartbeats = function() {
            return !0;
        }, n.prototype.onData = function(t) {
            if (this.clearCloseTimeout(), (this.socket.connected || this.socket.connecting || this.socket.reconnecting) && this.setCloseTimeout(), 
            "" !== t) {
                var n = e.parser.decodePayload(t);
                if (n && n.length) for (var o = 0, i = n.length; o < i; o++) this.onPacket(n[o]);
            }
            return this;
        }, n.prototype.onPacket = function(t) {
            return this.socket.setHeartbeatTimeout(), "heartbeat" == t.type ? this.onHeartbeat() : ("connect" == t.type && "" == t.endpoint && this.onConnect(), 
            "error" == t.type && "reconnect" == t.advice && (this.isOpen = !1), this.socket.onPacket(t), 
            this);
        }, n.prototype.setCloseTimeout = function() {
            if (!this.closeTimeout) {
                var t = this;
                this.closeTimeout = setTimeout(function() {
                    t.onDisconnect();
                }, this.socket.closeTimeout);
            }
        }, n.prototype.onDisconnect = function() {
            return this.isOpen && this.close(), this.clearTimeouts(), this.socket.onDisconnect(), 
            this;
        }, n.prototype.onConnect = function() {
            return this.socket.onConnect(), this;
        }, n.prototype.clearCloseTimeout = function() {
            this.closeTimeout && (clearTimeout(this.closeTimeout), this.closeTimeout = null);
        }, n.prototype.clearTimeouts = function() {
            this.clearCloseTimeout(), this.reopenTimeout && clearTimeout(this.reopenTimeout);
        }, n.prototype.packet = function(t) {
            this.send(e.parser.encodePacket(t));
        }, n.prototype.onHeartbeat = function(t) {
            this.packet({
                type: "heartbeat"
            });
        }, n.prototype.onOpen = function() {
            this.isOpen = !0, this.clearCloseTimeout(), this.socket.onOpen();
        }, n.prototype.onClose = function() {
            this.isOpen = !1, this.socket.onClose(), this.onDisconnect();
        }, n.prototype.prepareUrl = function() {
            var t = this.socket.options;
            return this.scheme() + "://" + t.host + ":" + t.port + "/" + t.resource + "/" + e.protocol + "/" + this.name + "/" + this.sessid;
        }, n.prototype.ready = function(t, e) {
            e.call(this);
        };
    }(void 0 !== n ? n : module.exports, void 0 !== n ? n : module.parent.exports), 
    function(t, e, n) {
        function o(t) {
            e.Transport.apply(this, arguments);
        }
        t.websocket = o, e.util.inherit(o, e.Transport), o.prototype.name = "websocket", 
        o.prototype.open = function() {
            var t, n = e.util.query(this.socket.options.query), o = this;
            t = wx.connectSocket;
            var i = this.prepareUrl() + n;
            return this.websocket = new t({
                url: i,
                data: {
                    x: "",
                    y: ""
                },
                header: {
                    "content-type": "application/json"
                },
                protocols: [ "protocol1" ],
                method: "GET"
            }), wx.onSocketOpen(function(t) {
                console.log("WebSocket连接已打开！"), o.onOpen(), o.socket.setBuffer(!1);
            }), wx.onSocketError(function(t) {
                console.log("WebSocket连接打开失败，请检查！");
            }), wx.onSocketMessage(function(t) {
                console.log("收到服务器内容：" + t.data), o.onData(t.data);
            }), this.websocket.send = function(t) {
                console.log("发送一次消息", t), wx.sendSocketMessage({
                    data: t
                });
            }, wx.onSocketClose(function(t) {
                o.onClose(), o.socket.setBuffer(!0), console.log("WebSocket 已关闭！");
            }), this.websocket.close = function(t) {
                wx.closeSocket();
            }, this.websocket.onopen = function() {
                o.onOpen(), o.socket.setBuffer(!1);
            }, this.websocket.onmessage = function(t) {
                o.onData(t.data);
            }, this.websocket.onclose = function() {
                o.onClose(), o.socket.setBuffer(!0);
            }, this.websocket.onerror = function(t) {
                o.onError(t);
            }, this;
        }, e.util.ua.iDevice ? o.prototype.send = function(t) {
            var e = this;
            return setTimeout(function() {
                e.websocket.send(t);
            }, 0), this;
        } : o.prototype.send = function(t) {
            return this.websocket.send(t), this;
        }, o.prototype.payload = function(t) {
            for (var e = 0, n = t.length; e < n; e++) this.packet(t[e]);
            return this;
        }, o.prototype.close = function() {
            return this.websocket.close(), this;
        }, o.prototype.onError = function(t) {
            this.socket.onError(t);
        }, o.prototype.scheme = function() {
            return this.socket.options.secure, "wss";
        }, o.check = function() {
            return "WebSocket" in n && !("__addTask" in WebSocket) || "MozWebSocket" in n;
        }, o.xdomainCheck = function() {
            return !0;
        }, e.transports.push("websocket");
    }(void 0 !== n ? n.Transport : module.exports, void 0 !== n ? n : module.parent.exports, this), 
    function(t, e) {
        console.log("9999", t, "lllll", e, "000000");
        var n = t.parser = {}, o = n.packets = [ "disconnect", "connect", "heartbeat", "message", "json", "event", "ack", "error", "noop" ], i = n.reasons = [ "transport not supported", "client not handshaken", "unauthorized" ], s = n.advice = [ "reconnect" ], r = e.JSON, c = e.util.indexOf;
        n.encodePacket = function(t) {
            var e = c(o, t.type), n = t.id || "", a = t.endpoint || "", p = t.ack, u = null;
            switch (t.type) {
              case "error":
                var h = t.reason ? c(i, t.reason) : "", l = t.advice ? c(s, t.advice) : "";
                "" === h && "" === l || (u = h + ("" !== l ? "+" + l : ""));
                break;

              case "message":
                "" !== t.data && (u = t.data);
                break;

              case "event":
                var f = {
                    name: t.name
                };
                t.args && t.args.length && (f.args = t.args), u = r.stringify(f);
                break;

              case "json":
                u = r.stringify(t.data);
                break;

              case "connect":
                t.qs && (u = t.qs);
                break;

              case "ack":
                u = t.ackId + (t.args && t.args.length ? "+" + r.stringify(t.args) : "");
            }
            var d = [ e, n + ("data" == p ? "+" : ""), a ];
            return null !== u && void 0 !== u && d.push(u), d.join(":");
        }, n.encodePayload = function(t) {
            var e = "";
            if (1 == t.length) return t[0];
            for (var n = 0, o = t.length; n < o; n++) e += "�" + t[n].length + "�" + t[n];
            return e;
        };
        var a = /([^:]+):([0-9]+)?(\+)?:([^:]+)?:?([\s\S]*)?/;
        n.decodePacket = function(t) {
            if (!(c = t.match(a))) return {};
            var e = c[2] || "", t = c[5] || "", n = {
                type: o[c[1]],
                endpoint: c[4] || ""
            };
            switch (e && (n.id = e, c[3] ? n.ack = "data" : n.ack = !0), n.type) {
              case "error":
                var c = t.split("+");
                n.reason = i[c[0]] || "", n.advice = s[c[1]] || "";
                break;

              case "message":
                n.data = t || "";
                break;

              case "event":
                try {
                    var p = r.parse(t);
                    n.name = p.name, n.args = p.args;
                } catch (t) {}
                n.args = n.args || [];
                break;

              case "json":
                try {
                    n.data = r.parse(t);
                } catch (t) {}
                break;

              case "connect":
                n.qs = t || "";
                break;

              case "ack":
                if ((c = t.match(/^([0-9]+)(\+)?(.*)/)) && (n.ackId = c[1], n.args = [], c[3])) try {
                    n.args = c[3] ? r.parse(c[3]) : [];
                } catch (t) {}
            }
            return n;
        }, n.decodePayload = function(t) {
            if ("�" == t.charAt(0)) {
                for (var e = [], o = 1, i = ""; o < t.length; o++) "�" == t.charAt(o) ? (e.push(n.decodePacket(t.substr(o + 1).substr(0, i))), 
                o += Number(i) + 1, i = "") : i += t.charAt(o);
                return e;
            }
            return [ n.decodePacket(t) ];
        };
    }(void 0 !== n ? n : module.exports, void 0 !== n ? n : module.parent.exports), 
    o.initialize = function(t) {
        if (!t) throw "BmobSocketIo.initialize() need a applicationId";
        o._initialize(t);
    }, o.serverURL = "wss://wss.bmob.cn/", o.obj = null, o.init = function(t) {
        o.obj = n.connect(o.serverURL), o.obj.on("server_pub", function(t) {
            var e = JSON.parse(t);
            switch (e.action) {
              case "updateTable":
                o.onUpdateTable(e.tableName, e.data);
                break;

              case "updateRow":
                o.onUpdateRow(e.tableName, e.objectId, e.data);
                break;

              case "deleteTable":
                o.onDeleteTable(e.tableName, e.data);
                break;

              case "deleteRow":
                o.onDeleteRow(e.tableName, e.objectId, e.data);
            }
        }), o.obj.on("client_send_data", function(t) {
            n.BmobSocketIo.onInitListen();
        }), o.obj.on("disconnect", function() {
            console.log("You have disconnected from the server");
        });
    }, o._initialize = function(t) {
        o.applicationId = t;
    }, o.updateTable = function(t) {
        var e = {
            appKey: o.applicationId,
            tableName: t,
            objectId: "",
            action: "updateTable"
        };
        o.obj.emit("client_sub", JSON.stringify(e));
    }, o.unsubUpdateTable = function(t) {
        var e = {
            appKey: o.applicationId,
            tableName: t,
            objectId: "",
            action: "unsub_updateTable"
        };
        o.obj.emit("client_unsub", JSON.stringify(e));
    }, o.updateRow = function(t, e) {
        var n = {
            appKey: o.applicationId,
            tableName: t,
            objectId: e,
            action: "updateRow"
        };
        o.obj.emit("client_sub", JSON.stringify(n));
    }, o.unsubUpdateRow = function(t, e) {
        var n = {
            appKey: o.applicationId,
            tableName: t,
            objectId: e,
            action: "unsub_updateRow"
        };
        o.obj.emit("client_unsub", JSON.stringify(n));
    }, o.deleteTable = function(t) {
        var e = {
            appKey: o.applicationId,
            tableName: t,
            objectId: "",
            action: "deleteTable"
        };
        o.obj.emit("client_sub", JSON.stringify(e));
    }, o.unsubDeleteTable = function(t) {
        var e = {
            appKey: o.applicationId,
            tableName: t,
            objectId: "",
            action: "unsub_deleteTable"
        };
        o.obj.emit("client_unsub", JSON.stringify(e));
    }, o.deleteRow = function(t, e) {
        var n = {
            appKey: o.applicationId,
            tableName: t,
            objectId: e,
            action: "deleteRow"
        };
        o.obj.emit("client_sub", JSON.stringify(n));
    }, o.unsubDeleteRow = function(t, e) {
        var n = {
            appKey: o.applicationId,
            tableName: t,
            objectId: e,
            action: "unsub_deleteRow"
        };
        o.obj.emit("client_unsub", JSON.stringify(n));
    }, o.onUpdateTable = function(t, e) {}, o.onUpdateRow = function(t, e, n) {}, o.onDeleteTable = function(t, e) {}, 
    o.onDeleteRow = function(t, e, n) {}, o.onInitListen = function() {};
}).call(void 0);