function t(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

module.exports = {
    formatTime: function(e) {
        var n = e.getFullYear(), o = e.getMonth() + 1, r = e.getDate(), u = e.getHours(), a = e.getMinutes(), i = e.getSeconds();
        return [ n, o, r ].map(t).join("/") + " " + [ u, a, i ].map(t).join(":");
    },
    formatDateTime: function(e) {
        return [ e.getFullYear(), e.getMonth() + 1, e.getDate() ].map(t).join(".");
    },
    zhanbudes0: ""
};