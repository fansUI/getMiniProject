var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n) {
    return typeof n;
} : function(n) {
    return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
}, t = "function" == typeof Symbol && "symbol" == n(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : n(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : n(t);
};

(function() {
    function n(n) {
        function t(t, r, e, u, i, o) {
            for (;i >= 0 && i < o; i += n) {
                var a = u ? u[i] : i;
                e = r(e, t[a], a, t);
            }
            return e;
        }
        return function(r, e, u, i) {
            e = m(e, i, 4);
            var o = !O(r) && g.keys(r), a = (o || r).length, c = n > 0 ? 0 : a - 1;
            return arguments.length < 3 && (u = r[o ? o[c] : c], c += n), t(r, e, u, o, c, a);
        };
    }
    function r(n) {
        return function(t, r, e) {
            r = b(r, e);
            for (var u = A(t), i = n > 0 ? 0 : u - 1; i >= 0 && i < u; i += n) if (r(t[i], i, t)) return i;
            return -1;
        };
    }
    function e(n, t, r) {
        return function(e, u, i) {
            var o = 0, a = A(e);
            if ("number" == typeof i) n > 0 ? o = i >= 0 ? i : Math.max(i + a, o) : a = i >= 0 ? Math.min(i + 1, a) : i + a + 1; else if (r && i && a) return i = r(e, u), 
            e[i] === u ? i : -1;
            if (u !== u) return (i = t(f.call(e, o, a), g.isNaN)) >= 0 ? i + o : -1;
            for (i = n > 0 ? o : a - 1; i >= 0 && i < a; i += n) if (e[i] === u) return i;
            return -1;
        };
    }
    function u(n, t) {
        var r = I.length, e = n.constructor, u = g.isFunction(e) && e.prototype || o, i = "constructor";
        for (g.has(n, i) && !g.contains(t, i) && t.push(i); r--; ) (i = I[r]) in n && n[i] !== u[i] && !g.contains(t, i) && t.push(i);
    }
    var i = Array.prototype, o = Object.prototype, a = Function.prototype, c = i.push, f = i.slice, l = o.toString, s = o.hasOwnProperty, p = Array.isArray, v = Object.keys, h = a.bind, y = Object.create, d = function() {}, g = function n(t) {
        return t instanceof n ? t : this instanceof n ? void (this._wrapped = t) : new n(t);
    };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = g), 
    exports._ = g) : root._ = g, g.VERSION = "1.8.3";
    var m = function(n, t, r) {
        if (void 0 === t) return n;
        switch (null == r ? 3 : r) {
          case 1:
            return function(r) {
                return n.call(t, r);
            };

          case 2:
            return function(r, e) {
                return n.call(t, r, e);
            };

          case 3:
            return function(r, e, u) {
                return n.call(t, r, e, u);
            };

          case 4:
            return function(r, e, u, i) {
                return n.call(t, r, e, u, i);
            };
        }
        return function() {
            return n.apply(t, arguments);
        };
    }, b = function(n, t, r) {
        return null == n ? g.identity : g.isFunction(n) ? m(n, t, r) : g.isObject(n) ? g.matcher(n) : g.property(n);
    };
    g.iteratee = function(n, t) {
        return b(n, t, 1 / 0);
    };
    var x = function(n, t) {
        return function(r) {
            var e = arguments.length;
            if (e < 2 || null == r) return r;
            for (var u = 1; u < e; u++) for (var i = arguments[u], o = n(i), a = o.length, c = 0; c < a; c++) {
                var f = o[c];
                t && void 0 !== r[f] || (r[f] = i[f]);
            }
            return r;
        };
    }, _ = function(n) {
        if (!g.isObject(n)) return {};
        if (y) return y(n);
        d.prototype = n;
        var t = new d();
        return d.prototype = null, t;
    }, j = function(n) {
        return function(t) {
            return null == t ? void 0 : t[n];
        };
    }, w = Math.pow(2, 53) - 1, A = j("length"), O = function(n) {
        var t = A(n);
        return "number" == typeof t && t >= 0 && t <= w;
    };
    g.each = g.forEach = function(n, t, r) {
        t = m(t, r);
        var e, u;
        if (O(n)) for (e = 0, u = n.length; e < u; e++) t(n[e], e, n); else {
            var i = g.keys(n);
            for (e = 0, u = i.length; e < u; e++) t(n[i[e]], i[e], n);
        }
        return n;
    }, g.map = g.collect = function(n, t, r) {
        t = b(t, r);
        for (var e = !O(n) && g.keys(n), u = (e || n).length, i = Array(u), o = 0; o < u; o++) {
            var a = e ? e[o] : o;
            i[o] = t(n[a], a, n);
        }
        return i;
    }, g.reduce = g.foldl = g.inject = n(1), g.reduceRight = g.foldr = n(-1), g.find = g.detect = function(n, t, r) {
        var e;
        if (void 0 !== (e = O(n) ? g.findIndex(n, t, r) : g.findKey(n, t, r)) && -1 !== e) return n[e];
    }, g.filter = g.select = function(n, t, r) {
        var e = [];
        return t = b(t, r), g.each(n, function(n, r, u) {
            t(n, r, u) && e.push(n);
        }), e;
    }, g.reject = function(n, t, r) {
        return g.filter(n, g.negate(b(t)), r);
    }, g.every = g.all = function(n, t, r) {
        t = b(t, r);
        for (var e = !O(n) && g.keys(n), u = (e || n).length, i = 0; i < u; i++) {
            var o = e ? e[i] : i;
            if (!t(n[o], o, n)) return !1;
        }
        return !0;
    }, g.some = g.any = function(n, t, r) {
        t = b(t, r);
        for (var e = !O(n) && g.keys(n), u = (e || n).length, i = 0; i < u; i++) {
            var o = e ? e[i] : i;
            if (t(n[o], o, n)) return !0;
        }
        return !1;
    }, g.contains = g.includes = g.include = function(n, t, r, e) {
        return O(n) || (n = g.values(n)), ("number" != typeof r || e) && (r = 0), g.indexOf(n, t, r) >= 0;
    }, g.invoke = function(n, t) {
        var r = f.call(arguments, 2), e = g.isFunction(t);
        return g.map(n, function(n) {
            var u = e ? t : n[t];
            return null == u ? u : u.apply(n, r);
        });
    }, g.pluck = function(n, t) {
        return g.map(n, g.property(t));
    }, g.where = function(n, t) {
        return g.filter(n, g.matcher(t));
    }, g.findWhere = function(n, t) {
        return g.find(n, g.matcher(t));
    }, g.max = function(n, t, r) {
        var e, u, i = -1 / 0, o = -1 / 0;
        if (null == t && null != n) for (var a = 0, c = (n = O(n) ? n : g.values(n)).length; a < c; a++) (e = n[a]) > i && (i = e); else t = b(t, r), 
        g.each(n, function(n, r, e) {
            ((u = t(n, r, e)) > o || u === -1 / 0 && i === -1 / 0) && (i = n, o = u);
        });
        return i;
    }, g.min = function(n, t, r) {
        var e, u, i = 1 / 0, o = 1 / 0;
        if (null == t && null != n) for (var a = 0, c = (n = O(n) ? n : g.values(n)).length; a < c; a++) (e = n[a]) < i && (i = e); else t = b(t, r), 
        g.each(n, function(n, r, e) {
            ((u = t(n, r, e)) < o || u === 1 / 0 && i === 1 / 0) && (i = n, o = u);
        });
        return i;
    }, g.shuffle = function(n) {
        for (var t, r = O(n) ? n : g.values(n), e = r.length, u = Array(e), i = 0; i < e; i++) (t = g.random(0, i)) !== i && (u[i] = u[t]), 
        u[t] = r[i];
        return u;
    }, g.sample = function(n, t, r) {
        return null == t || r ? (O(n) || (n = g.values(n)), n[g.random(n.length - 1)]) : g.shuffle(n).slice(0, Math.max(0, t));
    }, g.sortBy = function(n, t, r) {
        return t = b(t, r), g.pluck(g.map(n, function(n, r, e) {
            return {
                value: n,
                index: r,
                criteria: t(n, r, e)
            };
        }).sort(function(n, t) {
            var r = n.criteria, e = t.criteria;
            if (r !== e) {
                if (r > e || void 0 === r) return 1;
                if (r < e || void 0 === e) return -1;
            }
            return n.index - t.index;
        }), "value");
    };
    var S = function(n) {
        return function(t, r, e) {
            var u = {};
            return r = b(r, e), g.each(t, function(e, i) {
                var o = r(e, i, t);
                n(u, e, o);
            }), u;
        };
    };
    g.groupBy = S(function(n, t, r) {
        g.has(n, r) ? n[r].push(t) : n[r] = [ t ];
    }), g.indexBy = S(function(n, t, r) {
        n[r] = t;
    }), g.countBy = S(function(n, t, r) {
        g.has(n, r) ? n[r]++ : n[r] = 1;
    }), g.toArray = function(n) {
        return n ? g.isArray(n) ? f.call(n) : O(n) ? g.map(n, g.identity) : g.values(n) : [];
    }, g.size = function(n) {
        return null == n ? 0 : O(n) ? n.length : g.keys(n).length;
    }, g.partition = function(n, t, r) {
        t = b(t, r);
        var e = [], u = [];
        return g.each(n, function(n, r, i) {
            (t(n, r, i) ? e : u).push(n);
        }), [ e, u ];
    }, g.first = g.head = g.take = function(n, t, r) {
        if (null != n) return null == t || r ? n[0] : g.initial(n, n.length - t);
    }, g.initial = function(n, t, r) {
        return f.call(n, 0, Math.max(0, n.length - (null == t || r ? 1 : t)));
    }, g.last = function(n, t, r) {
        if (null != n) return null == t || r ? n[n.length - 1] : g.rest(n, Math.max(0, n.length - t));
    }, g.rest = g.tail = g.drop = function(n, t, r) {
        return f.call(n, null == t || r ? 1 : t);
    }, g.compact = function(n) {
        return g.filter(n, g.identity);
    };
    var k = function n(t, r, e, u) {
        for (var i = [], o = 0, a = u || 0, c = A(t); a < c; a++) {
            var f = t[a];
            if (O(f) && (g.isArray(f) || g.isArguments(f))) {
                r || (f = n(f, r, e));
                var l = 0, s = f.length;
                for (i.length += s; l < s; ) i[o++] = f[l++];
            } else e || (i[o++] = f);
        }
        return i;
    };
    g.flatten = function(n, t) {
        return k(n, t, !1);
    }, g.without = function(n) {
        return g.difference(n, f.call(arguments, 1));
    }, g.uniq = g.unique = function(n, t, r, e) {
        g.isBoolean(t) || (e = r, r = t, t = !1), null != r && (r = b(r, e));
        for (var u = [], i = [], o = 0, a = A(n); o < a; o++) {
            var c = n[o], f = r ? r(c, o, n) : c;
            t ? (o && i === f || u.push(c), i = f) : r ? g.contains(i, f) || (i.push(f), u.push(c)) : g.contains(u, c) || u.push(c);
        }
        return u;
    }, g.union = function() {
        return g.uniq(k(arguments, !0, !0));
    }, g.intersection = function(n) {
        for (var t = [], r = arguments.length, e = 0, u = A(n); e < u; e++) {
            var i = n[e];
            if (!g.contains(t, i)) {
                for (var o = 1; o < r && g.contains(arguments[o], i); o++) ;
                o === r && t.push(i);
            }
        }
        return t;
    }, g.difference = function(n) {
        var t = k(arguments, !0, !0, 1);
        return g.filter(n, function(n) {
            return !g.contains(t, n);
        });
    }, g.zip = function() {
        return g.unzip(arguments);
    }, g.unzip = function(n) {
        for (var t = n && g.max(n, A).length || 0, r = Array(t), e = 0; e < t; e++) r[e] = g.pluck(n, e);
        return r;
    }, g.object = function(n, t) {
        for (var r = {}, e = 0, u = A(n); e < u; e++) t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r;
    }, g.findIndex = r(1), g.findLastIndex = r(-1), g.sortedIndex = function(n, t, r, e) {
        for (var u = (r = b(r, e, 1))(t), i = 0, o = A(n); i < o; ) {
            var a = Math.floor((i + o) / 2);
            r(n[a]) < u ? i = a + 1 : o = a;
        }
        return i;
    }, g.indexOf = e(1, g.findIndex, g.sortedIndex), g.lastIndexOf = e(-1, g.findLastIndex), 
    g.range = function(n, t, r) {
        null == t && (t = n || 0, n = 0), r = r || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = Array(e), i = 0; i < e; i++, 
        n += r) u[i] = n;
        return u;
    };
    var F = function(n, t, r, e, u) {
        if (!(e instanceof t)) return n.apply(r, u);
        var i = _(n.prototype), o = n.apply(i, u);
        return g.isObject(o) ? o : i;
    };
    g.bind = function(n, t) {
        if (h && n.bind === h) return h.apply(n, f.call(arguments, 1));
        if (!g.isFunction(n)) throw new TypeError("Bind must be called on a function");
        var r = f.call(arguments, 2);
        return function e() {
            return F(n, e, t, this, r.concat(f.call(arguments)));
        };
    }, g.partial = function(n) {
        var t = f.call(arguments, 1);
        return function r() {
            for (var e = 0, u = t.length, i = Array(u), o = 0; o < u; o++) i[o] = t[o] === g ? arguments[e++] : t[o];
            for (;e < arguments.length; ) i.push(arguments[e++]);
            return F(n, r, this, this, i);
        };
    }, g.bindAll = function(n) {
        var t, r, e = arguments.length;
        if (e <= 1) throw new Error("bindAll must be passed function names");
        for (t = 1; t < e; t++) n[r = arguments[t]] = g.bind(n[r], n);
        return n;
    }, g.memoize = function(n, t) {
        var r = function r(e) {
            var u = r.cache, i = "" + (t ? t.apply(this, arguments) : e);
            return g.has(u, i) || (u[i] = n.apply(this, arguments)), u[i];
        };
        return r.cache = {}, r;
    }, g.delay = function(n, t) {
        var r = f.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r);
        }, t);
    }, g.defer = g.partial(g.delay, g, 1), g.throttle = function(n, t, r) {
        var e, u, i, o = null, a = 0;
        r || (r = {});
        var c = function() {
            a = !1 === r.leading ? 0 : g.now(), o = null, i = n.apply(e, u), o || (e = u = null);
        };
        return function() {
            var f = g.now();
            a || !1 !== r.leading || (a = f);
            var l = t - (f - a);
            return e = this, u = arguments, l <= 0 || l > t ? (o && (clearTimeout(o), o = null), 
            a = f, i = n.apply(e, u), o || (e = u = null)) : o || !1 === r.trailing || (o = setTimeout(c, l)), 
            i;
        };
    }, g.debounce = function(n, t, r) {
        var e, u, i, o, a, c = function c() {
            var f = g.now() - o;
            f < t && f >= 0 ? e = setTimeout(c, t - f) : (e = null, r || (a = n.apply(i, u), 
            e || (i = u = null)));
        };
        return function() {
            i = this, u = arguments, o = g.now();
            var f = r && !e;
            return e || (e = setTimeout(c, t)), f && (a = n.apply(i, u), i = u = null), a;
        };
    }, g.wrap = function(n, t) {
        return g.partial(t, n);
    }, g.negate = function(n) {
        return function() {
            return !n.apply(this, arguments);
        };
    }, g.compose = function() {
        var n = arguments, t = n.length - 1;
        return function() {
            for (var r = t, e = n[t].apply(this, arguments); r--; ) e = n[r].call(this, e);
            return e;
        };
    }, g.after = function(n, t) {
        return function() {
            if (--n < 1) return t.apply(this, arguments);
        };
    }, g.before = function(n, t) {
        var r;
        return function() {
            return --n > 0 && (r = t.apply(this, arguments)), n <= 1 && (t = null), r;
        };
    }, g.once = g.partial(g.before, 2);
    var E = !{
        toString: null
    }.propertyIsEnumerable("toString"), I = [ "valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString" ];
    g.keys = function(n) {
        if (!g.isObject(n)) return [];
        if (v) return v(n);
        var t = [];
        for (var r in n) g.has(n, r) && t.push(r);
        return E && u(n, t), t;
    }, g.allKeys = function(n) {
        if (!g.isObject(n)) return [];
        var t = [];
        for (var r in n) t.push(r);
        return E && u(n, t), t;
    }, g.values = function(n) {
        for (var t = g.keys(n), r = t.length, e = Array(r), u = 0; u < r; u++) e[u] = n[t[u]];
        return e;
    }, g.mapObject = function(n, t, r) {
        t = b(t, r);
        for (var e, u = g.keys(n), i = u.length, o = {}, a = 0; a < i; a++) o[e = u[a]] = t(n[e], e, n);
        return o;
    }, g.pairs = function(n) {
        for (var t = g.keys(n), r = t.length, e = Array(r), u = 0; u < r; u++) e[u] = [ t[u], n[t[u]] ];
        return e;
    }, g.invert = function(n) {
        for (var t = {}, r = g.keys(n), e = 0, u = r.length; e < u; e++) t[n[r[e]]] = r[e];
        return t;
    }, g.functions = g.methods = function(n) {
        var t = [];
        for (var r in n) g.isFunction(n[r]) && t.push(r);
        return t.sort();
    }, g.extend = x(g.allKeys), g.extendOwn = g.assign = x(g.keys), g.findKey = function(n, t, r) {
        t = b(t, r);
        for (var e, u = g.keys(n), i = 0, o = u.length; i < o; i++) if (e = u[i], t(n[e], e, n)) return e;
    }, g.pick = function(n, t, r) {
        var e, u, i = {}, o = n;
        if (null == o) return i;
        g.isFunction(t) ? (u = g.allKeys(o), e = m(t, r)) : (u = k(arguments, !1, !1, 1), 
        e = function(n, t, r) {
            return t in r;
        }, o = Object(o));
        for (var a = 0, c = u.length; a < c; a++) {
            var f = u[a], l = o[f];
            e(l, f, o) && (i[f] = l);
        }
        return i;
    }, g.omit = function(n, t, r) {
        if (g.isFunction(t)) t = g.negate(t); else {
            var e = g.map(k(arguments, !1, !1, 1), String);
            t = function(n, t) {
                return !g.contains(e, t);
            };
        }
        return g.pick(n, t, r);
    }, g.defaults = x(g.allKeys, !0), g.create = function(n, t) {
        var r = _(n);
        return t && g.extendOwn(r, t), r;
    }, g.clone = function(n) {
        return g.isObject(n) ? g.isArray(n) ? n.slice() : g.extend({}, n) : n;
    }, g.tap = function(n, t) {
        return t(n), n;
    }, g.isMatch = function(n, t) {
        var r = g.keys(t), e = r.length;
        if (null == n) return !e;
        for (var u = Object(n), i = 0; i < e; i++) {
            var o = r[i];
            if (t[o] !== u[o] || !(o in u)) return !1;
        }
        return !0;
    };
    var M = function n(r, e, u, i) {
        if (r === e) return 0 !== r || 1 / r == 1 / e;
        if (null == r || null == e) return r === e;
        r instanceof g && (r = r._wrapped), e instanceof g && (e = e._wrapped);
        var o = l.call(r);
        if (o !== l.call(e)) return !1;
        switch (o) {
          case "[object RegExp]":
          case "[object String]":
            return "" + r == "" + e;

          case "[object Number]":
            return +r != +r ? +e != +e : 0 == +r ? 1 / +r == 1 / e : +r == +e;

          case "[object Date]":
          case "[object Boolean]":
            return +r == +e;
        }
        var a = "[object Array]" === o;
        if (!a) {
            if ("object" != (void 0 === r ? "undefined" : t(r)) || "object" != (void 0 === e ? "undefined" : t(e))) return !1;
            var c = r.constructor, f = e.constructor;
            if (c !== f && !(g.isFunction(c) && c instanceof c && g.isFunction(f) && f instanceof f) && "constructor" in r && "constructor" in e) return !1;
        }
        u = u || [], i = i || [];
        for (var s = u.length; s--; ) if (u[s] === r) return i[s] === e;
        if (u.push(r), i.push(e), a) {
            if ((s = r.length) !== e.length) return !1;
            for (;s--; ) if (!n(r[s], e[s], u, i)) return !1;
        } else {
            var p, v = g.keys(r);
            if (s = v.length, g.keys(e).length !== s) return !1;
            for (;s--; ) if (p = v[s], !g.has(e, p) || !n(r[p], e[p], u, i)) return !1;
        }
        return u.pop(), i.pop(), !0;
    };
    g.isEqual = function(n, t) {
        return M(n, t);
    }, g.isEmpty = function(n) {
        return null == n || (O(n) && (g.isArray(n) || g.isString(n) || g.isArguments(n)) ? 0 === n.length : 0 === g.keys(n).length);
    }, g.isElement = function(n) {
        return !(!n || 1 !== n.nodeType);
    }, g.isArray = p || function(n) {
        return "[object Array]" === l.call(n);
    }, g.isObject = function(n) {
        var r = void 0 === n ? "undefined" : t(n);
        return "function" === r || "object" === r && !!n;
    }, g.each([ "Arguments", "Function", "String", "Number", "Date", "RegExp", "Error" ], function(n) {
        g["is" + n] = function(t) {
            return l.call(t) === "[object " + n + "]";
        };
    }), g.isArguments(arguments) || (g.isArguments = function(n) {
        return g.has(n, "callee");
    }), "function" != typeof /./ && "object" != ("undefined" == typeof Int8Array ? "undefined" : t(Int8Array)) && (g.isFunction = function(n) {
        return "function" == typeof n || !1;
    }), g.isFinite = function(n) {
        return isFinite(n) && !isNaN(parseFloat(n));
    }, g.isNaN = function(n) {
        return g.isNumber(n) && n !== +n;
    }, g.isBoolean = function(n) {
        return !0 === n || !1 === n || "[object Boolean]" === l.call(n);
    }, g.isNull = function(n) {
        return null === n;
    }, g.isUndefined = function(n) {
        return void 0 === n;
    }, g.has = function(n, t) {
        return null != n && s.call(n, t);
    }, g.noConflict = function() {
        return root._ = previousUnderscore, this;
    }, g.identity = function(n) {
        return n;
    }, g.constant = function(n) {
        return function() {
            return n;
        };
    }, g.noop = function() {}, g.property = j, g.propertyOf = function(n) {
        return null == n ? function() {} : function(t) {
            return n[t];
        };
    }, g.matcher = g.matches = function(n) {
        return n = g.extendOwn({}, n), function(t) {
            return g.isMatch(t, n);
        };
    }, g.times = function(n, t, r) {
        var e = Array(Math.max(0, n));
        t = m(t, r, 1);
        for (var u = 0; u < n; u++) e[u] = t(u);
        return e;
    }, g.random = function(n, t) {
        return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1));
    }, g.now = Date.now || function() {
        return new Date().getTime();
    };
    var N = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "`": "&#x60;"
    }, B = g.invert(N), T = function(n) {
        var t = function(t) {
            return n[t];
        }, r = "(?:" + g.keys(n).join("|") + ")", e = RegExp(r), u = RegExp(r, "g");
        return function(n) {
            return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, t) : n;
        };
    };
    g.escape = T(N), g.unescape = T(B), g.result = function(n, t, r) {
        var e = null == n ? void 0 : n[t];
        return void 0 === e && (e = r), g.isFunction(e) ? e.call(n) : e;
    };
    var R = 0;
    g.uniqueId = function(n) {
        var t = ++R + "";
        return n ? n + t : t;
    }, g.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var q = /(.)^/, K = {
        "'": "'",
        "\\": "\\",
        "\r": "r",
        "\n": "n",
        "\u2028": "u2028",
        "\u2029": "u2029"
    }, z = /\\|'|\r|\n|\u2028|\u2029/g, D = function(n) {
        return "\\" + K[n];
    };
    g.template = function(n, t, r) {
        !t && r && (t = r), t = g.defaults({}, t, g.templateSettings);
        var e = RegExp([ (t.escape || q).source, (t.interpolate || q).source, (t.evaluate || q).source ].join("|") + "|$", "g"), u = 0, i = "__p+='";
        n.replace(e, function(t, r, e, o, a) {
            return i += n.slice(u, a).replace(z, D), u = a + t.length, r ? i += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'" : e ? i += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : o && (i += "';\n" + o + "\n__p+='"), 
            t;
        }), i += "';\n", t.variable || (i = "with(obj||{}){\n" + i + "}\n"), i = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", i);
        } catch (n) {
            throw n.source = i, n;
        }
        var a = function(n) {
            return o.call(this, n, g);
        }, c = t.variable || "obj";
        return a.source = "function(" + c + "){\n" + i + "}", a;
    }, g.chain = function(n) {
        var t = g(n);
        return t._chain = !0, t;
    };
    var L = function(n, t) {
        return n._chain ? g(t).chain() : t;
    };
    g.mixin = function(n) {
        g.each(g.functions(n), function(t) {
            var r = g[t] = n[t];
            g.prototype[t] = function() {
                var n = [ this._wrapped ];
                return c.apply(n, arguments), L(this, r.apply(g, n));
            };
        });
    }, g.mixin(g), g.each([ "pop", "push", "reverse", "shift", "sort", "splice", "unshift" ], function(n) {
        var t = i[n];
        g.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments), "shift" !== n && "splice" !== n || 0 !== r.length || delete r[0], 
            L(this, r);
        };
    }), g.each([ "concat", "join", "slice" ], function(n) {
        var t = i[n];
        g.prototype[n] = function() {
            return L(this, t.apply(this._wrapped, arguments));
        };
    }), g.prototype.value = function() {
        return this._wrapped;
    }, g.prototype.valueOf = g.prototype.toJSON = g.prototype.value, g.prototype.toString = function() {
        return "" + this._wrapped;
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return g;
    });
}).call(void 0);