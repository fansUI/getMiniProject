var t = getApp(), n = "https://hz.j6yx.com/phb/myh5htbphb.php";

t.globalData.TEST && (n = "http://windroid.xyz:8081");

var o = function(n, o) {
    wx.cloud || o("wx.cloud err."), wx.cloud.database().collection("ranklist").orderBy("time", "desc").limit(1).get().then(function(o) {
        console.log(o.data[0]._id + " : " + o.data[0].time), console.log(o.data[0].list), 
        t.globalData.ranklist = o.data[0].list, t.globalData.ranklist.forEach(function(t, n) {
            void 0 != t.team && (t.teamLogoName = t.team.replace(/\s+/g, "").toLowerCase());
        }), t.globalData.time = o.data[0].time, n("ok");
    }).catch(function(t) {
        o(t);
    });
}, e = function(t, n) {
    i = !0, wx.login({
        success: function(t) {}
    });
}, i = !1, a = function(n) {
    return new Promise(function(n, o) {
        if (1 == i) return console.log("logining"), void n("doing");
        try {
            var a = wx.getStorageSync("openid");
            a ? (console.log(a), t.globalData.openid = a, n(a)) : e();
        } catch (t) {
            console.log(t), c("ERROR", "getStorageSync", t), e();
        }
        wx.checkSession({
            success: function() {
                console.log("session_key available"), void 0 == t.globalData.openid || "" == t.globalData.openid || n(t.globalData.openid);
            },
            fail: function() {
                console.log("session_key unavailable"), e();
            }
        });
    });
}, c = function(t, n, o, e, i) {
    return new Promise(function(t, n) {});
};

module.exports = {
    getList: function() {
        return new Promise(function(e, i) {
            wx.request({
                url: n,
                data: {
                    sign: "2"
                },
                header: {
                    "content-type": "application/json"
                },
                success: function(n) {
                    console.log(n.data);
                    var a = n.data.list;
                    void 0 != a ? (a.forEach(function(t, n) {
                        void 0 != t.team && (t.teamLogoName = t.team.replace(/\s+/g, "").toLowerCase());
                    }), t.globalData.ranklist = a, t.globalData.time = n.data.time, e("ok")) : o(e, i);
                },
                fail: function(t) {
                    console.log(t), o(e, i);
                }
            });
        });
    },
    getInfoList: function(t, n) {
        return new Promise(function(t, n) {});
    },
    getUser: function(t, n) {},
    getHotlist: function() {},
    formatTime: function(t, n) {
        var o = new Date(t), e = {
            "M+": o.getMonth() + 1,
            "d+": o.getDate(),
            "h+": o.getHours(),
            "m+": o.getMinutes(),
            "s+": o.getSeconds(),
            "q+": Math.floor((o.getMonth() + 3) / 3),
            "S+": o.getMilliseconds()
        };
        /(y+)/i.test(n) && (n = n.replace(RegExp.$1, (o.getFullYear() + "").substr(4 - RegExp.$1.length)));
        for (var i in e) new RegExp("(" + i + ")").test(n) && (n = n.replace(RegExp.$1, 1 == RegExp.$1.length ? e[i] : ("00" + e[i]).substr(("" + e[i]).length)));
        return n;
    },
    sendLike: function(t, n) {},
    doLogin: a,
    waitLogin: function() {
        return new Promise(function(t, n) {
            function o(e) {
                a().then(function(i) {
                    "doing" != i ? t(i) : (0 == e ? n("dologin cnt 5") : setTimeout(o, 1e3, e - 1), 
                    console.log("waitLogin: " + i));
                }).catch(function(t) {
                    0 == e ? n(t) : setTimeout(o, 1e3, e - 1), console.log(t);
                });
            }
            o(5);
        });
    },
    deepLogin: function(t) {},
    getMyinfo: function() {},
    sendFeedback: function(t, n, o) {},
    sendTick: c,
    getGamelist: function(t, n) {},
    getStartype: function(t, n) {},
    setStartype: function(t, n, o) {},
    getStarlist: function() {},
    getTeamPlayerlist: function() {},
    getSidById: function(t) {},
    getInfoTip: function() {
        return new Promise(function(t, o) {
            wx.request({
                url: n,
                data: {
                    sign: "1"
                },
                header: {
                    "content-type": "application/json"
                },
                success: function(n) {
                    "ok" == n.data.msg ? (console.log(n.data), t(n.data)) : (console.log("err: " + n.data), 
                    o("err"));
                },
                fail: function(t) {
                    console.log(t), o(t);
                }
            });
        });
    },
    sendRefresh: function(t) {},
    getMatch: function() {},
    overTask: function(t) {}
};