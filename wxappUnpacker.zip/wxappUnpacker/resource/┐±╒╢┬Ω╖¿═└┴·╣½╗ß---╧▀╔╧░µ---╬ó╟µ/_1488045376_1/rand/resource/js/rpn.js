function e(e) {
    return "+-*/()×÷".indexOf(e) > -1;
}

function r(e) {
    return "-" == e || "+" == e ? 1 : "*" == e || "/" == e || "×" == e || "÷" == e ? 2 : 0;
}

function n(e, n) {
    return r(e) <= r(n);
}

function t(r) {
    var t = [], p = [], u = [], o = !1;
    r.replace(/\s/g, ""), e(r[0]) && (r = r.substring(1), o = !0);
    for (var s = 0, f = r.length; s < f; s++) e(r[s]) || e(r[s - 1]) || 0 == s ? t.push(r[s]) : t[t.length - 1] = t[t.length - 1] + r[s] + "";
    for (o && (t[0] = -t[0]); t.length > 0; ) {
        var i = t.shift();
        if (e(i)) if ("(" == i) p.push(i); else if (")" == i) for (var l = p.pop(); "(" != l && p.length > 0; ) u.push(l), 
        l = p.pop(); else {
            for (;n(i, p[p.length - 1]) && p.length > 0; ) u.push(p.pop());
            p.push(i);
        } else u.push(Number(i));
    }
    if (p.length > 0) for (;p.length > 0; ) u.push(p.pop());
    return u;
}

function p(r) {
    for (var n = [], t = 0, p = r.length; t < p; t++) if (e(r[t])) {
        var u = n.pop(), o = n.pop();
        if ("-" == r[t]) s = o - u; else if ("+" == r[t]) s = o + u; else if ("*" == r[t] || "×" == r[t]) s = o * u; else if ("/" == r[t] || "÷" == r[t]) var s = o / u;
        n.push(s);
    } else n.push(r[t]);
    return n[0];
}

module.exports = {
    isOperator: e,
    getPrioraty: r,
    outputRpn: t,
    calRpnExp: p,
    calCommonExp: function(e) {
        return p(t(e));
    }
};