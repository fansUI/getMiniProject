var a = {
    getIndexDataUrl: "entry/wxapp/index",
    saveMinpTypeUrl: "entry/wxapp/saveMinpType",
    saveJumpMinpUrl: "entry/wxapp/saveJumpMinp",
    getClassDataUrl: "entry/wxapp/classData",
    getRuleDataUrl: "entry/wxapp/ruleData",
    saveUserInfoUrl: "entry/wxapp/saveUserInfo",
    getUserDataUrl: "entry/wxapp/personal",
    getSignDataUrl: "entry/wxapp/signData",
    ReceiveRewardUrl: "entry/wxapp/receiveReward",
    doSignTodaysUrl: "entry/wxapp/sign",
    getRecordDataUrl: "entry/wxapp/recordData",
    getLuckDataUrl: "entry/wxapp/luckData",
    getLuckAwardUrl: "entry/wxapp/luckAward",
    getLatelyUsedDataUrl: "entry/wxapp/LatelyUsed",
    getWithdrawUrl: "entry/wxapp/withdraw",
    saveActWithdrawUrl: "entry/wxapp/actWithdraw"
};

module.exports = a;