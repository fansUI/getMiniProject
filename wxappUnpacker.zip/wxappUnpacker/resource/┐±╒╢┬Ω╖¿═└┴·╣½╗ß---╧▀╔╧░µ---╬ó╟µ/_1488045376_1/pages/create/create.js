var e = getApp(), t = require("../../utils/bmob.js");

Page({
    data: {
        name: "",
        phone: "",
        job: "",
        userInfo: {}
    },
    onLoad: function(t) {
        var n = this;
        wx.getUserInfo({
            success: function(t) {
                e.globalData.userInfo = t.userInfo, n.setData({
                    userInfo: t.userInfo
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    inputName: function(e) {
        this.setData({
            name: e.detail.value
        });
    },
    inputPhone: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    inputJob: function(e) {
        this.setData({
            job: e.detail.value
        });
    },
    handleSaveTap: function(e) {
        if ("" !== this.data.name) if ("" !== this.data.phone) {
            console.log("return:");
            var n = new (t.Object.extend("Student"))();
            n.set("name", this.data.name), n.set("phone", this.data.phone), n.set("job", this.data.job), 
            n.set("nickName", this.data.userInfo.nickName), n.set("gender", this.data.userInfo.gender + ""), 
            n.set("city", this.data.userInfo.city), n.set("avatarUrl", this.data.userInfo.avatarUrl), 
            n.save(null, {
                success: function(e) {
                    console.log("提交个人信息成功, objectId:" + e.id);
                },
                error: function(e, t) {
                    console.log("提交个人信息失败");
                }
            }), wx.showLoading({
                title: "开启ヾ(❀╹◡╹)ﾉ~..."
            }), setTimeout(function() {
                wx.hideLoading(), wx.navigateBack();
            }, 1e3);
        } else wx.showToast({
            title: "请输入电话号码",
            icon: "none",
            duration: 2e3
        }); else wx.showToast({
            title: "请输入姓名",
            icon: "none",
            duration: 2e3
        });
    }
});