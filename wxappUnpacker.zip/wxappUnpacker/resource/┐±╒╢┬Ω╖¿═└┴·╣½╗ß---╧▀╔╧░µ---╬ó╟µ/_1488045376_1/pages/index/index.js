var e, n = getApp(), t = require("../../utils/bmob.js");

Page({
    data: {
        motto: "Hello World",
        userInfo: {},
        hasUserInfo: !1,
        canIUse: wx.canIUse("button.open-type.getUserInfo"),
        completeInfo: !1,
        students: []
    },
    bindViewTap: function() {
        wx.navigateTo({
            url: "../logs/logs"
        });
    },
    onLoad: function() {
        e = this, n.globalData.userInfo ? (this.setData({
            userInfo: n.globalData.userInfo,
            hasUserInfo: !0
        }), console.log("1")) : (this.data.canIUse, e.getUserInfo());
    },
    getUserInfo: function() {
        var t = this;
        e.data.hasUserInfo || wx.getUserInfo({
            success: function(e) {
                n.globalData.userInfo = e.userInfo, t.setData({
                    userInfo: e.userInfo,
                    hasUserInfo: !0
                });
            }
        });
    },
    onShow: function() {
        e.checkCompleteInfo(), e.loadStudents();
    },
    completeInfo: function(e) {
        wx.navigateTo({
            url: "../create/create"
        });
    },
    updateComplete: function(n) {
        e.setData({
            completeInfo: n
        });
    },
    checkCompleteInfo: function() {
        var n = t.Object.extend("Student"), o = new t.Query(n);
        o.equalTo("nickName", e.data.userInfo.nickName), o.find({
            success: function(n) {
                null != n[0].get("phone") && e.updateComplete(!0);
            },
            error: function(n, t) {
                console.log("error"), e.updateComplete(!1);
            }
        });
    },
    loadStudents: function() {
        var n = t.Object.extend("Student");
        new t.Query(n).find({
            success: function(n) {
                e.setData({
                    students: n
                });
            },
            error: function(e) {
                console.log("查询失败: " + e.code + " " + e.message);
            }
        });
    },
    itemClick: function(e) {
        var n = e.currentTarget.dataset;
        wx.addPhoneContact({
            nickName: n.nickname,
            firstName: n.name,
            mobilePhoneNumber: n.phone,
            addressCity: n.city,
            title: n.job
        });
    },
    openSetting: function() {
        e.data.hasUserInfo || wx.openSetting({
            success: function(e) {}
        });
    },
    onShareAppMessage: function(e) {}
});