Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        showModal: {
            type: Boolean,
            value: !1
        },
        showTitle: {
            type: Boolean,
            value: !0
        },
        showClose: {
            type: Boolean,
            value: !0
        },
        dialogTitle: {
            type: String,
            value: "测试标题"
        }
    },
    data: {},
    methods: {
        closeTk: function(e) {
            this.setData({
                showModal: !1
            }), this.triggerEvent("close", e);
        }
    }
});