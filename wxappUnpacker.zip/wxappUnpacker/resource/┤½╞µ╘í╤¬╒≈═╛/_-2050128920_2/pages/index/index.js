var t = getApp(), e = require("../../tools/wxParse/wxParse.js");

Page({
    data: {
        banner_list: [],
        service_list: [ "假一赔三", "货到付款", "7天退货", "消费者保障服务" ],
        score_list: [ {
            name: "用户口碑",
            score: 4.73
        }, {
            name: "服务态度",
            score: 4.57
        }, {
            name: "发货速度",
            score: 4.75
        } ],
        swiper_num: 0,
        customer_list: [ {
            title: "我的订单如何查询？",
            content: "请您登录今日头条App，点击右上角“放心购”进入放心购频道，然后点击“我的订单”；或者点击左上角您的头像，然后选择“我的钱包”，再点击“放心购”，选择“我的订单”。",
            show: !1
        }, {
            title: "我的订单大概多久发货？",
            content: "订单的发货时间为您下单之后的72小时内，请您耐心等待。订单状态及物流运转进度可在订单详情中查看，普通地区异地物流运转时间3-5天左右，偏远地区异地物流运转时间5-7天左右，如遇特殊情况将会导致延误，以物流官网进度为准。若您的订单超出72小时仍未发货，建议您联系商家进行咨询。",
            show: !1
        }, {
            title: "我的订单如何查询物流进度？",
            content: "若您需要查看订单发货状态以及物流进度，请您登录今日头条App，点击右上角“放心购”进入放心购频道，然后点击“我的订单”；或者点击左上角您的头像，然后选择“我的钱包”，再点击“放心购”，选择“我的订单”，然后在订单详情中查询相应的物流信息。也可以通过查看订单发货后手机短信通知中物流名称以及物流单号，在对应的物流官网查询运转进度。",
            show: !1
        }, {
            title: "商品不满意，想退货怎么办？",
            content: "您的订单支持7天退换货尊享服务（若商家和顾客另有约定，已约定的退换货服务为准）。未签收：若您验收时对商品不满意，无需支付任何费用，将商品拒签，快递员带回即可，不用对订单进行任何操作。已签收：若您已签收商品，需办理退货，请先将订单操作“确认收货”，再发起“申请退货”，申请后等待商家处理，商家同意后会有手机短信通知您退货信息，请您按照退货地址将商品退回，并向商家提供商品寄回有效物流单号。退货要求：保证商品全新，不影响二次销售，商品包装完好，附件、赠品齐全。在退货包裹中放置小纸条注明您的联系方式、订单号及退款账号（支付宝号/微信号/银行卡号），禁止使用“到付”运费支付形式将商品寄回。若商家拒绝退货申请，平台客服将介入处理。同时请您及时联系商家协商退货事宜。（注：为保护您及其他顾客的利益，酒、生鲜商品、内衣、奶粉、个人定制商品不属于退换货范围，若经权威检测，确定有质量问题，我们将按相关法规进行处理）",
            show: !1
        }, {
            title: "我的订单如何申请换货?",
            content: "若您需办理换货，无需对订单进行任何操作，请您及时联系商家协商换货事宜，向商家索取商品寄回地址信息，将商品寄回至商家处，并向商家提供商品寄回有效物流单号，由商家为您安排换货。换货要求：保证商品全新，不影响二次销售，商品包装完好，附件、赠品齐全。在寄回包裹中放置小纸条注明您的联系方式、订单号，禁止使用“到付”运费支付形式将商品寄回。",
            show: !1
        }, {
            title: "如何查看商家联系方式？",
            content: "若您还未下单，您可在商品推广页面最下方，点击【咨询】致电商家进行咨询。若您已下单，请您登录今日头条App，点击右上角“放心购”进入放心购频道，然后点击“我的订单”；或者点击左上角您的头像，然后选择“我的钱包”，再点击“放心购”，选择“我的订单”，在订单详情中查看“商家电话”或查看订单发货后手机短信通知中商家联系方式。",
            show: !1
        }, {
            title: "价格说明",
            content: "划线价格：指商品的专柜价，吊牌价，正品零售价，厂商指导价或该商品曾经展示的售卖价，并非原价，仅供参考。未划线价格：指商品的实时标价，不因表述的差异改变性质。具体成交价格根据商品参加活动或者会员试用优惠券、积分等发生变化，最终以订单结算价格为准。",
            show: !1
        }, {
            title: "如何修改评价？",
            content: "当用户发表评价为中差评时，在首次发表评价后的30天内，支持在”我的订单-评价“下进入指定评价中，对评价内容进行修改。30天后，评价入口将隐藏，不再支持修改评价。",
            show: !1
        } ],
        select_list: [],
        select_index: -1,
        price: !1,
        user_name: null,
        user_phone: null,
        user_address: null,
        ticket: null,
        buy_num: 1,
        total_price: 0,
        total_price_deg: 0,
        buy_list_height: 0,
        extra: 0,
        goods_info: null,
        big_price: null,
        small_price: null,
        buy_info: {},
        top_wrap_H: 0,
        scrollTop: 0,
        tabbar_show: !0,
        id: null
    },
    swiperChange: function(t) {
        this.setData({
            swiper_num: t.currentTarget.dataset.ac
        });
    },
    selectChange: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.select_list[e];
        if (a.show) if (e == this.data.select_index) this.setData({
            select_index: -1,
            price: !1,
            total_price: 0,
            buy_list_height: 0,
            total_price_deg: 0
        }); else {
            var s = a.price * this.data.buy_num + this.data.extra;
            this.setData({
                select_index: e,
                price: a.price,
                total_price: s
            });
        }
    },
    customerShow: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.customer_list, s = a[e];
        s.show = !s.show, this.setData({
            customer_list: a
        });
    },
    formSubmit: function(t) {
        console.log("form发生了submit事件，携带数据为：", t.detail.value);
    },
    buyListShow: function() {
        this.data.select_index < 0 || (0 == this.data.total_price_deg ? this.setData({
            total_price_deg: 90,
            buy_list_height: 206
        }) : this.setData({
            total_price_deg: 0,
            buy_list_height: 0
        }));
    },
    addBuyNum: function(t) {
        if (!(this.data.select_index < 0)) {
            var e = t.currentTarget.dataset.num;
            e *= 1;
            var a = this.data.buy_num;
            if (!(-1 == e && a <= 1)) {
                a += e;
                var s = this.data.select_index, i = a * this.data.select_list[s].price + this.data.extra;
                this.setData({
                    buy_num: a,
                    total_price: i
                });
            }
        }
    },
    check_form: function(t) {
        var e = t.detail.value, a = t.currentTarget.dataset.name;
        "user_name" == a && this.setData({
            user_name: e
        }), "user_phone" == a && this.setData({
            user_phone: e
        }), this.data.user_name && this.data.user_phone ? this.setData({
            tabbar_show: !1
        }) : this.setData({
            tabbar_show: !0
        });
    },
    buyNow: function(t) {
        var e = this.data.select_index, a = this.data.select_list[e], s = (this.data.buy_num, 
        this.data.total_price, {}), i = t.detail.value.user_name, n = t.detail.value.user_phone, o = /^[1][3,4,5,7,8][0-9]{9}$/.test(n), l = t.detail.value.user_address;
        if (this.data.select_index < 0) wx.showModal({
            title: "您未选择套餐",
            content: "请先选择套餐",
            showCancel: !1
        }); else if (i.length >= 20 || 0 == i.length) wx.showModal({
            title: "收货人名字格式错误",
            content: "收货人不能为空并且文字长度不得大于20个字符",
            showCancel: !1
        }); else if (o) if (0 != l.length) {
            s.product_id = this.data.goods_info.id, s.img = this.data.banner_list[0], s.name = this.data.goods_info.name, 
            s.select_item = a, s.num = this.data.buy_num, s.price = this.data.total_price, s.consignee = t.detail.value.user_name, 
            s.connect = t.detail.value.user_phone, s.address = t.detail.value.user_address, 
            s.message = t.detail.value.user_message;
            var r = JSON.stringify(s);
            wx.navigateTo({
                url: "../buylist/index?info=" + r
            }), console.log(s);
        } else wx.showModal({
            title: "您未输入收货地址",
            content: "请输入详细收货地址",
            showCancel: !1
        }); else wx.showModal({
            title: "手机号输入有误",
            content: "请输入正确的11位手机号码",
            showCancel: !1
        });
    },
    gotoBuy: function() {
        this.setData({
            scrollTop: 2e4
        });
    },
    onLoad: function(a) {
        console.log(a);
        var s = this, i = a.id;
        this.setData({
            id: a.id
        }), wx.request({
            url: t.domain + "/index.php?g=Wap&m=Mwxaapi&a=product_detail&id=" + i,
            success: function(t) {
                var a = s;
                console.log("goods_info", t);
                var i = 0, n = 0, o = t.data.data;
                e.wxParse("article", "html", o.content, s, 5);
                for (var l = t.data.data.set_meal.split("\n"), r = 0; r < l.length; r++) {
                    var c = l[r].split(",");
                    0 == r ? (i = c[1], n = c[1]) : c[1] > i ? i = c[1] : c[1] < n && (n = c[1]);
                    var u = {};
                    u.name = c[0], u.price = c[1], u.show = !0, l[r] = u;
                }
                s.setData({
                    select_list: l,
                    big_price: i,
                    small_price: n
                }), s.setData({
                    goods_info: o
                });
                var d = o.image.split(",");
                s.setData({
                    banner_list: d
                });
                var h = 0;
                wx.createSelectorQuery().select(".top_wrap").boundingClientRect(function(t) {
                    console.log(t), h = t.height, a.setData({
                        top_wrap_H: t.height
                    }), console.log(a.data.top_wrap_H);
                }).exec();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this;
        return {
            title: t.data.goods_info.name,
            path: "pages/index/index?id=" + t.data.id,
            success: function(t) {
                t.shareTickets;
            },
            fail: function(t) {}
        };
    }
});