var e = getApp();

Page({
    data: {
        info: null,
        ios_show: !1
    },
    pay_feature: function() {
        var a = this.data.info, n = {
            product_id: a.product_id,
            num: a.num,
            name: a.name,
            consignee: a.consignee,
            connect: a.connect,
            address: a.address,
            price: a.price,
            message: a.message,
            set_meal: a.select_item.name + "," + a.select_item.price,
            cash_on_delivery: 1
        };
        console.log(n), wx.request({
            url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=submit_order",
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: n,
            success: function() {
                wx.navigateTo({
                    url: "../buysuccess/index?cash_on_delivery=1"
                });
            }
        });
    },
    pay: function() {
        var a = this;
        if (e.is_ios) this.setData({
            ios_show: !0
        }); else {
            var n = {
                type: "book_point",
                price: this.data.info.price,
                payment_id: "1",
                point: "1"
            };
            wx.request({
                url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=payment&session_3rd=" + e.session_3rd,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                data: n,
                success: function(n) {
                    if (1001 == n.data.status && n.data.data && JSON.parse(n.data.data)) {
                        var t = JSON.parse(n.data.data);
                        console.log("data", t);
                        t.package.replace("prepay_id=", "");
                        wx.requestPayment({
                            timeStamp: t.timeStamp,
                            nonceStr: t.nonceStr,
                            package: t.package,
                            signType: "MD5",
                            paySign: t.paySign,
                            success: function(n) {
                                wx.showLoading({
                                    title: "支付加载中..."
                                });
                                var t = a.data.info, o = {
                                    product_id: t.product_id,
                                    num: t.num,
                                    name: t.name,
                                    consignee: t.consignee,
                                    connect: t.connect,
                                    address: t.address,
                                    price: t.price,
                                    message: t.message,
                                    set_meal: t.select_item.name + "," + t.select_item.price,
                                    cash_on_delivery: 0
                                };
                                wx.request({
                                    url: e.domain + "/index.php?g=Wap&m=Mwxaapi&a=submit_order",
                                    method: "POST",
                                    header: {
                                        "content-type": "application/x-www-form-urlencoded"
                                    },
                                    data: o,
                                    success: function() {
                                        this.data.info.wp_address ? wx.navigateTo({
                                            url: "../buysuccess/index?cash_on_delivery=2&title=" + this.data.info.wp_address
                                        }) : wx.navigateTo({
                                            url: "../buysuccess/index?cash_on_delivery=0"
                                        });
                                    }
                                });
                            },
                            fail: function(e) {
                                wx.showToast({
                                    title: "已取消支付",
                                    icon: "loading",
                                    duration: 1e3
                                });
                            }
                        });
                    }
                }
            });
        }
    },
    copy: function() {
        var a = this;
        wx.setClipboardData({
            data: e.kf_info.kf,
            success: function(n) {
                wx.showToast({
                    title: e.kf_info.name,
                    icon: "none",
                    duration: 1e3
                }), a.setData({
                    ios_show: !1
                });
            }
        });
    },
    onLoad: function(e) {
        var a = JSON.parse(e.info);
        this.setData({
            info: a
        }), console.log(a);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});