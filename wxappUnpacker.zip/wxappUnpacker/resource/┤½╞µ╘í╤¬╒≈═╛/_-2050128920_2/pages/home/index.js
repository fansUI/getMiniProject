var t = getApp();

Page({
    data: {
        tabindex: 0,
        tablist: [ {
            name: "首页",
            classname: "icon-home",
            path: "../home/index"
        }, {
            name: "个人",
            classname: "icon-user",
            path: "../mine/index"
        } ],
        product_list: [],
        page: 1,
        data_null: !1
    },
    onLoad: function() {
        this.getproduct_list();
    },
    getproduct_list: function() {
        if (!this.data.data_null) {
            var a = this, e = this.data.page;
            wx.request({
                url: t.domain + "/index.php?g=Wap&m=Mwxaapi&a=product_list&page=" + e,
                method: "get",
                success: function(e) {
                    if (console.log("---------------", e), e.data.data) {
                        for (var i = e.data.data, s = 0; s < i.length; s++) {
                            var o = i[s].image.split(",");
                            i[s].image = o;
                            for (var l = 0, n = 0, c = i[s].set_meal.split("\n"), d = 0; d < c.length; d++) {
                                var p = c[d].split(",");
                                0 == d ? (l = p[1], n = p[1]) : p[1] > l ? l = p[1] : p[1] < n && (n = p[1]);
                                var r = {};
                                r.name = p[0], r.price = p[1], r.show = !0, c[d] = r;
                            }
                            i[s].big_price = l, i[s].small_price = n;
                        }
                        console.log("product_list", i), i = a.data.product_list.concat(i), a.setData({
                            product_list: i
                        }), t.product_list = i;
                    } else a.setData({
                        data_null: !0
                    });
                    console.log(a.data)
                }
            });
        }
    },
    onReachBottom: function() {
        var t = this.data.page + 1;
        this.setData({
            page: t
        }), this.getproduct_list();
    }
});