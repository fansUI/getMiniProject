function t(t, n, o) {
    return n in t ? Object.defineProperty(t, n, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[n] = o, t;
}

var n, o = getApp();

Page((n = {
    data: {
        kf_info: null,
        title: ""
    },
    bigImg: function(t) {
        var n = this.data.kf_info.img;
        wx.previewImage({
            urls: [ n ]
        });
    },
    copy: function() {
        var t = this;
        wx.setClipboardData({
            data: t.data.kf_info.kf,
            success: function(n) {
                wx.showToast({
                    title: t.data.kf_info.name,
                    icon: "none",
                    duration: 1e3
                });
            }
        });
    },
    gohome: function() {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    onLoad: function(t) {
        console.log(o.kf_info), console.log(t), 1 == t.cash_on_delivery ? this.setData({
            title: "恭喜您货到付款下单成功！"
        }) : 2 == t.cash_on_delivery ? this.setData({
            title: t.title
        }) : this.setData({
            title: "恭喜您支付成功！"
        }), this.setData({
            kf_info: o.kf_info,
            options_data: t
        });
    }
}, t(n, "copy", function() {
    var t = this.data.options_data;
    wx.setClipboardData({
        data: t.title,
        success: function(t) {
            wx.showToast({
                title: "复制成功",
                icon: "none",
                duration: 1e3
            });
        }
    });
}), t(n, "onReady", function() {}), t(n, "onShow", function() {}), t(n, "onHide", function() {}), 
t(n, "onUnload", function() {}), t(n, "onPullDownRefresh", function() {}), t(n, "onReachBottom", function() {}), 
t(n, "onShareAppMessage", function() {}), n));