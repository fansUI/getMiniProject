App({
    appid: "wx3d71509667b90fb8",
    domain: "https://linkj.cn",
    token: "cqyxzt1545039524",
    share_title: "精彩内容，就在传奇浴血征途",
    session_3rd: null,
    host: null,
    is_ios: !1,
    kf_info: null,
    product_list: [],
    onLaunch: function() {
        this.getSystem(), this.nowLogin(), this.getKf();
    },
    nowLogin: function() {
        var e = this;
        wx.login({
            success: function(s) {
                console.log(s.code);
                var n = s.code;
                wx.request({
                    url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=login&token=" + e.token + "&code=" + n,
                    success: function(s) {
                        if (console.log("user_info", s), e.session_3rd = s.data.session_3rd, s.data.userinfo && s.data.userinfo.wecha_id) return e.host = s.data.userinfo, 
                        void wx.setStorage({
                            key: "user_info",
                            data: {
                                session_3rd: e.session_3rd,
                                host: e.host
                            }
                        });
                        wx.getUserInfo({
                            success: function(s) {
                                console.log("---------", s);
                                var n = {
                                    name: s.userInfo.nickName,
                                    portrait: s.userInfo.avatarUrl,
                                    unionid: "",
                                    wecha_id: "",
                                    province: s.userInfo.province,
                                    city: s.userInfo.city,
                                    sex: s.userInfo.gender
                                };
                                e.host = n, wx.getUserInfo({
                                    withCredentials: !0,
                                    success: function(s) {
                                        console.log("userInfo_withCr", s), e.encryptedData = s.encryptedData, e.iv = s.iv, 
                                        e.getUserBySession();
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    getUserBySession: function() {
        var e = this;
        e.session_3rd && e.encryptedData && e.iv && wx.request({
            url: e.domain + "/index.php?g=Wap&m=Wxaapi&a=getunionid",
            method: "GET",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                session_3rd: e.session_3rd,
                encrypted: e.encryptedData,
                iv: e.iv
            },
            success: function(s) {
                s.data && s.data.wecha_id && (e.host.unionid = s.data.unionid, e.host.wecha_id = s.data.wecha_id, 
                console.log(e.host), wx.setStorage({
                    key: "user_info",
                    data: {
                        session_3rd: e.session_3rd,
                        host: e.host
                    }
                }));
            }
        });
    },
    getSystem: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(s) {
                var n = s.model.slice(0, 6);
                e.is_ios = "iPhone" == n;
            }
        });
    },
    getKf: function(e) {
        var s = this;
        wx.request({
            url: this.domain + "/index.php?g=Wap&m=WxaBook&a=get_kf_set&token=" + this.token,
            header: {
                "content-type": "application/json"
            },
            success: function(n) {
                1001 == n.data.status && (s.kf_info = n.data.set, e && e(n));
            }
        });
    }
});