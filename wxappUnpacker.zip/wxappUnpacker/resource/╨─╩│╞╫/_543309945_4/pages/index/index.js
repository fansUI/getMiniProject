var t = require("../../utils/tools");

Page({
    onShareAppMessage: function(t) {
        return {
            title: "心食谱 -- 您身边的美食厨房",
            path: "/page/index/index"
        };
    },
    data: {
        banner: [],
        hotshipu: [],
        xinshipu: [],
        words: []
    },
    onLoad: function(e) {
        var n = this, a = t.myPro({
            url: t.baseUrl + "doGetIndexShipu.html",
            header: {
                "Content-Type": "json"
            }
        });
        Promise.all([ a ]).then(function(t) {
            n.setData({
                banner: t[0].data.banner,
                hotshipu: t[0].data.hotshipu,
                xinshipu: t[0].data.xinshipu
            });
            console.log(n.data.banner)
        }), t.myPro({
            url: t.baseUrl + "doGetSeasonHotDic.html",
            header: {
                "Content-Type": "json"
            }
        }).then(function(t) {
            console.log(t), n.setData({
                words: t.data.words
            });
        });
    }
});