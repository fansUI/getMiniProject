var i = require("../../utils/tools");

Page({
    data: {
        id: "",
        leisi: [],
        shipu: {}
    },
    onShareAppMessage: function(i) {
        return {
            title: "心食谱 -- " + this.data.shipu.shipuName,
            path: "/page/detail/detail?id=" + this.data.shipu.id
        };
    },
    onLoad: function(t) {
        var a = this;
        console.log(t.id), this.setData({
            id: t.id
        }), i.myPro({
            url: i.baseUrl + "doGetZuofa.html?shipuid=" + this.data.id,
            header: {
                "Content-Type": "json"
            }
        }).then(function(i) {
            console.log(i), a.setData({
                shipu: i.data.shipu,
                leisi: i.data.leisi
            });
        });
    }
});