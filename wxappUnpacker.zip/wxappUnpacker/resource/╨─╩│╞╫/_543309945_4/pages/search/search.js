var a = require("../../utils/tools"), t = require("../../utils/list");

Page({
    data: {
        myDataList: t,
        shipuList: [],
        page: 1,
        totalPages: 0,
        searchName: "",
        count: 1
    },
    onShareAppMessage: function(a) {
        return {
            title: "心食谱 -- " + this.data.searchName,
            path: "/pages/search/search?query=" + this.data.searchName
        };
    },
    onLoad: function(t) {
        var e = this;
        console.log(t.query), void 0 != t.query && (this.setData({
            searchName: t.query
        }), a.myPro({
            url: a.baseUrl + "doShipuSearch.html?q=" + encodeURIComponent("" + this.data.searchName),
            data: {
                page: this.data.page
            },
            header: {
                "Content-Type": "json"
            }
        }).then(function(a) {
            console.log(a), e.setData({
                shipuList: a.data.list,
                totalPages: a.data.totalPages
            });
        }));
    },
    search: function(t) {
        var e = this;
        console.log(t), this.data.searchName = t.detail.value, console.log(this.data.searchName), 
        a.myPro({
            url: a.baseUrl + "doShipuSearch.html?q=" + encodeURIComponent("" + this.data.searchName),
            header: {
                "Content-Type": "json"
            }
        }).then(function(a) {
            console.log(a.data), e.setData({
                shipuList: a.data.list,
                totalPages: a.data.totalPages
            });
        });
    },
    onReachBottom: function() {
        var t = this;
        if (wx.stopPullDownRefresh(), this.data.page > this.data.totalPages) wx.showToast({
            title: "后面木有啦!",
            icon: "none",
            image: "",
            duration: 2e3,
            mask: !1,
            success: function(a) {},
            fail: function() {},
            complete: function() {}
        }); else {
            wx.showLoading({
                title: "玩命加载中"
            });
            var e = this.data.page + this.data.count;
            this.setData({
                page: e
            }), console.log("P:" + this.data.page), a.myPro({
                url: a.baseUrl + "doShipuSearch.html?q=" + encodeURIComponent("" + this.data.searchName),
                data: {
                    page: this.data.page
                },
                header: {
                    "Content-Type": "json"
                }
            }).then(function(a) {
                var e = t.data.shipuList;
                e = e.concat(a.data.list), t.setData({
                    shipuList: e,
                    totalPages: a.data.totalPages
                }), wx.hideLoading();
            });
        }
    },
    onPullDownRefresh: function() {
        var t = this;
        console.log("下拉刷新"), this.setData({
            page: 1
        }), a.myPro({
            url: a.baseUrl + "doShipuSearch.html?q=" + this.data.searchName,
            data: {
                page: this.data.page
            },
            header: {
                "Content-Type": "json"
            }
        }).then(function(a) {
            t.setData({
                shipuList: a.data.list,
                totalPages: a.data.totalPages
            }), wx.stopPullDownRefresh();
        });
    }
});