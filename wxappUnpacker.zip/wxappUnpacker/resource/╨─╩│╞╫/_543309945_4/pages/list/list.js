var t = require("../../utils/tools");

Page({
    data: {
        tag: "",
        url: "",
        page: 1,
        shipuList: [],
        totalPages: 0,
        listName: "",
        count: 1
    },
    onShareAppMessage: function(t) {
        return {
            title: "心食谱 -- " + this.data.tag,
            path: "/pages/list/list?tag=" + this.data.tag
        };
    },
    onLoad: function(a) {
        var s = this;
        switch (console.log(a.tag), this.setData({
            tag: a.tag
        }), this.data.tag) {
          case "hot":
            this.setData({
                listName: "热门菜谱",
                url: "doWeeklyhotshipu.html"
            });
            break;

          case "new":
            this.setData({
                listName: "每日食谱",
                url: "doXinshipu.html"
            });
        }
        t.myPro({
            url: t.baseUrl + this.data.url,
            data: {
                page: this.data.page
            },
            header: {
                "Content-Type": "json"
            }
        }).then(function(t) {
            console.log(t), s.setData({
                shipuList: t.data.list,
                totalPages: t.data.totalPages
            });
        });
    },
    onReachBottom: function() {
        var a = this;
        if (wx.stopPullDownRefresh(), this.data.page > this.data.totalPages) wx.showToast({
            title: "后面木有啦!",
            icon: "none",
            image: "",
            duration: 2e3,
            mask: !1,
            success: function(t) {},
            fail: function() {},
            complete: function() {}
        }); else {
            wx.showLoading({
                title: "玩命加载中"
            });
            var s = this.data.page + this.data.count;
            this.setData({
                page: s
            }), console.log("P:" + this.data.page), t.myPro({
                url: t.baseUrl + this.data.url,
                data: {
                    page: this.data.page
                },
                header: {
                    "Content-Type": "json"
                }
            }).then(function(t) {
                var s = a.data.shipuList;
                s = s.concat(t.data.list), a.setData({
                    shipuList: s,
                    totalPages: t.data.totalPages
                }), wx.hideLoading();
            });
        }
    },
    onPullDownRefresh: function() {
        var a = this;
        console.log("下拉刷新"), this.setData({
            page: 1
        }), t.myPro({
            url: t.baseUrl + this.data.url,
            data: {
                page: this.data.page
            },
            header: {
                "Content-Type": "json"
            }
        }).then(function(t) {
            a.setData({
                shipuList: t.data.list,
                totalPages: t.data.totalPages
            }), swan.stopPullDownRefresh();
        });
    }
});