App({
    onLaunch: function(n) {},
    onShow: function(n) {},
    globalData: {
        userInfo: "user"
    }
});