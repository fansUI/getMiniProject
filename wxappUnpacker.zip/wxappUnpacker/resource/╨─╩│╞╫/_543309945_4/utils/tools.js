module.exports = {
    baseUrl: "https://www.xinshipu.com/api/bdapp/",
    myPro: function(e) {
        return new Promise(function(t, a) {
            wx.request({
                url: e.url || "",
                method: e.method || "GET",
                dataType: e.dataType || "json",
                data: e.data || {},
                header: e.header || {
                    "content-type": "application/json"
                },
                success: function(e) {
                    t(e);
                },
                fail: function(e) {
                    a("错误码：" + e.errCode);
                }
            });
        });
    }
};