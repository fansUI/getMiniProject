module.exports = [ {
    color: "rgb(35, 132, 232)",
    title: "猪肉",
    subTitle: "红烧肉、回锅肉"
}, {
    color: "rgb(230, 70, 126)",
    title: "牛肉",
    subTitle: "红烧牛肉"
}, {
    color: "rgb(159, 120, 96)",
    title: "羊肉",
    subTitle: "孜然羊肉"
}, {
    color: "rgb(225, 100, 77)",
    title: "奶制品",
    subTitle: "奶油奶酪"
}, {
    color: "rgb(122, 106, 219)",
    title: "鸡肉",
    subTitle: "鸡翅、鸡腿"
}, {
    color: "rgb(42, 184, 204)",
    title: "鱼肉",
    subTitle: "鲤鱼、草鱼"
}, {
    color: "rgb(87, 116, 197)",
    title: "蛋类",
    subTitle: "鸡蛋、鸭蛋"
}, {
    color: "rgb(64, 207, 169)",
    title: "虾类",
    subTitle: "大虾、虾仁"
}, {
    color: "rgb(159, 120, 96)",
    title: "蔬菜",
    subTitle: "白菜、芹菜"
}, {
    color: "rgb(244, 143, 46)",
    title: "豆类",
    subTitle: "花生、\b链子"
}, {
    color: "rgb(89, 108, 221)",
    title: "豆制品",
    subTitle: "豆腐、豆皮"
}, {
    color: "rgb(66, 189, 86)",
    title: "菌类",
    subTitle: "香菇、蘑菇"
} ];