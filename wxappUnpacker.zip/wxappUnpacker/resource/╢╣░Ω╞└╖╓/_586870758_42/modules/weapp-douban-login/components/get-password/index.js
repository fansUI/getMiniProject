var _const = require("../../const.js");

Component({
    properties: {},
    data: {},
    methods: {
        _getPassword: function() {
            wx.showActionSheet({
                itemList: [ "手机找回", "邮箱找回" ],
                success: function(e) {
                    var t = 0 === e.tapIndex ? "phone" : "email", o = _const.API_DOMAIN + "/passport/get_password?type=" + t + "&env=miniprogram";
                    wx.LOGIN_MA.report("getPassword", {}), wx.navigateTo({
                        url: "../../pages/webview/index?url=" + encodeURIComponent(o)
                    });
                }
            });
        }
    }
});