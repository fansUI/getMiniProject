var _fetch = require("../../utils/fetch.js"), _fetch2 = _interopRequireDefault(_fetch), _const = require("../../const.js"), _asyncStatus = require("../../utils/async-status.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var SUPPORTED_NATIONS_API = "/j/misc/supported_nations";

Component({
    properties: {
        selectedCode: {
            type: String,
            value: "+86"
        }
    },
    data: {
        status: _asyncStatus.DEFAULT,
        list: [],
        selectedCode: null
    },
    methods: {
        selectHandle: function(t) {
            var e = t.currentTarget.dataset.item;
            this.triggerEvent("areaSelected", {
                selected: e
            });
        },
        _fetchData: function() {
            var s = this;
            this.setData({
                status: _asyncStatus.PENDING
            }), _fetch2.default.get("" + _const.API_DOMAIN + SUPPORTED_NATIONS_API).then(function(t) {
                var e = t.data;
                s.setData({
                    status: _asyncStatus.SUCCESS,
                    list: e
                });
            }).catch(function(t) {
                s.setData({
                    status: _asyncStatus.FAIL
                });
            });
        }
    },
    attached: function() {
        var t = this.properties.selectedCode, e = this.data.list;
        this.setData({
            selectedCode: t
        }), e && 0 !== e.length || this._fetchData();
    }
});