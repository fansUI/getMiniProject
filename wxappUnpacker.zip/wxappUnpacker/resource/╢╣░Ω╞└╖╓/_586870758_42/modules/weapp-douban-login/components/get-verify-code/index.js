var _TEXT_LIST, _properties, _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (t[a] = r[a]);
    }
    return t;
}, _asyncStatus = require("../../utils/async-status.js"), _const = require("../../const.js"), _fetch = require("../../utils/fetch.js"), _fetch2 = _interopRequireDefault(_fetch);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _defineProperty(t, e, r) {
    return e in t ? Object.defineProperty(t, e, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = r, t;
}

var PHONE_CODE_API = "/j/wxa/login/request_phone_code", TEXT_LIST = (_defineProperty(_TEXT_LIST = {}, _asyncStatus.DEFAULT, "获取验证码"), 
_defineProperty(_TEXT_LIST, _asyncStatus.PENDING, "正在获取"), _defineProperty(_TEXT_LIST, _asyncStatus.SUCCESS, "获取成功"), 
_defineProperty(_TEXT_LIST, _asyncStatus.FAIL, "获取失败"), _TEXT_LIST);

Component({
    properties: (_properties = {
        appid: {
            type: String,
            required: !0
        },
        area_code: {
            type: String
        },
        number: {
            type: String
        }
    }, _defineProperty(_properties, "appid", {
        type: String
    }), _defineProperty(_properties, "timer", {
        type: Number,
        value: 60
    }), _defineProperty(_properties, "autoGetCode", {
        type: Boolean,
        value: !1,
        observer: "autoGetVerifyCode"
    }), _defineProperty(_properties, "captcha_solution", {
        type: String
    }), _defineProperty(_properties, "captcha_id", {
        type: String
    }), _defineProperty(_properties, "ticket", {
        type: String
    }), _defineProperty(_properties, "randstr", {
        type: String
    }), _properties),
    data: {
        text: TEXT_LIST[_asyncStatus.DEFAULT],
        status: _asyncStatus.DEFAULT,
        needCaptcha: !1,
        captchaPayload: null,
        time: 0
    },
    methods: {
        getCode: function() {
            var s = this;
            wx.LOGIN_MA.report("requestPhoneCode", {
                need_captcha: this.data.needCaptcha
            });
            var t = this.properties, e = t.appid, r = t.number, a = t.area_code, i = t.captcha_solution, n = t.captcha_id;
            if (e || console.error("没有获取到 appid"), !r || !a) return wx.showToast({
                icon: "none",
                title: "请输入手机号"
            }), !1;
            var o = this.properties, _ = o.ticket, p = o.randstr;
            this.setData({
                status: _asyncStatus.PENDING
            }), _fetch2.default.post("" + _const.API_DOMAIN + PHONE_CODE_API, {
                appid: e,
                number: r,
                area_code: a,
                captcha_solution: i,
                captcha_id: n,
                ticket: _,
                randstr: p
            }, {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8"
            }).then(function(t) {
                var e = t.data, r = e.status, a = e.description, i = (e.payload, e.message);
                r === _const.LOGIN_SUCCESS ? (wx.showToast({
                    title: "验证码已发送"
                }), s.triggerEvent("getSuccess", _extends({}, e)), s.setData({
                    status: _asyncStatus.SUCCESS
                }), s._startTimer()) : (i !== _const.LOGIN_MESSAGE_NEED_CAPTCHA && wx.showModal({
                    title: i === _const.LOGIN_MESSAGE_NEED_CAPTCHA ? "" : "出错啦",
                    content: a,
                    showCancel: !1
                }), s.triggerEvent("getFailed", _extends({}, e)), s.setData({
                    status: _asyncStatus.FAIL
                }));
            }).catch(function(t) {
                console.error(t), s.triggerEvent("getFailed", {
                    error: t
                }), s.setData({
                    status: _asyncStatus.FAIL
                });
            });
        },
        _startTimer: function() {
            var e = this, t = this.properties.timer;
            this.setData({
                time: t
            }), this.timer = setInterval(function() {
                var t = e.data.time;
                t <= 0 ? e._clearTimer() : e.setData({
                    time: t - 1
                });
            }, 1e3);
        },
        _clearTimer: function() {
            clearInterval(this.timer), this.timer = null;
        },
        autoGetVerifyCode: function() {
            this.getCode();
        }
    }
});