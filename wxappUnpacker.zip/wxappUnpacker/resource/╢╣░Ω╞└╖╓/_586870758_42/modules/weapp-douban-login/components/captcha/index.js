var _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    }
    return t;
}, _refreshCaptcha2 = require("../../utils/refresh-captcha.js"), _refreshCaptcha3 = _interopRequireDefault(_refreshCaptcha2), _const = require("../../const.js"), _subscriptEvent = require("../../utils/subscript-event.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function transformCaptchaImageUrl(t) {
    return /^\/j\/captcha/gi.test(t) && (t = "" + _const.API_DOMAIN + t), t;
}

Component({
    properties: {
        payload: {
            type: Object,
            required: !0
        },
        useTCaptcha: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        payload: null,
        captcha_solution: "",
        tCaptchaMiniProgramAppId: _const.T_CAPTCHA_MINIPROHRAM_APPID,
        tCaptchaExtraData: {
            appId: _const.T_CAPTCHA_EXTRA_APPID
        }
    },
    methods: {
        setCaptchaSolution: function(t) {
            var a = t.detail.value, e = this.data.payload;
            this.setData({
                captcha_solution: a
            }), this.triggerEvent("setCaptchaSolution", {
                captcha_solution: a,
                payload: e
            });
        },
        clickCaptchaHandle: function() {
            this.triggerEvent("clickCaptcha");
        },
        refreshCaptcha: function(t) {
            var e = this;
            (0, _refreshCaptcha3.default)().then(function(t) {
                var a = _extends({}, t);
                a.captcha_image_url = transformCaptchaImageUrl(a.captcha_image_url), e.setData({
                    payload: a
                });
            }).catch(function(t) {
                wx.showModal({
                    title: "刷新失败",
                    content: "请重试",
                    showCancel: !1
                });
            });
        }
    },
    attached: function() {
        var a = this, t = this.properties.payload, e = _extends({}, t);
        e.captcha_image_url = transformCaptchaImageUrl(e.captcha_image_url), this.setData({
            payload: e
        }), (0, _subscriptEvent.on)("tCaptchaSuccess", function(t) {
            a.triggerEvent("tCaptchaSuccess", _extends({}, t));
        }), (0, _subscriptEvent.on)("tCaptchaFailed", function(t) {
            a.triggerEvent("tCaptchaFailed", {
                error: t
            });
        });
    }
});