var _STATUS_TEXT, _slicedToArray = function(t, a) {
    if (Array.isArray(t)) return t;
    if (Symbol.iterator in Object(t)) return function(t, a) {
        var e = [], s = !0, n = !1, r = void 0;
        try {
            for (var i, c = t[Symbol.iterator](); !(s = (i = c.next()).done) && (e.push(i.value), 
            !a || e.length !== a); s = !0) ;
        } catch (t) {
            n = !0, r = t;
        } finally {
            try {
                !s && c.return && c.return();
            } finally {
                if (n) throw r;
            }
        }
        return e;
    }(t, a);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
    }
    return t;
}, _asyncStatus = require("../../utils/async-status.js"), _validate3 = require("../../utils/validate.js"), _validate4 = _interopRequireDefault(_validate3), _basicLogin = require("../../utils/login/basic-login.js"), _basicLogin2 = _interopRequireDefault(_basicLogin), _const = require("../../const.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var RULES = {
    name: {
        validator: "name",
        message: "请输入正确的手机号或邮箱"
    },
    password: {
        validator: "required",
        message: "请输入密码"
    }
}, STATUS_TEXT = (_defineProperty(_STATUS_TEXT = {}, _asyncStatus.PENDING, "提交中..."), 
_defineProperty(_STATUS_TEXT, _asyncStatus.SUCCESS, "登录成功"), _defineProperty(_STATUS_TEXT, _asyncStatus.FAIL, "失败, 请重试"), 
_defineProperty(_STATUS_TEXT, _asyncStatus.DEFAULT, "登录"), _defineProperty(_STATUS_TEXT, _const.CAPTCHA, "验证并登录"), 
_STATUS_TEXT);

Component({
    properties: {
        appid: {
            type: String,
            required: !0
        }
    },
    data: {
        status: _asyncStatus.DEFAULT,
        statusText: "登录",
        needCaptcha: !1,
        useTCaptcha: !0,
        captchaPayload: null,
        captcha_id: "",
        captcha_solution: "",
        captchaModalVisible: !1,
        formData: {
            name: "",
            password: "",
            captcha_id: "",
            captcha_solution: "",
            ticket: "",
            randstr: ""
        }
    },
    methods: {
        submit: function(t) {
            var r = this;
            wx.LOGIN_MA.report("chooseBasicLogin", {
                need_captcha: this.data.needCaptcha
            });
            var a = this.properties.appid, e = this.data, s = e.status, i = e.formData, c = e.needCaptcha, o = e.useTCaptcha, n = e.captchaPayload;
            if (s === _asyncStatus.PENDING) return !1;
            var u = _extends({}, RULES);
            c && !o && (u.captcha_solution = {
                validator: "required",
                message: "请输入验证码"
            }, i.captcha_id = n.captcha_id);
            var _ = (0, _validate4.default)(i, u), d = _slicedToArray(_, 3), l = d[0], h = (d[1], 
            d[2]);
            if (!l) return wx.showModal({
                title: "出错啦",
                content: h,
                showCancel: !1
            }), !1;
            this.setData({
                status: _asyncStatus.PENDING,
                statusText: STATUS_TEXT[_asyncStatus.PENDING]
            }), (0, _basicLogin2.default)(a, i).then(function(t) {
                var a = t.data, e = a.status, s = a.message, n = Object.assign({}, a, {
                    type: _const.LOGIN_TYPE_BASIC
                });
                e === _const.LOGIN_SUCCESS ? (r.setData({
                    status: _asyncStatus.SUCCESS,
                    statusText: STATUS_TEXT[_asyncStatus.SUCCESS]
                }), r.triggerEvent(_const.LOGIN_SUCCESS_EVENT, n)) : (s === _const.LOGIN_MESSAGE_NEED_CAPTCHA ? r.setData({
                    captchaModalVisible: !0,
                    captchaModalConfig: {
                        content: "请先完成图形验证"
                    },
                    needCaptcha: !0,
                    captchaPayload: a.payload,
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.DEFAULT]
                }) : (r.setData({
                    formData: Object.assign({}, i, {
                        password: ""
                    })
                }), r.setData({
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.FAIL]
                }), r.triggerEvent(_const.LOGIN_FAILED_EVENT, n)), c && !o && r.refreshCaptcha());
            }).catch(function(t) {
                var a = Object.assign({
                    error: t
                }, {
                    type: _const.LOGIN_TYPE_BASIC
                });
                r.setData({
                    status: _asyncStatus.FAIL
                }), c && !o && r.refreshCaptcha(), r.triggerEvent(_const.LOGIN_FAILED_EVENT, a);
            });
        },
        setName: function(t) {
            var a = t.detail.value, e = this.data.formData;
            this.setData({
                formData: Object.assign({}, e, {
                    name: a
                })
            });
        },
        setPassword: function(t) {
            var a = t.detail.value, e = this.data.formData;
            this.setData({
                formData: Object.assign({}, e, {
                    password: a
                })
            });
        },
        refreshCaptcha: function(a) {
            function t(t) {
                return a.apply(this, arguments);
            }
            return t.toString = function() {
                return a.toString();
            }, t;
        }(function(t) {
            var a = this;
            refreshCaptcha().then(function(t) {
                a.setData({
                    captchaPayload: t
                });
            }).catch(function(t) {
                wx.showModal({
                    title: "刷新失败",
                    content: "请重试",
                    showCancel: !1
                });
            });
        }),
        clickCaptchaHandle: function() {
            this.setData({
                captchaModalVisible: !1
            });
        },
        setCaptchaSolution: function(t) {
            var a = this.data.formData, e = t.detail, s = e.captcha_solution, n = e.payload;
            this.setData({
                formData: Object.assign({}, a, {
                    captcha_solution: s
                }),
                captchaPayload: n
            });
        },
        tCaptchaSuccess: function(t) {
            var a = t.detail, e = a.ticket, s = a.randstr, n = a.currentRoute;
            if (n && 0 <= n.indexOf("basic")) {
                var r = this.data.formData;
                return this.setData({
                    formData: Object.assign({}, r, {
                        ticket: e,
                        randstr: s
                    })
                }), this.submit();
            }
            return !1;
        },
        tCaptchaFailed: function(t) {
            var a = t.detail.currentRoute;
            a && 0 <= a.indexOf("basic") && wx.showModal({
                title: "出错啦",
                content: "验证码校验出错",
                showCancel: !1
            });
        }
    }
});