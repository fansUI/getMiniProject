var _STATUS_TEXT, _slicedToArray = function(t, a) {
    if (Array.isArray(t)) return t;
    if (Symbol.iterator in Object(t)) return function(t, a) {
        var e = [], s = !0, r = !1, n = void 0;
        try {
            for (var i, c = t[Symbol.iterator](); !(s = (i = c.next()).done) && (e.push(i.value), 
            !a || e.length !== a); s = !0) ;
        } catch (t) {
            r = !0, n = t;
        } finally {
            try {
                !s && c.return && c.return();
            } finally {
                if (r) throw n;
            }
        }
        return e;
    }(t, a);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
    }
    return t;
}, _asyncStatus = require("../../utils/async-status.js"), _validate3 = require("../../utils/validate.js"), _validate4 = _interopRequireDefault(_validate3), _basicLogin = require("../../utils/login/basic-login.js"), _basicLogin2 = _interopRequireDefault(_basicLogin), _refreshCaptcha = require("../../utils/refresh-captcha.js"), _refreshCaptcha2 = _interopRequireDefault(_refreshCaptcha), _const = require("../../const.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var RULES = {
    name: {
        validator: "num",
        message: "请输入正确的手机号"
    },
    password: {
        validator: "required",
        message: "请输入密码"
    }
}, STATUS_TEXT = (_defineProperty(_STATUS_TEXT = {}, _asyncStatus.PENDING, "提交中..."), 
_defineProperty(_STATUS_TEXT, _asyncStatus.SUCCESS, "登录成功"), _defineProperty(_STATUS_TEXT, _asyncStatus.FAIL, "失败, 请重试"), 
_defineProperty(_STATUS_TEXT, _asyncStatus.DEFAULT, "登录"), _defineProperty(_STATUS_TEXT, _const.CAPTCHA, "去验证"), 
_STATUS_TEXT);

Component({
    properties: {
        appid: {
            type: String,
            required: !0
        }
    },
    data: {
        status: _asyncStatus.DEFAULT,
        statusText: "登录",
        areaSelectorVisible: !1,
        needCaptcha: !1,
        useTCaptcha: !0,
        captchaPayload: null,
        captcha_solution: "",
        captcha_id: "",
        ticket: "",
        randstr: "",
        captchaModalVisible: !1,
        formData: {
            name: "",
            password: "",
            area_code: "+86",
            captcha_id: "",
            captcha_solution: "",
            ticket: "",
            randstr: ""
        }
    },
    methods: {
        submit: function() {
            var n = this;
            wx.LOGIN_MA.report("chooseForeginLogin", {
                need_captcha: this.data.needCaptcha
            });
            var t = this.properties.appid, a = this.data, e = a.status, s = a.formData, i = a.needCaptcha, c = a.useTCaptcha, r = a.captchaPayload;
            if (e === _asyncStatus.PENDING) return !1;
            var o = _extends({}, RULES);
            i && !c && (o.captcha_solution = {
                validator: "required",
                message: "请输入验证码"
            }, s.captcha_id = r.captcha_id);
            var u = (0, _validate4.default)(s, o), _ = _slicedToArray(u, 3), l = _[0], d = (_[1], 
            _[2]);
            if (!l) return wx.showModal({
                title: "出错啦",
                content: d,
                showCancel: !1
            }), !1;
            this.setData({
                status: _asyncStatus.PENDING,
                statusText: STATUS_TEXT[_asyncStatus.PENDING]
            }), (0, _basicLogin2.default)(t, s).then(function(t) {
                var a = t.data, e = a.status, s = a.message, r = Object.assign({}, a, {
                    type: _const.LOGIN_TYPE_FOREIGN
                });
                e === _const.LOGIN_SUCCESS ? (n.setData({
                    status: _asyncStatus.SUCCESS,
                    statusText: STATUS_TEXT[_asyncStatus.SUCCESS]
                }), n.triggerEvent(_const.LOGIN_SUCCESS_EVENT, r)) : (s === _const.LOGIN_MESSAGE_NEED_CAPTCHA ? n.setData({
                    captchaModalVisible: !0,
                    needCaptcha: !0,
                    captchaPayload: a.payload,
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.DEFAULT]
                }) : (n.setData({
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.FAIL]
                }), n.triggerEvent(_const.LOGIN_FAILED_EVENT, r)), i && !c && n.refreshCaptcha());
            }).catch(function(t) {
                var a = Object.assign({
                    error: t
                }, {
                    type: _const.LOGIN_TYPE_FOREIGN
                });
                n.setData({
                    status: _asyncStatus.FAIL
                }), i && !c && n.refreshCaptcha(), n.triggerEvent(_const.LOGIN_FAILED_EVENT, a);
            });
        },
        setPhoneNumber: function(t) {
            var a = t.detail.value, e = _extends({}, this.data.formData);
            e.name = a, this.setData({
                formData: e
            });
        },
        setPassword: function(t) {
            var a = t.detail.value, e = _extends({}, this.data.formData);
            e.password = a, this.setData({
                formData: e
            });
        },
        chooseArea: function() {
            this.setData({
                areaSelectorVisible: !0
            });
        },
        areaSelected: function(t) {
            var a = t.detail.selected, e = _slicedToArray(a, 4), s = (e[0], e[1], e[2]), r = (e[3], 
            _extends({}, this.data.formData));
            r.area_code = s, this.setData({
                areaSelectorVisible: !1,
                formData: r
            });
        },
        refreshCaptcha: function(t) {
            var a = this;
            (0, _refreshCaptcha2.default)().then(function(t) {
                a.setData({
                    captchaPayload: t
                });
            }).catch(function(t) {
                wx.showModal({
                    title: "刷新失败",
                    content: "请重试",
                    showCancel: !1
                });
            });
        },
        clickCaptchaHandle: function() {
            this.setData({
                captchaModalVisible: !1
            });
        },
        setCaptchaSolution: function(t) {
            var a = this.data.formData, e = t.detail, s = e.captcha_solution, r = e.payload;
            this.setData({
                formData: Object.assign({}, a, {
                    captcha_solution: s
                }),
                captchaPayload: r
            });
        },
        tCaptchaSuccess: function(t) {
            var a = t.detail, e = a.ticket, s = a.randstr, r = this.data.formData;
            return this.setData({
                formData: Object.assign({}, r, {
                    ticket: e,
                    randstr: s
                })
            }), this.submit();
        },
        tCaptchaFailed: function() {
            wx.showModal({
                title: "出错啦",
                content: "验证码校验出错",
                showCancel: !1
            });
        }
    }
});