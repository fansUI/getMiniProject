Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        isCustomSlot: {
            type: Boolean,
            value: !1
        },
        config: {
            type: Object,
            value: {
                title: {
                    type: String,
                    value: ""
                },
                content: {
                    type: String,
                    value: ""
                }
            }
        }
    },
    data: {},
    methods: {
        _preventTouchMove: function() {}
    }
});