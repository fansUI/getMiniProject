var _STATUS_TEXT, _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
    }
    return t;
}, _slicedToArray = function(t, a) {
    if (Array.isArray(t)) return t;
    if (Symbol.iterator in Object(t)) return function(t, a) {
        var e = [], s = !0, r = !1, n = void 0;
        try {
            for (var i, o = t[Symbol.iterator](); !(s = (i = o.next()).done) && (e.push(i.value), 
            !a || e.length !== a); s = !0) ;
        } catch (t) {
            r = !0, n = t;
        } finally {
            try {
                !s && o.return && o.return();
            } finally {
                if (r) throw n;
            }
        }
        return e;
    }(t, a);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _asyncStatus = require("../../utils/async-status.js"), _const = require("../../const.js"), _validate3 = require("../../utils/validate.js"), _validate4 = _interopRequireDefault(_validate3), _smsLogin = require("../../utils/login/sms-login.js"), _smsLogin2 = _interopRequireDefault(_smsLogin), _register = require("../../utils/login/register.js"), _register2 = _interopRequireDefault(_register);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var RULES = {
    number: {
        validator: "phone",
        message: "请输入正确的手机号码"
    },
    code: {
        validator: "required",
        message: "请输入验证码"
    },
    area_code: {
        validator: "required",
        message: "请选择区号"
    }
}, STATUS_TEXT = (_defineProperty(_STATUS_TEXT = {}, _asyncStatus.PENDING, "提交中..."), 
_defineProperty(_STATUS_TEXT, _asyncStatus.SUCCESS, "登录成功"), _defineProperty(_STATUS_TEXT, _asyncStatus.FAIL, "失败, 请重试"), 
_defineProperty(_STATUS_TEXT, _asyncStatus.DEFAULT, "登录"), _defineProperty(_STATUS_TEXT, _const.CAPTCHA, "去验证"), 
_STATUS_TEXT);

Component({
    properties: {
        appid: {
            type: String,
            required: !0
        }
    },
    data: {
        status: _asyncStatus.DEFAULT,
        statusText: STATUS_TEXT[_asyncStatus.DEFAULT],
        autoGetCode: !1,
        needCaptcha: !1,
        useTCaptcha: !0,
        captchaPayload: null,
        areaSelectorVisible: !1,
        captcha_solution: "",
        captcha_id: "",
        ticket: "",
        randstr: "",
        captchaModalVisible: !1,
        formData: {
            number: "",
            code: "",
            area_code: "+86"
        }
    },
    methods: {
        submit: function() {
            var u = this;
            wx.LOGIN_MA.report("chooseSmsLogin", {});
            var _ = this.data.formData, t = this.properties.appid, a = (0, _validate4.default)(_, RULES), e = _slicedToArray(a, 3), s = e[0], r = (e[1], 
            e[2]);
            if (!s) return wx.showModal({
                title: "出错啦",
                content: r,
                showCancel: !1
            }), !1;
            this.setData({
                status: _asyncStatus.PENDING,
                statusText: STATUS_TEXT[_asyncStatus.PENDING]
            }), (0, _smsLogin2.default)(_extends({
                appid: t
            }, _)).then(function(t) {
                var a = t.data, e = a.status, s = (a.message, a.payload);
                if (s && !s.account_info && s.vtoken) {
                    var r = u.data.appid, n = _.area_code, i = _.number, o = s.vtoken;
                    return (0, _register2.default)({
                        appid: r,
                        vtoken: o,
                        area_code: n,
                        number: i
                    }).then(function(t) {
                        var a = t.data, e = a.status, s = (a.message, a.payload, Object.assign({}, a, {
                            type: _const.LOGIN_TYPE_SMS
                        }));
                        e === _const.LOGIN_SUCCESS ? (u.setData({
                            status: _asyncStatus.SUCCESS,
                            statusText: STATUS_TEXT[_asyncStatus.SUCCESS]
                        }), u.triggerEvent(_const.LOGIN_SUCCESS_EVENT, s)) : (u.setData({
                            status: _asyncStatus.FAIL,
                            statusText: STATUS_TEXT[_asyncStatus.FAIL]
                        }), u.triggerEvent(_const.LOGIN_FAILED_EVENT, s));
                    }).catch(function(t) {
                        var a = Object.assign({
                            error: t
                        }, {
                            type: _const.LOGIN_TYPE_SMS
                        });
                        u.setData({
                            status: _asyncStatus.FAIL,
                            statusText: STATUS_TEXT[_asyncStatus.FAIL]
                        }), u.triggerEvent(_const.LOGIN_FAILED_EVENT, a);
                    });
                }
                var c = Object.assign({}, a, {
                    type: _const.LOGIN_TYPE_SMS
                });
                e === _const.LOGIN_SUCCESS ? (u.setData({
                    status: _asyncStatus.SUCCESS,
                    statusText: STATUS_TEXT[_asyncStatus.SUCCESS]
                }), u.triggerEvent(_const.LOGIN_SUCCESS_EVENT, c)) : (u.setData({
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.FAIL]
                }), u.triggerEvent(_const.LOGIN_FAILED_EVENT, c));
            }).catch(function(t) {
                var a = Object.assign({
                    error: t
                }, {
                    type: _const.LOGIN_TYPE_SMS
                });
                u.setData({
                    status: _asyncStatus.FAIL,
                    statusText: STATUS_TEXT[_asyncStatus.FAIL]
                }), u.triggerEvent(_const.LOGIN_FAILED_EVENT, a);
            });
        },
        setPhoneNumber: function(t) {
            var a = t.detail.value, e = _extends({}, this.data.formData);
            e.number = a, this.setData({
                formData: e
            });
        },
        setCode: function(t) {
            var a = t.detail.value, e = _extends({}, this.data.formData);
            e.code = a, this.setData({
                formData: e
            });
        },
        chooseArea: function() {
            this.setData({
                areaSelectorVisible: !0
            });
        },
        areaSelected: function(t) {
            var a = t.detail.selected, e = _slicedToArray(a, 4), s = (e[0], e[1], e[2]), r = (e[3], 
            _extends({}, this.data.formData));
            r.area_code = s, this.setData({
                areaSelectorVisible: !1,
                formData: r
            });
        },
        getVerifyFailed: function(t) {
            var a = t.detail, e = a.payload;
            a.message === _const.LOGIN_MESSAGE_NEED_CAPTCHA && this.setData({
                needCaptcha: !0,
                captchaPayload: e,
                captchaModalVisible: !0,
                captchaModalConfig: {
                    content: "请先完成图形验证"
                }
            });
        },
        getVerifySuccess: function(t) {
            this.setData({
                needCaptcha: !1
            });
        },
        clickCaptchaHandle: function() {
            this.setData({
                captchaModalVisible: !1
            });
        },
        setCaptchaSolution: function(t) {
            var a = t.detail, e = a.captcha_solution, s = a.payload;
            this.setData({
                captcha_solution: e,
                captcha_id: s.captcha_id
            });
        },
        tCaptchaSuccess: function(t) {
            var a = t.detail, e = a.ticket, s = a.randstr, r = a.currentRoute;
            return !!(r && 0 <= r.indexOf("sms")) && this.setData({
                autoGetCode: !0,
                ticket: e,
                randstr: s
            });
        },
        tCaptchaFailed: function(t) {
            var a = t.detail.currentRoute;
            if (a && 0 <= a.indexOf("sms")) return wx.showModal({
                title: "出错啦",
                content: "验证码校验出错",
                showCancel: !1
            });
        }
    }
});