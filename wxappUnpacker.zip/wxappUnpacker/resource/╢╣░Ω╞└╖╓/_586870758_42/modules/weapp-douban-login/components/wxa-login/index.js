var _promisify = require("../../utils/promisify.js"), _promisify2 = _interopRequireDefault(_promisify), _setDataToStorage = require("../../utils/set-data-to-storage.js"), _setDataToStorage2 = _interopRequireDefault(_setDataToStorage), _getDataToStorage = require("../../utils/get-data-to-storage.js"), _getDataToStorage2 = _interopRequireDefault(_getDataToStorage), _wxaLogin = require("../../utils/login/wxa-login.js"), _wxaLogin2 = _interopRequireDefault(_wxaLogin), _wxaPhoneLogin = require("../../utils/login/wxa-phone-login.js"), _wxaPhoneLogin2 = _interopRequireDefault(_wxaPhoneLogin), _wxaThirdpartyLogin = require("../../utils/login/wxa-thirdparty-login.js"), _wxaThirdpartyLogin2 = _interopRequireDefault(_wxaThirdpartyLogin), _register = require("../../utils/login/register.js"), _register2 = _interopRequireDefault(_register), _asyncStatus = require("../../utils/async-status.js"), _const = require("../../const.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var wxLogin = (0, _promisify2.default)(wx.login), getUserInfo = (0, _promisify2.default)(wx.getUserInfo), getSetting = (0, 
_promisify2.default)(wx.getSetting);

Component({
    properties: {
        appid: {
            type: String,
            required: !0
        }
    },
    data: {
        status: _asyncStatus.DEFAULT,
        authorizeModalVisible: !1,
        isLoginModalVisible: !1,
        isCreateNewAccountModalVisible: !1,
        defaultAvatar: _const.DEFAULT_AVATAR
    },
    methods: {
        login: function(t) {
            wx.LOGIN_MA.report("chooseWxaLogin", {});
            var e = t.detail, a = (t.errMsg, e.encryptedData), i = e.iv;
            if (!a || !i) return !1;
            this.phoneData = {
                encryptedData: a,
                iv: i
            };
            this.properties.appid, this.data.status;
            var s = (0, _getDataToStorage2.default)("wxa_sessionid");
            if (!s) return !1;
            var o = new Date().getTime;
            (0, _setDataToStorage2.default)({
                access_token_set_time: o
            }), this._phoneLogin(s);
        },
        _phoneLogin: function(c) {
            var u = this, t = this.properties.appid, e = this.phoneData, a = e.encryptedData, i = e.iv;
            (0, _wxaPhoneLogin2.default)({
                wxa_sessionid: c,
                appid: t,
                encryptedData: a,
                iv: i
            }).then(function(t) {
                var e = t.data, a = e.status, i = e.payload, s = e.message, o = e.description;
                if (u.wxaPhoneLoginResData = e, a === _asyncStatus.SUCCESS && i) {
                    var n = i.access_token, r = i.account_info;
                    i.phone;
                    r && n && (r.weixin_binded ? u._triggerSuccess(e, _const.LOGIN_TYPE_WXA_PHONE) : u.setData({
                        tempDoubanInfo: r,
                        isLoginModalVisible: !0
                    }));
                } else {
                    if (s === _const.ACCOUNT_NOT_EXIST) return u._userInfoLogin(c, o);
                    s === _const.UNEXPECT_STATUS && wx.removeStorageSync("wxa_sessionid"), u._triggerFailed(e);
                }
            }).catch(function(t) {
                u._triggerFailed({
                    description: "获取手机号出错"
                }), console.error(t);
            });
        },
        _confirmIsLogin: function() {
            this._triggerSuccess(this.wxaPhoneLoginResData, _const.LOGIN_TYPE_WXA_PHONE);
        },
        _userInfoLogin: function(n) {
            var r = this;
            1 < arguments.length && void 0 !== arguments[1] && arguments[1];
            getSetting().then(function(t) {
                t.authSetting["scope.userInfo"] ? getUserInfo().then(function(t) {
                    var e = t.encryptedData, a = t.iv, i = r.data.appid, s = r.phoneData.encryptedData, o = r.phoneData.iv;
                    return (0, _wxaThirdpartyLogin2.default)({
                        wxa_sessionid: n,
                        appid: i,
                        encryptedData: e,
                        iv: a,
                        phoneEncryptedData: s,
                        phoneIv: o
                    });
                }).then(function(t) {
                    var e = t.data, a = e.status;
                    e.payload;
                    a !== _asyncStatus.SUCCESS ? r._triggerFailed(e) : r._triggerSuccess(e, _const.LOGIN_TYPE_WXA_USER);
                }).catch(function(t) {
                    r._triggerFailed({
                        description: "获取授权信息出错"
                    }), console.error(t);
                }) : r.setData({
                    authorizeModalVisible: !0,
                    authorizeModalConfig: {
                        title: "豆瓣帐号查询",
                        content: "该手机号未绑定过豆瓣帐号"
                    }
                });
            }).catch(function(t) {
                r._triggerFailed({
                    description: "获取授权信息出错"
                }), console.error(t);
            });
        },
        _getUserInfo: function(t) {
            var n = this, e = t.detail, a = e.errMsg, r = e.encryptedData, c = e.iv, i = (0, 
            _getDataToStorage2.default)("wxa_sessionid"), s = this.data.appid;
            if (a && "getUserInfo:fail auth deny" === a) return this.setData({
                authorizeModalVisible: !1
            });
            this.data.isLoginModalVisible && this.setData({
                isLoginModalVisible: !1
            }), this.data.authorizeModalVisible && this.setData({
                authorizeModalVisible: !1
            });
            var o = this.phoneData.encryptedData, u = this.phoneData.iv;
            return (0, _wxaThirdpartyLogin2.default)({
                wxa_sessionid: i,
                appid: s,
                encryptedData: r,
                iv: c,
                phoneEncryptedData: o,
                phoneIv: u
            }).then(function(t) {
                var e = t.data, a = e.status, i = e.payload;
                if (a !== _asyncStatus.SUCCESS) n._triggerFailed(e); else {
                    var s = i.account_info, o = i.vtoken;
                    !s && o ? (n.registerNeedData = {
                        vtoken: o,
                        encryptedData: r,
                        iv: c
                    }, n.setData({
                        isCreateNewAccountModalVisible: !0,
                        createNewAccountModalConfig: {
                            title: "是否创建一个新的豆瓣帐号？",
                            content: ""
                        }
                    })) : n._triggerSuccess(e, _const.LOGIN_TYPE_WXA_USER);
                }
            }).catch(function(t) {
                n._triggerFailed({
                    description: "获取授权信息出错"
                }), console.error(t);
            });
        },
        cancelCreateNewAccount: function() {
            this.setData({
                isCreateNewAccountModalVisible: !1
            });
        },
        confirmCreateNewAccount: function() {
            var i = this;
            this.setData({
                isCreateNewAccountModalVisible: !1
            });
            var t = (0, _getDataToStorage2.default)("wxa_sessionid"), e = Object.assign({}, this.registerNeedData, {
                appid: this.data.appid,
                wxa_sessionid: t
            });
            (0, _register2.default)(e).then(function(t) {
                var e = t.data, a = e.status;
                e.message, e.payload;
                a !== _asyncStatus.SUCCESS ? i._triggerFailed(e) : setTimeout(function() {
                    i._triggerSuccess(e, _const.LOGIN_TYPE_WXA);
                }, 500);
            }).catch(function(t) {
                console.log(t), i._triggerFailed(data);
            });
        },
        cancelAuthorizeModal: function() {
            this.setData({
                authorizeModalVisible: !1
            });
        },
        _failed: function(t) {
            wx.showModal({
                title: "出错啦",
                content: t && (t.description || t.message) ? t.description || t.message : "登录失败"
            });
        },
        _triggerSuccess: function(t, e) {
            var a = Object.assign({}, t, {
                type: e || _const.LOGIN_TYPE_WXA
            });
            this.setData({
                status: _asyncStatus.SUCCESS
            }), this.triggerEvent(_const.LOGIN_SUCCESS_EVENT, a);
        },
        _triggerFailed: function(t) {
            var e = Object.assign({}, t, {
                type: _const.LOGIN_TYPE_WXA
            });
            this.setData({
                status: _asyncStatus.FAIL
            }), this.triggerEvent(_const.LOGIN_FAILED_EVENT, e);
        },
        _setWxaSessionId: function() {
            var a = getApp().globalData.appid;
            wxLogin().then(function(t) {
                var e = t.code;
                return (0, _wxaLogin2.default)({
                    code: e,
                    appid: a
                });
            }).then(function(t) {
                var e = t.data, a = e.message, i = e.payload;
                if (a === _asyncStatus.SUCCESS && i) {
                    var s = i.wxa_sessionid;
                    (0, _setDataToStorage2.default)({
                        wxa_sessionid: s
                    });
                }
            });
        }
    },
    attached: function() {
        var t = this;
        wx.checkSession({
            success: function() {
                (0, _getDataToStorage2.default)("wxa_sessionid") || t._setWxaSessionId();
            },
            fail: function() {
                t._setWxaSessionId();
            }
        });
    }
});