Object.defineProperty(exports, "__esModule", {
    value: !0
});

var DEFAULT = exports.DEFAULT = "default", PENDING = exports.PENDING = "pending", SUCCESS = exports.SUCCESS = "success", FAIL = exports.FAIL = "fail";