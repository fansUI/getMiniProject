Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _fetch = require("../fetch.js"), _fetch2 = _interopRequireDefault(_fetch), _const = require("../../const.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var WXA_PHONE_LOGIN_API = "/j/wxa/login/phone_login";

exports.default = function(e) {
    var t = e.wxa_sessionid, r = e.appid, n = e.encryptedData, i = e.iv;
    return _fetch2.default.post("" + _const.API_DOMAIN + WXA_PHONE_LOGIN_API, {
        wxa_sessionid: t,
        appid: r,
        encryptedData: n,
        iv: i
    }, {
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8"
    });
};