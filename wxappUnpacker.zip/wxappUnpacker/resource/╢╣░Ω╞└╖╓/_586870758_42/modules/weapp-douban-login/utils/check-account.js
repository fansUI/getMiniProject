Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _getDataToStorage = require("./get-data-to-storage.js"), _getDataToStorage2 = _interopRequireDefault(_getDataToStorage);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

exports.default = function() {
    var e = (0, _getDataToStorage2.default)("access_token"), t = (0, _getDataToStorage2.default)("expires_in"), a = (0, 
    _getDataToStorage2.default)("access_token_set_time"), r = new Date().getTime();
    return !(!e | !t) && !!(e && r < a + 1e3 * parseInt(t, 10));
};