Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
};

function merge() {
    var o = Array.from(arguments), e = {}, n = {};
    o.forEach(function(o) {
        for (var r in o) if (o.hasOwnProperty(r)) {
            var t = o[r];
            if ("function" == typeof t) {
                n[r] = n[r] ? n[r].concat([ t ]) : [ t ];
                continue;
            }
            if (e[r]) {
                if (!e[r] || !isShouldCover(t)) throw new Error(r + " is can not merge, please check the type of " + r);
                e[r] = t;
            } else e[r] = t;
        }
    });
    var r = function(o) {
        n.hasOwnProperty(o) && (e[o] = function() {
            var r = this, t = Array.from(arguments);
            n[o].forEach(function(o) {
                o.apply(r, t);
            });
        });
    };
    for (var t in n) r(t);
    return e;
}

function isShouldCover(o) {
    var r = void 0 === o ? "undefined" : _typeof(o), t = "[object Object]" === Object.prototype.toString.call(o), e = Array.isArray(o);
    return "string" === r || "number" === r || t || e;
}

exports.default = merge;