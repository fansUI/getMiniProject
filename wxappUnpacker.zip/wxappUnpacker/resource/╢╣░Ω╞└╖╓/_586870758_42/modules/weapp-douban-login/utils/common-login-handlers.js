Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.failedHandler = exports.successHandler = void 0;

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = arguments[t];
        for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r]);
    }
    return e;
}, _setDataToStorage = require("./set-data-to-storage.js"), _setDataToStorage2 = _interopRequireDefault(_setDataToStorage), _navigateBack = require("./navigate-back.js"), _navigateBack2 = _interopRequireDefault(_navigateBack);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var successHandler = exports.successHandler = function(e) {
    var t = e.detail, a = t.type;
    wx.LOGIN_MA.report(a + "LoginSuccess", {}), wx.showToast({
        title: "登录成功"
    });
    var r = t.payload, o = new Date().getTime();
    (0, _setDataToStorage2.default)(_extends({
        access_token_set_time: o
    }, r)), console.log(r);
    var s = this.data.params;
    s && s.redirect ? setTimeout(function() {
        (0, _navigateBack2.default)(decodeURIComponent(s.redirect));
    }, 500) : setTimeout(function() {
        wx.navigateBack({
            delta: -1
        });
    }, 500);
}, failedHandler = exports.failedHandler = function(e) {
    var t = e.detail;
    wx.showModal({
        title: "登录失败",
        content: t.description || t.message || "出错啦,请重试",
        showCancel: !1
    });
};