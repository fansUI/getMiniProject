Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function a(e, t) {
        for (var r = 0; r < t.length; r++) {
            var a = t[r];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(e, t, r) {
        return t && a(e.prototype, t), r && a(e, r), e;
    };
}(), _fetch = require("./fetch.js"), _fetch2 = _interopRequireDefault(_fetch), _getDataToStorage = require("./get-data-to-storage.js"), _getDataToStorage2 = _interopRequireDefault(_getDataToStorage), _const = require("../const.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var app = getApp(), MarketAnalytics = function() {
    function e() {
        _classCallCheck(this, e), this.reportUrl = _const.MA_REPORT_URL;
    }
    return _createClass(e, [ {
        key: "report",
        value: function(t, e) {
            var r = this._prepare(e), a = getCurrentPages().reverse(), n = {
                group: "userAction",
                action: t,
                url: this.getPageUrl(a[0]),
                referrer: this.getPageUrl(a[1]),
                extra: JSON.stringify(r)
            }, o = app.globalData.openMaReport;
            return !(!o && 0) && _fetch2.default.post(this.reportUrl, {
                actions: [ n ],
                flush: !0
            }).then(function(e) {
                200 === e.statusCode && console.log("MA数据上报成功", t, {
                    url: n.url,
                    referrer: n.referrer,
                    extra: r
                });
            });
        }
    }, {
        key: "_prepare",
        value: function(e) {
            var t = Object.assign({}, e, {
                appid: app.globalData.appid
            });
            return {
                scene: (0, _getDataToStorage2.default)("scene"),
                entry_id: (0, _getDataToStorage2.default)("entry_id"),
                referrer_info: (0, _getDataToStorage2.default)("referrer_info"),
                system_info: wx.getSystemInfoSync(),
                network_type: app.globalData.networkType,
                version: app.globalData.version,
                data: t
            };
        }
    }, {
        key: "getPageUrl",
        value: function(e) {
            if (!e) return "";
            var t = e.route || e.__route__, r = e ? this.json2string(e.options) : "";
            return "" + t + (r = r ? "?" + r : "");
        }
    }, {
        key: "json2string",
        value: function(e) {
            var t = Object.assign({}, e);
            return Object.keys(t).map(function(e) {
                return e + "=" + t[e];
            }).join("&");
        }
    } ]), e;
}();

exports.default = MarketAnalytics;