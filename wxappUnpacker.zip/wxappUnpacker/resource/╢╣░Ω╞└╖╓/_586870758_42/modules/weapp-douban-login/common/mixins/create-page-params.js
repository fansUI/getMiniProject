Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _ma = require("../../utils/ma.js"), _ma2 = _interopRequireDefault(_ma);

function _interopRequireDefault(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

function param2str(a) {
    var t = [];
    for (var r in a) a.hasOwnProperty(r) && t.push(r + "=" + a[r]);
    return 0 === t.length ? "" : t.join("&");
}

exports.default = function() {
    return {
        onLoad: function(a) {
            var t = {}, r = getApp();
            for (var e in r.globalData && r.globalData.appid && (t.appid = r.globalData.appid), 
            r.globalData && r.globalData.loginSuccessUrl && (t.redirect = r.globalData.loginSuccessUrl), 
            a) a.hasOwnProperty(e) && (t[e] = a[e]);
            this.data || (this.data = {});
            var s = Object.assign({}, this.data.params, t);
            this.setData({
                params: s,
                paramsStr: param2str(s)
            }), wx.LOGIN_MA = new _ma2.default();
        }
    };
};