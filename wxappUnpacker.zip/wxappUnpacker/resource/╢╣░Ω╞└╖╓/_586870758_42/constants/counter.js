Object.defineProperty(exports, "__esModule", {
    value: !0
});

var ADD = exports.ADD = "ADD", MINUS = exports.MINUS = "MINUS";