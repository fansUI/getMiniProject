Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _index = require("../npm/keymirror/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

exports.default = (0, _index2.default)({
    RECEIVE_ANNUAL_LIST: null,
    RECEIVE_INTEREST: null,
    RESET_LIST: null
});