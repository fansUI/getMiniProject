Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var i = arguments[e];
        for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (t[r] = i[r]);
    }
    return t;
}, _createClass = function() {
    function r(t, e) {
        for (var i = 0; i < e.length; i++) {
            var r = e[i];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(t, e, i) {
        return e && r(t.prototype, e), i && r(t, i), t;
    };
}(), _get = function t(e, i, r) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, i);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, i, r);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(r) : void 0;
}, _tslib = require("../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../npm/@tarojs/redux/index.js"), _frodoApi = require("../../services/frodo-api.js"), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _subjectApi = require("../../services/subject-api.js"), _account = require("../../actions/account.js"), _shareDataCollector = require("../../utils/share-data-collector.js"), _shareDataCollector2 = _interopRequireDefault(_shareDataCollector);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
    return e.default = t, e;
}

function _asyncToGenerator(t) {
    return function() {
        var o = t.apply(this, arguments);
        return new Promise(function(a, s) {
            return function e(t, i) {
                try {
                    var r = o[t](i), n = r.value;
                } catch (t) {
                    return void s(t);
                }
                if (!r.done) return Promise.resolve(n).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                a(n);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var reduceSubjectDataForWX = function(t) {
    return {
        type: "general",
        uniq_id: "subject_" + t.id,
        title: t.title,
        digest: t.intro,
        thumbs: t.pic && t.pic.large,
        tags: t.tags.map(function(t) {
            return t.name;
        }).slice(0, 10)
    };
}, Subject = (_temp2 = _class = function(t) {
    function s() {
        var t, e, i;
        _classCallCheck(this, s);
        for (var r = arguments.length, n = Array(r), a = 0; a < r; a++) n[a] = arguments[a];
        return (e = i = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "_subject", "_navTitle", "scopeData", "_isLogin", "_is_phone_verified", "_ratingData", "_trailers", "_photos", "_interests", "type", "_recommendations", "_reviews", "scene", "_labels", "subjectScopeForWX", "accountInfo", "getAccountInfo" ], 
        i.getAccountInfo = function() {
            i.props.getAccountInfo().then(function(t) {
                t && (i.userId = t.id, i.api.user(t.id));
            });
        }, i.onNavigateToInterests = function() {
            var t = i.state.subject.data;
            t && _index2.default.navigateTo({
                url: "/pages/subject/interests?id=" + t.id + "&type=" + t.type
            });
        }, i.$$refs = [], _possibleConstructorReturn(i, e);
    }
    var e, i;
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            var r = this;
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).apply(this, arguments), 
            this.subjectId = "", this.userId = "", this.scene = null, this.subjectApi = new _subjectApi.SubjectAPI(this.$router.params.type), 
            this.loadableApi = {
                user: {
                    api: _frodoApi.frodoApi.user,
                    init: null,
                    toast: !1
                },
                subject: {
                    api: this.subjectApi.subject,
                    init: null
                },
                rating: {
                    api: this.subjectApi.rating,
                    init: null
                },
                photos: {
                    api: this.subjectApi.photos,
                    init: {
                        start: 0,
                        count: 0,
                        total: 0,
                        photos: []
                    }
                },
                trailers: {
                    api: this.subjectApi.trailers,
                    init: {
                        trailers: []
                    }
                },
                interests: {
                    api: this.subjectApi.interests,
                    init: null
                },
                reviews: {
                    api: this.subjectApi.reviews,
                    init: null,
                    updater: function(t) {
                        var e = r.state.reviews && r.state.reviews.data;
                        if (e) {
                            var i = e.reviews.concat(t.reviews);
                            return Object.assign({}, t, {
                                reviews: i
                            });
                        }
                        return t;
                    }
                },
                recommendations: {
                    api: this.subjectApi.recommendations,
                    init: null
                }
            }, this.state = _extends({
                subjectScopeForWX: {}
            }, Loadable.init(this.loadableApi)), this.api = Loadable.api(this.loadableApi, this), 
            this.type = "movie";
        }
    }, {
        key: "componentDidMount",
        value: (i = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, i, r, n, a;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.scene = wx.getLaunchOptionsSync().scene, this.getAccountInfo(), e = this.$router.params.id, 
                    i = this.$router.params.type, (r = this.$router.params.q) && (r = decodeURIComponent(r), 
                    n = r.match(/\/(movie|book|music|game)\/(\w+)/) || [], e = n[2] || e, i = n[1] || i), 
                    i = i || "movie", this.subjectId = e, this.type = i, t.next = 11, this.api.subject(e, i);

                  case 11:
                    a = t.sent, this.setState({
                        subjectScopeForWX: reduceSubjectDataForWX(a.data)
                    }), this.api.rating(e, i), -1 < [ "movie", "tv" ].indexOf(i) && (this.api.photos(e, {
                        type: i
                    }), this.api.trailers(e, i)), this.api.interests(e, {
                        start: 0,
                        count: 4,
                        type: i
                    }), this.api.reviews(e, {
                        type: i
                    }), this.api.recommendations(e, i), _index2.default.setNavigationBarTitle({
                        title: a.data.title
                    }), this.$router.params.redirect && _index2.default.navigateTo({
                        url: this.$router.params.redirect
                    });

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return i.apply(this, arguments);
        })
    }, {
        key: "componentDidShow",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    this.getAccountInfo(), this.userId && this.api.user(this.userId), this.subjectId && this.api.subject(this.subjectId);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "onReachBottom",
        value: function() {
            var t = this.state.reviews && this.state.reviews.data;
            if (t && t.total !== t.reviews.length) {
                var e = t.start, i = t.count;
                this.api.disableLoadingFlag(), this.api.reviews(this.subjectId, {
                    start: e + i,
                    count: i,
                    type: this.type
                });
            }
        }
    }, {
        key: "onShareAppMessage",
        value: function() {
            var t = this.state.subject.data, e = t.null_rating_reason ? "" : "，豆瓣评分" + t.rating.value + "，" + t.rating.count + "人评价";
            return {
                title: this.subjectApi.getLabels(t.type).name + "《" + t.title + "》" + e,
                path: "/pages/subject/subject?type=" + t.type + "&id=" + t.id
            };
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.type, e = this.scene, i = this.__state.user.data, r = this.__state.subject.data, n = this.__state.rating.data, a = this.__state.trailers.data, s = this.__state.photos.data, o = this.__state.interests.data, u = this.__state.reviews.data, c = this.__state.recommendations.data, p = !!this.__props.accountInfo, l = !!i && i.is_phone_verified, _ = this.subjectApi.getLabels(this.type);
            if (!r) return null;
            var h = r.title, d = (_index2.default.getApp(), [ {
                service_type: 11038,
                movie_name: r.title,
                alias: r.aka
            }, {
                service_type: 11039,
                movie_name: r.title,
                alias: r.aka
            } ]), f = (0, _index.internal_inline_style)({
                background: "#" + r.body_bg_color
            }), b = -1 < [ "movie", "tv" ].indexOf(r.type) && (0 !== a.trailers.length || 0 !== s.total) ? "全部 " + (s ? s.total : "") : null, v = -1 < [ "movie", "tv" ].indexOf(r.type), m = -1 < [ "movie", "tv" ].indexOf(r.type) && (0 !== a.trailers.length || 0 !== s.total);
            return Object.assign(this.__state, {
                anonymousState__temp: f,
                anonymousState__temp2: b,
                anonymousState__temp3: v,
                anonymousState__temp4: m,
                _subject: r,
                _navTitle: h,
                scopeData: d,
                _isLogin: p,
                _is_phone_verified: l,
                _ratingData: n,
                _trailers: a,
                _photos: s,
                _interests: o,
                type: t,
                _recommendations: c,
                _reviews: u,
                scene: e,
                _labels: _
            }), this.__state;
        }
    } ]), s;
}(), _class.properties = {
    accountInfo: {
        type: null,
        value: null
    },
    getAccountInfo: {
        type: null,
        value: null
    }
}, _class.$$events = [ "onNavigateToInterests" ], _temp2);

Subject = tslib_1.__decorate([ _shareDataCollector2.default, (0, _index3.connect)(function(t) {
    return {
        accountInfo: t.accountInfo
    };
}, function(t) {
    return {
        getAccountInfo: function() {
            return (0, _account.getAccountInfo)()(t);
        }
    };
}) ], Subject), exports.default = Subject, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Subject, !0));