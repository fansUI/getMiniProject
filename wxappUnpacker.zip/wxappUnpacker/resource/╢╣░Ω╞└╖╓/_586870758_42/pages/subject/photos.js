Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (t[o] = r[o]);
    }
    return t;
}, _createClass = function() {
    function o(t, e) {
        for (var r = 0; r < e.length; r++) {
            var o = e[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(t, e, r) {
        return e && o(t.prototype, e), r && o(t, r), t;
    };
}(), _get = function t(e, r, o) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, o);
    }
    if ("value" in n) return n.value;
    var i = n.get;
    return void 0 !== i ? i.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _subjectApi = require("../../services/subject-api.js");

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var s = t.apply(this, arguments);
        return new Promise(function(a, i) {
            return function e(t, r) {
                try {
                    var o = s[t](r), n = o.value;
                } catch (t) {
                    return void i(t);
                }
                if (!o.done) return Promise.resolve(n).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                a(n);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Subject = function(t) {
    function i() {
        var t, e, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return (e = n = _possibleConstructorReturn(this, (t = i.__proto__ || Object.getPrototypeOf(i)).call.apply(t, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "_photos", "_movie" ], 
        n.handlePreview = function(t) {
            var e = t.target.dataset.url, r = n.state.photos.data, o = r ? r.photos.map(function(t) {
                return t.image.large.url;
            }) : [ e ];
            _index2.default.previewImage({
                current: e,
                urls: o
            });
        }, n.$$refs = [], _possibleConstructorReturn(n, e);
    }
    var e;
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function() {
            var o = this;
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).apply(this, arguments), 
            this.id = "", this.subjectApi = new _subjectApi.SubjectAPI(this.$router.params.type), 
            this.loadableApi = {
                movie: {
                    api: this.subjectApi.subject,
                    init: null
                },
                photos: {
                    api: this.subjectApi.photos,
                    init: null,
                    updater: function(t) {
                        var e = o.state.photos && o.state.photos.data;
                        if (e) {
                            var r = e.photos.concat(t.photos);
                            return Object.assign({}, t, {
                                photos: r
                            });
                        }
                        return t;
                    }
                }
            }, this.state = _extends({}, Loadable.init(this.loadableApi)), this.api = Loadable.api(this.loadableApi, this);
        }
    }, {
        key: "componentDidMount",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, r;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = this.$router.params.id, this.id = e, t.next = 4, this.api.movie(e);

                  case 4:
                    r = t.sent, this.api.photos(e, {}), _index2.default.setNavigationBarTitle({
                        title: r.data.title + "的剧照"
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "onReachBottom",
        value: function() {
            var t = this.state.photos.data;
            if (t) {
                var e = t.start, r = t.count;
                this.api.disableLoadingFlag(), this.api.photos(this.id, {
                    start: e + r,
                    count: r
                });
            }
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state.movie.data, e = this.__state.photos.data;
            if (!t || !e) return null;
            var r = "《" + t.title + "》的剧照";
            return Object.assign(this.__state, {
                anonymousState__temp: r,
                _photos: e,
                _movie: t
            }), this.__state;
        }
    } ]), i;
}();

Subject.properties = {}, Subject.$$events = [ "handlePreview" ], exports.default = Subject, 
Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Subject, !0));