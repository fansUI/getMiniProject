Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n]);
    }
    return t;
}, _createClass = function() {
    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, r) {
        return e && n(t.prototype, e), r && n(t, r), t;
    };
}(), _get = function t(e, r, n) {
    null === e && (e = Function.prototype);
    var a = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === a) {
        var i = Object.getPrototypeOf(e);
        return null === i ? void 0 : t(i, r, n);
    }
    if ("value" in a) return a.value;
    var o = a.get;
    return void 0 !== o ? o.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _subjectApi = require("../../services/subject-api.js"), _reportApi = require("../../services/report-api.js"), _index3 = require("../../utils/index.js");

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var s = t.apply(this, arguments);
        return new Promise(function(i, o) {
            return function e(t, r) {
                try {
                    var n = s[t](r), a = n.value;
                } catch (t) {
                    return void o(t);
                }
                if (!n.done) return Promise.resolve(a).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                i(a);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Mark = function(t) {
    function o() {
        var t, e, r;
        _classCallCheck(this, o);
        for (var n = arguments.length, a = Array(n), i = 0; i < n; i++) a[i] = arguments[i];
        return (e = r = _possibleConstructorReturn(this, (t = o.__proto__ || Object.getPrototypeOf(o)).call.apply(t, [ this ].concat(a)))).$usedState = [ "anonymousState__temp", "action", "_movieInterest", "rating", "comment", "navTitle" ], 
        r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    var e, r, n;
    return _inherits(o, _index.Component), _createClass(o, [ {
        key: "_constructor",
        value: function() {
            _get(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "_constructor", this).apply(this, arguments), 
            this.id = "", this.subjectApi = new _subjectApi.SubjectAPI(this.$router.params.type), 
            this.loadableApi = {
                subject: {
                    api: this.subjectApi.subject,
                    init: null
                },
                interest: {
                    api: this.subjectApi.interest,
                    init: null
                }
            }, this.state = _extends({}, Loadable.init(this.loadableApi), {
                rating: 0,
                comment: "",
                navTitle: ""
            }), this.api = Loadable.api(this.loadableApi, this);
        }
    }, {
        key: "getActionStatus",
        value: function(t, e) {
            var r = (0, _index3.getActionCnByType)(e);
            switch (t) {
              case "mark":
                return "想" + r;

              case "doing":
                return "在" + r;

              case "done":
                return r + "过";

              default:
                return "标记";
            }
        }
    }, {
        key: "componentDidMount",
        value: (n = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, r, n, a, i;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = this.$router.params, r = e.id, n = e.action, a = e.type, this.id = r, 
                    t.next = 4, this.api.interest(r);

                  case 4:
                    i = t.sent, this.setState({
                        rating: i.data.rating ? i.data.rating.value : 0,
                        comment: i.data.comment,
                        navTitle: this.getActionStatus(n, a)
                    }), _index2.default.setNavigationBarTitle({
                        title: this.getActionStatus(n, a)
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return n.apply(this, arguments);
        })
    }, {
        key: "onInput",
        value: function(t) {
            var e = t.target.value;
            this.setState({
                comment: e
            });
        }
    }, {
        key: "onRate",
        value: function(t) {
            this.setState({
                rating: t
            });
        }
    }, {
        key: "onSubmit",
        value: (r = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var r, n, a, i, o, s;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = this.state, n = r.rating, a = r.comment, i = this.$router.params, o = i.id, 
                    s = i.action, _reportApi.reportApi.addFormId(e.detail.formId), t.next = 5, this.subjectApi.mark(o, s, {
                        rating: n,
                        comment: a,
                        sync_douban: 0
                    });

                  case 5:
                    t.sent.code || (_index2.default.showToast({
                        title: "标记成功",
                        icon: "success"
                    }), _index2.default.navigateBack());

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t) {
            return r.apply(this, arguments);
        })
    }, {
        key: "onDelete",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = this.$router.params.id, t.next = 3, this.subjectApi.unmark(e);

                  case 3:
                    t.sent.code || (_index2.default.showToast({
                        title: "删除成功",
                        icon: "success"
                    }), _index2.default.navigateBack());

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state.interest.data, e = this.$router.params.action, r = "mark" !== e ? 2 * this.__state.rating : null;
            return Object.assign(this.__state, {
                anonymousState__temp: r,
                action: e,
                _movieInterest: t
            }), this.__state;
        }
    } ]), o;
}();

Mark.properties = {}, Mark.$$events = [ "onRate", "onSubmit", "onInput", "onDelete" ], 
exports.default = Mark, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Mark, !0));