Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, n);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var u = e.apply(this, arguments);
        return new Promise(function(i, a) {
            return function t(e, r) {
                try {
                    var n = u[e](r), o = n.value;
                } catch (e) {
                    return void a(e);
                }
                if (!n.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                i(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Review = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "id" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    var t;
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            var e, t = this;
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.id = (e = t.$router.params.id, t.$router.params.q && (decodeURIComponent(t.$router.params.q).match(/review\/(\w+)/) || [])[1] || e);
        }
    }, {
        key: "componentDidMount",
        value: (t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t = this.$router.params.subject_title, _index2.default.setNavigationBarTitle({
                        title: t + "的评论"
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "onShareAppMessage",
        value: function() {
            var t = this;
            return {
                title: "《" + this.$router.params.subject_title + "》影评",
                path: "/pages/subject/review?" + Object.keys(this.$router.params).map(function(e) {
                    return e + "=" + t.$router.params[e];
                }).join("&")
            };
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.id;
            return Object.assign(this.__state, {
                id: e
            }), this.__state;
        }
    } ]), a;
}();

Review.properties = {}, Review.$$events = [], exports.default = Review, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Review, !0));