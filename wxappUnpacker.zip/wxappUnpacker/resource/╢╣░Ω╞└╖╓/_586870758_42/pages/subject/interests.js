Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n]);
    }
    return t;
}, _createClass = function() {
    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, r) {
        return e && n(t.prototype, e), r && n(t, r), t;
    };
}(), _get = function t(e, r, n) {
    null === e && (e = Function.prototype);
    var i = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === i) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, n);
    }
    if ("value" in i) return i.value;
    var s = i.get;
    return void 0 !== s ? s.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _subjectApi = require("../../services/subject-api.js");

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var o = t.apply(this, arguments);
        return new Promise(function(a, s) {
            return function e(t, r) {
                try {
                    var n = o[t](r), i = n.value;
                } catch (t) {
                    return void s(t);
                }
                if (!n.done) return Promise.resolve(i).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                a(i);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Subject = function(t) {
    function s() {
        var t, e, r;
        _classCallCheck(this, s);
        for (var n = arguments.length, i = Array(n), a = 0; a < n; a++) i[a] = arguments[a];
        return (e = r = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(i)))).$usedState = [ "anonymousState__temp", "_ratingData", "loopArray0", "_subject", "$anonymousCallee__0", "_interests", "filterType" ], 
        r.onFilterTypeChange = function(t) {
            t !== r.state.filterType && r.setState({
                filterType: t,
                interests: {
                    data: null
                }
            }, function() {
                r.api.interests(r.id, {
                    start: 0,
                    count: 20,
                    status: r.state.filterType
                });
            });
        }, r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    var e;
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            var n = this;
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).apply(this, arguments), 
            this.id = "", this.subjectApi = new _subjectApi.SubjectAPI(this.$router.params.type), 
            this.loadableApi = {
                subject: {
                    api: this.subjectApi.subject,
                    init: null
                },
                rating: {
                    api: this.subjectApi.rating,
                    init: null
                },
                interests: {
                    api: this.subjectApi.interests,
                    init: null,
                    updater: function(t) {
                        var e = n.state.interests && n.state.interests.data;
                        if (e) {
                            var r = e.interests.concat(t.interests);
                            return Object.assign({}, t, {
                                interests: r
                            });
                        }
                        return t;
                    }
                }
            }, this.state = _extends({}, Loadable.init(this.loadableApi), {
                filterType: "done"
            }), this.api = Loadable.api(this.loadableApi, this);
        }
    }, {
        key: "componentDidMount",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, r;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = this.$router.params.id, this.id = e, t.next = 4, this.api.subject(e);

                  case 4:
                    r = t.sent, this.api.rating(e), this.api.interests(e, {
                        start: 0,
                        count: 20,
                        status: this.state.filterType
                    }), _index2.default.setNavigationBarTitle({
                        title: r.data.title + "的短评"
                    });

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "onReachBottom",
        value: function() {
            var t = this.state.interests.data;
            t && (this.api.disableLoadingFlag(), this.api.interests(this.id, {
                start: t.start + t.count,
                count: t.count,
                status: this.state.filterType
            }));
        }
    }, {
        key: "getPercent",
        value: function(t) {
            return (100 * t).toFixed(1) + "%";
        }
    }, {
        key: "_createData",
        value: function() {
            var r = this;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state.subject.data, e = this.__state.rating.data, n = this.__state.interests.data;
            if (!t || !e) return null;
            var i = "《" + t.title + "》的短评", a = e.stats.slice(0).reverse(), s = e.stats.slice(0).reverse().map(function(t, e) {
                return t = {
                    $original: (0, _index.internal_get_original)(t)
                }, {
                    $loopState__temp3: r.getPercent(t.$original),
                    $original: t.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp: i,
                _ratingData: e,
                loopArray0: s,
                _subject: t,
                $anonymousCallee__0: a,
                _interests: n
            }), this.__state;
        }
    } ]), s;
}();

Subject.properties = {}, Subject.$$events = [ "onFilterTypeChange" ], exports.default = Subject, 
Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Subject, !0));