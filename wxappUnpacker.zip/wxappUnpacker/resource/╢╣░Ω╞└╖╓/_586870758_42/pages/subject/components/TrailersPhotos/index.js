Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, o);
    }
    if ("value" in n) return n.value;
    var a = n.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var TrailersPhotos = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, o = Array(r), i = 0; i < r; i++) o[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "photos", "loopArray0", "trailers", "videoUrl" ], 
        n.play = function() {
            var e = n.props.trailers;
            n.setState({
                videoUrl: e.trailers[0].video_url
            });
        }, n.handlePreview = function(e) {
            var t = e.target.dataset.url, r = n.props.photos, o = r ? r.photos.map(function(e) {
                return e.image.large.url;
            }) : [ t ];
            _index2.default.previewImage({
                current: t,
                urls: o
            });
        }, n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                videoUrl: ""
            };
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.trailers, r = e.photos, o = (this.__state.videoUrl, 
            r ? r.photos.map(function(e) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp2: r ? (0, _index.internal_inline_style)({
                        width: (0, _index.pxTransform)(160 * e.$original.image.normal.width / e.$original.image.normal.height)
                    }) : null,
                    $original: e.$original
                };
            }) : []);
            return Object.assign(this.__state, {
                photos: r,
                loopArray0: o,
                trailers: t
            }), this.__state;
        }
    } ]), a;
}();

TrailersPhotos.properties = {
    trailers: {
        type: null,
        value: null
    },
    photos: {
        type: null,
        value: null
    }
}, TrailersPhotos.$$events = [ "play", "handlePreview" ], exports.default = TrailersPhotos, 
Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(TrailersPhotos));