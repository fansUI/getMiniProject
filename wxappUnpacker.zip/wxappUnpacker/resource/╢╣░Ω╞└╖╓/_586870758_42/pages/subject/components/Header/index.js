Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, n);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _tslib = require("../../../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../../utils/index.js"), _reportApi = require("../../../../services/report-api.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Header = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "subject", "isNotDone", "isMark", "isDoing", "isDone", "actionCn", "isLogin", "isPhoneVerified" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "renderMeta",
        value: function() {
            var e = [], t = this.props.subject;
            switch (t.type) {
              case "movie":
                var r = t;
                e.push(r.genres, r.countries, r.release_date ? [ r.release_date.replace("-", "年").replace("-", "月") + "日上映" ] : null, (r.durations || []).slice(0, 1).map(function(e) {
                    return "片长" + e;
                }));
                break;

              case "tv":
                var n = t;
                e.push(n.genres, n.countries, n.release_date ? [ n.release_date.replace("-", "年").replace("-", "月") + "日首播" ] : null, [ n.episodes_count + "集" ], (n.durations || []).slice(0, 1).map(function(e) {
                    return "单集片长" + e;
                }));
                break;

              case "book":
                var o = t;
                e.push(o.author, o.press, [ "出版时间：" + o.pubdate.join(" ") ]);
                break;

              case "music":
                var i = t;
                e.push(i.genres, [ "表演者：" + i.singer.map(function(e) {
                    return e.name;
                }).join(" ") ], [ "发行时间：" + i.pubdate.join(" ") ]);
            }
            return e.filter(Boolean).map(function(e) {
                return e.join(" ");
            }).join(" / ");
        }
    }, {
        key: "handleMarkClick",
        value: function(e) {
            var t = this.props, r = t.subject;
            t.isLogin, t.isPhoneVerified;
            _reportApi.reportApi.addFormId(e.detail.formId);
            var n = e.detail.target.dataset.action;
            _index2.default.navigateTo({
                url: "/pages/subject/mark?id=" + r.id + "&action=" + n + "&type=" + r.type
            });
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.subject;
            if (!e) return null;
            var t = e.interest, r = t && "mark" === t.status, n = t && "doing" === t.status, o = t && "done" === t.status, i = !t || "done" !== t.status, a = (0, 
            _index3.getActionCnByType)(e.type), s = (0, _index3.setRatio)(e.type), u = this.renderMeta(), l = -1 < [ "tv", "book", "music" ].indexOf(e.type) && i;
            return Object.assign(this.__state, {
                anonymousState__temp: s,
                anonymousState__temp2: u,
                anonymousState__temp3: l,
                subject: e,
                isNotDone: i,
                isMark: r,
                isDoing: n,
                isDone: o,
                actionCn: a
            }), this.__state;
        }
    } ]), a;
}();

Header.properties = {
    subject: {
        type: null,
        value: null
    },
    isLogin: {
        type: null,
        value: null
    },
    isPhoneVerified: {
        type: null,
        value: null
    }
}, Header.$$events = [ "handleMarkClick" ], tslib_1.__decorate([ (0, _index3.requireLogin)("props.isLogin"), (0, 
_index3.requirePhoneVerified)("props.isPhoneVerified") ], Header.prototype, "handleMarkClick", null), 
exports.default = Header, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Header));