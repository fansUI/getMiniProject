Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(t, e, n) {
        return e && r(t.prototype, e), n && r(t, n), t;
    };
}(), _get = function t(e, n, r) {
    null === e && (e = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(e, n);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, n, r);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Intro = function(t) {
    function i() {
        var t, e, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return (e = n = _possibleConstructorReturn(this, (t = i.__proto__ || Object.getPrototypeOf(i)).call.apply(t, [ this ].concat(o)))).$usedState = [ "_clamp", "row", "_showExpand", "intro", "clamp", "showExpand" ], 
        n.handleExpand = function() {
            n.setState(function(t) {
                return {
                    clamp: !t.clamp
                };
            });
        }, n.$$refs = [], _possibleConstructorReturn(n, e);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function() {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                clamp: !1,
                showExpand: !1
            };
        }
    }, {
        key: "componentDidMount",
        value: function() {
            var e = this, n = this.props.row;
            _index2.default.createSelectorQuery().in(this.$scope).select(".intro").boundingClientRect(function(t) {
                t.height > 24 * n && e.setState({
                    clamp: !0,
                    showExpand: !0
                });
            }).exec();
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props, e = t.intro, n = t.row, r = void 0 === n ? 4 : n, o = this.__state.clamp, a = this.__state.showExpand;
            return Object.assign(this.__state, {
                _clamp: o,
                row: r,
                _showExpand: a,
                intro: e
            }), this.__state;
        }
    } ]), i;
}();

Intro.properties = {
    row: {
        type: null,
        value: null
    },
    intro: {
        type: null,
        value: null
    }
}, Intro.$$events = [ "handleExpand" ], exports.default = Intro, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Intro));