Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(t, e, n) {
        return e && r(t.prototype, e), n && r(t, n), t;
    };
}(), _get = function t(e, n, r) {
    null === e && (e = Function.prototype);
    var a = Object.getOwnPropertyDescriptor(e, n);
    if (void 0 === a) {
        var o = Object.getPrototypeOf(e);
        return null === o ? void 0 : t(o, n, r);
    }
    if ("value" in a) return a.value;
    var i = a.get;
    return void 0 !== i ? i.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var RatingStats = function(t) {
    function i() {
        var t, e, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, a = Array(r), o = 0; o < r; o++) a[o] = arguments[o];
        return (e = n = _possibleConstructorReturn(this, (t = i.__proto__ || Object.getPrototypeOf(i)).call.apply(t, [ this ].concat(a)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "ratingData", "nullRatingReason", "isWhiteStar", "rating", "size", "ratingColor" ], 
        n.$$refs = [], _possibleConstructorReturn(n, e);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(t) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, t);
        }
    }, {
        key: "getPercent",
        value: function(t) {
            return 100 * t.toFixed(2) + "%";
        }
    }, {
        key: "getRatingValueStyle",
        value: function(t, e) {
            return e ? {
                fontSize: (0, _index.pxTransform)(t),
                color: "#FFF"
            } : {
                fontSize: (0, _index.pxTransform)(t)
            };
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props, e = t.ratingData, n = t.rating, r = t.nullRatingReason, a = t.size, o = 30;
            "large" === a && (o = 40);
            var i = !1;
            if ("white" === t.ratingColor && (i = !0), !e) return null;
            var l = (0, _index.internal_inline_style)(this.getRatingValueStyle(o, i)), s = n.value.toFixed(1), u = r ? null : (0, 
            _index.internal_inline_style)(i ? {
                color: "rgba(255,255,255,0.20)"
            } : "");
            return Object.assign(this.__state, {
                anonymousState__temp: l,
                anonymousState__temp2: s,
                anonymousState__temp3: u,
                ratingData: e,
                nullRatingReason: r,
                isWhiteStar: i,
                rating: n,
                size: a
            }), this.__state;
        }
    } ]), i;
}();

RatingStats.properties = {
    ratingData: {
        type: null,
        value: null
    },
    rating: {
        type: null,
        value: null
    },
    nullRatingReason: {
        type: null,
        value: null
    },
    size: {
        type: null,
        value: null
    },
    ratingColor: {
        type: null,
        value: null
    }
}, RatingStats.$$events = [], exports.default = RatingStats, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(RatingStats));