Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var s = Object.getPrototypeOf(t);
        return null === s ? void 0 : e(s, n, r);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _helpers = require("../../../../utils/helpers.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var InterestsItemComponent = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, o = Array(r), s = 0; s < r; s++) o[s] = arguments[s];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "interest", "isClamped" ], 
        n.handleClickComment = function() {
            n.state.isClamped && n.setState({
                isClamped: !1
            });
        }, n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                isClamped: !0
            };
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.interest, t = e.rating ? 2 * e.rating.value : null, n = (0, 
            _helpers.formatTime)(e.create_time);
            return Object.assign(this.__state, {
                anonymousState__temp: t,
                anonymousState__temp2: n,
                interest: e
            }), this.__state;
        }
    } ]), a;
}();

InterestsItemComponent.properties = {
    interest: {
        type: null,
        value: null
    }
}, InterestsItemComponent.$$events = [ "handleClickComment" ], exports.default = InterestsItemComponent, 
Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(InterestsItemComponent));