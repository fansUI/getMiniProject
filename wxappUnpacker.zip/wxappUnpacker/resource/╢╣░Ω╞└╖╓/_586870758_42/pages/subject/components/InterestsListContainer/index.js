Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, n);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = require("../../../../utils/index.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var InterestListContainer = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "loopArray0", "filterTypes", "commentCount", "interests", "currentFilterType", "subjectType", "__fn_onFilterTypeChange" ], 
        r.getSwitcherLabelText = function(e) {
            var t = (0, _index2.getActionCnByType)(r.props.subjectType);
            switch (e) {
              case "done":
                return t + "过";

              case "mark":
                return "想" + t;
            }
        }, r.switchFilterType = function(e) {
            r.__triggerPropsFn("onFilterTypeChange", [ null ].concat([ e ]));
        }, r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments);
        }
    }, {
        key: "_createData",
        value: function() {
            var t = this;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = [ "mark", "done" ], r = this.getSwitcherLabelText(this.__props.currentFilterType), n = e.map(function(e) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp3: t.__props.currentFilterType === e.$original,
                    $loopState__temp5: t.getSwitcherLabelText(e.$original),
                    $original: e.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp: r,
                loopArray0: n,
                filterTypes: e
            }), this.__state;
        }
    } ]), a;
}();

InterestListContainer.properties = {
    commentCount: {
        type: null,
        value: null
    },
    interests: {
        type: null,
        value: null
    },
    currentFilterType: {
        type: null,
        value: null
    },
    subjectType: {
        type: null,
        value: null
    },
    __fn_onFilterTypeChange: {
        type: null,
        value: null
    }
}, InterestListContainer.$$events = [ "switchFilterType" ], exports.default = InterestListContainer, 
Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(InterestListContainer));