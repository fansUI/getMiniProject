Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(t, e) {
        for (var r = 0; r < e.length; r++) {
            var o = e[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(t, e, r) {
        return e && o(t.prototype, e), r && o(t, r), t;
    };
}(), _get = function t(e, r, o) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(e);
        return null === i ? void 0 : t(i, r, o);
    }
    if ("value" in n) return n.value;
    var l = n.get;
    return void 0 !== l ? l.call(o) : void 0;
}, _index = require("../../../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var DropdownItem = function(t) {
    function l() {
        var t, e, r;
        _classCallCheck(this, l);
        for (var o = arguments.length, n = Array(o), i = 0; i < o; i++) n[i] = arguments[i];
        return (e = r = _possibleConstructorReturn(this, (t = l.__proto__ || Object.getPrototypeOf(l)).call.apply(t, [ this ].concat(n)))).$usedState = [ "isActivated", "children" ], 
        r.onClick = function() {
            r.props.onClickItem && r.__triggerPropsFn("onClickItem", [ null ].concat([]));
        }, r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    return _inherits(l, _index.Component), _createClass(l, [ {
        key: "_constructor",
        value: function(t) {
            _get(l.prototype.__proto__ || Object.getPrototypeOf(l.prototype), "_constructor", this).call(this, t);
        }
    }, {
        key: "_createData",
        value: function() {
            return this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {}, 
            Object.assign(this.__state, {}), this.__state;
        }
    } ]), l;
}();

DropdownItem.properties = {
    isActivated: {
        type: null,
        value: null
    },
    onClickItem: {
        type: null,
        value: null
    },
    __fn_onClickItem: {
        type: null,
        value: null
    }
}, DropdownItem.$$events = [ "onClick" ], exports.default = DropdownItem, Component(require("../../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(DropdownItem));