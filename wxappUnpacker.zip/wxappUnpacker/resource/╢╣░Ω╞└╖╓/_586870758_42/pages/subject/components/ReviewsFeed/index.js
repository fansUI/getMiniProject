Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, n);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../../utils/index.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var ReviewsFeed = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "reviews", "loopArray0" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "handleClick",
        value: function(e, t) {
            t.preventDefault(), t.stopPropagation(), _index2.default.navigateTo({
                url: "/pages/user/user?id=" + e
            });
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.reviews;
            if (!e) return null;
            var t = e.reviews.map(function(e) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp2: (0, _index3.getActionCnByType)(e.$original.subject.type),
                    $loopState__temp4: e.$original.rating ? 2 * e.$original.rating.value : null,
                    $original: e.$original
                };
            });
            return Object.assign(this.__state, {
                reviews: e,
                loopArray0: t
            }), this.__state;
        }
    } ]), a;
}();

ReviewsFeed.properties = {
    reviews: {
        type: null,
        value: null
    }
}, ReviewsFeed.$$events = [ "handleClick" ], exports.default = ReviewsFeed, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(ReviewsFeed));