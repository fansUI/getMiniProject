Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(t, e, n) {
        return e && r(t.prototype, e), n && r(t, n), t;
    };
}(), _get = function t(e, n, r) {
    null === e && (e = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(e, n);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, n, r);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var RatingCard = function(t) {
    function i() {
        var t, e, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return (e = n = _possibleConstructorReturn(this, (t = i.__proto__ || Object.getPrototypeOf(i)).call.apply(t, [ this ].concat(o)))).$usedState = [ "ratingData", "rating", "nullRatingReason", "__fn_onClick" ], 
        n.$$refs = [], _possibleConstructorReturn(n, e);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(t) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, t);
        }
    }, {
        key: "getPercent",
        value: function(t) {
            return 100 * t.toFixed(2) + "%";
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props, e = t.ratingData, n = t.rating, r = t.nullRatingReason;
            t.onNavigateToInterests;
            return e ? (Object.assign(this.__state, {
                ratingData: e,
                rating: n,
                nullRatingReason: r
            }), this.__state) : null;
        }
    }, {
        key: "funPrivateDwZLL",
        value: function() {
            this.__triggerPropsFn("onNavigateToInterests", [].concat(Array.prototype.slice.call(arguments)));
        }
    } ]), i;
}();

RatingCard.properties = {
    ratingData: {
        type: null,
        value: null
    },
    rating: {
        type: null,
        value: null
    },
    nullRatingReason: {
        type: null,
        value: null
    },
    onNavigateToInterests: {
        type: null,
        value: null
    },
    __fn_onClick: {
        type: null,
        value: null
    },
    __fn_onNavigateToInterests: {
        type: null,
        value: null
    }
}, RatingCard.$$events = [ "funPrivateDwZLL" ], exports.default = RatingCard, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(RatingCard));