Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, o);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Celebrities = function(e) {
    function s() {
        var e, t, r;
        _classCallCheck(this, s);
        for (var o = arguments.length, n = Array(o), i = 0; i < o; i++) n[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(e, [ this ].concat(n)))).$usedState = [ "actors", "directors" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(e) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.directors, r = e.actors;
            return r ? (Object.assign(this.__state, {
                actors: r,
                directors: t
            }), this.__state) : null;
        }
    } ]), s;
}();

Celebrities.properties = {
    directors: {
        type: null,
        value: null
    },
    actors: {
        type: null,
        value: null
    }
}, Celebrities.$$events = [], exports.default = Celebrities, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Celebrities));