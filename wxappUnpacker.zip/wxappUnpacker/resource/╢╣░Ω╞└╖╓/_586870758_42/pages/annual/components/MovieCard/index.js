Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, o);
    }
    if ("value" in n) return n.value;
    var a = n.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var MovieCard = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var o = arguments.length, n = Array(o), i = 0; i < o; i++) n[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(n)))).$usedState = [ "item", "isPhoneVerified" ], 
        r.handleNavi = function() {
            var e = r.props, t = e.item;
            e.isPhoneVerified ? t && t.id && _index2.default.navigateTo({
                url: "/pages/subject/mark?id=" + t.id + "&action=done&type=movie"
            }) : _index2.default.navigateTo({
                url: "/pages/user/verify"
            });
        }, r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments);
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.item;
            return e ? (Object.assign(this.__state, {
                item: e
            }), this.__state) : null;
        }
    } ]), a;
}();

MovieCard.properties = {
    item: {
        type: null,
        value: null
    },
    isPhoneVerified: {
        type: null,
        value: null
    }
}, MovieCard.$$events = [ "handleNavi" ], exports.default = MovieCard, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(MovieCard));