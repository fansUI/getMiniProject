Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, n, r);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _helpers = require("../../../../utils/helpers.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var RankListItem = function(e) {
    function i() {
        var e, t, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return (t = n = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "item" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "getBgImageStyle",
        value: function(e) {
            return "background-image: url(" + e + ")";
        }
    }, {
        key: "getMaskBg",
        value: function(e) {
            return "background: " + (0, _helpers.hex2rgb)(e, .5);
        }
    }, {
        key: "getInfoContent",
        value: function(e) {
            return "background: " + (0, _helpers.hex2rgb)(e, 1);
        }
    }, {
        key: "handleClick",
        value: function(e, t) {
            t.preventDefault(), _index2.default.navigateTo({
                url: "/pages/annual/list?id=" + e
            });
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.item, t = e.background_color_scheme.primary_color_dark, n = (0, 
            _index.internal_inline_style)(this.getBgImageStyle(e.header_bg_image)), r = (0, 
            _index.internal_inline_style)(this.getMaskBg(t)), o = (0, _index.internal_inline_style)(this.getInfoContent(t));
            return Object.assign(this.__state, {
                anonymousState__temp: n,
                anonymousState__temp2: r,
                anonymousState__temp3: o,
                item: e
            }), this.__state;
        }
    } ]), i;
}();

RankListItem.properties = {
    item: {
        type: null,
        value: null
    }
}, RankListItem.$$events = [ "handleClick" ], exports.default = RankListItem, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(RankListItem));