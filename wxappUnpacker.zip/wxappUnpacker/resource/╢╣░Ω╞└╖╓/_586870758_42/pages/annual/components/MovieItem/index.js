Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, r) {
        return e && n(t.prototype, e), r && n(t, r), t;
    };
}(), _get = function t(e, r, n) {
    null === e && (e = Function.prototype);
    var a = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === a) {
        var o = Object.getPrototypeOf(e);
        return null === o ? void 0 : t(o, r, n);
    }
    if ("value" in a) return a.value;
    var s = a.get;
    return void 0 !== s ? s.call(n) : void 0;
}, _tslib = require("../../../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../../npm/@tarojs/redux/index.js"), _annual = require("../../../../actions/annual.js");

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}

function _objectDestructuringEmpty(t) {
    if (null == t) throw new TypeError("Cannot destructure undefined");
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var star0ImgPath = "/pages/annual/components/MovieItem/assets/film-star-0.png", star1ImgPath = "/pages/annual/components/MovieItem/assets/film-star-1.png", star2ImgPath = "/pages/annual/components/MovieItem/assets/film-star-2.png", star3ImgPath = "/pages/annual/components/MovieItem/assets/film-star-3.png", star4ImgPath = "/pages/annual/components/MovieItem/assets/film-star-4.png", star5ImgPath = "/pages/annual/components/MovieItem/assets/film-star-5.png", MovieItem = (_temp2 = _class = function(t) {
    function s() {
        var t, e, o;
        _classCallCheck(this, s);
        for (var r = arguments.length, n = Array(r), a = 0; a < r; a++) n[a] = arguments[a];
        return (e = o = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "item", "isWatched", "boxShadow", "boxBorder", "handleMark" ], 
        o.handleClick = function(t) {
            var e = o.props.item;
            _index2.default.navigateTo({
                url: "/pages/subject/subject?id=" + e.id + "&type=movie"
            });
        }, o.toggleLike = function(t) {
            var e = o.props, r = e.item, n = e.handleMark, a = r.interest ? "unmark" : "mark";
            n(r.id, a);
        }, o.getWatchedCls = function(t) {
            var e = t.rating;
            return e ? "watched star-" + e.value : "watched star-0";
        }, o.getWatchedImgPath = function(t) {
            var e = t.rating;
            if (!e) return star0ImgPath;
            switch (e.value) {
              case 1:
                return star1ImgPath;

              case 2:
                return star2ImgPath;

              case 3:
                return star3ImgPath;

              case 4:
                return star4ImgPath;

              case 5:
                return star5ImgPath;

              default:
                return star0ImgPath;
            }
        }, o.$$refs = [], _possibleConstructorReturn(o, e);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).apply(this, arguments);
        }
    }, {
        key: "getWrapperStyle",
        value: function(t, e) {
            return "item-wrapper " + (t ? "shadow-box" : "") + " " + (e ? "box-border" : "");
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props.item, e = this.__props.boxShadow, r = void 0 !== e && e, n = this.__props.boxBorder, a = void 0 !== n && n, o = t.interest && "done" === t.interest.status, s = o ? this.getWatchedImgPath(t.interest) : null, i = this.getWrapperStyle(r, a);
            return Object.assign(this.__state, {
                anonymousState__temp: s,
                anonymousState__temp2: i,
                item: t,
                isWatched: o
            }), this.__state;
        }
    } ]), s;
}(), _class.properties = {
    item: {
        type: null,
        value: null
    },
    boxShadow: {
        type: null,
        value: null
    },
    boxBorder: {
        type: null,
        value: null
    },
    handleMark: {
        type: null,
        value: null
    }
}, _class.$$events = [ "handleClick", "toggleLike" ], _temp2);

MovieItem = tslib_1.__decorate([ (0, _index3.connect)(function(t) {
    return _objectDestructuringEmpty(t), {};
}, function(r) {
    return {
        handleMark: function(t, e) {
            "mark" === e ? ((0, _annual.markItem)(t)(r), (0, _index.showToast)({
                title: "已经添加到想看列表",
                icon: "none"
            })) : ((0, _annual.unMarkItem)(t)(r), (0, _index.showToast)({
                title: "已从想看列表中移除",
                icon: "none"
            }));
        }
    };
}) ], MovieItem), exports.default = MovieItem, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(MovieItem));