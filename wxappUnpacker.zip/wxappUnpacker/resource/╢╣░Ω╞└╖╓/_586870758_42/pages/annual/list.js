Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, r);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _tslib = require("../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _account = require("../../actions/account.js"), _annual = require("../../actions/annual.js"), _user = require("../../actions/user.js"), _index3 = require("../../npm/@tarojs/redux/index.js"), _index4 = require("../../utils/index.js"), _base = require("../../npm/js-base64/base64.js"), _index5 = require("../../domains/index.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _asyncToGenerator(e) {
    return function() {
        var s = e.apply(this, arguments);
        return new Promise(function(i, a) {
            return function t(e, n) {
                try {
                    var r = s[e](n), o = r.value;
                } catch (e) {
                    return void a(e);
                }
                if (!r.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                i(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var PAGE_TITLE = "豆瓣2018年度电影榜单", SAVE_IMG_URL = "https://www.douban.com/service/screenshot/save_html", List = (_temp2 = _class = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, o = Array(r), i = 0; i < r; i++) o[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "loopArray0", "subject_collection", "subject_collection_items", "_navTitle", "total", "isPhoneVerified", "$anonymousCallee__0", "related_list", "openShareDialog", "shareImg", "getAccountInfo", "fetchUserInfo", "fetchList", "resetList", "accountInfo", "annual", "userInfo" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    var t;
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.state = {
                openShareDialog: !1,
                shareImg: ""
            };
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this._setTitle(), this.props.getAccountInfo();
            var e = _index2.default.getStorageSync("douban_user_id");
            e && this.props.fetchUserInfo(e);
        }
    }, {
        key: "componentDidShow",
        value: function() {
            var e = this.$router.params, t = e.id, n = e.scene;
            if (n) try {
                t = (n = JSON.parse(_base.Base64.decode(n))).id;
            } catch (e) {
                console.error(e, n);
            }
            this._isLogin() ? this.props.fetchList(t) : (0, _index4.redirectToLogin)();
        }
    }, {
        key: "componentDidHide",
        value: function() {
            this.props.resetList();
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            this.props.resetList();
        }
    }, {
        key: "getItemCls",
        value: function(e) {
            return "item-num-icon item-num-" + (e + 2);
        }
    }, {
        key: "toggleShare",
        value: (t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, n, r, o, i;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = !this.state.openShareDialog, n = this.state.shareImg, t) return _index2.default.showLoading({
                        title: "图片生成中..."
                    }), r = {
                        user: this.props.accountInfo,
                        collection: (0, _index5.collectionToLite)(this.props.annual),
                        qrImg: this.props.annual.subject_collection.wx_qr_code,
                        qrShape: "rect"
                    }, e.next = 7, _index2.default.request({
                        url: SAVE_IMG_URL,
                        method: "POST",
                        data: {
                            type: "report2018",
                            data: JSON.stringify({
                                data: JSON.stringify(r)
                            })
                        },
                        header: {
                            "content-type": "application/x-www-form-urlencoded"
                        }
                    }).catch(function(e) {
                        throw (0, _index.showToast)({
                            title: "图片生成失败",
                            icon: "error"
                        }), e;
                    });
                    e.next = 17;
                    break;

                  case 7:
                    return o = e.sent, e.next = 10, (0, _index4.sleep)(500);

                  case 10:
                    return 750, n = o.data.img_src + (0 <= o.data.img_src.indexOf("?") ? "&" : "?") + "window_size=750,1334", 
                    e.next = 14, _index2.default.getImageInfo({
                        src: n
                    });

                  case 14:
                    i = e.sent, n = i.path, _index2.default.hideLoading();

                  case 17:
                    this.setState({
                        openShareDialog: t,
                        shareImg: n
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "getListTitle",
        value: function(e) {
            var t = e.name, n = e.medium_name, r = e.rank_type, o = e.id, i = t;
            return "year" === r && -1 !== o.indexOf("2018") && (i = n), i;
        }
    }, {
        key: "jumpToOverView",
        value: function() {
            _index2.default.navigateTo({
                url: "/pages/annual/overview"
            });
        }
    }, {
        key: "_createData",
        value: function() {
            var n = this;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.annual, r = e.userInfo, o = t.total, i = t.subject_collection, a = t.subject_collection_items, s = r.isPhoneVerified;
            if (!i || 0 === a.length) return null;
            var u = this.getListTitle(i), l = i.related_charts.items, c = i.medium_name, _ = a.slice(1, 10), p = a.slice(1, 10).map(function(e, t) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp3: n.getItemCls(t),
                    $original: e.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp: u,
                loopArray0: p,
                subject_collection: i,
                subject_collection_items: a,
                _navTitle: c,
                total: o,
                isPhoneVerified: s,
                $anonymousCallee__0: _,
                related_list: l
            }), this.__state;
        }
    }, {
        key: "_setTitle",
        value: function() {
            _index2.default.setNavigationBarTitle({
                title: PAGE_TITLE
            });
        }
    }, {
        key: "_isLogin",
        value: function() {
            return !!_index2.default.getStorageSync("access_token");
        }
    } ]), a;
}(), _class.properties = {
    getAccountInfo: {
        type: null,
        value: null
    },
    fetchUserInfo: {
        type: null,
        value: null
    },
    fetchList: {
        type: null,
        value: null
    },
    resetList: {
        type: null,
        value: null
    },
    accountInfo: {
        type: null,
        value: null
    },
    annual: {
        type: null,
        value: null
    },
    userInfo: {
        type: null,
        value: null
    }
}, _class.$$events = [ "toggleShare", "jumpToOverView" ], _temp2);

List = tslib_1.__decorate([ (0, _index3.connect)(function(e) {
    return {
        accountInfo: e.accountInfo,
        annual: e.annual,
        userInfo: e.userInfo
    };
}, function(t) {
    return {
        getAccountInfo: function() {
            t((0, _account.getAccountInfo)());
        },
        fetchList: function(e) {
            t((0, _annual.fetchList)(e));
        },
        resetList: function() {
            t((0, _annual.resetList)());
        },
        fetchUserInfo: function(e) {
            t((0, _user.fetchUserInfo)(e));
        }
    };
}) ], List), exports.default = List, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(List, !0));