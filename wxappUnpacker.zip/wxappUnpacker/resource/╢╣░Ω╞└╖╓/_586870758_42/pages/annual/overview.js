Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, r);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var annualUrl = "https://m.douban.com/annual/2018", webviewurl = "https://accounts.douban.com/auth2_redir?url=https://m.douban.com/annual/2018", PAGE_TITLE = "豆瓣2018年度电影榜单", Overview = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, o = Array(r), i = 0; i < r; i++) o[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "url" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.state = {
                url: webviewurl
            };
        }
    }, {
        key: "componentDidShow",
        value: function() {
            if (this._setTitle(), this._isLogin()) {
                var e = _index2.default.getStorageSync("access_token");
                this.setState({
                    url: "https://accounts.douban.com/auth2_redir?url=https://m.douban.com/annual/2018&token=" + e
                });
            } else this.setState({
                url: webviewurl
            });
        }
    }, {
        key: "componentDidHide",
        value: function() {
            this.setState({
                url: ""
            });
        }
    }, {
        key: "_createData",
        value: function() {
            return this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {}, 
            Object.assign(this.__state, {}), this.__state;
        }
    }, {
        key: "_isLogin",
        value: function() {
            return !!_index2.default.getStorageSync("access_token");
        }
    }, {
        key: "_setTitle",
        value: function() {
            _index2.default.setNavigationBarTitle({
                title: PAGE_TITLE
            });
        }
    }, {
        key: "_logout",
        value: function() {
            _index2.default.removeStorageSync("access_token"), _index2.default.removeStorageSync("account_info");
        }
    } ]), a;
}();

Overview.properties = {}, Overview.$$events = [], exports.default = Overview, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Overview, !0));