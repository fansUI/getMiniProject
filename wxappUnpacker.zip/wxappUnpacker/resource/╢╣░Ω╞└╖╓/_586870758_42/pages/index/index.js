Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var o = arguments[e];
        for (var i in o) Object.prototype.hasOwnProperty.call(o, i) && (t[i] = o[i]);
    }
    return t;
}, _createClass = function() {
    function i(t, e) {
        for (var o = 0; o < e.length; o++) {
            var i = e[o];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(t, e, o) {
        return e && i(t.prototype, e), o && i(t, o), t;
    };
}(), _get = function t(e, o, i) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, o);
    if (void 0 === n) {
        var r = Object.getPrototypeOf(e);
        return null === r ? void 0 : t(r, o, i);
    }
    if ("value" in n) return n.value;
    var a = n.get;
    return void 0 !== a ? a.call(i) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _frodoApi = require("../../services/frodo-api.js");

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    return e.default = t, e;
}

function _asyncToGenerator(t) {
    return function() {
        var s = t.apply(this, arguments);
        return new Promise(function(r, a) {
            return function e(t, o) {
                try {
                    var i = s[t](o), n = i.value;
                } catch (t) {
                    return void a(t);
                }
                if (!i.done) return Promise.resolve(n).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                r(n);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var loadableApi = {
    movieShowing: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("movie_showing");
        },
        init: {
            subject_collection: {
                name: "影院热映",
                id: "movie_showing"
            },
            subject_collection_items: []
        },
        toast: !1
    },
    movieHotGaia: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("movie_hot_gaia");
        },
        init: {
            subject_collection: {
                name: "豆瓣热门",
                id: "movie_hot_gaia"
            },
            subject_collection_items: []
        },
        toast: !1
    },
    tvHot: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("tv_hot");
        },
        init: {
            subject_collection: {
                name: "近期热门剧集",
                id: "tv_hot"
            },
            subject_collection_items: []
        },
        toast: !1
    },
    tvVarietyShow: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("tv_variety_show");
        },
        init: {
            subject_collection: {
                name: "近期热门综艺节目",
                id: "tv_variety_show"
            },
            subject_collection_items: []
        },
        toast: !1
    },
    bookBestseller: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("book_bestseller");
        },
        init: {
            subject_collection: {
                name: "畅销图书",
                id: "book_bestseller"
            },
            subject_collection_items: []
        }
    },
    musicSingle: {
        api: function() {
            return _frodoApi.frodoApi.subjectCollection("music_single");
        },
        init: {
            subject_collection: {
                name: "畅销图书",
                id: "热门单曲"
            },
            subject_collection_items: []
        }
    }
}, Index = function(t) {
    function a() {
        var t, e, o;
        _classCallCheck(this, a);
        for (var i = arguments.length, n = Array(i), r = 0; r < i; r++) n[r] = arguments[r];
        return (e = o = _possibleConstructorReturn(this, (t = a.__proto__ || Object.getPrototypeOf(a)).call.apply(t, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "anonymousState__temp6", "movieShowing", "movieHotGaia", "tvHot", "tvVarietyShow", "bookBestseller", "musicSingle" ], 
        o.config = {
            navigationBarBackgroundColor: "#42BD56",
            navigationBarTextStyle: "white"
        }, o.$$refs = [], _possibleConstructorReturn(o, e);
    }
    var e;
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.id = "", this.state = _extends({}, Loadable.init(loadableApi)), this.api = Loadable.api(loadableApi, this);
        }
    }, {
        key: "componentWillReceiveProps",
        value: function(t) {
            console.log(this.props, t);
        }
    }, {
        key: "componentDidMount",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    this.api.movieShowing(), this.api.movieHotGaia(), this.api.tvHot(), this.api.tvVarietyShow(), 
                    this.api.bookBestseller(), this.api.musicSingle();

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state, e = t.movieShowing, o = t.movieHotGaia, i = t.tvHot, n = t.tvVarietyShow, r = t.bookBestseller, a = t.musicSingle, s = "/pages/subject-items/subject-items?id=" + e.data.subject_collection.id + "&type=subject_collection", c = "/pages/subject-items/subject-items?id=" + o.data.subject_collection.id + "&type=subject_collection", u = "/pages/subject-items/subject-items?id=" + i.data.subject_collection.id + "&type=subject_collection", l = "/pages/subject-items/subject-items?id=" + n.data.subject_collection.id + "&type=subject_collection", p = "/pages/subject-items/subject-items?id=" + r.data.subject_collection.id + "&type=subject_collection", _ = "/pages/subject-items/subject-items?id=" + a.data.subject_collection.id + "&type=subject_collection";
            return Object.assign(this.__state, {
                anonymousState__temp: s,
                anonymousState__temp2: c,
                anonymousState__temp3: u,
                anonymousState__temp4: l,
                anonymousState__temp5: p,
                anonymousState__temp6: _,
                movieShowing: e,
                movieHotGaia: o,
                tvHot: i,
                tvVarietyShow: n,
                bookBestseller: r,
                musicSingle: a
            }), this.__state;
        }
    } ]), a;
}();

Index.properties = {}, Index.$$events = [], exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));