Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var l = Object.getPrototypeOf(t);
        return null === l ? void 0 : e(l, r, o);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Column = function(e) {
    function s() {
        var e, t, r;
        _classCallCheck(this, s);
        for (var o = arguments.length, n = Array(o), l = 0; l < o; l++) n[l] = arguments[l];
        return (t = r = _possibleConstructorReturn(this, (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(e, [ this ].concat(n)))).$usedState = [ "$anonymousCallee__0", "$anonymousCallee__1", "subjects", "moreUrl", "title" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(e) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.title, r = e.moreUrl, o = e.subjects, n = 0 === o.length ? Array.from({
                length: 3
            }) : [], l = 0 === o.length ? Array.from({
                length: 3
            }) : [];
            return Object.assign(this.__state, {
                $anonymousCallee__0: n,
                $anonymousCallee__1: l,
                subjects: o,
                moreUrl: r,
                title: t
            }), this.__state;
        }
    } ]), s;
}();

Column.properties = {
    title: {
        type: null,
        value: null
    },
    moreUrl: {
        type: null,
        value: null
    },
    subjects: {
        type: null,
        value: null
    }
}, Column.$$events = [], exports.default = Column, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Column));