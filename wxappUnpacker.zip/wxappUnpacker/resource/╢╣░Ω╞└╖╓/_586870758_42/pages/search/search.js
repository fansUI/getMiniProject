Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
}, _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, r, n);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _frodoApi = require("../../services/frodo-api.js"), _helpers = require("../../utils/helpers.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var s = e.apply(this, arguments);
        return new Promise(function(a, i) {
            return function t(e, r) {
                try {
                    var n = s[e](r), o = n.value;
                } catch (e) {
                    return void i(e);
                }
                if (!n.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                a(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var loadableApi = {
    search: {
        api: _frodoApi.frodoApi.search,
        init: null,
        toast: !1
    }
}, Index = function(e) {
    function i() {
        var e, t, r;
        _classCallCheck(this, i);
        for (var n = arguments.length, o = Array(n), a = 0; a < n; a++) o[a] = arguments[a];
        return (t = r = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "_search", "q", "focus" ], 
        r.config = {
            navigationBarBackgroundColor: "#42BD56",
            navigationBarTextStyle: "white"
        }, r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    var t;
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function() {
            var r = this;
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).apply(this, arguments), 
            this.state = _extends({}, Loadable.init(loadableApi), {
                focus: !1
            }), this.api = Loadable.api(loadableApi, this), this.handleInput = (0, _helpers.debounce)(function(e) {
                var t = e.target.value;
                t.trim() ? r.api.search(t) : r.setState(_extends({}, Loadable.init(loadableApi)));
            });
        }
    }, {
        key: "componentDidMount",
        value: (t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.$router.params.q) return t = this.$router.params.q, _index2.default.showLoading({
                        title: "正在搜索"
                    }), e.next = 5, this.api.search(t);
                    e.next = 8;
                    break;

                  case 5:
                    _index2.default.hideLoading(), e.next = 9;
                    break;

                  case 8:
                    this.setState({
                        focus: !0
                    });

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__state.search.data, t = this.$router.params.q;
            return Object.assign(this.__state, {
                _search: e,
                q: t
            }), this.__state;
        }
    } ]), i;
}();

Index.properties = {}, Index.$$events = [ "handleInput" ], exports.default = Index, 
Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));