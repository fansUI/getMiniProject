var _mergePage = require("../../modules/weapp-douban-login/utils/merge-page.js"), _mergePage2 = _interopRequireDefault(_mergePage), _createPageParams = require("../../modules/weapp-douban-login/common/mixins/create-page-params.js"), _createPageParams2 = _interopRequireDefault(_createPageParams), _commonLoginHandlers = require("../../modules/weapp-douban-login/utils/common-login-handlers.js"), _config = require("../../components/custom-nav/config.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page((0, _mergePage2.default)((0, _createPageParams2.default)(), {
    loginSuccess: _commonLoginHandlers.successHandler,
    loginFailed: _commonLoginHandlers.failedHandler,
    data: {
        customNavHeight: _config.CUSTOM_NAV_HEIGHT
    }
}));