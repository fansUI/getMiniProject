Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(t, e) {
        for (var r = 0; r < e.length; r++) {
            var o = e[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(t, e, r) {
        return e && o(t.prototype, e), r && o(t, r), t;
    };
}(), _get = function t(e, r, o) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, o);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _frodoApi = require("../../services/frodo-api.js"), _log = require("../../utils/log.js"), _log2 = _interopRequireDefault(_log);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var windowHeight = _index2.default.getSystemInfoSync().windowHeight, Status = function(t) {
    function s() {
        var t, e, r;
        _classCallCheck(this, s);
        for (var o = arguments.length, n = Array(o), a = 0; a < o; a++) n[a] = arguments[a];
        return (e = r = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(n)))).$usedState = [ "loopArray0", "loopArray1", "from", "index", "head", "foot", "status", "related_statuses" ], 
        r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this), 
            this.state = {
                status: null,
                related_statuses: []
            }, this.fetching = !1, this.related_start = 0, this.sid = "", this.from = "", this.ob = null;
        }
    }, {
        key: "componentDidMount",
        value: function() {
            var t = this.$router.params.sid;
            this.$router.params.q && (t = (decodeURIComponent(this.$router.params.q).match(/status\/(\w+)/) || [])[1] || _id);
            this.sid = t, this.fetchRelatedStatuses();
            var e = this.$router.params.from || "normal";
            this.from = e, (0, _log2.default)("wx_miniprogram_video_status_load", {
                sid: t,
                page_from: e
            });
        }
    }, {
        key: "setOb",
        value: function() {
            this.ob && this.ob.disconnect(), this.ob = this.$scope.createIntersectionObserver({
                observeAll: !0,
                thresholds: [ .9 ]
            }), this.ob.relativeToViewport().observe(".all-status >>> .video", function(t) {
                if (t.intersectionRatio < .9) _index2.default.createSelectorQuery().select(".all-status >>> .video-" + t.id).context(function(t) {
                    t.context.pause();
                }).exec(); else {
                    var o = t.dataset.index;
                    _index2.default.createSelectorQuery().selectAll(".all-status >>> .video").context(function(t) {
                        var e = o - 3;
                        e = e < 0 ? 0 : e;
                        var r = o + 3;
                        r = r > t.length - 1 ? t.length : r, t.slice(e, r).forEach(function(t) {
                            t.context.pause();
                        });
                    }).exec(), _index2.default.createSelectorQuery().select(".all-status >>> .video-" + t.id).context(function(t) {
                        t.context.play();
                    }).exec();
                }
            });
        }
    }, {
        key: "fetchRelatedStatuses",
        value: function() {
            var e = this;
            this.fetching = !0, _frodoApi.frodoApi.related_statuses(this.sid, this.related_start, 5).then(function(t) {
                e.related_start = t.data.start + t.data.count, e.setState({
                    related_statuses: e.state.related_statuses.concat(t.data.items)
                }, function() {
                    e.related_start < t.data.total && (e.fetching = !1), e.setOb();
                });
            });
        }
    }, {
        key: "onShareAppMessage",
        value: function(t) {
            var e = t.target.dataset;
            return {
                title: e.author + "的视频：" + e.content,
                path: "pages/status/status?sid=" + e.sid + "&from=wxshare",
                imageUrl: e.cover
            };
        }
    }, {
        key: "onPageScroll",
        value: function() {
            var e = this;
            _index2.default.createSelectorQuery().select("#last").boundingClientRect(function(t) {
                t.top <= windowHeight && !e.fetching && e.fetchRelatedStatuses();
            }).exec();
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.from, e = this.__state.related_statuses, r = e.slice(0, e.length - 3), o = e.slice(e.length - 3, e.length), n = 0, a = r.length ? r.map(function(t) {
                return t = {
                    $original: (0, _index.internal_get_original)(t)
                }, {
                    $loopState__temp2: r.length ? 0 === n : null,
                    $loopState__temp4: r.length ? n++ : null,
                    $original: t.$original
                };
            }) : [], s = o.length ? o.map(function(t, e) {
                return t = {
                    $original: (0, _index.internal_get_original)(t)
                }, {
                    $loopState__temp6: o.length ? n++ : null,
                    $original: t.$original
                };
            }) : [];
            return Object.assign(this.__state, {
                loopArray0: a,
                loopArray1: s,
                from: t,
                index: n,
                head: r,
                foot: o
            }), this.__state;
        }
    } ]), s;
}();

Status.properties = {}, Status.$$events = [], exports.default = Status, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Status, !0));