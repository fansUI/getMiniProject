Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function i(t, e) {
        for (var o = 0; o < e.length; o++) {
            var i = e[o];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(t, e, o) {
        return e && i(t.prototype, e), o && i(t, o), t;
    };
}(), _get = function t(e, o, i) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, o);
    if (void 0 === n) {
        var r = Object.getPrototypeOf(e);
        return null === r ? void 0 : t(r, o, i);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(i) : void 0;
}, _index = require("../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _frodoApi = require("../../../services/frodo-api.js"), _consts = require("../../../utils/consts.js"), _log = require("../../../utils/log.js"), _log2 = _interopRequireDefault(_log);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var VideoStatus = function(t) {
    function s() {
        var t, e, o;
        _classCallCheck(this, s);
        for (var i = arguments.length, n = Array(i), r = 0; r < i; r++) n[r] = arguments[r];
        return (e = o = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "loopArray0", "text", "id", "video_info", "autoplay", "index", "author", "entities", "topic", "comments", "liked", "liked_count", "comments_count", "create_time", "status", "from" ], 
        o.$$refs = [], _possibleConstructorReturn(o, e);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(t) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, t), 
            this.isLogin = !!_index2.default.getStorageSync("access_token"), this.state = {
                liked: !1,
                liked_count: 0
            }, this.loged = !1, t.status && (this.state = {
                liked: t.status.liked,
                liked_count: t.status.like_count
            });
        }
    }, {
        key: "onLikeClick",
        value: function() {
            var e = this;
            this.isLogin ? _frodoApi.frodoApi.likeStatus(this.props.status.id, !this.state.liked).then(function(t) {
                e.setState({
                    liked: t.data.liked,
                    liked_count: t.data.like_count
                });
            }) : _index2.default.navigateTo({
                url: _consts.LOGIN_BASIC + "?redirect=" + encodeURIComponent("/pages/status/status?sid=" + this.props.status.id)
            });
        }
    }, {
        key: "onCommentsClick",
        value: function() {
            var t = this.props.status;
            _index2.default.navigateTo({
                url: "/pages/status/comments?pid=" + t.author.id + "&sid=" + t.id
            });
        }
    }, {
        key: "componentDidShow",
        value: function() {
            this.isLogin = !!_index2.default.getStorageSync("access_token");
        }
    }, {
        key: "onPlay",
        value: function() {
            var t = this.props, e = t.status, o = t.from;
            this.loged || (this.loged = !0, (0, _log2.default)("wx_miniprogram_video_play", {
                sid: e.id,
                page_from: o
            }));
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props, e = t.autoplay, o = void 0 !== e && e, i = t.index, n = this.__props.status, r = n.video_info, s = n.author, a = n.create_time, u = n.text, l = n.topic, c = n.comments_count, p = n.id, _ = n.entities, d = n.comments, f = this.__state, h = (f.liked, 
            f.liked_count, r ? r.video_width : 1), y = r ? r.video_height : 1, g = Math.min(y / h, 1) * _index2.default.getSystemInfoSync().windowWidth + "px", m = (0, 
            _index.internal_inline_style)({
                height: g
            }), v = d && 0 !== d.length ? d.map(function(e) {
                var t = (e = {
                    $original: (0, _index.internal_get_original)(e)
                }).$original.text.length, o = 0, i = [];
                return e.$original.entities.forEach(function(t) {
                    i.push({
                        type: "text",
                        content: e.$original.text.slice(o, t.start)
                    }), i.push({
                        type: "user",
                        content: e.$original.text.slice(t.start, t.end),
                        uri: "/pages/user/user?id=" + e.$original.author.id
                    }), o = t.end;
                }), i.push({
                    type: "text",
                    content: e.$original.text.slice(o, t)
                }), {
                    total: t,
                    start: o,
                    res: i,
                    $original: e.$original
                };
            }) : [];
            return Object.assign(this.__state, {
                anonymousState__temp: m,
                loopArray0: v,
                text: u,
                id: p,
                video_info: r,
                autoplay: o,
                index: i,
                author: s,
                entities: _,
                topic: l,
                comments: d,
                comments_count: c,
                create_time: a
            }), this.__state;
        }
    } ]), s;
}();

VideoStatus.properties = {
    status: {
        type: null,
        value: null
    },
    from: {
        type: null,
        value: null
    },
    autoplay: {
        type: null,
        value: null
    },
    index: {
        type: null,
        value: null
    }
}, VideoStatus.$$events = [ "onPlay", "onLikeClick", "onCommentsClick" ], exports.default = VideoStatus, 
Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(VideoStatus));