Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(e, t, n) {
        return t && a(e.prototype, t), n && a(e, n), e;
    };
}(), _get = function e(t, n, a) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var r = Object.getPrototypeOf(t);
        return null === r ? void 0 : e(r, n, a);
    }
    if ("value" in o) return o.value;
    var s = o.get;
    return void 0 !== s ? s.call(a) : void 0;
}, _tslib = require("../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../npm/classnames/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../npm/@tarojs/taro-weapp/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("../../npm/autobind-decorator/lib/index.js"), _index6 = _interopRequireDefault(_index5), _frodoApi = require("../../services/frodo-api.js"), _subjectApi = require("../../services/subject-api.js"), _reportApi = require("../../services/report-api.js"), _consts = require("../../utils/consts.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var systemInfo = _index4.default.getSystemInfoSync(), isiPhoneX = /iphone\s?x/gi.test(systemInfo.model), height = systemInfo.windowHeight;

function choiceLevel(e) {
    return 5e3 < e ? [ 12, "叫我第一名", "∞" ] : 2e3 < e ? [ 11, "教父", 5e3 ] : 1e3 < e ? [ 10, "一代宗师", 2e3 ] : 500 < e ? [ 9, "头号玩家", 1e3 ] : 400 < e ? [ 8, "杰出公民", 500 ] : 300 < e ? [ 7, "无名战士", 400 ] : 200 < e ? [ 6, "步履不停", 300 ] : 100 < e ? [ 5, "街头霸王", 200 ] : 50 < e ? [ 4, "年轻气盛", 100 ] : 20 < e ? [ 3, "江湖儿女", 50 ] : 10 < e ? [ 2, "少年时代", 20 ] : [ 1, "小鬼当家", 10 ];
}

var QuickMark = (_temp2 = _class = function(e) {
    function s() {
        var e, t, n;
        _classCallCheck(this, s);
        for (var a = arguments.length, o = Array(a), r = 0; r < a; r++) o[r] = arguments[r];
        return (t = n = _possibleConstructorReturn(this, (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(e, [ this ].concat(o)))).$usedState = [ "_$anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "anonymousState__temp6", "anonymousState__temp7", "anonymousState__temp8", "anonymousState__temp9", "loaded", "hasSubjects", "firstSubject", "milestoneLV", "milestoneName", "milestonePercent", "subjects", "normalMarkedCount", "normalNextLevelCount", "annualMarkedCount", "annualNextLevelCount", "__fn_on" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(s, _index3.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).apply(this, arguments), 
            this.subjectApi = new _subjectApi.SubjectAPI("movie"), this.start = 0, this.source = this.$router.params.source || "", 
            this.user = _index4.default.getStorageSync("account_info"), this.lastSubject = null, 
            this.state = {
                subjects: [],
                normalMarkedCount: 0,
                normalNextLevelCount: 1,
                annualMarkedCount: 0,
                annualNextLevelCount: 1,
                hasSubjects: !1,
                loaded: !1
            };
        }
    }, {
        key: "componentDidMount",
        value: function() {
            _index4.default.eventCenter.trigger("canPageRefresh");
        }
    }, {
        key: "componentDidShow",
        value: function() {
            _index4.default.eventCenter.off("quick-mark-updateSubjects", this.updateSubjects), 
            _index4.default.eventCenter.on("quick-mark-updateSubjects", this.updateSubjects), 
            this.user ? (this.fetchNormalCount(), this.fetchSubjects()) : _index4.default.navigateTo({
                url: _consts.LOGIN_BASIC + "?redirect=" + encodeURIComponent("/pages/quick-mark/quick-mark?source=" + this.source)
            });
        }
    }, {
        key: "fetchNormalCount",
        value: function() {
            var t = this;
            _frodoApi.frodoApi.userInterests(this.user.id, "done", 0, 1, "movie").then(function(e) {
                t.setState({
                    normalMarkedCount: e.data.total,
                    normalNextLevelCount: choiceLevel(e.data.total)[2]
                });
            });
        }
    }, {
        key: "fetchSubjects",
        value: function() {
            var n = this;
            _frodoApi.frodoApi.markRecommendations(this.start, "annual" === this.source ? "111199784" : "").then(function(e) {
                var t = n.state.subjects.concat(e.data.subjects);
                n.setState({
                    subjects: t,
                    loaded: !0,
                    hasSubjects: 0 < t.length,
                    annualMarkedCount: e.data.done_count,
                    annualNextLevelCount: e.data.total + e.data.done_count
                }), e.data.done_count >= e.data.total + e.data.done_count && "annual" === n.source && _index4.default.reLaunch({
                    url: "/pages/annual/overview"
                });
            });
        }
    }, {
        key: "updateSubjects",
        value: function(e) {
            if (0 !== this.state.subjects.length) {
                var t = this.state.subjects[0], n = this.state.subjects.slice(1), a = this.state.normalMarkedCount + ("mark" === e ? 1 : 0), o = choiceLevel(a)[2], r = this.state.annualMarkedCount + ("mark" === e ? 1 : 0), s = this.state.annualNextLevelCount;
                this.setState({
                    subjects: n,
                    hasSubjects: 0 !== n.length,
                    normalMarkedCount: a,
                    normalNextLevelCount: o,
                    annualMarkedCount: r,
                    annualNextLevelCount: s
                }), this.lastSubject = t, "mark" === e && (this.mark(t.id), s <= r && "annual" === this.source && _index4.default.reLaunch({
                    url: "/pages/annual/overview"
                })), n.length < 10 && (this.start += 20, this.fetchSubjects());
            }
        }
    }, {
        key: "revert",
        value: function() {
            var e = this.lastSubject;
            if (e) {
                var t = this.state.normalMarkedCount - 1, n = choiceLevel(t)[2], a = this.state.annualMarkedCount - 1, o = this.state.annualNextLevelCount, r = [ e ].concat(this.state.subjects);
                this.setState({
                    subjects: r,
                    hasSubjects: 0 !== r.length,
                    normalMarkedCount: t,
                    normalNextLevelCount: n,
                    annualMarkedCount: a,
                    annualNextLevelCount: o
                }), this.unmark(e.id), this.lastSubject = null;
            }
        }
    }, {
        key: "mark",
        value: function(e) {
            this.subjectApi.mark(e, "done", {}, "movie");
        }
    }, {
        key: "unmark",
        value: function(e) {
            this.subjectApi.unmark(e, "movie");
        }
    }, {
        key: "back",
        value: function(e) {
            _reportApi.reportApi.addFormId(e.detail.formId), _index4.default.navigateBack({
                delta: 1
            });
        }
    }, {
        key: "_createData",
        value: function() {
            var e;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state, n = t.subjects, a = t.loaded, o = t.hasSubjects, r = t.normalMarkedCount, s = t.normalNextLevelCount, u = t.annualMarkedCount, i = t.annualNextLevelCount, l = void 0, c = void 0, _ = void 0, d = void 0, p = void 0, m = void 0;
            a && o ? (l = (c = n[0]).color_scheme ? c.color_scheme.primary_color_dark : "d8d8d8", 
            e = n.slice(0, 4), m = "annual" === this.source ? (_ = "豆瓣2018年度榜单", d = u + "/" + i, 
            u / i * 100 + "%") : (p = "Lv." + choiceLevel(r)[0], _ = choiceLevel(r)[1], d = r + "/" + s, 
            r / s * 100 + "%")) : l = "ffac2d";
            var h = (0, _index3.internal_inline_style)({
                paddingBottom: isiPhoneX ? "34px" : 0
            }), f = (0, _index3.internal_inline_style)({
                backgroundColor: "#" + l
            }), v = (0, _index2.default)({
                "subject-list": !0,
                "subject-list-50": !0,
                "subject-list-60": 700 < height
            }), b = o ? c.countries.join(" ") : null, j = o ? c.genres.join(" ") : null, y = o ? c.durations.slice(0, 1).join(" ") : null, k = (0, 
            _index2.default)({
                btn: !0,
                revert: !0,
                can_revert: null !== this.lastSubject
            }), S = a ? (0, _index3.internal_inline_style)({
                width: m
            }) : null;
            return Object.assign(this.__state, {
                _$anonymousState__temp: e,
                anonymousState__temp2: h,
                anonymousState__temp3: f,
                anonymousState__temp4: v,
                anonymousState__temp5: b,
                anonymousState__temp6: j,
                anonymousState__temp7: y,
                anonymousState__temp8: k,
                anonymousState__temp9: S,
                firstSubject: c,
                milestoneLV: p,
                milestoneName: _,
                milestonePercent: d
            }), this.__state;
        }
    } ]), s;
}(), _class.properties = {
    __fn_on: {
        type: null,
        value: null
    }
}, _class.$$events = [ "back", "revert", "updateSubjects" ], _temp2);

QuickMark = tslib_1.__decorate([ _index6.default ], QuickMark), exports.default = QuickMark, 
Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(QuickMark, !0));