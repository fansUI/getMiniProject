Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(t, e) {
        for (var o = 0; o < e.length; o++) {
            var n = e[o];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, o) {
        return e && n(t.prototype, e), o && n(t, o), t;
    };
}(), _get = function t(e, o, n) {
    null === e && (e = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(e, o);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(e);
        return null === i ? void 0 : t(i, o, n);
    }
    if ("value" in r) return r.value;
    var s = r.get;
    return void 0 !== s ? s.call(n) : void 0;
}, _tslib = require("../../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../../npm/classnames/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../npm/@tarojs/taro-weapp/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("../../../npm/autobind-decorator/lib/index.js"), _index6 = _interopRequireDefault(_index5);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    return e.default = t, e;
}

function _defineProperty(t, e, o) {
    return e in t ? Object.defineProperty(t, e, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = o, t;
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var PosterList = (_temp2 = _class = function(t) {
    function s() {
        var t, e, o;
        _classCallCheck(this, s);
        for (var n = arguments.length, r = Array(n), i = 0; i < n; i++) r[i] = arguments[i];
        return (e = o = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(r)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "anonymousState__temp6", "loopArray0", "subjects", "$anonymousCallee__0", "firstBottomY", "droped" ], 
        o.$$refs = [], _possibleConstructorReturn(o, e);
    }
    return _inherits(s, _index3.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(t) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, t), 
            this.startY = 0, this.state = {
                firstBottomY: 0,
                droped: !1
            };
        }
    }, {
        key: "componentWillReceiveProps",
        value: function() {
            this.setState({
                firstBottomY: 0,
                droped: !1
            });
        }
    }, {
        key: "onTouchStart",
        value: function(t) {
            t.preventDefault(), t.stopPropagation(), this.startY = t.touches[0].clientY, this.setState({
                droped: !1
            });
        }
    }, {
        key: "onTouchMove",
        value: function(t) {
            t.preventDefault(), t.stopPropagation();
            var e = t.touches[0].clientY, o = this.startY - e;
            this.setState({
                firstBottomY: o
            });
        }
    }, {
        key: "onTouchEnd",
        value: function(t) {
            var e = this;
            t.preventDefault(), t.stopPropagation(), this.startY = 0, 120 < Math.abs(this.state.firstBottomY) ? this.setState({
                firstBottomY: this.state.firstBottomY / Math.abs(this.state.firstBottomY) * 2e3,
                droped: !0
            }, function() {
                setTimeout(function() {
                    _index4.default.eventCenter.trigger("quick-mark-updateSubjects", 0 < e.state.firstBottomY ? "" : "mark");
                }, 700);
            }) : this.setState({
                firstBottomY: 0,
                droped: !0
            });
        }
    }, {
        key: "onRemove",
        value: function() {
            _index4.default.eventCenter.trigger("quick-mark-updateSubjects", "");
        }
    }, {
        key: "_createData",
        value: function() {
            var t;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var o = this.__props.subjects, e = (0, _index2.default)((_defineProperty(t = {}, "first-poster", !0), 
            _defineProperty(t, "droped", this.__state.droped), t)), n = (0, _index3.internal_inline_style)({
                bottom: this.__state.firstBottomY + "px"
            }), r = o.length - 1, i = (0, _index3.internal_inline_style)({
                opacity: Math.abs((0 < this.__state.firstBottomY ? this.__state.firstBottomY : 0) / 120)
            }), s = (0, _index3.internal_inline_style)({
                opacity: Math.abs((this.__state.firstBottomY < 0 ? this.__state.firstBottomY : 0) / 120)
            }), a = o.slice(1), u = o.slice(1).map(function(t, e) {
                return {
                    $loopState__temp8: (t = {
                        $original: (0, _index3.internal_get_original)(t)
                    }).$original.id + "-" + e,
                    $loopState__temp10: o.length - (e + 2),
                    $loopState__temp12: e + 1 !== o.length - 1,
                    $original: t.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp: "/pages/quick-mark/components/trash_area.png",
                anonymousState__temp2: e,
                anonymousState__temp3: n,
                anonymousState__temp4: r,
                anonymousState__temp5: i,
                anonymousState__temp6: s,
                loopArray0: u,
                subjects: o,
                $anonymousCallee__0: a
            }), this.__state;
        }
    } ]), s;
}(), _class.properties = {
    subjects: {
        type: null,
        value: null
    }
}, _class.$$events = [ "onTouchMove", "onTouchStart", "onTouchEnd", "onRemove" ], 
_temp2);

PosterList = tslib_1.__decorate([ _index6.default ], PosterList), exports.default = PosterList, 
Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(PosterList));