Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(t, e) {
        for (var r = 0; r < e.length; r++) {
            var o = e[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(t, e, r) {
        return e && o(t.prototype, e), r && o(t, r), t;
    };
}(), _get = function t(e, r, o) {
    null === e && (e = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, o);
    }
    if ("value" in n) return n.value;
    var s = n.get;
    return void 0 !== s ? s.call(o) : void 0;
}, _index = require("../../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Empty = function(t) {
    function s() {
        var t, e, r;
        _classCallCheck(this, s);
        for (var o = arguments.length, n = Array(o), a = 0; a < o; a++) n[a] = arguments[a];
        return (e = r = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(n)))).$usedState = [ "loaded" ], 
        r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(t) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, t);
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__props.loaded;
            return Object.assign(this.__state, {
                loaded: t
            }), this.__state;
        }
    } ]), s;
}();

Empty.properties = {
    loaded: {
        type: null,
        value: null
    }
}, Empty.$$events = [], exports.default = Empty, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Empty));