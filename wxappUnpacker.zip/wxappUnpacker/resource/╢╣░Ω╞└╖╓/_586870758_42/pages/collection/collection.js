Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
}, _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, n, r);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(r) : void 0;
}, _tslib = require("../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../npm/@tarojs/redux/index.js"), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _account = require("../../actions/account.js"), _frodoApi = require("../../services/frodo-api.js"), _base = require("../../npm/js-base64/base64.js"), _index4 = require("../../utils/index.js"), _index5 = require("../../domains/index.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _asyncToGenerator(e) {
    return function() {
        var s = e.apply(this, arguments);
        return new Promise(function(a, i) {
            return function t(e, n) {
                try {
                    var r = s[e](n), o = r.value;
                } catch (e) {
                    return void i(e);
                }
                if (!r.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                a(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Index = (_temp2 = _class = function(e) {
    function i() {
        var e, t, n;
        _classCallCheck(this, i);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return (t = n = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "_name", "_navTitle", "scopeData", "data", "accountInfo", "openShareDialog", "shareImg", "getAccountInfo" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    var t, n, r;
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function() {
            var r = this;
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).apply(this, arguments), 
            this.loadableApi = {
                subjectCollection: {
                    api: function(e) {
                        var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0, n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 20;
                        return _frodoApi.frodoApi.subjectCollection(e, t, n);
                    },
                    init: {
                        subject_collection: null,
                        subject_collection_items: [],
                        total: 0,
                        start: 0,
                        count: 0,
                        isPhoneVerified: !1
                    },
                    toast: !1,
                    updater: function(e) {
                        var t = r.state.subjectCollection && r.state.subjectCollection.data;
                        if (t) {
                            var n = t.subject_collection_items.concat(e.subject_collection_items);
                            return Object.assign({}, e, {
                                subject_collection_items: n
                            });
                        }
                        return e;
                    }
                }
            }, this.state = _extends({
                openShareDialog: !1,
                shareImg: ""
            }, Loadable.init(this.loadableApi)), this.api = Loadable.api(this.loadableApi, this);
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this.props.getAccountInfo();
        }
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: (r = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    this.fetchData();

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return r.apply(this, arguments);
        })
    }, {
        key: "fetchData",
        value: (n = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = this.$router.params.scene, this.id = this.$router.params.id, t) try {
                        t = JSON.parse(_base.Base64.decode(t)), this.id = t.id;
                    } catch (e) {
                        console.error(e, t);
                    }
                    return this.props.getAccountInfo(), e.abrupt("return", this.api.subjectCollection(this.id, 0));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return n.apply(this, arguments);
        })
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "onReachBottom",
        value: function() {
            var e = this.state.subjectCollection.data, t = e.start, n = void 0 === t ? 0 : t, r = e.count;
            (n += void 0 === r ? 0 : r) < e.total && this.api.subjectCollection(this.id, n);
        }
    }, {
        key: "toggleShare",
        value: (t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, n, r, o, a, i;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = !this.state.openShareDialog, n = this.state.shareImg, t) return _index2.default.showLoading({
                        title: "数据获取中…"
                    }), r = this.state.subjectCollection.data, o = {
                        user: this.props.accountInfo,
                        collection: (0, _index5.collectionToLite)(r),
                        qrImg: r.subject_collection.wx_qr_code,
                        qrShape: "rect"
                    }, e.prev = 6, e.next = 9, _index2.default.request({
                        url: "https://www.douban.com/service/screenshot/save_html",
                        method: "POST",
                        data: {
                            type: "report2018",
                            data: JSON.stringify({
                                data: JSON.stringify(o)
                            })
                        },
                        header: {
                            "content-type": "application/x-www-form-urlencoded"
                        }
                    });
                    e.next = 26;
                    break;

                  case 9:
                    return a = e.sent, e.next = 12, (0, _index4.sleep)(500);

                  case 12:
                    return 750, n = a.data.img_src + (0 <= a.data.img_src.indexOf("?") ? "&" : "?") + "window_size=750,1334", 
                    _index2.default.showLoading({
                        title: "图片生成中…"
                    }), e.next = 17, _index2.default.getImageInfo({
                        src: n
                    });

                  case 17:
                    i = e.sent, n = i.path, e.next = 25;
                    break;

                  case 21:
                    e.prev = 21, e.t0 = e.catch(6), console.error(e.t0), n = "";

                  case 25:
                    _index2.default.hideLoading();

                  case 26:
                    if (n) {
                        e.next = 29;
                        break;
                    }
                    return _index2.default.showToast({
                        title: "图片生成失败, 请重试",
                        icon: "none"
                    }), e.abrupt("return");

                  case 29:
                    this.setState({
                        openShareDialog: t,
                        shareImg: n
                    });

                  case 30:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 6, 21 ] ]);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.accountInfo, t = this.__state.subjectCollection, n = t.data;
            t.isLoading ? _index2.default.showLoading({
                title: "榜单更新中"
            }) : _index2.default.hideLoading();
            var r = n.subject_collection && n.subject_collection.name;
            if (!r) return null;
            var o = [ {
                service_type: 11040,
                movie_type: ""
            } ];
            if (-1 < r.indexOf("评分最高")) {
                var a = r.split("评分最高").pop();
                o[0].movie_type = a || "";
            }
            var i = t.data.subject_collection && t.data.subject_collection.medium_name;
            return Object.assign(this.__state, {
                _name: r,
                _navTitle: i,
                scopeData: o,
                data: n,
                accountInfo: e
            }), this.__state;
        }
    } ]), i;
}(), _class.properties = {
    getAccountInfo: {
        type: null,
        value: null
    },
    accountInfo: {
        type: null,
        value: null
    }
}, _class.$$events = [ "toggleShare", "fetchData" ], _temp2);

Index = tslib_1.__decorate([ (0, _index3.connect)(function(e) {
    return {
        accountInfo: e.accountInfo
    };
}, function(e) {
    return {
        getAccountInfo: function() {
            (0, _account.getAccountInfo)()(e);
        }
    };
}) ], Index), exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));