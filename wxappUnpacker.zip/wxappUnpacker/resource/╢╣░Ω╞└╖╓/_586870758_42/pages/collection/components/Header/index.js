Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, r, o);
    }
    if ("value" in n) return n.value;
    var i = n.get;
    return void 0 !== i ? i.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _helpers = require("../../../../utils/helpers.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Header = function(e) {
    function i() {
        var e, t, r;
        _classCallCheck(this, i);
        for (var o = arguments.length, n = Array(o), a = 0; a < o; a++) n[a] = arguments[a];
        return (t = r = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "collection" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "getMaskBg",
        value: function(e) {
            return "background: linear-gradient(to bottom, " + (0, _helpers.hex2rgb)(e, .7) + ", " + (0, 
            _helpers.hex2rgb)(e, 1) + " 100%)";
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props.collection, t = (0, _index.internal_inline_style)({
                backgroundImage: "url(" + e.header_bg_image + ")"
            }), r = -1 < [ "movie_hot_weekly", "movie_weekly_best" ].indexOf(e.id) ? (0, _index.internal_inline_style)(this.getMaskBg(e.background_color_scheme.primary_color_dark)) : null, o = (0, 
            _index.internal_inline_style)({
                backgroundImage: "url(" + e.header_fg_image + ")"
            }), n = -1 < [ "movie_hot_weekly", "movie_weekly_best" ].indexOf(e.id);
            return Object.assign(this.__state, {
                anonymousState__temp: t,
                anonymousState__temp2: r,
                anonymousState__temp3: o,
                anonymousState__temp4: n,
                collection: e
            }), this.__state;
        }
    } ]), i;
}();

Header.properties = {
    collection: {
        type: null,
        value: null
    }
}, Header.$$events = [], Header.defaultProps = {
    collection: {
        id: ""
    }
}, exports.default = Header, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Header));