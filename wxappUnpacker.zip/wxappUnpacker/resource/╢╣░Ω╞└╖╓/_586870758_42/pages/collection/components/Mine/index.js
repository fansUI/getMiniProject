Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var l = r.get;
    return void 0 !== l ? l.call(o) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = require("../../../../utils/index.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Mine = function(e) {
    function l() {
        var e, t, n;
        _classCallCheck(this, l);
        for (var o = arguments.length, r = Array(o), i = 0; i < o; i++) r[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = l.__proto__ || Object.getPrototypeOf(l)).call.apply(e, [ this ].concat(r)))).$usedState = [ "anonymousState__temp", "collection", "accountInfo", "type", "__fn_onClick", "onShare" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(l, _index.Component), _createClass(l, [ {
        key: "_constructor",
        value: function(e) {
            _get(l.prototype.__proto__ || Object.getPrototypeOf(l.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "login",
        value: function() {
            (0, _index2.redirectToLogin)();
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.accountInfo, n = e.collection, o = (e.onShare, e.type), r = (0, 
            _index2.getActionCnByType)(o);
            return Object.assign(this.__state, {
                anonymousState__temp: r,
                collection: n,
                accountInfo: t
            }), this.__state;
        }
    }, {
        key: "funPrivateaHnoh",
        value: function() {
            this.__triggerPropsFn("onShare", [].concat(Array.prototype.slice.call(arguments)));
        }
    } ]), l;
}();

Mine.properties = {
    accountInfo: {
        type: null,
        value: null
    },
    collection: {
        type: null,
        value: null
    },
    onShare: {
        type: null,
        value: null
    },
    type: {
        type: null,
        value: null
    },
    __fn_onClick: {
        type: null,
        value: null
    },
    __fn_onShare: {
        type: null,
        value: null
    }
}, Mine.$$events = [ "funPrivateaHnoh", "login" ], exports.default = Mine, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Mine));