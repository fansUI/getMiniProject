Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, r);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../../npm/classnames/index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var s = e.apply(this, arguments);
        return new Promise(function(i, a) {
            return function t(e, n) {
                try {
                    var r = s[e](n), o = r.value;
                } catch (e) {
                    return void a(e);
                }
                if (!r.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                i(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var ShareDialog = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, o = Array(r), i = 0; i < r; i++) o[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "url", "isDialogShow", "visible" ], 
        n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    var t;
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                isDialogShow: !1
            };
        }
    }, {
        key: "componentWillReceiveProps",
        value: function(e, t) {
            var n = this;
            e.visible !== this.props.visible && (e.visible ? setTimeout(function() {
                n.setState({
                    isDialogShow: !0
                });
            }, 30) : this.setState({
                isDialogShow: !1
            }));
        }
    }, {
        key: "saveImg",
        value: (t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, _index2.default.getImageInfo({
                        src: this.props.url
                    });

                  case 2:
                    return t = e.sent, e.next = 5, _index2.default.saveImageToPhotosAlbum({
                        filePath: t.path
                    });

                  case 5:
                    _index2.default.showToast({
                        title: "已保存到手机",
                        icon: "success"
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "hide",
        value: function() {
            var e = this.props;
            e.visible, e.onRequestHidden;
            this.__triggerPropsFn("onRequestHidden", [ null ].concat([])), this.setState({
                isDialogShow: !1
            });
        }
    }, {
        key: "stopEvent",
        value: function(e) {
            e.stopPropagation(), e.preventDefault();
        }
    }, {
        key: "preview",
        value: function() {
            _index2.default.previewImage({
                current: this.props.url,
                urls: [ this.props.url ]
            });
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.visible, n = e.url, r = this.__state.isDialogShow, o = (0, 
            _index4.default)("share-dialog", t && "visible"), i = (0, _index4.default)("dialog", r && "visible");
            return Object.assign(this.__state, {
                anonymousState__temp: o,
                anonymousState__temp2: i,
                anonymousState__temp3: "/images/collection/ic_download.svg",
                url: n
            }), this.__state;
        }
    } ]), a;
}();

ShareDialog.properties = {
    visible: {
        type: null,
        value: null
    },
    url: {
        type: null,
        value: null
    },
    onRequestHidden: {
        type: null,
        value: null
    },
    __fn_onRequestHidden: {
        type: null,
        value: null
    }
}, ShareDialog.$$events = [ "stopEvent", "hide", "preview", "saveImg" ], ShareDialog.defaultProps = {
    items: [],
    collection: null
}, exports.default = ShareDialog, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(ShareDialog));