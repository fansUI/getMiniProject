Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
}, _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, n);
    }
    if ("value" in o) return o.value;
    var a = o.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _tslib = require("../../../../npm/tslib/tslib.js"), tslib_1 = _interopRequireWildcard(_tslib), _index = require("../../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../../../utils/index.js"), _subjectApi = require("../../../../services/subject-api.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _defineProperty(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

function _asyncToGenerator(e) {
    return function() {
        var u = e.apply(this, arguments);
        return new Promise(function(i, a) {
            return function t(e, r) {
                try {
                    var n = u[e](r), o = n.value;
                } catch (e) {
                    return void a(e);
                }
                if (!n.done) return Promise.resolve(o).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                i(o);
            }("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Subjects = function(e) {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "loopArray0", "items", "collection", "unfoldedMap", "isLogin" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    var o;
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                unfoldedMap: {}
            }, this._isLoading = !1;
        }
    }, {
        key: "handleMark",
        value: (o = _asyncToGenerator(regeneratorRuntime.mark(function e(t, r, n, o) {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (o.preventDefault(), o.stopPropagation(), this._isLoading) return e.abrupt("return");
                    e.next = 4;
                    break;

                  case 4:
                    if (this._isLoading = !0, e.prev = 5, "mark" === n) return e.next = 9, new _subjectApi.SubjectAPI(t).mark(r, n, {});
                    e.next = 11;
                    break;

                  case 9:
                    e.next = 13;
                    break;

                  case 11:
                    return e.next = 13, new _subjectApi.SubjectAPI(t).unmark(r);

                  case 13:
                    if (e.t0 = this.props.onMark, e.t0) return e.next = 17, this.__triggerPropsFn("onMark", [ null ].concat([]));
                    e.next = 17;
                    break;

                  case 17:
                    e.next = 22;
                    break;

                  case 19:
                    e.prev = 19, e.t1 = e.catch(5), console.error(e.t1);

                  case 22:
                    return e.prev = 22, this._isLoading = !1, e.finish(22);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 5, 19, 22, 25 ] ]);
        })), function(e, t, r, n) {
            return o.apply(this, arguments);
        })
    }, {
        key: "handleMarkJump",
        value: function(e, t, r, n) {
            _index2.default.navigateTo({
                url: "/pages/subject/subject?id=" + t + "&redirect=" + encodeURIComponent("/pages/subject/mark?id=" + t + "&action=" + r + "&type=" + e)
            }), n.preventDefault(), n.stopPropagation();
        }
    }, {
        key: "toggleFolded",
        value: function(e, t) {
            this.setState({
                unfoldedMap: _extends({}, this.state.unfoldedMap, _defineProperty({}, e.id, !this.state.unfoldedMap[e.id]))
            }), t.stopPropagation(), t.preventDefault();
        }
    }, {
        key: "stopEvent",
        value: function(e) {
            e.stopPropagation(), e.preventDefault();
        }
    }, {
        key: "_createData",
        value: function() {
            var i = this;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.items, r = e.collection, n = (e.isLogin, 0 !== t.length ? t.map(function(e, t) {
                var r = "", n = "";
                if ((e = {
                    $original: (0, _index.internal_get_original)(e)
                }).$original.interest) {
                    var o = e.$original.interest.create_time.split(" ")[0].split("-");
                    r = o[0], n = o.slice(1).join("-");
                }
                return {
                    year: r,
                    date: n,
                    isUnfolded: i.__state.unfoldedMap[e.$original.id],
                    $loopState__temp2: (0, _index.internal_inline_style)({
                        backgroundImage: "url(" + e.$original.cover.url + ")"
                    }),
                    $original: e.$original
                };
            }) : []);
            return Object.assign(this.__state, {
                loopArray0: n,
                items: t,
                collection: r
            }), this.__state;
        }
    } ]), a;
}();

Subjects.properties = {
    onMark: {
        type: null,
        value: null
    },
    __fn_onMark: {
        type: null,
        value: null
    },
    items: {
        type: null,
        value: null
    },
    collection: {
        type: null,
        value: null
    },
    isLogin: {
        type: null,
        value: null
    }
}, Subjects.$$events = [ "handleMark", "handleMarkJump", "toggleFolded" ], Subjects.defaultProps = {
    items: [],
    collection: null,
    onMark: null
}, tslib_1.__decorate([ (0, _index3.requireLogin)("props.isLogin") ], Subjects.prototype, "handleMark", null), 
tslib_1.__decorate([ (0, _index3.requireLogin)("props.isLogin") ], Subjects.prototype, "handleMarkJump", null), 
exports.default = Subjects, Component(require("../../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Subjects));