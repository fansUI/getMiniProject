Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n]);
    }
    return t;
}, _createClass = function() {
    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, r) {
        return e && n(t.prototype, e), r && n(t, r), t;
    };
}(), _get = function t(e, r, n) {
    null === e && (e = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, n);
    }
    if ("value" in o) return o.value;
    var s = o.get;
    return void 0 !== s ? s.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _frodoApi = require("../../services/frodo-api.js"), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _index2 = require("../../utils/index.js");

function _interopRequireWildcard(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}

function _asyncToGenerator(t) {
    return function() {
        var i = t.apply(this, arguments);
        return new Promise(function(a, s) {
            return function e(t, r) {
                try {
                    var n = i[t](r), o = n.value;
                } catch (t) {
                    return void s(t);
                }
                if (!n.done) return Promise.resolve(o).then(function(t) {
                    e("next", t);
                }, function(t) {
                    e("throw", t);
                });
                a(o);
            }("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var SubjectItems = function(t) {
    function s() {
        var t, e, r;
        _classCallCheck(this, s);
        for (var n = arguments.length, o = Array(n), a = 0; a < n; a++) o[a] = arguments[a];
        return (e = r = _possibleConstructorReturn(this, (t = s.__proto__ || Object.getPrototypeOf(s)).call.apply(t, [ this ].concat(o)))).$usedState = [ "_subjects", "_navTitle", "_ratio", "start", "count", "total", "subjects" ], 
        r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    var e, r, n;
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function() {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).apply(this, arguments), 
            this.type = "", this.subject_type = "", this.loadableApi = {
                subjectCollection: {
                    api: _frodoApi.frodoApi.subjectCollection,
                    init: {
                        start: -20,
                        count: 20,
                        total: 0,
                        subject_collection: {},
                        subject_collection_items: []
                    },
                    toast: !1
                },
                userInterests: {
                    api: _frodoApi.frodoApi.userInterests,
                    init: {
                        start: -20,
                        count: 20,
                        total: 0,
                        interests: []
                    },
                    toast: !1
                }
            }, this.state = _extends({}, Loadable.init(this.loadableApi), {
                start: -20,
                count: 20,
                total: 0,
                subjects: []
            }), this.api = Loadable.api(this.loadableApi, this);
        }
    }, {
        key: "componentDidMount",
        value: (n = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, r, n;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e = this.$router.params, r = e.type, n = e.subject_type, this.type = r, this.subject_type = n || "movie", 
                    this.fetchSubjects();

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return n.apply(this, arguments);
        })
    }, {
        key: "fetchSubjects",
        value: (r = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, r, n, o, a, s, i, u;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e = this.state, r = e.start, n = e.count, this.api.disableLoadingFlag(), o = void 0, 
                    t.t0 = this.type, t.next = "subject_collection" === t.t0 ? 6 : "interests" === t.t0 ? 12 : 18;
                    break;

                  case 6:
                    return a = this.$router.params.id, t.next = 9, this.api.subjectCollection(a, r + n, n);

                  case 9:
                    return (o = t.sent).data && this.setState({
                        start: o.data.start,
                        count: o.data.count,
                        total: o.data.total,
                        subjects: this.state.subjects.concat(o.data.subject_collection_items)
                    }), t.abrupt("break", 19);

                  case 12:
                    return s = this.$router.params.user_id, i = this.$router.params.status, t.next = 16, 
                    this.api.userInterests(s, i, r + n, n, this.subject_type);

                  case 16:
                    (o = t.sent).data && (u = o.data.interests.map(function(t) {
                        return t.subject;
                    }), this.setState({
                        start: o.data.start,
                        count: o.data.count,
                        total: o.data.total,
                        subjects: this.state.subjects.concat(u)
                    }));

                  case 18:
                    return t.abrupt("break", 19);

                  case 19:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return r.apply(this, arguments);
        })
    }, {
        key: "onReachBottom",
        value: (e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    this.fetchSubjects();

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var t = this.__state.subjects;
            if (0 === t.length) return null;
            var e = (0, _index2.setRatio)(t[0].type), r = this.__state.subjectCollection.data && this.__state.subjectCollection.data.subject_collection.name;
            return Object.assign(this.__state, {
                _subjects: t,
                _navTitle: r,
                _ratio: e
            }), this.__state;
        }
    } ]), s;
}();

SubjectItems.properties = {}, SubjectItems.$$events = [], exports.default = SubjectItems, 
Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(SubjectItems, !0));