Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
}, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var i = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === i) {
        var r = Object.getPrototypeOf(t);
        return null === r ? void 0 : e(r, n, o);
    }
    if ("value" in i) return i.value;
    var a = i.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _helpers = require("../../utils/helpers.js"), _loadable = require("../../utils/loadable.js"), Loadable = _interopRequireWildcard(_loadable), _subjectApi = require("../../services/subject-api.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var annualBgImg = "http://img3.doubanio.com/view/activity_page/raw/public/p3788.jpg", annualImgs = [ "http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2519070834.jpg", "http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2516578307.jpg", "http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2518856022.jpg" ], loadableApi = {
    movieRankList: {
        api: function() {
            return _subjectApi.subjectApi.rankList("movie");
        },
        init: {
            count: 0,
            start: 0,
            total: 0,
            selected_collections: [],
            title: ""
        },
        toast: !1
    },
    bookRankList: {
        api: function() {
            return _subjectApi.subjectApi.rankList("book");
        },
        init: {
            count: 0,
            start: 0,
            total: 0,
            selected_collections: [],
            title: ""
        },
        toast: !1
    }
}, Index = function(e) {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var o = arguments.length, i = Array(o), r = 0; r < o; r++) i[r] = arguments[r];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(i)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "loopArray0", "annualImgs", "selected_collections" ], 
        n.config = {
            navigationBarTitleText: "榜单"
        }, n.$$refs = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function() {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).apply(this, arguments), 
            this.state = _extends({}, Loadable.init(loadableApi)), this.api = Loadable.api(loadableApi, this);
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this.api.movieRankList(), this.api.bookRankList();
        }
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "getMaskBg",
        value: function(e) {
            return "background: linear-gradient(to right, " + (0, _helpers.hex2rgb)(e, .95) + ", " + (0, 
            _helpers.hex2rgb)(e, .95) + " 30%, " + (0, _helpers.hex2rgb)(e, .5) + " 100%)";
        }
    }, {
        key: "_createData",
        value: function() {
            var t = this;
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__state.movieRankList, n = this.__state.bookRankList;
            e.isLoading || n.isLoading ? _index2.default.showLoading({
                title: "榜单加载中"
            }) : _index2.default.hideLoading();
            var o = e.data.selected_collections;
            o = o.concat(n.data.selected_collections.slice(0, 3));
            var i = (0, _index.internal_inline_style)({
                backgroundImage: "url(" + annualBgImg + ")",
                backgroundPosition: "center left"
            }), r = (0, _index.internal_inline_style)({
                opacity: 0
            }), a = o.map(function(e) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp4: -1 < [ "movie_hot_weekly", "movie_weekly_best" ].indexOf(e.$original.id) ? (0, 
                    _index.internal_inline_style)({
                        backgroundImage: "url(" + e.$original.header_bg_image + ")"
                    }) : null,
                    $loopState__temp6: -1 < [ "movie_hot_weekly", "movie_weekly_best" ].indexOf(e.$original.id) ? (0, 
                    _index.internal_inline_style)(t.getMaskBg(e.$original.background_color_scheme.primary_color_dark)) : null,
                    $loopState__temp8: (0, _index.internal_inline_style)({
                        backgroundImage: "url(" + e.$original.header_bg_image + ")"
                    }),
                    $loopState__temp10: -1 < [ "movie_hot_weekly", "movie_weekly_best" ].indexOf(e.$original.id),
                    $original: e.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp: i,
                anonymousState__temp2: r,
                loopArray0: a,
                annualImgs: annualImgs,
                selected_collections: o
            }), this.__state;
        }
    } ]), a;
}();

Index.properties = {}, Index.$$events = [], exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));