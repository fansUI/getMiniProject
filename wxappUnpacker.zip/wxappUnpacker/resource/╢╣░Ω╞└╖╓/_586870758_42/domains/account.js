Object.defineProperty(exports, "__esModule", {
    value: !0
});

var LoginType = exports.LoginType = {
    bindPhone: "bind-phone",
    login: "login"
};