Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fetchUserInfo = exports.userPhoneVerified = void 0;

var _user = require("../constants/user.js"), _user2 = _interopRequireDefault(_user), _frodoApi = require("../services/frodo-api.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var userPhoneVerified = exports.userPhoneVerified = function(e) {
    return {
        type: _user2.default.RECEIVE_USERINFO,
        isPhoneVerified: e
    };
}, fetchUserInfo = exports.fetchUserInfo = function(e) {
    return function(o) {
        return _frodoApi.frodoApi.user(e).then(function(e) {
            if (0 === e.code) {
                var r = e.data;
                o(userPhoneVerified(r.is_phone_verified));
            }
        });
    };
};