Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(e, t) {
        for (var a = 0; a < t.length; a++) {
            var n = t[a];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, a) {
        return t && n(e.prototype, t), a && n(e, a), e;
    };
}(), _index = require("./npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

require("./npm/@tarojs/async-await/index.js");

var _index3 = require("./npm/@tarojs/redux/index.js"), _index4 = require("./store/index.js"), _index5 = _interopRequireDefault(_index4), _tCaptchaCallback = require("./modules/weapp-douban-login/utils/t-captcha-callback.js"), _tCaptchaCallback2 = _interopRequireDefault(_tCaptchaCallback);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var store = (0, _index5.default)();

(0, _index3.setStore)(store);

var _App = function(e) {
    function t() {
        _classCallCheck(this, t);
        var e = _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
        return e.config = {
            pages: [ "pages/index/index", "pages/search/search", "pages/collections/collections", "pages/collection/collection", "pages/user/user", "pages/user/mine", "pages/user/verify", "pages/standbyme/2018", "pages/user/columns", "pages/subject/subject", "pages/subject/interests", "pages/subject/photos", "pages/subject/review", "pages/subject/mark", "pages/annual/list", "pages/annual/overview", "pages/subject-items/subject-items", "pages/subject-profile/subject-profile", "pages/subject-charts/subject-charts", "pages/quick-mark/quick-mark", "pages/webview/index", "pages/login/basic", "pages/login/wxa", "pages/login/sms", "pages/login/foreign", "pages/login/license", "pages/status/status", "pages/status/comments" ],
            window: {
                backgroundTextStyle: "light",
                navigationBarBackgroundColor: "#ffffff",
                navigationBarTitleText: "豆瓣评分",
                navigationBarTextStyle: "black",
                navigationStyle: "custom"
            },
            tabBar: {
                color: "#AAAAAA",
                selectedColor: "#42BD56",
                backgroundColor: "#FFFFFF",
                list: [ {
                    pagePath: "pages/index/index",
                    text: "首页",
                    iconPath: "images/tabbar/movie.png",
                    selectedIconPath: "images/tabbar/movie_selected.png"
                }, {
                    pagePath: "pages/collections/collections",
                    text: "榜单",
                    iconPath: "images/tabbar/collections.png",
                    selectedIconPath: "images/tabbar/collections_selected.png"
                }, {
                    pagePath: "pages/user/mine",
                    text: "我的",
                    iconPath: "images/tabbar/mine.png",
                    selectedIconPath: "images/tabbar/mine_selected.png"
                } ]
            },
            usingComponents: {
                "custom-nav": "/components/custom-nav/index"
            },
            navigateToMiniProgramAppIdList: [ "wx5a3a7366fd07e119" ]
        }, e.globalData = {
            appid: "wx2f9b06c1de1ccfca"
        }, e;
    }
    return _inherits(t, _index.Component), _createClass(t, [ {
        key: "componentDidMount",
        value: function() {
            var t = this;
            _index2.default.getSystemInfo({
                success: function(e) {
                    t.globalData = Object.assign(t.globalData, {
                        systemInfo: e
                    });
                }
            });
        }
    }, {
        key: "componentDidShow",
        value: function() {
            var e = this.$router.params, t = e.referrerInfo;
            if (1038 === e.scene && t && t.extraData) return (0, _tCaptchaCallback2.default)(e);
        }
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "componentCatchError",
        value: function() {}
    }, {
        key: "_createData",
        value: function() {}
    } ]), t;
}();

exports.default = _App, App(require("./npm/@tarojs/taro-weapp/index.js").default.createApp(_App)), 
_index2.default.initPxTransform({
    designWidth: 375,
    deviceRatio: {
        375: .5
    }
});