Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, r) {
        return e && n(t.prototype, e), r && n(t, r), t;
    };
}(), _get = function t(e, r, n) {
    null === e && (e = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(e, r);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, r, n);
    }
    if ("value" in o) return o.value;
    var l = o.get;
    return void 0 !== l ? l.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Rating = function(t) {
    function l() {
        var t, e, r;
        _classCallCheck(this, l);
        for (var n = arguments.length, o = Array(n), a = 0; a < n; a++) o[a] = arguments[a];
        return (e = r = _possibleConstructorReturn(this, (t = l.__proto__ || Object.getPrototypeOf(l)).call.apply(t, [ this ].concat(o)))).$usedState = [ "anonymousState__temp3", "loopArray0", "isWhiteStar", "all", "showValue", "ratingValue", "size", "starColor" ], 
        r.$$refs = [], _possibleConstructorReturn(r, e);
    }
    return _inherits(l, _index.Component), _createClass(l, [ {
        key: "_constructor",
        value: function(t) {
            _get(l.prototype.__proto__ || Object.getPrototypeOf(l.prototype), "_constructor", this).call(this, t);
        }
    }, {
        key: "handleClick",
        value: function(t) {
            var e = t.target.dataset.starCount;
            this.props.onRate && this.__triggerPropsFn("onRate", [ null ].concat([ e ]));
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            for (var t = this.__props, e = t.ratingValue, r = t.showValue, n = t.size, o = t.starColor, a = [], l = (e / 2).toFixed(1).split("."), i = +l[0], u = +l[1], s = 5 - i, p = 0; p < i; p++) a.push("full");
            5 < u ? (a.push("full"), s -= 1) : u <= 5 && 0 < u && (a.push("half"), s -= 1);
            for (var c = 0; c < s; c++) a.push("empty");
            var _ = void 0;
            n && (_ = {
                width: (0, _index.pxTransform)(n),
                height: (0, _index.pxTransform)(n)
            });
            var f = !1;
            "white" === o && (f = !0);
            var h = r ? Number(e).toFixed(1) : null, y = a.map(function(t, e) {
                return t = {
                    $original: (0, _index.internal_get_original)(t)
                }, {
                    $loopState__temp2: (0, _index.internal_inline_style)(_),
                    $original: t.$original
                };
            });
            return Object.assign(this.__state, {
                anonymousState__temp3: h,
                loopArray0: y,
                isWhiteStar: f,
                all: a,
                showValue: r
            }), this.__state;
        }
    } ]), l;
}();

Rating.properties = {
    onRate: {
        type: null,
        value: null
    },
    __fn_onRate: {
        type: null,
        value: null
    },
    ratingValue: {
        type: null,
        value: null
    },
    showValue: {
        type: null,
        value: null
    },
    size: {
        type: null,
        value: null
    },
    starColor: {
        type: null,
        value: null
    }
}, Rating.$$events = [ "handleClick" ], exports.default = Rating, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Rating));