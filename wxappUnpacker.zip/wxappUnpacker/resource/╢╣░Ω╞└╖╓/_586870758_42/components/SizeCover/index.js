Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, r, o);
    }
    if ("value" in n) return n.value;
    var i = n.get;
    return void 0 !== i ? i.call(o) : void 0;
};

exports.cls = cls;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function cls() {
    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return t.filter(function(e) {
        return "string" == typeof e;
    }).join(" ");
}

var SizeCover = function(e) {
    function i() {
        var e, t, r;
        _classCallCheck(this, i);
        for (var o = arguments.length, n = Array(o), a = 0; a < o; a++) n[a] = arguments[a];
        return (t = r = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "children", "src", "width", "ratio", "showBorder", "borderRadius", "showBoxShadow" ], 
        r.$$refs = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e);
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            var e = this.__props, t = e.src, r = e.children, o = e.width, n = void 0 === o ? 100 : o, a = e.ratio, i = void 0 === a ? 1.4 : a, s = e.showBorder, l = void 0 === s || s, u = e.borderRadius, p = void 0 === u ? 0 : u, c = e.showBoxShadow, _ = {
                borderRadius: "" + (0, _index.pxTransform)(p),
                width: "" + (0, _index.pxTransform)(n),
                height: "" + (0, _index.pxTransform)(n * i)
            }, d = {
                paddingTop: 100 * i + "%",
                borderRadius: "" + (0, _index.pxTransform)(p)
            }, h = {
                background: "no-repeat url(" + t + ") center / cover",
                borderRadius: "" + (0, _index.pxTransform)(p)
            }, f = cls("sizeCover", l ? "showBorder" : ""), y = (0, _index.internal_inline_style)(_), v = (0, 
            _index.internal_inline_style)(d), m = cls("background", c ? "showBoxShadow" : ""), b = (0, 
            _index.internal_inline_style)(h);
            return Object.assign(this.__state, {
                anonymousState__temp: f,
                anonymousState__temp2: y,
                anonymousState__temp3: v,
                anonymousState__temp4: m,
                anonymousState__temp5: b,
                children: r
            }), this.__state;
        }
    } ]), i;
}();

SizeCover.properties = {
    src: {
        type: null,
        value: null
    },
    children: {
        type: null,
        value: null
    },
    width: {
        type: null,
        value: null
    },
    ratio: {
        type: null,
        value: null
    },
    showBorder: {
        type: null,
        value: null
    },
    borderRadius: {
        type: null,
        value: null
    },
    showBoxShadow: {
        type: null,
        value: null
    }
}, SizeCover.$$events = [], SizeCover.defaultProps = {
    width: 100,
    ratio: 1.4,
    showBorder: !0,
    borderRadius: 0,
    showBoxShadow: !1
}, exports.default = SizeCover, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(SizeCover));