var _getDeviceOs = require("./utils/getDeviceOs.js"), _getDeviceOs2 = _interopRequireDefault(_getDeviceOs), _config = require("./config.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var app = getApp();

Component({
    behaviors: [],
    options: {
        multipleSlots: !0
    },
    properties: {
        externalClasses: {
            type: String,
            value: ""
        },
        bgColor: {
            type: String,
            value: "#fff"
        },
        iconColor: {
            type: String,
            value: "#333"
        },
        navHeight: {
            type: Number,
            value: _config.CUSTOM_NAV_HEIGHT
        },
        enableBack: {
            type: Boolean,
            value: !1
        },
        enableHome: {
            type: Boolean,
            value: !1
        },
        customLeft: {
            type: Boolean,
            value: !1
        },
        customCenter: {
            type: Boolean,
            value: !1
        },
        navTitle: {
            type: String,
            value: ""
        }
    },
    data: {
        statusBarHeight: app.globalData.systemInfo.statusBarHeight,
        gap: 5
    },
    methods: {
        tapBackBtnHandle: function() {
            wx.navigateBack({
                delta: 1
            });
        },
        tapHomeBtnHandle: function() {
            wx.switchTab({
                url: "/pages/index/index"
            });
        },
        _fixAndroidGap: function() {
            var e = this.data.gap;
            "android" === (0, _getDeviceOs2.default)(app.globalData.systemInfo.system) && (e += 3, 
            this.setData({
                gap: e,
                os: "android"
            }));
        },
        preventTouchMove: function() {}
    },
    created: function() {},
    attached: function() {
        this._fixAndroidGap();
    },
    ready: function() {},
    moved: function() {},
    detached: function() {}
});