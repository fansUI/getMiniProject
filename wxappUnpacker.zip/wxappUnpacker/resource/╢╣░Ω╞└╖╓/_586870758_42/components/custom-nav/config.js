var app = getApp(), MIN_NAV_GAP = 14;

module.exports = {
    CUSTOM_NAV_HEIGHT: 30 + app.globalData.systemInfo.statusBarHeight + MIN_NAV_GAP
};