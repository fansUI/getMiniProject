Object.defineProperty(exports, "__esModule", {
    value: !0
});

var isAndroid = function(i) {
    return -1 < i.indexOf("Android") || -1 < i.indexOf("Adr");
}, isiOS = function(i) {
    return -1 < !!i.indexOf("iOS");
}, isiPad = exports.isiPad = function(i) {
    return i.toLocaleLowerCase().includes("ipad");
}, getOS = function(i) {
    return isAndroid(i) ? "android" : isiOS(i) ? "ios" : "";
};

exports.default = getOS;