exports.app_key = "638c1376fac3e919962215fd359befa8", exports.getLocation = !1, 
exports.plugin = !1, exports.useOpen = !1;