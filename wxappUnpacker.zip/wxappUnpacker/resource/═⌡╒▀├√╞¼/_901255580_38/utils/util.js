function t(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

module.exports = {
    formatTime: function(e) {
        var n = e.getFullYear(), r = e.getMonth() + 1, o = e.getDate(), u = e.getHours(), a = e.getMinutes(), i = e.getSeconds();
        return [ n, r, o ].map(t).join("/") + " " + [ u, a, i ].map(t).join(":");
    },
    formatTime2: function(e) {
        var n = e.getMonth() + 1, r = e.getDate(), o = e.getHours(), u = e.getMinutes();
        return t(n) + "月" + t(r) + "日 " + t(o) + ":" + t(u);
    },
    formatTime3: function(t) {
        return t.getFullYear() + "/" + (t.getMonth() + 1) + "/" + t.getDate();
    },
    randomI: function(t, e) {
        return t + Math.ceil((e - t + 1) * Math.random()) - 1;
    }
};