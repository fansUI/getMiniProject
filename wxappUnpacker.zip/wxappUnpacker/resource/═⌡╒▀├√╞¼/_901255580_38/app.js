require("utils/ald-stat.js");

var t = require("utils/util.js"), a = require("utils/Bmob-1.6.7.min.js");

a.initialize("f85c41803ab94936beff7ef1369205c1", "d08aeaad48735dd72484eff093a38ad9"), 
App({
    globalData: {
        debug: !1,
        version: "v1.1.8",
        sysinfo: null,
        openid: null,
        userInfo: null,
        queue: []
    },
    onLaunch: function(t) {
        this.globalData.Bmob = a;
        var e = wx.getSystemInfoSync();
        if (e) {
            this.globalData.sysinfo = e;
            var i = e.windowWidth;
            this.globalData.px2rpx = 750 / i, this.globalData.rpx2px = i / 750, this.globalData.StatusBar = e.statusBarHeight;
            var o = wx.getMenuButtonBoundingClientRect();
            this.globalData.Custom = o, this.globalData.CustomBar = o.bottom + o.top - e.statusBarHeight, 
            t.query && t.query.uid && t.query.inviteid && (this.globalData.flagCheckInvite = !0, 
            this.globalData.ciuid = t.query.uid, this.globalData.ciinviteid = t.query.inviteid);
        }
        if (this.globalData.openid = wx.getStorageSync("openid") || null, this.globalData.userInfo = wx.getStorageSync("userInfo") || null, 
        this.login(), "function" == typeof wx.getUpdateManager) {
            var n = wx.getUpdateManager();
            n.onCheckForUpdate(function(t) {}), n.onUpdateReady(function() {
                n.applyUpdate();
            }), n.onUpdateFailed(function() {});
        }
    },
    onShow: function(t) {},
    initData: function() {
        var t = {
            name: "弹一弹球球",
            appid: "wx1d758056d7f87899",
            logoUrl: "https://bmob-cdn-9276.bmobcloud.com/2019/08/16/6e7962e74083d65e800f2234bfb742af.jpg"
        }, a = {
            appid: "wxfad04d63d3c7f5dc",
            logoUrl: "https://bmob-cdn-9276.bmobcloud.com/2019/08/16/a70e2b9940a351d7809cbe1387ac0973.png",
            name: "鲲去哪了"
        }, e = {
            name: "数字谜盘",
            appid: "wxce6f43c78553082e",
            logoUrl: "https://bmob-cdn-9276.bmobcloud.com/2019/08/16/36e484354095d8b3800e68ee47b6ee30.jpg"
        }, i = {
            name: "90坦克大战OL",
            appid: "wxc8e78b5614114f43",
            logoUrl: "https://bmob-cdn-9276.bmobcloud.com/2019/08/16/ea4ccfc04061bbff80f2ba355f7b6c2b.png"
        }, o = {
            name: "一笔画王者",
            appid: "wxcb7b167ba7f0c539",
            logoUrl: "https://bmob-cdn-9276.bmobcloud.com/2019/08/16/db3fbea940b4a8bc80168f7db6e70371.jpg"
        };
        this.globalData.mgs = [ t, a, e, i, o ];
    },
    login: function() {
        a.User.current() ? this.getUserData() : this.register();
    },
    register: function(t) {
        var e = this;
        wx.login({
            success: function(i) {
                i.code && a.User.requestOpenId(i.code).then(function(i) {
                    e.globalData.openid = i.openid, wx.setStorage({
                        key: "openid",
                        data: e.globalData.openid
                    });
                    var o = {
                        username: e.globalData.openid,
                        password: e.globalData.openid
                    };
                    a.User.register(o).then(function(a) {
                        e.getUserData(t), e.globalData.flagCheckInvite && e.checkInvite(e.globalData.ciuid, e.globalData.ciinviteid);
                    }).catch(function(a) {
                        console.log(a), e.getUserData(t);
                    });
                }).catch(function(t) {
                    console.log(t), e.showError();
                });
            },
            fail: function(t) {
                console.log("register fail:"), console.log(t), e.showError();
            }
        });
    },
    isIos: function() {
        return !(!this.globalData.sysinfo.platform || "ios" != this.globalData.sysinfo.platform.toLowerCase().substr(0, 3));
    },
    showError: function() {
        var t = this;
        wx.showModal({
            title: "登录失败",
            content: "请重新登录",
            cancelText: "取消",
            confirmText: "登录",
            success: function(a) {
                console.log(a), a.confirm && t.register();
            }
        });
    },
    getUserData: function(t) {
        var e = this;
        this.globalData.openid ? a.User.login(this.globalData.openid, this.globalData.openid).then(function(a) {
            e.setUserData(a), "function" == typeof t && t();
        }).catch(function(t) {
            console.log(t), e.showError();
        }) : this.register();
    },
    setUserData: function(e) {
        if (e.hks && e.hks.length > 0 && a.User.current()) {
            var i = a.User.current().objectId;
            if (-1 != e.hks.indexOf(i)) return;
        }
        this.globalData.userInfo = e.userInfo, wx.setStorage({
            key: "userInfo",
            data: this.globalData.userInfo
        }), this.globalData.joins = e.joins || [], this.globalData.bingos = e.bingos || [], 
        this.globalData.chips = e.chips || 0, this.globalData.isAlert = e.isAlert || !1, 
        console.log(this.globalData.isAlert), this.globalData.hascheckin = !1, this.globalData.checkindays = e.checkindays || [];
        for (var o = t.formatTime3(new Date()), n = 0; n < this.globalData.checkindays.length; n++) if (o == this.globalData.checkindays[n]) {
            this.globalData.hascheckin = !0;
            break;
        }
        this.globalData.hasLogin = !0;
        for (n = 0; n < this.globalData.queue.length; n++) "function" == typeof this.globalData.queue[n] && this.globalData.queue[n]();
        this.globalData.queue = [];
    },
    incrementData: function(t, e, i) {
        this.globalData.openid && a.Query("_User").get(a.User.current().objectId).then(function(a) {
            a.increment(t, e), a.save(), "function" == typeof i && i();
        }).catch(function(t) {
            console.log(t);
        });
    },
    updateData: function(t, e, i) {
        this.globalData.openid && a.Query("_User").get(a.User.current().objectId).then(function(a) {
            a.set(t, e), a.save(), "function" == typeof i && i();
        }).catch(function(t) {
            console.log(t);
        });
    },
    checkInvite: function(t, e) {
        var i;
        i = this.globalData.sysinfo && this.globalData.sysinfo.model ? this.globalData.sysinfo.model : "" + new Date().getTime(), 
        a.Query("Invite").get(e).then(function(t) {
            console.log(t);
            var a = t.friends || [];
            a.push(i), t.set("friends", a), t.save();
        }).catch(function(t) {
            console.log(t);
        });
    },
    updateUserInfo: function(t, e) {
        this.globalData.userInfo = t, wx.setStorage({
            key: "userInfo",
            data: this.globalData.userInfo
        }), this.globalData.openid && a.Query("_User").get(a.User.current().objectId).then(function(a) {
            a.set("nickname", t.nickName), a.set("avatarUrl", t.avatarUrl), a.set("userInfo", t), 
            a.save(), "function" == typeof e && e();
        }).catch(function(t) {
            console.log(t);
        });
    },
    bindClick: function(t) {
        return t || (t = 1e3), this.clicktimestart ? (this.clicktimenow = new Date().getTime(), 
        !(this.clicktimenow - this.clicktimestart < t) && (this.clicktimestart = this.clicktimenow, 
        !0)) : (this.clicktimestart = new Date().getTime(), !0);
    },
    previewImage: function(t) {
        wx.previewImage({
            urls: [ t ],
            success: function(t) {},
            fail: function(t) {},
            complete: function(t) {}
        });
    },
    getDianzanid: function() {
        if (this.globalData.dianzanid) return this.globalData.dianzanid;
        try {
            return this.globalData.dianzanid = wx.getStorageSync("dianzanid"), this.globalData.dianzanid ? this.globalData.dianzanid : (this.globalData.dianzanid = [], 
            wx.setStorage({
                key: "dianzanid",
                data: this.globalData.dianzanid
            }), this.globalData.dianzanid);
        } catch (t) {}
    },
    saveDianzanid: function() {
        wx.setStorage({
            key: "dianzanid",
            data: this.globalData.dianzanid
        });
    }
});