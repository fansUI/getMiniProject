var t, e = require("../../utils/util.js"), a = getApp(), o = a.globalData.Bmob;

Page({
    data: {
        isAlert: !1,
        chipsnum: 0,
        newlyFormId: !1,
        games: []
    },
    onLoad: function(e) {
        t = this, a.globalData.hasLogin ? this.updateChipsnum() : a.globalData.queue.push(this.updateChipsnum.bind(this)), 
        this.loadData(), e.joinid && t.checkJoin(e.joinid, e.tablejoin), this.initCover();
    },
    init: function() {
        this.updateChipsnum(), this.loadData();
    },
    checkJoin: function(e, n) {
        t.joinid = e, t.tablejoin = n || "Join", o.User.current() && a.globalData.userInfo && a.globalData.userInfo.avatarUrl && o.Query(t.tablejoin).get(e).then(function(e) {
            console.log(e);
            var a = e.luckys || [], n = "领取", i = 1;
            if (a.length >= 5) n = "领完了", i = 3; else for (s = 0; s < a.length; s++) if (a[s].uid == o.User.current().objectId) {
                n = "已经领了", i = 2;
                break;
            }
            if (3 == i && o.User.current().objectId == e.playerid) {
                for (var l = !1, s = 0; s < a.length; s++) if (a[s].uid == o.User.current().objectId) {
                    l = !0;
                    break;
                }
                l || (n = "领取", i = 1);
            }
            a.length >= 5 && (a = a.slice(0, 5)), t.showModal("getluckys"), t.setData({
                join: e,
                luckystr: n,
                luckystate: i
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    bindGetLucys: function() {
        this.hideModal(), 1 == this.data.luckystate && o.Query(t.tablejoin).get(t.joinid).then(function(n) {
            var i = n.luckys || [];
            i.push({
                uid: o.User.current().objectId,
                avatarUrl: a.globalData.userInfo.avatarUrl
            }), n.set("luckys", i), n.save();
            var l = e.randomI(1, 2);
            a.incrementData("chips", l, function() {
                a.globalData.chips || (a.globalData.chips = 0), a.globalData.chips += l, wx.showToast({
                    title: "获得" + l + "个皮肤碎片",
                    icon: "success",
                    duration: 2e3
                }), t.updateChipsnum();
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    randomGames: function() {
        if (a.globalData.mgs && a.globalData.mgs.length > 0) {
            for (var e = [], o = 0; o < a.globalData.mgs.length; o++) e.push(a.globalData.mgs[o]);
            e.sort(function(t, e) {
                return Math.random() > .5 ? -1 : 1;
            }), t.setData({
                games: e
            });
        }
    },
    updateChipsnum: function() {
        this.setData({
            flagChips: !0,
            chipsnum: a.globalData.chips,
            isAlert: a.globalData.isAlert
        });
    },
    bindChips: function(t) {
        console.log(t), a.globalData.hasLogin && wx.navigateTo({
            url: "/pages/chips/chips"
        });
    },
    loadData: function() {
        var a = this, n = o.Query("Skin");
        n.equalTo("show", "==", !0), n.order("-createdAt"), n.select("url", "tag", "name", "time", "show"), 
        n.limit(100), n.find().then(function(o) {
            if (a.results = o, a.setData({
                hasLoad: !0
            }), a.results && a.results.length > 0) {
                for (var n = 0; n < t.results.length; n++) {
                    var i = new Date(t.results[n].time.iso.replace(/-/g, "/")), l = e.formatTime2(i);
                    t.results[n].time = l;
                }
                a.setData({
                    skins: t.results
                });
            }
        }).catch(function(t) {
            console.log(t), a.setData({
                hasLoad: !0
            });
        });
    },
    showModal: function(t) {
        this.setData({
            modalName: t
        });
    },
    hideModal: function() {
        this.setData({
            modalName: null
        }), 1 == e.randomI(1, 2) && this.showCover();
    },
    bindDetail: function(t) {
        var e = t.currentTarget.dataset.id;
        e || (e = t.target.dataset.id), e && wx.navigateTo({
            url: "/pages/detail/detail?id=" + e
        });
    },
    initCover: function() {
        this.interstitialAd = null, wx.createInterstitialAd && (this.interstitialAd = wx.createInterstitialAd({
            adUnitId: "adunit-d21249fbd4b8ab69"
        }), this.interstitialAd.onLoad(function() {
            console.log("onLoad event emit");
        }), this.interstitialAd.onError(function(t) {
            console.log("onError event emit", t);
        }), this.interstitialAd.onClose(function(t) {
            console.log("onClose event emit", t);
        }));
    },
    showCover: function() {
        t.interstitialAd.show().catch(function(t) {
            console.error(t);
        });
    },
    onReady: function() {},
    onShow: function() {
        a.globalData.hasLogin && this.updateChipsnum();
    },
    bindMg: function(t) {
        var e = t.target.dataset.item;
        e || (e = t.currentTarget.dataset.item), this.bindMoreGame(e);
    },
    bindMoreGame: function(t) {
        console.log(t), "function" == typeof wx.navigateToMiniProgram && t && t.appid ? wx.navigateToMiniProgram({
            appId: t.appid,
            path: t.path ? t.path : null,
            extraData: t.extraData ? t.extraData : null,
            fail: function() {
                t && t.detail && wx.previewImage({
                    urls: [ t.detail ]
                });
            }.bind(this)
        }) : t && t.detail && wx.previewImage({
            urls: [ t.detail ]
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/index/index"
        };
    },
    bindsubmit: function(t) {
        console.log(t), t && t.detail && t.detail.formId && a.globalData.hasLogin && (a.globalData.newlyFormId ? a.globalData.checkInFormId || this.updateFormId2(t.detail.formId) : this.updateFormId(t.detail.formId));
    },
    bindAlert: function(t) {
        this.setData({
            isAlert: t.detail.value
        }), a.globalData.isAlert = this.data.isAlert, a.updateData("isAlert", this.data.isAlert);
    },
    updateFormId: function(e) {
        o.Query("NewlyFormId").get("GPZM6667").then(function(n) {
            var i = n.count, l = o.Query("NewlyFormId");
            l.equalTo("count", "==", i);
            var s = o.Pointer("_User").set(o.User.current().objectId);
            l.equalTo("player", "==", s), l.find().then(function(n) {
                if (n && n.length > 0) console.log("has newlyFormId"), a.globalData.newlyFormId = !0, 
                t.setData({
                    newlyFormId: !0
                }), t.updateFormId2(e); else {
                    var l = new Date().getTime(), s = o.Query("NewlyFormId"), r = o.Pointer("_User").set(o.User.current().objectId);
                    s.set("player", r), s.set("openid", a.globalData.openid), s.set("formid", e), s.set("count", i), 
                    s.set("title", "form"), s.set("t", l), s.save().then(function(e) {
                        a.globalData.newlyFormId = !0, console.log("new newlyFormId"), t.setData({
                            newlyFormId: !0
                        });
                    }).catch(function(t) {
                        console.log(t);
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    updateFormId2: function(e) {
        o.Query("CheckInFormId").get("gHQK555G").then(function(n) {
            var i = n.day, l = o.Query("CheckInFormId");
            l.equalTo("day", "==", i);
            var s = o.Pointer("_User").set(o.User.current().objectId);
            l.equalTo("player", "==", s), l.find().then(function(n) {
                if (n && n.length > 0) console.log("has checkInFormId"), a.globalData.checkInFormId = !0, 
                t.setData({
                    checkInFormId: !0
                }); else {
                    var l = new Date().getTime(), s = o.Query("CheckInFormId"), r = o.Pointer("_User").set(o.User.current().objectId);
                    s.set("player", r), s.set("openid", a.globalData.openid), s.set("formid", e), s.set("day", i), 
                    s.set("title", "form"), s.set("t", l), s.save().then(function(e) {
                        a.globalData.checkInFormId = !0, console.log("new checkInFormId"), t.setData({
                            checkInFormId: !0
                        });
                    }).catch(function(t) {
                        console.log(t);
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    }
});