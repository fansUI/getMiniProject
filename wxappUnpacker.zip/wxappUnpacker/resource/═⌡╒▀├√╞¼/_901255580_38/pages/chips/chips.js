var e, a = require("../../utils/util.js"), t = getApp(), i = t.globalData.Bmob;

Page({
    data: {
        chipsnum: 0,
        invitedaynum: 0,
        videodaynum: 0,
        invitenum: 0,
        notreceivenum: 0
    },
    onLoad: function(i) {
        e = this, this.getState(this.updateState.bind(this)), e.videoday = "video" + a.formatTime3(new Date());
        var n = wx.getStorageSync(e.videoday);
        n = n ? parseInt(n) : 0, t.globalData[e.videoday] = n, t.globalData[e.videoday] >= 3 && (t.globalData[e.videoday] = 3), 
        this.updateVideodaynum(), t.globalData[e.videoday] < 3 && this.initVideo(), this.getInviteId(this.updateInvite.bind(this));
    },
    getState: function(e) {
        if (i.User.current()) {
            var n = i.User.current().objectId, o = i.Query("_User");
            o.equalTo("objectId", "==", n), o.select("chips", "checkindays"), o.find().then(function(i) {
                if (i && i.length > 0) {
                    i[0].chips ? t.globalData.chips = i[0].chips : t.globalData.chips = 0, i[0].checkindays ? t.globalData.checkindays = i[0].checkindays : t.globalData.checkindays = [], 
                    t.globalData.hascheckin = !1;
                    for (var n = a.formatTime3(new Date()), o = 0; o < t.globalData.checkindays.length; o++) if (n == t.globalData.checkindays[o]) {
                        t.globalData.hascheckin = !0;
                        break;
                    }
                    "function" == typeof e && e();
                }
            }).catch(function(e) {
                console.log(e);
            });
        }
    },
    updateState: function() {
        this.updateCheckin(), this.updateChipsnum();
    },
    getChips: function(e) {
        if (i.User.current()) {
            var a = i.User.current().objectId, n = i.Query("_User");
            n.equalTo("objectId", "==", a), n.select("chips"), n.find().then(function(a) {
                a && a.length > 0 && (a[0].chips ? t.globalData.chips = a[0].chips : t.globalData.chips = 0, 
                "function" == typeof e && e());
            }).catch(function(e) {
                console.log(e);
            });
        }
    },
    updateInvite: function() {
        t.globalData.invite && this.setData({
            invitenum: t.globalData.invite.friends.length,
            notreceivenum: t.globalData.invite.friends.length - t.globalData.invite.receivenum,
            flagInvite: !0,
            userInfo: t.globalData.userInfo ? t.globalData.userInfo : null
        });
    },
    bindAlert: function(e) {
        this.setData({
            isAlertCheckIn: e.detail.value
        }), t.globalData.isAlertCheckIn = this.data.isAlertCheckIn, t.updateData("isAlertCheckIn", this.data.isAlertCheckIn);
    },
    bindAdd: function() {
        wx.setClipboardData({
            data: "1819816268",
            success: function(e) {
                wx.showModal({
                    title: "提示",
                    showCancel: !1,
                    content: "复制成功，请在qq里面添加好友",
                    confirmText: "知道了",
                    confirmColor: "#e54d42"
                });
            }
        });
    },
    bindReceive: function() {
        if (t.globalData.invite && t.globalData.invite.inviteid && t.bindClick()) {
            var a = t.globalData.invite.friends.length - t.globalData.invite.receivenum;
            a > 0 && (t.globalData.invite.receivenum = t.globalData.invite.friends.length, i.Query("Invite").get(t.globalData.invite.inviteid).then(function(i) {
                i.set("receivenum", t.globalData.invite.receivenum), i.save(), t.incrementData("chips", 5 * a, function() {
                    t.globalData.chips || (t.globalData.chips = 0), t.globalData.chips += 5 * a, e.updateChipsnum(), 
                    wx.showToast({
                        title: "获得" + 5 * a + "个皮肤碎片",
                        icon: "success",
                        duration: 2e3
                    }), e.updateInvite();
                });
            }).catch(function(e) {
                console.log(e);
            }));
        }
    },
    updateVideodaynum: function() {
        this.setData({
            flagrrw: !(t.globalData[e.videoday] >= 3),
            videodaynum: t.globalData[e.videoday]
        }), t.globalData[e.videoday];
    },
    handleContact: function(e) {
        console.log(e.path), console.log(e.query);
    },
    updateCheckin: function() {
        t.globalData.hascheckin ? this.setData({
            flagCheckin7: !1,
            flagCheckinP: !1,
            hasCheckin: t.globalData.hascheckin,
            flagad: !0
        }) : !t.globalData.checkindays || t.globalData.checkindays.length >= 7 ? (!1, !0, 
        this.setData({
            flagCheckin7: !1,
            flagCheckinP: !0,
            hasCheckin: t.globalData.hascheckin
        })) : (!0, this.setData({
            flagCheckin7: !0,
            flagCheckinP: !1,
            day: t.globalData.checkindays.length,
            hasCheckin: t.globalData.hascheckin
        }));
    },
    bindCheckin: function() {
        t.bindClick() && !t.globalData.hascheckin && (t.globalData.hascheckin = !0, this.setCheckIn());
    },
    setCheckIn: function() {
        var n = a.formatTime3(new Date());
        t.globalData.checkindays || (t.globalData.checkindays = []);
        for (var o = 0; o < t.globalData.checkindays.length; o++) if (n == t.globalData.checkindays[o]) return void (t.globalData.hascheckin = !0);
        t.globalData.checkindays.push(n), i.Query("_User").get(i.User.current().objectId).then(function(a) {
            a.set("checkindays", t.globalData.checkindays);
            var i = e.checkinnum(t.globalData.checkindays.length);
            a.increment("chips", i), a.save(), t.globalData.hascheckin = !0, e.updateCheckin(), 
            t.globalData.chips || (t.globalData.chips = 0), t.globalData.chips += i, wx.showToast({
                title: "获得" + i + "个皮肤碎片",
                icon: "success",
                duration: 2e3
            }), e.setData({
                flagCheckinP: !1,
                flagCheckin7: !1,
                flagad: !0
            }), e.updateChipsnum();
        }).catch(function(e) {
            t.globalData.hascheckin = !1, console.log(e);
        });
    },
    checkinnum: function(e) {
        switch (e) {
          case 1:
          default:
          case 2:
            return 5;

          case 3:
          case 4:
            return 10;

          case 5:
          case 6:
            return 15;

          case 7:
            return 25;
        }
    },
    updateChipsnum: function() {
        this.setData({
            chipsnum: t.globalData.chips || 0
        });
    },
    initVideo: function() {
        this.videoAd = null, wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
            adUnitId: "adunit-f884e6dd20689818"
        }), this.videoAd.onLoad(function() {
            console.log("hasVideo"), e.hasVideo = !0;
        }), this.videoAd.onError(function(a) {
            console.log("not hasVideo"), e.hasVideo = !1;
        }), this.videoAd.onClose(function(a) {
            wx.getSystemInfoSync().SDKVersion >= "2.1.0" ? a.isEnded ? (wx.aldstat.sendEvent("看完了视频 chips", "isEnded"), 
            e.getLottery()) : wx.showToast({
                title: "需要看完才能获得",
                icon: "none",
                duration: 2e3
            }) : e.getLottery();
        }));
    },
    bindGetUserInfo: function(e) {
        console.log(e), e && e.detail && e.detail.userInfo && t.updateUserInfo(e.detail.userInfo, this.setUserInfo.bind(this));
    },
    setUserInfo: function() {
        e.setData({
            userInfo: t.globalData.userInfo ? t.globalData.userInfo : null
        });
    },
    bindVideo: function() {
        t.globalData[e.videoday] >= 3 || (console.log("bindVideo"), e.seevideo = !0, e.videoAd && t.bindClick() && e.videoAd.show().catch(function() {
            e.videoAd.load().then(function() {
                return e.videoAd.show();
            }).catch(function(e) {
                console.log("激励视频 广告显示失败"), wx.showToast({
                    title: "暂无视频广告",
                    icon: "none",
                    duration: 2e3
                }), wx.aldstat.sendEvent("无视频广告 chips", "");
            });
        }));
    },
    loadData: function() {
        i.Query("_User").get(i.User.current().objectId).then(function(e) {
            console.log(e), t.globalData.chips = e.chips || 0, "function" == typeof cb && cb();
        }).catch(function(e) {
            console.log(e);
        });
    },
    getLottery: function() {
        t.incrementData("chips", 3, function() {
            t.globalData.chips || (t.globalData.chips = 0), t.globalData.chips += 3, e.updateChipsnum(), 
            wx.showToast({
                title: "获得3个皮肤碎片",
                icon: "success",
                duration: 2e3
            }), t.globalData[e.videoday] += 1, t.globalData[e.videoday] >= 5 && (t.globalData[e.videoday] = 5), 
            wx.setStorage({
                key: e.videoday,
                data: t.globalData[e.videoday]
            }), e.updateVideodaynum();
        });
    },
    onReady: function() {},
    getInviteId: function(e) {
        if (t.globalData.invite && t.globalData.invite.inviteid) i.Query("Invite").get(t.globalData.invite.inviteid).then(function(a) {
            var i = a.receivenum;
            i || (i = 0);
            var n = a.friends;
            n || (n = []), t.globalData.invite = {
                inviteid: a.objectId,
                receivenum: i,
                friends: n
            }, "function" == typeof e && e();
        }).catch(function(e) {
            console.log(e);
        }); else if (i.User.current()) {
            var a = i.Query("Invite"), n = i.Pointer("_User").set(i.User.current().objectId);
            a.equalTo("player", "==", n), a.find().then(function(a) {
                if (a && a.length > 0) {
                    var o = a[0], c = o.receivenum;
                    c || (c = 0);
                    var l = o.friends;
                    l || (l = []), t.globalData.invite = {
                        inviteid: o.objectId,
                        receivenum: c,
                        friends: l
                    }, "function" == typeof e && e();
                } else {
                    var s = i.Query("Invite");
                    s.set("player", n), s.save().then(function(a) {
                        console.log(a), t.globalData.invite = {
                            inviteid: a.objectId,
                            receivenum: 0,
                            friends: []
                        }, "function" == typeof e && e();
                    }).catch(function(e) {
                        console.log(e);
                    });
                }
            }).catch(function(e) {
                console.log(e);
            });
        }
    },
    onShow: function() {
        this.updateChipsnum();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return i.User.current() && t.globalData.invite && t.globalData.invite.inviteid ? {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/index/index?uid=" + i.User.current().objectId + "&inviteid=" + t.globalData.invite.inviteid,
            imageUrl: "../../images/share.jpg"
        } : {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/index/index",
            imageUrl: "../../images/share.jpg"
        };
    }
});