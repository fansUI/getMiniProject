require("../../utils/util.js");

var n, t = getApp(), o = t.globalData.Bmob;

Page({
    data: {},
    onLoad: function(o) {
        n = this, t.globalData.joins && t.globalData.joins.length > 0 && this.loadData();
    },
    formatTime: function() {},
    loadData: function() {
        var a = o.Query("Skin");
        a.containedIn("objectId", t.globalData.joins), a.find().then(function(t) {
            if (t && t.length > 0) {
                for (var o = [], a = [], e = 0; e < t.length; e++) t[e].time = t[e].time.iso.slice(0, 10), 
                t[e].over ? o.push(t[e]) : a.push(t[e]);
                n.setData({
                    overs: o,
                    notovers: a
                });
            }
        }).catch(function(n) {
            console.log(n);
        });
    },
    bindDetail: function(n) {
        console.log(n);
        var t = n.currentTarget.dataset.id;
        t || (t = n.target.dataset.id), t && wx.navigateTo({
            url: "/pages/detail/detail?id=" + t
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});