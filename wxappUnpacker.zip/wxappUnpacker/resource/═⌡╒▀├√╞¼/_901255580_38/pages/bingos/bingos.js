require("../../utils/util.js");

var n, o = getApp(), t = o.globalData.Bmob;

Page({
    data: {},
    onLoad: function(t) {
        n = this, o.globalData.bingos && o.globalData.bingos.length > 0 && this.loadData();
    },
    formatTime: function() {},
    loadData: function() {
        var a = t.Query("Skin");
        a.containedIn("objectId", o.globalData.bingos), a.find().then(function(o) {
            if (console.log(o), o && o.length > 0) {
                for (var t = 0; t < o.length; t++) o[t].time = o[t].time.iso.slice(0, 10);
                n.setData({
                    overs: o
                });
            }
        }).catch(function(n) {
            console.log(n);
        });
    },
    bindDetail: function(n) {
        console.log(n);
        var o = n.currentTarget.dataset.id;
        o || (o = n.target.dataset.id), o && wx.navigateTo({
            url: "/pages/detail/detail?id=" + o
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});