var o, a = getApp();

a.globalData.Bmob;

Page({
    data: {},
    onLoad: function(a) {
        o = this, this.drawCover(), this.initVideo();
    },
    initVideo: function() {
        this.videoAd = null, wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
            adUnitId: "adunit-242c5ba695e96525"
        }), this.videoAd.onLoad(function() {
            console.log("hasVideo"), o.hasVideo = !0;
        }), this.videoAd.onError(function(a) {
            console.log("not hasVideo"), o.hasVideo = !1;
        }), this.videoAd.onClose(function(a) {
            wx.getSystemInfoSync().SDKVersion >= "2.1.0" ? a.isEnded ? (wx.aldstat.sendEvent("看完了视频 wzzj", "isEnded"), 
            o.getLottery()) : wx.showToast({
                title: "需要看完才能下载",
                icon: "none",
                duration: 2e3
            }) : o.getLottery();
        }));
    },
    bindVideo: function() {
        console.log("bindVideo"), a.globalData.debug ? o.saveCanvas() : o.hassee ? o.saveCanvas() : o.videoAd && o.videoAd.show().catch(function() {
            o.videoAd.load().then(function() {
                return o.videoAd.show();
            }).catch(function(o) {
                console.log("激励视频 广告显示失败"), wx.showToast({
                    title: "暂无视频广告",
                    icon: "none",
                    duration: 2e3
                }), wx.aldstat.sendEvent("无视频广告 wzzj", JSON.stringify(o));
            });
        });
    },
    getLottery: function() {
        o.hassee = !0, o.saveCanvas();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    drawCover: function() {
        var o = wx.createCanvasContext("myCanvas");
        o.clearRect(0, 0, 1e3, 1200), o.drawImage(a.globalData.fileZj, 0, 0, 750 * a.globalData.rpx2px, 468.75 * a.globalData.rpx2px), 
        o.drawImage(a.globalData.fileAvatar, 12 / 1.237333 * a.globalData.rpx2px, 505 / 1.237333 * a.globalData.rpx2px, 66 / 1.237333 * a.globalData.rpx2px, 66 / 1.237333 * a.globalData.rpx2px), 
        o.drawImage("/images/mvp.png", 0, 483 / 1.237333 * a.globalData.rpx2px, 78 / 1.237333 * a.globalData.rpx2px, 46 / 1.237333 * a.globalData.rpx2px), 
        o.draw(!1, function() {
            console.log("draw success");
        });
    },
    saveCanvas: function() {
        wx.canvasToTempFilePath({
            canvasId: "myCanvas",
            success: function(o) {
                wx.saveImageToPhotosAlbum({
                    filePath: o.tempFilePath,
                    success: function(o) {
                        console.log(o), wx.aldstat.sendEvent("保存五连绝世", ""), wx.showToast({
                            title: "已保存到相册"
                        });
                    },
                    fail: function(o) {
                        console.log(o);
                    }
                });
            },
            fail: function(o) {
                console.log(o);
            }
        });
    }
});