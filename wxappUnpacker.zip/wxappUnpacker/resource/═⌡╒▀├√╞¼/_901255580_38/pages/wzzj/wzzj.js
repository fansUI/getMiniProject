var a, t = getApp(), o = t.globalData.Bmob;

Page({
    data: {
        wxname: !0,
        wxavatar: !0,
        nameValue: ""
    },
    onLoad: function(o) {
        a = this, t.globalData.wxavatar = !0, t.globalData.wxname = !0, o.id ? (a.id = o.id, 
        t.globalData.hasLogin ? this.loadData() : t.globalData.queue.push(this.loadData.bind(this))) : wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    loadData: function() {
        o.Query("Wzzj").get(a.id).then(function(o) {
            a.setData({
                hasLoad: !0,
                zj: o,
                userInfo: t.globalData.userInfo ? t.globalData.userInfo : null
            }), a.hasLoad = !0, t.globalData.userInfo || a.showModal("getuserinfo");
        }).catch(function(a) {
            console.log(a), wx.navigateBack({});
        });
    },
    bindNameInput: function(a) {
        this.setData({
            nameValue: a.detail.value
        }), t.globalData.wxnameValue = this.data.nameValue;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    bindWxName: function(a) {
        this.setData({
            wxname: a.detail.value
        }), t.globalData.wxname = this.data.wxname, t.globalData.wxname && (this.setData({
            nameValue: ""
        }), t.globalData.wxnameValue = "");
    },
    bindWxAvatar: function(a) {
        this.setData({
            wxavatar: a.detail.value
        }), t.globalData.wxavatar = this.data.wxname;
    },
    bindChooseImage: function() {
        wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album" ],
            success: function(o) {
                o.tempFilePaths && o.tempFilePaths.length > 0 && (a.setData({
                    avatar: o.tempFilePaths[0]
                }), t.globalData.fileAvatarBd = o.tempFilePaths[0]);
            }
        });
    },
    showModal: function(a) {
        this.setData({
            modalName: a
        });
    },
    hideModal: function() {
        this.setData({
            modalName: null
        });
    },
    updateUserInfo: function() {
        wx.showToast({
            title: "更新头像成功"
        }), a.setData({
            userInfo: t.globalData.userInfo ? t.globalData.userInfo : null
        });
    },
    bindGetUserInfo: function(o) {
        console.log(o), o && o.detail && o.detail.userInfo && t.updateUserInfo(o.detail.userInfo, function() {
            a.updateUserInfo(), a.hideModal();
        });
    },
    bindStart: function() {
        t.globalData.hasLogin ? t.globalData.userInfo ? this.data.wxname || "" != this.data.nameValue ? t.bindClick() && this.requestZj() : wx.showToast({
            title: "请输入玩家名称",
            icon: "loading"
        }) : a.showModal("getuserinfo") : wx.showToast({
            title: "还未登录",
            icon: "loading"
        });
    },
    requestZj: function() {
        wx.showToast({
            title: "正在赶来",
            icon: "loading",
            duration: 2e3
        });
        var e, n = new Date().getTime(), l = o.User.current().objectId + n + ".jpg";
        e = this.data.wxname ? t.globalData.userInfo.nickName : t.globalData.wxnameValue;
        var i = this.data.zj.bgname;
        wx.request({
            url: "https://www.bkbgame.com:5003?nickname=" + e + "&filename=" + l + "&bgname=" + i,
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                console.log(t), "200" == t.data && a.downloadZj(l, a.downloadAvatar);
            }
        });
    },
    g2wzzj2: function() {
        wx.navigateTo({
            url: "/pages/wzzj/wzzj2"
        });
    },
    downloadAvatar: function(o) {
        t.globalData.fileAvatar ? ("function" == typeof o && o(), a.g2wzzj2()) : wx.downloadFile({
            url: t.globalData.userInfo.avatarUrl,
            success: function(e) {
                console.log(e), 200 === e.statusCode && (t.globalData.fileAvatar = e.tempFilePath, 
                "function" == typeof o && o(), a.g2wzzj2());
            },
            fail: function(a) {}
        });
    },
    downloadZj: function(a, o) {
        wx.downloadFile({
            url: "https://www.bkbgame.com:5003/" + a,
            success: function(a) {
                console.log(a), 200 === a.statusCode && (t.globalData.fileZj = a.tempFilePath, "function" == typeof o && o());
            },
            fail: function(a) {}
        });
    }
});