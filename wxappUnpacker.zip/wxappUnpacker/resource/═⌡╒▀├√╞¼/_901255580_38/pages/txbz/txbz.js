var t, a = getApp(), o = a.globalData.Bmob, s = 0, i = 0, e = 0;

Page({
    data: {
        scrollH: 0,
        imgWidth: 0,
        loadingCount: 0,
        images: [],
        col1: [],
        col2: [],
        col3: [],
        TabCur: 0,
        TagCur: 0,
        scrollLeft: 0,
        professions: [ "战士", "刺客", "法师", "射手", "辅助" ],
        profession0: [ "曹操", "程咬金", "达摩", "典韦", "宫本武藏", "花木兰", "橘右京", "铠", "老夫子", "芈月", "哪吒", "孙策", "夏侯惇", "亚瑟", "狂铁", "关羽", "李信", "吕布", "苏烈", "曜" ],
        profession1: [ "阿轲", "百里玄策", "韩信", "兰陵王", "孙悟空", "赵云", "李白", "露娜", "娜可露露", "裴擒虎", "司马懿", "元歌", "云中君", "盘古" ],
        profession2: [ "安琪拉", "扁鹊", "不知火舞", "妲己", "貂蝉", "高渐离", "姜子牙", "墨子", "王昭君", "小乔", "甄姬", "周瑜", "女娲", "嫦娥", "干将莫邪", "米莱狄", "沈梦溪", "上官婉儿", "武则天", "杨玉环", "奕星", "嬴政", "张良", "诸葛亮" ],
        profession3: [ "百里守约", "狄仁杰", "伽罗", "公孙离", "后羿", "黄忠", "李元芳", "鲁班七号", "马可波罗", "孙尚香", "虞姬", "成吉思汗" ],
        profession4: [ "大乔", "刘禅", "牛魔", "孙膑", "太乙真人", "张飞", "庄周", "蔡文姬", "盾山", "鬼谷子", "明世隐", "瑶" ],
        datas: []
    },
    onLoad: function(a) {
        var o = this;
        t = this, this.setData({
            profession: this.data.profession0
        }), this.loadData(this.data["profession" + this.data.TabCur][this.data.TagCur]), 
        wx.getSystemInfo({
            success: function(t) {
                var a = .3 * t.windowWidth, s = t.windowHeight;
                o.setData({
                    scrollH: s,
                    imgWidth: a
                });
            }
        });
    },
    tabSelect: function(t) {
        this.data.TabCur != t.currentTarget.dataset.id && (this.setData({
            TabCur: t.currentTarget.dataset.id,
            TagCur: 0,
            scrollLeft: 60 * (t.currentTarget.dataset.id - 1),
            profession: this.data["profession" + t.currentTarget.dataset.id]
        }), this.loadData(this.data["profession" + this.data.TabCur][this.data.TagCur]));
    },
    tagSelect: function(t) {
        this.data.TagCur != t.currentTarget.dataset.id && (this.setData({
            TagCur: t.currentTarget.dataset.id
        }), this.loadData(this.data["profession" + this.data.TabCur][this.data.TagCur]));
    },
    loadData: function(a) {
        var s = this;
        if (this.data.datas[a]) t.results = this.data.datas[a], this.loadImages(); else {
            var i = this, e = o.Query("Image");
            e.equalTo("tags", "==", a), e.select("url", "file", "likes"), e.limit(100), e.find().then(function(o) {
                i.results = o, i.results && i.results.length > 0 && (s.data.datas[a] = t.results, 
                s.loadImages());
            }).catch(function(t) {
                console.log(t);
            });
        }
    },
    test: function() {
        wx.request({
            url: "https://www.bkbgame.com:5003?nickname=我爱罗一家人",
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                console.log(t);
            }
        });
    },
    download: function() {
        wx.showToast({
            title: "正在赶来",
            icon: "loading",
            duration: 2e3
        }), this.downloadAvatar(this.downloadZj.bind(this));
    },
    downloadAvatar: function(t) {
        a.globalData.fileAvatar ? "function" == typeof t && t() : wx.downloadFile({
            url: a.globalData.userInfo.avatarUrl,
            success: function(o) {
                console.log("downloadAvatar"), console.log(o), 200 === o.statusCode && (a.globalData.fileAvatar = o.tempFilePath, 
                "function" == typeof t && t());
            },
            fail: function(t) {}
        });
    },
    downloadZj: function(o) {
        wx.downloadFile({
            url: "https://www.bkbgame.com:5003/output3.jpg",
            success: function(s) {
                console.log("download zj"), console.log(s), 200 === s.statusCode && (a.globalData.fileZjs || (a.globalData.fileZjs = []), 
                a.globalData.fileZjs.xxx = s.tempFilePath, "function" == typeof o && o(), t.g2wzzj());
            },
            fail: function(t) {}
        });
    },
    g2wzzj: function() {
        wx.navigateTo({
            url: "/pages/wzzj/wzzj?id=" + t.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/index/index"
        };
    },
    onImageLoad: function(t) {
        for (var a = t.currentTarget.id, o = t.detail.width, n = t.detail.height * (this.data.imgWidth / o), l = this.data.images, d = null, r = 0; r < l.length; r++) {
            var u = l[r];
            if (u.id === a) {
                d = u;
                break;
            }
        }
        d.height = n;
        var c = this.data.loadingCount - 1, h = this.data.col1, g = this.data.col2, f = this.data.col3;
        s <= i && s <= e ? (s += n, h.push(d)) : i <= s && i <= e ? (i += n, g.push(d)) : (e += n, 
        f.push(d));
        var p = {
            loadingCount: c,
            col1: h,
            col2: g,
            col3: f
        };
        c || (p.images = []), this.setData(p);
    },
    loadImages2: function() {},
    loadImages: function() {
        for (var a = [], o = 0; o < t.results.length; o++) a.push({
            objectId: t.results[o].objectId,
            pic: t.results[o].file.url,
            height: 0,
            likes: t.results[o].likes
        });
        for (var s = "img-" + +new Date(), i = 0; i < a.length; i++) a[i].id = s + "-" + i;
        this.data.col1 = [], this.data.col2 = [], this.data.col3 = [], this.setData({
            loadingCount: a.length,
            images: a
        });
    },
    bindImage: function(t) {
        var a = t.currentTarget.dataset.item;
        a.likes || (a.likes = 0), wx.navigateTo({
            url: "/pages/txbz/txbz2?url=" + a.pic + "&id=" + a.objectId + "&likes=" + a.likes
        });
    }
});