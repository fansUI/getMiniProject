var t, i = getApp(), e = i.globalData.Bmob, a = "../../images/like.png", n = "../../images/like2.png";

Page({
    data: {},
    onLoad: function(e) {
        t = this, console.log(e), this.data.item = e;
        var s = i.getDianzanid();
        s && (-1 != s.indexOf(this.data.item.id) ? this.data.item.likesrc = n : this.data.item.likesrc = a), 
        this.data.item.likes || (this.data.item.likes = 0), this.data.item.likes = parseInt(this.data.item.likes), 
        e && e.url && e.id ? this.setData({
            item: this.data.item
        }) : wx.navigateBack({});
    },
    bindDownload: function() {
        console.log("bindDownload"), wx.showToast({
            title: "正在支援",
            icon: "loading",
            duration: 2e3
        }), wx.downloadFile({
            url: this.data.item.url,
            success: function(t) {
                console.log(t), 200 === t.statusCode && wx.saveImageToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function(t) {
                        console.log(t), wx.aldstat.sendEvent("保存头像壁纸", ""), wx.showToast({
                            title: "已保存到相册"
                        });
                    },
                    fail: function(t) {
                        console.log(t);
                    }
                });
            },
            fail: function(t) {}
        });
    },
    bindShare: function() {},
    bindLike: function() {
        var t = i.getDianzanid();
        if (t) {
            if (-1 != t.indexOf(this.data.item.id)) return console.log("点赞过"), void (this.data.item.likesrc == a && (this.data.item.likes = this.data.item.likes + 1, 
            this.data.item.likesrc = n, this.setData({
                item: this.data.item
            })));
            console.log("还没点赞过"), t.push(this.data.item.id), i.saveDianzanid(), this.data.item.likes = this.data.item.likes + 1, 
            this.data.item.likesrc = n, this.setData({
                item: this.data.item
            }), e.Query("Image").get(this.data.item.id).then(function(t) {
                t.increment("likes", 1), t.save(), "function" == typeof cb && cb();
            }).catch(function(t) {
                console.log(t);
            });
        }
    },
    onReady: function() {},
    bindPreview: function() {
        i.previewImage(this.data.item.url);
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/index/index"
        };
    }
});