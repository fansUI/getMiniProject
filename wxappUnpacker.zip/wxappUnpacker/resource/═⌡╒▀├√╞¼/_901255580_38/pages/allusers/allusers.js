var n, t = getApp(), o = t.globalData.Bmob;

Page({
    data: {
        users: []
    },
    onLoad: function(t) {
        n = this, t.id && (n.id = t.id, n.tablejoin = t.tablejoin || "Join"), n.id && (this.loadCount(), 
        this.loadJoins());
    },
    loadCount: function() {
        var t = o.Query(n.tablejoin);
        t.equalTo("skinid", "==", n.id), t.count().then(function(t) {
            console.log(t), n.setData({
                joinUserCount: t
            });
        });
    },
    loadJoins: function() {
        var t = this, a = o.Query(n.tablejoin);
        a.equalTo("skinid", "==", n.id), a.order("-createdAt"), a.select("avatarUrl"), a.limit(100), 
        n.lastdata && a.equalTo("createdAt", "<", n.lastdata), a.find().then(function(o) {
            o && o.length > 0 && (n.lastdata = o[o.length - 1].createdAt, t.setData({
                users: n.data.users.concat(o)
            }));
        }).catch(function(n) {
            console.log(n);
        });
    },
    loadJoins7: function() {
        o.Query(n.tablejoin).count().then(function(t) {
            console.log(t), n.setData({
                joinUserCount: t
            });
            var a = o.Query(n.tablejoin);
            a.equalTo("skinid", "==", n.id), a.order("-createdAt"), a.select("avatarUrl"), a.limit(7), 
            a.find().then(function(t) {
                t && t.length > 0 && n.setData({
                    users: t
                });
            }).catch(function(n) {
                console.log(n);
            });
        });
    },
    onReady: function() {},
    bindMore: function() {
        t.bindClick() && n.loadJoins();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});