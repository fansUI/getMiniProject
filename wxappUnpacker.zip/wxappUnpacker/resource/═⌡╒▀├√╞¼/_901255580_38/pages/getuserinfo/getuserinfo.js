var n = getApp();

Page({
    data: {},
    onLoad: function(n) {},
    bindGetUserInfo: function(o) {
        console.log(o), o && o.detail && o.detail.userInfo && n.updateUserInfo(o.detail.userInfo, function() {
            wx.navigateBack();
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});