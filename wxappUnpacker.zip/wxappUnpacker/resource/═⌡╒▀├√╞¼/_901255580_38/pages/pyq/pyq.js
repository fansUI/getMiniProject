var a, o = getApp();

o.globalData.Bmob;

Page({
    data: {},
    onLoad: function(o) {
        a = this, o.id && (a.id = o.id, this.drawCover());
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    drawCover: function() {
        var t = wx.createCanvasContext("myCanvas");
        t.clearRect(0, 0, 1e3, 1200), t.drawImage(o.globalData.fileEwms[a.id], 0, 0, 750 * o.globalData.rpx2px, 1100 * o.globalData.rpx2px), 
        t.save(), t.beginPath(), t.arc(375 * o.globalData.rpx2px, 100 * o.globalData.rpx2px, 50 * o.globalData.rpx2px, 0, 2 * Math.PI), 
        t.clip(), t.drawImage(o.globalData.fileAvatar, 325 * o.globalData.rpx2px, 50 * o.globalData.rpx2px, 100 * o.globalData.rpx2px, 100 * o.globalData.rpx2px), 
        t.restore(), t.setFontSize(23 * o.globalData.rpx2px), t.setFillStyle("#f1f1f1"), 
        t.setTextAlign("center"), t.fillText(o.globalData.userInfo.nickName, 375 * o.globalData.rpx2px, 180 * o.globalData.rpx2px), 
        t.draw(!1, function() {
            console.log("draw success");
        });
    },
    saveCanvas: function() {
        wx.canvasToTempFilePath({
            canvasId: "myCanvas",
            success: function(o) {
                wx.saveImageToPhotosAlbum({
                    filePath: o.tempFilePath,
                    success: function(o) {
                        console.log(o), wx.aldstat.sendEvent("保存朋友圈", a.id), wx.showToast({
                            title: "已保存到相册"
                        });
                    },
                    fail: function(a) {
                        console.log(a);
                    }
                });
            },
            fail: function(a) {
                console.log(a);
            }
        });
    }
});