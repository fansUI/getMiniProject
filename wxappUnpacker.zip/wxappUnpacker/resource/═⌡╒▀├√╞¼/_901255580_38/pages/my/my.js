require("../../utils/util.js");

var a, n = getApp(), o = n.globalData.Bmob;

Page({
    data: {},
    onLoad: function(n) {
        a = this;
    },
    bindJoinall: function() {
        n.globalData.joins && n.globalData.joins.length > 0 && wx.navigateTo({
            url: "/pages/joinall/joinall"
        });
    },
    bindBingos: function() {
        n.globalData.bingos && n.globalData.bingos.length > 0 && wx.navigateTo({
            url: "/pages/bingos/bingos"
        });
    },
    bindGetUserInfo: function(o) {
        console.log(o), o && o.detail && o.detail.userInfo && n.updateUserInfo(o.detail.userInfo, function() {
            a.updateUserInfo();
        });
    },
    updateUserInfo: function() {
        this.setData({
            avatarUrl: n.globalData.userInfo.avatarUrl,
            nickName: n.globalData.userInfo.nickName
        });
    },
    onReady: function() {},
    onShow: function() {
        n.globalData.userInfo && n.globalData.userInfo.avatarUrl ? this.setData({
            avatarUrl: n.globalData.userInfo.avatarUrl,
            nickName: n.globalData.userInfo.nickName
        }) : this.setData({
            avatarUrl: "../../images/wzmp/icon_lyf.png",
            nickName: "点我修改头像"
        }), this.setData({
            countall: n.globalData.joins ? n.globalData.joins.length : 0,
            countbingo: n.globalData.bingos ? n.globalData.bingos.length : 0,
            id: o.User.current() ? o.User.current().objectId : ""
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});