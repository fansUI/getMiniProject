var t, o = require("../../utils/util.js"), e = getApp(), a = e.globalData.Bmob;

Page({
    data: {
        state: 0,
        cardCur: 0
    },
    onLoad: function(a) {
        if (t = this, a.id) t.id = a.id; else if (a.scene) {
            var n = decodeURIComponent(a.scene).split("&");
            t.id = n[0];
        }
        t.id && (e.globalData.hasLogin ? this.loadData() : e.globalData.queue.push(this.loadData.bind(this))), 
        this.initVideo(), 1 == o.randomI(1, 2) && (this.flagcover = !0, this.initCover());
    },
    initCover: function() {
        this.interstitialAd = null, wx.createInterstitialAd && (this.interstitialAd = wx.createInterstitialAd({
            adUnitId: "adunit-1bcd42ef67a0edcb"
        }), this.interstitialAd.onLoad(function() {
            console.log("onLoad event emit");
        }), this.interstitialAd.onError(function(t) {
            console.log("onError event emit", t);
        }), this.interstitialAd.onClose(function(t) {
            console.log("onClose event emit", t);
        }));
    },
    showCover: function() {
        t.interstitialAd.show().catch(function(t) {
            console.error(t);
        });
    },
    handleContact: function(t) {
        console.log(t.path), console.log(t.query);
    },
    initVideo: function() {
        this.videoAd = null, wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
            adUnitId: "adunit-242c5ba695e96525"
        }), this.videoAd.onLoad(function() {
            console.log("hasVideo"), t.hasVideo = !0;
        }), this.videoAd.onError(function(o) {
            console.log("not hasVideo"), t.hasVideo = !1;
        }), this.videoAd.onClose(function(o) {
            wx.getSystemInfoSync().SDKVersion >= "2.1.0" ? o.isEnded ? (wx.aldstat.sendEvent("看完了视频 detail", "isEnded"), 
            t.getLottery(!0)) : wx.showToast({
                title: "需要看完才能参与",
                icon: "none",
                duration: 2e3
            }) : t.getLottery(!0);
        }));
    },
    loadData: function() {
        a.Query("Skin").get(t.id).then(function(a) {
            var n, i = new Date(a.time.iso.replace(/-/g, "/")), l = o.formatTime2(i), s = !1;
            -1 != e.globalData.joins.indexOf(t.id) && (s = !0), n = a.over ? 3 : s ? 2 : 1;
            var d, r;
            a.result && a.result.results ? (r = a.result.results, d = null) : (r = null, d = a.result), 
            t.setData({
                hasLoad: !0,
                skin: a,
                time: l,
                hasJoin: s,
                state: n,
                flagpyq: !!a.flagpyq,
                result: d || null,
                results: r || null,
                flagSwiper: !!a.swipers,
                swipers: a.swipers ? a.swipers : [],
                userInfo: e.globalData.userInfo ? e.globalData.userInfo : null,
                flagjoins: a.flagjoins
            }), t.hasLoad = !0, t.flagjoins = a.flagjoins, t.tablejoin = a.tablejoin || "Join", 
            t.loadJoins();
        }).catch(function(t) {
            console.log(t), wx.navigateBack({});
        });
    },
    bindGetUserInfo: function(t) {
        console.log(t), t && t.detail && t.detail.userInfo && e.updateUserInfo(t.detail.userInfo, this.setUserInfo.bind(this));
    },
    setUserInfo: function() {
        t.setData({
            userInfo: e.globalData.userInfo ? e.globalData.userInfo : null
        });
    },
    cardSwiper: function(t) {
        this.setData({
            cardCur: t.detail.current
        });
    },
    bindSwiper: function(t) {
        console.log(t);
        var o = t.target.dataset.id;
        o || (o = t.currentTarget.dataset.id), o && wx.navigateTo({
            url: "/pages/detail/detail?id=" + o
        });
    },
    bindsubmit: function(o) {
        o && o.detail && o.detail.formId && t.hasLoad && e.globalData.hasLogin && !t.formId && this.updateFormId(o.detail.formId);
    },
    updateFormId: function(o) {
        var n = new Date().getTime(), i = a.Query("FormId"), l = a.Pointer("_User").set(a.User.current().objectId);
        i.set("player", l), i.set("openid", e.globalData.openid), i.set("formid", o), i.set("t", n), 
        i.set("skinid", t.id), i.save().then(function(e) {
            t.formId = o;
        }).catch(function(t) {
            console.log(t);
        });
    },
    bindAllUsers: function() {
        t.hasLoad && wx.navigateTo({
            url: "/pages/allusers/allusers?id=" + t.id + "&tablejoin=" + t.tablejoin
        });
    },
    onReady: function() {},
    onShow: function() {
        console.log("onShow"), t.hasLoad && !t.seevideo && (t.seevideo = !1, this.loadJoins());
    },
    loadJoins: function() {
        if (t.flagjoins) {
            var o = a.Query(t.tablejoin);
            o.equalTo("skinid", "==", t.id), o.count().then(function(o) {
                t.setData({
                    joinUserCount: o
                });
                var e = a.Query(t.tablejoin);
                e.equalTo("skinid", "==", t.id), e.order("-createdAt"), e.select("avatarUrl"), e.limit(7), 
                e.find().then(function(o) {
                    o && o.length > 0 && t.setData({
                        users: o
                    });
                }).catch(function(t) {
                    console.log(t);
                });
            });
        }
    },
    bindAdd: function() {
        wx.setClipboardData({
            data: "1819816268",
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    showCancel: !1,
                    content: "复制成功，请在qq里面添加好友",
                    confirmText: "知道了",
                    confirmColor: "#e54d42"
                });
            }
        });
    },
    bindLottery: function() {
        if (console.log("bindLottery"), e.bindClick(1800)) {
            if (!t.hasLoad) return;
            e.globalData.hasLogin ? e.globalData.userInfo ? this.bindVideo() : wx.navigateTo({
                url: "/pages/getuserinfo/getuserinfo"
            }) : e.register(this.bindLottery.bind(this));
        }
    },
    bindVideo: function() {
        t.seevideo = !0, t.videoAd && t.videoAd.show().catch(function() {
            t.videoAd.load().then(function() {
                return t.videoAd.show();
            }).catch(function(o) {
                console.log("激励视频 广告显示失败"), t.flagGetLotteryFalse || t.getLottery(!1), wx.aldstat.sendEvent("无视频广告 detail", JSON.stringify(o));
            });
        });
    },
    getLottery: function(n) {
        n || (t.flagGetLotteryFalse = !0), a.Query("Skin").get(t.id).then(function(i) {
            var l = a.Relation("_User").add(a.User.current().objectId);
            i.increment("count"), i.set("players", l), i.save(), t.checkJoin(t.newJoin.bind(t)), 
            t.setData({
                hasJoin: !0,
                state: 2
            }), -1 == e.globalData.joins.indexOf(t.id) && (e.globalData.joins.push(t.id), e.updateData("joins", e.globalData.joins)), 
            n && t.setChipsnum(o.randomI(1, 4)), t.showModal("getchips");
        });
    },
    setChipsnum: function(t) {
        this.setData({
            chipsnum: t
        }), t && e.incrementData("chips", t, function() {
            e.globalData.chips || (e.globalData.chips = 0), e.globalData.chips += t;
        });
    },
    showModal: function(t) {
        this.setData({
            modalName: t
        });
    },
    hideModal: function() {
        this.setData({
            modalName: null
        }), t.flagcover && !t.flagcover2 && t.showCover();
    },
    checkJoin: function(o) {
        console.log("checkJoin");
        var e = a.Query(t.tablejoin);
        e.equalTo("skinid", "==", t.id), e.equalTo("playerid", "==", a.User.current().objectId), 
        e.find().then(function(t) {
            console.log("xxx"), console.log(t), t && t.length > 0 ? console.log("已经建了") : "function" == typeof o && o();
        }).catch(function(t) {
            console.log(t);
        });
    },
    newJoin: function() {
        console.log("newJoin");
        var o = a.Query(t.tablejoin), n = a.Pointer("_User").set(a.User.current().objectId);
        o.set("player", n), o.set("playerid", a.User.current().objectId);
        var i = a.Pointer("Skin").set(t.id);
        o.set("skin", i), o.set("skinid", t.id), o.set("nickname", e.globalData.userInfo.nickName), 
        o.set("avatarUrl", e.globalData.userInfo.avatarUrl), o.save().then(function(o) {
            console.log(o), t.joinid = o.objectId, t.loadJoins();
        }).catch(function(t) {
            console.log(t);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return t.joinid ? (t.flagcover2 = !0, {
            title: "点进来瓜分王者皮肤碎片礼包~",
            path: "/pages/index/index?joinid=" + t.joinid + "&tablejoin=" + t.tablejoin,
            imageUrl: t.data.skin.url2
        }) : {
            title: "抽个王者皮肤，手快有手慢无~",
            path: "/pages/detail/detail?id=" + t.id,
            imageUrl: t.data.skin.url2
        };
    },
    bindMore: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    bindPyq: function() {
        3 != this.data.state && 4 != this.data.state && t.data.skin.ewm && (wx.showToast({
            title: "正在赶来",
            icon: "loading",
            duration: 2e3
        }), this.downloadAvatar(this.downloadEwm.bind(this)));
    },
    downloadAvatar: function(t) {
        e.globalData.fileAvatar ? "function" == typeof t && t() : wx.downloadFile({
            url: e.globalData.userInfo.avatarUrl,
            success: function(o) {
                console.log("downloadAvatar"), console.log(o), 200 === o.statusCode && (e.globalData.fileAvatar = o.tempFilePath, 
                "function" == typeof t && t());
            },
            fail: function(t) {}
        });
    },
    downloadEwm: function(o) {
        e.globalData.fileEwms && e.globalData.fileEwms[t.id] ? ("function" == typeof o && o(), 
        t.g2pyq()) : wx.downloadFile({
            url: t.data.skin.ewm,
            success: function(a) {
                console.log("downloadEwm"), console.log(a), 200 === a.statusCode && (e.globalData.fileEwms || (e.globalData.fileEwms = []), 
                e.globalData.fileEwms[t.id] = a.tempFilePath, "function" == typeof o && o(), t.g2pyq());
            },
            fail: function(t) {}
        });
    },
    g2pyq: function() {
        wx.navigateTo({
            url: "/pages/pyq/pyq?id=" + t.id
        });
    },
    drawCover: function() {
        var o = wx.createCanvasContext("myCanvas");
        o.clearRect(0, 0, 1e3, 1200), o.drawImage(e.globalData.fileEwm, 0, 0, 750 * e.globalData.rpx2px, 1170 * e.globalData.rpx2px), 
        o.save(), o.beginPath(), o.arc(375 * e.globalData.rpx2px, 100 * e.globalData.rpx2px, 50 * e.globalData.rpx2px, 0, 2 * Math.PI), 
        o.clip(), o.drawImage(e.globalData.fileAvatar, 325 * e.globalData.rpx2px, 50 * e.globalData.rpx2px, 100 * e.globalData.rpx2px, 100 * e.globalData.rpx2px), 
        o.restore(), o.setFontSize(23 * e.globalData.rpx2px), o.setFillStyle("#f1f1f1"), 
        o.setTextAlign("center"), o.fillText(e.globalData.userInfo.nickName, 375 * e.globalData.rpx2px, 200 * e.globalData.rpx2px), 
        o.draw(!1, function() {
            setTimeout(function() {
                t.yyy();
            }, 200);
        });
    },
    yyy: function() {
        wx.canvasToTempFilePath({
            canvasId: "myCanvas",
            success: function(t) {
                e.previewImage(t.tempFilePath);
            },
            fail: function(t) {
                console.log(t);
            }
        });
    }
});