var t, a = getApp(), o = a.globalData.Bmob;

Page({
    data: {
        TabCur: 0,
        scrollLeft: 0,
        professions: [ "战士", "刺客", "法师", "射手", "辅助" ]
    },
    onLoad: function(a) {
        t = this, this.loadData(0);
    },
    tabSelect: function(t) {
        this.setData({
            TabCur: t.currentTarget.dataset.id,
            scrollLeft: 60 * (t.currentTarget.dataset.id - 1)
        }), this.loadData(this.data.TabCur);
    },
    loadData: function(a) {
        var n = this;
        if (console.log("set" + a), this.data["zjs" + a]) this.setData({
            zjs: this.data["zjs" + a]
        }); else {
            var e = this, s = o.Query("Wzzj");
            s.equalTo("show", "==", !0), s.equalTo("tag", "==", a), s.order("index"), s.select("url", "tag", "name", "bgname"), 
            s.limit(100), s.find().then(function(o) {
                e.results = o, e.results && e.results.length > 0 && (n.data["zjs" + a] = t.results, 
                e.setData({
                    zjs: t.results
                }));
            }).catch(function(t) {
                console.log(t);
            });
        }
    },
    bindDetail: function(t) {
        var a = t.currentTarget.dataset.id;
        a || (a = t.target.dataset.id), a && wx.navigateTo({
            url: "/pages/wzzj/wzzj?id=" + a
        });
    },
    test: function() {
        wx.request({
            url: "https://www.bkbgame.com:5003?nickname=我爱罗一家人",
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                console.log(t);
            }
        });
    },
    download: function() {
        wx.showToast({
            title: "正在赶来",
            icon: "loading",
            duration: 2e3
        }), this.downloadAvatar(this.downloadZj.bind(this));
    },
    downloadAvatar: function(t) {
        a.globalData.fileAvatar ? "function" == typeof t && t() : wx.downloadFile({
            url: a.globalData.userInfo.avatarUrl,
            success: function(o) {
                console.log("downloadAvatar"), console.log(o), 200 === o.statusCode && (a.globalData.fileAvatar = o.tempFilePath, 
                "function" == typeof t && t());
            },
            fail: function(t) {}
        });
    },
    downloadZj: function(o) {
        wx.downloadFile({
            url: "https://www.bkbgame.com:5003/output3.jpg",
            success: function(n) {
                console.log("download zj"), console.log(n), 200 === n.statusCode && (a.globalData.fileZjs || (a.globalData.fileZjs = []), 
                a.globalData.fileZjs.xxx = n.tempFilePath, "function" == typeof o && o(), t.g2wzzj());
            },
            fail: function(t) {}
        });
    },
    g2wzzj: function() {
        wx.navigateTo({
            url: "/pages/wzzj/wzzj?id=" + t.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});