	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};	var __vd_version_info__ = __vd_version_info__ || {};
		definePlugin("plugin://wxa75efa648b60994b", function(define, require, module, exports, global, wx, App, Page, Component, Behavior, getApp, getCurrentPages) {			
			/*v0.5vv_20190312_syb_scopedata*/global.__wcc_version__='v0.5vv_20190312_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx_wxa75efa648b60994b=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx_wxa75efa648b60994b:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b || [];
function gz$gwx_wxa75efa648b60994b_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_1)return __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_1
__WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'autoplay']])
Z([3,'__onTvpEnded'])
Z([3,'__onTvpError'])
Z([3,'__onTvpFullScreenChange'])
Z([3,'__onTvpPause'])
Z([3,'__onTvpPlay'])
Z([3,'__onTvpTimeupdate'])
Z([3,'player_video'])
Z([[2,'!'],[[7],[3,'tvpIsAd']]])
Z([[7],[3,'danmuBtn']])
Z([[7],[3,'danmuList']])
Z([[7],[3,'enableDanmu']])
Z([[2,'||'],[[7],[3,'isHiddenVideo']],[[2,'=='],[[7],[3,'tvpState']],[1,'error']]])
Z([[7],[3,'playerid']])
Z([[7],[3,'poster']])
Z([[7],[3,'showCenterPlayBtn']])
Z([[7],[3,'tvpUrl']])
})(__WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_1);return __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_1
}
function gz$gwx_wxa75efa648b60994b_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_2)return __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_2
__WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'autoplay']])
Z([3,'__onTvpEnded'])
Z([3,'__onTvpError'])
Z([3,'__onTvpFullScreenChange'])
Z([3,'__onTvpPause'])
Z([3,'__onTvpPlay'])
Z([3,'__onTvpTimeupdate'])
Z([3,'player_video'])
Z([[2,'!'],[[2,'==='],[[7],[3,'controls']],[1,false]]])
Z([[7],[3,'danmuBtn']])
Z([[7],[3,'danmuList']])
Z([[2,'?:'],[[2,'==='],[[7],[3,'direction']],[[2,'-'],[1,1]]],[1,90],[[7],[3,'direction']]])
Z([[7],[3,'enableDanmu']])
Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,false],[[7],[3,'enableProgressGesture']]])
Z([[2,'||'],[[7],[3,'isHiddenVideo']],[[2,'=='],[[7],[3,'tvpState']],[1,'error']]])
Z([[7],[3,'playerid']])
Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,0],[[7],[3,'initialTime']]])
Z([[7],[3,'loop']])
Z([[7],[3,'muted']])
Z([[7],[3,'objectFit']])
Z([[7],[3,'pageGesture']])
Z([[2,'?:'],[[7],[3,'usePoster']],[[2,'||'],[[7],[3,'poster']],[[2,'?:'],[[7],[3,'vid']],[[2,'+'],[[2,'+'],[1,'http://shp.qpic.cn/qqvideo/0/'],[[7],[3,'vid']]],[1,'/0']],[1,'']]],[1,'']])
Z([[7],[3,'showCenterPlayBtn']])
Z([[7],[3,'showFullscreenBtn']])
Z([[7],[3,'showPlayBtn']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'tvpIsAd']]],[[7],[3,'showProgress']]])
Z([[7],[3,'tvpUrl']])
Z([[7],[3,'title']])
Z([[2,'&&'],[[7],[3,'tvpIsAd']],[[2,'>'],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]]])
Z([3,'mod_skipad'])
Z([[2,'!'],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]])
Z(z[30])
Z([[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'tvpIsAd']]],[[7],[3,'fullscreen']]])
Z([[2,'!'],[[2,'!'],[[7],[3,'formats_selected']]]])
Z([[2,'&&'],[[7],[3,'fullscreen']],[[2,'||'],[[7],[3,'showHDSelector']],[[7],[3,'showBrightSelector']]]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[7],[3,'fullscreen']],[[7],[3,'showHDSelector']]],[[7],[3,'formats']]],[[6],[[7],[3,'formats']],[3,'length']]])
Z([[2,'&&'],[[7],[3,'fullscreen']],[[7],[3,'showBrightSelector']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_2);return __WXML_GLOBAL__.ops_cached.$gwx_wxa75efa648b60994b_2
}
__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b=z;
__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b=true;
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./component/live/live.wxml','./component/video/video.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_wxa75efa648b60994b_1()
var oB=_mz(z,'video',['autoplay',0,'bindended',1,'binderror',1,'bindfullscreenchange',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'danmuList',9,'enableDanmu',10,'hidden',11,'id',12,'poster',13,'showCenterPlayBtn',14,'src',15],[],e,s,gg)
var xC=_n('slot')
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_wxa75efa648b60994b_2()
var fE=_mz(z,'video',['autoplay',0,'bindended',1,'binderror',1,'bindfullscreenchange',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'danmuList',9,'direction',10,'enableDanmu',11,'enableProgressGesture',12,'hidden',13,'id',14,'initialTime',15,'loop',16,'muted',17,'objectFit',18,'pageGesture',19,'poster',20,'showCenterPlayBtn',21,'showFullscreenBtn',22,'showPlayBtn',23,'showProgress',24,'src',25,'title',26],[],e,s,gg)
var cF=_v()
_(fE,cF)
if(_oz(z,28,e,s,gg)){cF.wxVkey=1
var lK=_n('cover-view')
_rz(z,lK,'class',29,e,s,gg)
var aL=_v()
_(lK,aL)
if(_oz(z,30,e,s,gg)){aL.wxVkey=1
}
var tM=_v()
_(lK,tM)
if(_oz(z,31,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(lK,eN)
if(_oz(z,32,e,s,gg)){eN.wxVkey=1
}
aL.wxXCkey=1
tM.wxXCkey=1
eN.wxXCkey=1
_(cF,lK)
}
var hG=_v()
_(fE,hG)
if(_oz(z,33,e,s,gg)){hG.wxVkey=1
var bO=_v()
_(hG,bO)
if(_oz(z,34,e,s,gg)){bO.wxVkey=1
}
bO.wxXCkey=1
}
var oH=_v()
_(fE,oH)
if(_oz(z,35,e,s,gg)){oH.wxVkey=1
}
var cI=_v()
_(fE,cI)
if(_oz(z,36,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(fE,oJ)
if(_oz(z,37,e,s,gg)){oJ.wxVkey=1
}
var oP=_n('slot')
_(fE,oP)
cF.wxXCkey=1
hG.wxXCkey=1
oH.wxXCkey=1
cI.wxXCkey=1
oJ.wxXCkey=1
_(r,fE)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}

				global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.json'] = {"component":true};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.wxml'] = $gwx_wxa75efa648b60994b( './component/live/live.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.json'] = {"component":true};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.wxml'] = $gwx_wxa75efa648b60994b( './component/video/video.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.json'] = {
  "publicComponents": {
    "video": "component/video/video",
    "live": "component/live/live"
  },
  "main": "component/txv-context.js"
}
;
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.wxml'] = $gwx_wxa75efa648b60994b( './plugin.wxml' );
	
				define("component/live/data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../src/util/base64text");module.exports={tvpUrl:e,tvpIsAd:!1,tvpState:"",tvpVideoError:"",title:"",liveEndInfo:"",liveStatus:"",liveStartTime:"",getDataError:"",errCode:"",isBefore:!1,isAfter:!1,isHiddenContainer:!1,isHiddenVideo:!1,isHiddenWithVoice:!1}; 
 			}); 
		define("component/live/properties.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={pid:{type:String,value:"",observer:"onVideoChange"},sid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1},width:{type:String,value:""},height:{type:String,value:""},isHiddenStop:{type:Boolean,value:!1},isNeedMutex:{type:Boolean,value:!0},enableDanmu:{type:Boolean,value:!1},danmuBtn:{type:Boolean,value:!1},danmuList:{type:Array,value:[]},poster:{type:String,value:""},showCenterPlayBtn:{type:Boolean,value:!1},beforeText:{type:String,value:"直播未开始"},afterText:{type:String,value:"直播已结束"},isStopPoll:{type:Boolean,value:!1},extraParam:{type:Object,value:{}}}; 
 			}); 
		define("component/txv-context.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../src/module/log"),t=require("../src/module/reporter/index"),r=require("../src/lib/request"),n={},o="",s=Object.create({report:{on:function(e){"report"==e&&(t.off("report"),t.on.apply(t,arguments))},release:t.release,saveState:t.saveState,restoreState:t.restoreState,checkState:t.checkState},setRequest:function(e){r.busRequest=e}});module.exports=Object.assign(s,{getTxvContext:function(e){if(!n[e])throw new Error("找不到playerid为"+e+"的txv-video组件");return n[e]},existTxvContext:function(e){return!!n[e]},txvAttached:function(e,t){n[e]=t},txvDetached:function(e){delete n[e]},getAllContext:function(){return n},getLastPlayId:function(){return o},setLastPlayId:function(e){o=e},setTvpPlayState:function(e,t){this.getTxvContext(e).isPlaying=t},openLog:function(){e.isOpenLog=!0},closeLog:function(){e.isOpenLog=!1}}); 
 			}); 
		define("component/video/data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={progressBaseTime:0,progressSkipTime:0,progressTime:0,progressDuration:0,tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:"",reportUrl:"",isHiddenContainer:!1,isHiddenVideo:!1,fullscreen:!1,showHDSelector:!1,showBrightSelector:!1,showRateSelector:!1,showControlBtn:!1,bright:function(){for(var r=[],e=1;e<=8;e++)r.push({val:.125*e});return r}(),currentBright:0,isPlaying:!1,isIpx:!1}; 
 			}); 
		define("component/video/properties.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}var t;module.exports=(t={vid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:"",observer:"onPlayeridChange"},autoplay:{type:Boolean,value:!1},objectFit:{type:String,value:"contain"},poster:{type:String,value:""},showProgress:{type:Boolean,value:!0},controls:{type:Boolean,value:!0},initialTime:{type:Number,value:0},showFullscreenBtn:{type:Boolean,value:!0},showPlayBtn:{type:Boolean,value:!0},showCenterPlayBtn:{type:Boolean,value:!0},enableProgressGesture:{type:Boolean,value:!0},pageGesture:{type:Boolean,value:!1},muted:{type:Boolean,value:!1},loop:{type:Boolean,value:!1},direction:{type:Number,value:-1}},e(t,"controls",{type:Boolean,value:!0}),e(t,"width",{type:String,value:""}),e(t,"height",{type:String,value:""}),e(t,"usePoster",{type:Boolean,value:!0}),e(t,"isHiddenStop",{type:Boolean,value:!1}),e(t,"isNeedMutex",{type:Boolean,value:!0}),e(t,"enableDanmu",{type:Boolean,value:!1}),e(t,"danmuBtn",{type:Boolean,value:!1}),e(t,"danmuList",{type:Array,value:[]}),e(t,"videoInfo",{type:Object,value:{}}),e(t,"defn",{type:String,value:""}),e(t,"extraParam",{type:Object,value:{}}),e(t,"title",{type:String,value:""}),t); 
 			}); 
		define("conf.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={version:"2.0.3"}; 
 			}); 
		define("index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./src/video");module.exports=e; 
 			}); 
		define("lib-inject.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="./src/lib/es6-promise",r="./src/lib/request";try{var s=require("../tvp.js");e=s.Promise||e,r=s.request||r}catch(e){}module.exports={Promise:require(e),request:require(r).get,post:require(r).post}; 
 			}); 
		define("private-setting.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t={};module.exports={set:function(e,r){return t[e]=r,this},get:function(e){return t[e]}}; 
 			}); 
		define("src/classes/Content.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},i=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),n=require("../lib/message"),r=1;module.exports=function(){function o(e){var i=this;t(this,o),this.mockUpdate=0,this._urlIndex=0,Object.defineProperties(this,{_iretcode:{value:e.iretcode},_url:{value:e.url instanceof Array?e.url:[e.url]},_id:{value:r++},_duration:{value:e.duration},_filesize:{value:e.filesize},_charged:{value:e.charged},_preview:{value:e.preview},isad:{value:e.isad}}),(new n).assign(this);var u=null,a=null;this.on("play",function(){u=setTimeout(function(){i.emit("timeout",1e4)},1e4),a=setTimeout(function(){i.emit("timeout",2e4)},2e4)},!0),this.on("start",function(){clearTimeout(u),clearTimeout(a)},!0)}return i(o,[{key:"url",get:function(){return this._url[this._urlIndex]}},{key:"id",get:function(){return this._id}},{key:"duration",get:function(){return this._duration}},{key:"filesize",get:function(){return this._filesize}},{key:"preview",get:function(){return this._preview}},{key:"charged",get:function(){return this._charged}},{key:"iretcode",get:function(){return this._iretcode}}]),i(o,[{key:"onContentEnd",value:function(){this.emit("end")}},{key:"onContentPlay",value:function(){this.emittedPlay=!0,this.emit("play")}},{key:"onContentPause",value:function(){this.emit("pause")}},{key:"onContentTimeupdate",value:function(t){this.emittedPlay&&(t&&t.target&&(t=t.detail.currentTime),!this.emittedStart&&((void 0===t?"undefined":e(t))==e(void 0)?this.mockUpdate++>5:t>0)&&(this.emit("start"),this.emittedStart=!0),this.emit.apply(this,["timeupdate",t]))}},{key:"onContentError",value:function(){if(this._url.length>this._urlIndex+1)return this._urlIndex++,void this.emit("change",this.url);this.emit.apply(this,["error"].concat([].slice.call(arguments,0)))}},{key:"onContentSkip",value:function(){this.isad&&this.emit("skip")}}]),o}(); 
 			}); 
		define("src/classes/Controller.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t){var e={};return(t instanceof Array?t:[].slice.call(arguments,0)).forEach(function(t){var n=t.initialize;Object.defineProperty(e,t.name,{get:function(){return n},set:function(e){var r=n;n=e,t.onChange&&t.onChange(e,r)}})}),e}var n=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),r=require("../lib/message"),o=require("../../lib-inject").Promise;module.exports=function(){function i(){for(var n=this,a=arguments.length,s=Array(a),c=0;c<a;c++)s[c]=arguments[c];t(this,i),this.started=o.defer(),(new r).assign(this);var u=this.model=new e([{name:"state",onChange:function(t,e){n.emit("statechange",t,e)},initialize:"loading"},{name:"currentContent",initialize:null}]);Object.defineProperties(this,{currentContent:{get:function(){return u.currentContent}},state:{get:function(){return u.state}}}),this.flow=this.createFlow.apply(this,s),this.flow.catch(function(t){n.emit("error",t)}),["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(t){n["onContent"+t]=function(){for(var e=arguments.length,r=Array(e),o=0;o<e;o++)r[o]=arguments[o];n.emit.apply(n,["content"+t.toLowerCase()].concat(r))},n["on"+t]=function(){console.warn("不建议再使用video.on"+t+"，请使用onContent"+t),this["onContent"+t].apply(this,arguments)}})}return n(i,[{key:"createFlow",value:function(){}},{key:"start",value:function(){return console.log("process start"),this.started.resolve(),this}},{key:"stop",value:function(){return this.started.reject(),this.flow&&this.flow.stop&&this.flow.stop(),this.off(),this}}]),i}(); 
 			}); 
		define("src/classes/State.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(){}var n=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),r=require("../lib/message"),s=require("../../lib-inject").Promise;module.exports=function(){function a(n,s){e(this,a),this.destroyed=!1;var i=Object.keys(n);i.forEach(function(e){!(n[e].to instanceof Array)&&(n[e].to=[]),!("function"==typeof n[e].beforeLeave)&&(n[e].beforeLeave=t),!("function"==typeof n[e].beforeEnter)&&(n[e].beforeEnter=t),!("function"==typeof n[e].afterLeave)&&(n[e].afterLeave=t),!("function"==typeof n[e].afterEnter)&&(n[e].afterEnter=t)}),this.message=new r,this.states=n,this._state=i[0],this._laststate="",Object.defineProperties(this,{state:{get:function(){return this._state}},lastState:{get:function(){return this._laststate}}})}return n(a,null,[{key:"create",value:function(e,t){return new a(e,t)}}]),n(a,[{key:"setState",value:function(e,t){var n=(t=t||{}).force||!1,r=t.silent||!1,s=this.states;if(n||~s[this._state].to.indexOf(e)){var a=this._state;if(r)this._laststate=this._state,this._state=e;else{var i=!1;if(n||(i=!1===s[a].beforeLeave(e),i=!1===s[e].beforeEnter(a)||!0===i),i)return;this._laststate=this._state,this._state=e,this.message.emit("change",e,a),s[a].afterLeave(e),s[e].afterEnter(a)}return 0==s[e].to.length&&(this.message.emit("end",e),this.message.off()),this}}},{key:"getStatePromise",value:function(e){var t=this;if("function"!=typeof e){var n=e;e=function(e){return e==n}}return new s(function(n,r){var s=t.message.on("change",function(t){e(t)&&(s(),n())});t.message.on("end",function(e){s(),r(new Error("state ended:"+e))},!0)})}},{key:"onChange",value:function(e){return this.message.on("change",e),this}}]),a}(); 
 			}); 
		define("src/controller-live/flow-getinfo/err-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={4444:"网络错误",3333:"播放出错"};module.exports={PLAY_ERROR:1,errCode:e,genCode:function(e,r){return"63"+(1==r?104:200)+"."+e},genError:function(r){var n=new Error(r.msg||e[r.em]),o=1==r.scene;return n.code=o?"P.0":"G."+r.em,n.em=r.em,n.fullecode=this.genCode(r.em,o?0:1),n}}; 
 			}); 
		define("src/controller-live/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../util/platform-config").APP_PLATFORM,r=require("../../../lib-inject").request,t=require("../../lib/algorithm/qvsec"),i=require("../../module/network"),n=require("../../lib/algorithm/fillTimeStamp"),o=require("../../../lib-inject").Promise,u=require("../../module/log")("live-info"),c=require("./err-code"),f=require("../../module/guid");module.exports=function(l,q,m,d){function s(r){return"https://info.zb.video.qq.com/?host=qq.com&cmd=2&qq=0&guid="+f+"&appVer=7&stream=2&ip=&system=1&sdtfrom="+e[m]+"&livepid="+q+"&cnlid="+l+"&_rnd="+v+"&"+h+"&newnettype="+r.networkCode+(d?"&defn="+d+"&fntick="+r.fntick:"")}function a(){return p=s({fntick:Date.now(),networkCode:b}),r(p,{needlogin:!0})}var v=n(),g=t["v4138"==m?"$xxzb":"$xxzbf"](e[m],l,1,1,v),h="";g&&(h="encver="+("v4138"==m?"201":"301")+"&_qv_rmtv2="+g);var p,b=0;return new o(function(e){i(function(r){b=r,e()})}).then(a).catch(function(e){return u("first request error",e),a()}).catch(function(){throw c.genError({em:4444})}).then(function(e){return u("getinfo result:",e),e})}; 
 			}); 
		define("src/controller-live/flow-getinfo/live-detail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").request;module.exports=function(t){return e("https://access.video.qq.com/tinyapp/live_detail?vappid=49109510&vsecret=c1202d7f3ba41f86cdd2d3d1082605b4ed764c21e29520f3&pid="+t)}; 
 			}); 
		define("src/controller-live/flow-getinfo/live-poll.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").request;module.exports=function(t){return e("https://zbaccess.video.qq.com/fcgi/live_poll?vappid=31678259&vsecret=1e029a67beb2d7e7e7bb8321fb161a46fe76c7837beb2cee",{data:t})}; 
 			}); 
		define("src/controller-live/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function r(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}var n=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),o=function e(t,r,n){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,r);if(void 0===o){var i=Object.getPrototypeOf(t);return null===i?void 0:e(i,r,n)}if("value"in o)return o.value;var u=o.get;if(void 0!==u)return u.call(n)},i=require("./flow-getinfo/index"),u=require("../classes/Controller"),a=require("../classes/Content"),c=require("./reporter"),f=require("../lib/message"),l=require("../lib/es6-promise"),p=require("../module/gen-guid"),s=require("./flow-getinfo/err-code"),d=require("../util/platform-config").APP_PLATFORM,y=function(y){function m(){return e(this,m),t(this,(m.__proto__||Object.getPrototypeOf(m)).apply(this,arguments))}return r(m,u),n(m,[{key:"createFlow",value:function(e,t){var r=this,n=e.sid,o=e.from,u=e.pid,y=(e.defn,t.getReportParam);var m,v=null,g=!1,h=p();c.setSeq(0);var w=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=Date.now();return i(n,u,o,e.defn||"").then(function(e){v&&v.off(),v=new a({url:e.data.playurl,iretcode:e.data.iretcode}),r.emit("contentchange",{currentContent:v,getinforaw:e}),m&&m.off(),m=new f,c.initPlay(m,{playno:h,platform:d[o],url:v.url,iretcode:v.iretcode,sid:n,pid:u},y),c.report({firstload:Date.now()-t,cmd:205})}).then(function(){return new l(function(e,t){!g&&v.on("start",function(){m.emit("videoplaying",v),g=!0},!0),v.on("start",function(){m.emit("videostart",v)}),v.on("play",function(){m.emit("videoplay",v)}),v.on("pause",function(){m.emit("videopause",v)}),v.on("timeupdate",function(e){m.emit("videotimeupdate",e)}),v.on("error",function(e){var r=s.genError({msg:e?e.detail&&e.detail.errMsg||e.message:"",em:3333,scene:s.PLAY_ERROR});t(r)},!0),v.on("end",e,!0),v.on("timeout",function(e){m.emit("videotimeout",e)})})}).catch(function(e){c.error(e),r.emit("error",e),console.log("err",e)})},b=w();return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(e){r.on("content"+e.toLowerCase(),function(t){for(var r=arguments.length,n=Array(r>1?r-1:0),o=1;o<r;o++)n[o-1]=arguments[o];v&&v["onContent"+e].apply(v,n)})}),this.switchDefn=function(e){w({defn:e})},b}},{key:"stop",value:function(){o(m.prototype.__proto__||Object.getPrototypeOf(m.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),m}();module.exports=function(e,t){return new y(e,t)}; 
 			}); 
		define("src/controller-live/reporter-play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,r){var i=e.sid||r.sid||"",t={guid:o,fplayerver:d,BossId:p,Pwd:l,prog:i,livepid:e.pid||"",viewid:i.slice(0,-2),_dc:Math.random(),devtype:m,playertype:a};return y.forEach(function(o){t[o]=r[o]||e[o]||""}),t}var r=require("../module/reporter/report-queue"),o=require("../module/guid"),i=require("../module/system-info")(),t=require("../module/network"),n=require("../module/account"),c=require("../../conf"),s=n.getAccountInfoSync(),d=s&&s.plugin&&s.plugin.version||c.version,u=i.system.match(/ios/i),p=7433,l=1230624807,a=0,f={"6g":6,"5g":5,"4g":4,"3g":3,"2g":2,wifi:1,"有线":100,0:0},m=0;switch(i.platform){case"devtools":m=u?3:2;break;case"android":m=2;break;case"ios":m=3;break;case"ipad":m=4}var y=["playno","hc_qq","sdtfrom","firstload","blocktime","block","prd","errcode","dsip","durl","firstreport","sUrl","sRef","viewid","seq","cmd","fullecode","live_type","geturltime","playtime","ispay","isuserpay","switch","lookback","freetype","https","cdn","vip_type","hc_pvid","login_type","open_id"];module.exports=function(o,i){i(function(i,n){!i&&n||(n={});var c=e(o,n);(n.networkCode?function(e){e&&e(f[n.networkCode])}:t)(function(e){Object.assign(c,{nettype:e}),console.log("report obj",c),r.push({reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(c).map(function(e){return e in c?e+"="+encodeURIComponent(c[e]):""}).filter(function(e){return e}).join("&")})},f)})}; 
 			}); 
		define("src/controller-live/reporter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function n(n){if(!n)return{};var e=n.url||(n.durl=n.url),o=t.queryParse(e),i=e.match(/\/\/([^/]+?)\//),r=/^https:/.test(e),c="0.0.0.0";i&&i[1]&&(c=(i[1]||"").split(":")[0]);var a={dsip:c,sdtfrom:o.sdtfrom,cdn:u[o.cdn]||0,https:r?1:0};return Object.assign(a,n)}var e=require("./reporter-play"),t=require("../lib/url"),o=void 0,i=void 0,r=0,u={zijian:1,lanxun:2,wangsu:3,dilian:4,akama:5,tongxin:6};module.exports={initPlay:function(e,t,u){i=u,(o=n(t)).seq=r,e.on("videoplay",function(n){}),e.on("videoplaying",function(n){}),e.on("videopause",function(){}),e.on("videotimeupdate",function(n){console.log("time",n)}),e.on("videotimeout",function(n){}),e.on("terminate",function(){}),e.on("end",function(){})},report:function(n){e(Object.assign(n,o),i),r++},error:function(n){this.report({cmd:150,errcode:n.em,fullecode:n.fullecode})},setSeq:function(n){r=n}}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){s(r,{header:{Cookie:"appuser="+l+"; Lturn="+d}}).then(function(r){v("上报成功"),v(r)},function(e){v("上报失败"),v(e),r=r+"&appuesr="+l,q.emit("report",{reportUrl:r}),v("用message抛出上报事件")})}function e(){d=c.get("Lturn"),v("Lturn:"+d),d?v("Lturn+1:"+(d+=1)):(d=Math.floor(1e3*Math.random()),v("create Lturn:"+d)),d>999&&(d=0),c.set("Lturn",d,72e5)}function t(r){var e=[];return r.item.forEach(function(r,t){e.push(r)}),e}function i(r){v("开始检查trueview贴片状态");for(var e=r.length,t=[],i=0,p=0;p<e;p++)r[p].trueviewTurn=!1,1==r[p].order_id||"FT"==r[p].type?t[p]=0:(o(r[p])&&(r[p].trueviewTurn=!0),t[p]=1,i+=1);a=1==i,v("trueviewCheckArr内容是："+t+",trueviewCount值是："+i)}function o(r){if(v("开始检查trueview开关"),r.params&&void 0!=r.params&&""!=r.params){var e=r.params;if(-1!=e.indexOf("richdata=")){var t=e.substr(e.indexOf("richdata=")+9);-1!=t.indexOf("&")&&(t=t.substr(0,t.indexOf("&"))),t=decodeURIComponent(t.replace(/\+/g," ")),v("转换出来的richdata参数是："+t);try{var i=JSON.parse(t);if(v("转换成json后的对象是："+i),i.plugins&&void 0!=i.plugins&&i.plugins.trueview&&void 0!=i.plugins.trueview&&"Y"==i.plugins.trueview)return v("trueview开关是打开的Y！"),!0}catch(r){v("richdata解析出错！")}}}return!1}function p(r){y=0;for(var e=0;e<r.length;e++)1!=r[e].order_id&&(y+=r[e].duration/1e3);v("广告总时长为："+y)}var a,n,d,l,u,s=require("../../../../lib-inject").request,h=require("../../../lib/message"),c=require("../../../module/cache"),v=require("../../../module/log")("ad"),m=require("./adReport"),U=require("./md5"),f=require("../../../../private-setting"),g="",D=0,w="",L=0,T=-1,O=1,S=-1,y=0,K="",R="",q=new h;(module.exports=function(o){v(o),o.vid&&(g=o.vid),o.live&&(D=o.live),o.chid&&(L=o.chid),o.coverid&&(w=o.coverid),o.pu&&(T=o.pu),o.openid&&(R=o.openid),l=String(U(R).substr(0,16)).toUpperCase(),e();var h={};return n=(new Date).getTime(),s("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+D+"&pu="+T+"&rfid="+K+"&openid="+R+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+L+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+g+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&"+(1===f.get("adstyle")?"style=1":"")+"&coverid="+w,{needlogin:!0,header:{Cookie:"appuser="+l+"; Lturn="+d}}).then(function(r){u=r,r.data.adLoc&&r.data.adLoc.tpid&&(O=r.data.adLoc.tpid),h={t:"0",url:"",vid:g,coverid:w,pf:"H5",vptag:"",pid:"",chid:L,tpid:O};var e=(new Date).getTime()-n;v("livew请求完成，进行dp3上报,时间为:"+e),m.reportDp3(2,"WL",e,1,100,0,R,h),n=(new Date).getTime();var o=t(r.data.adList);return v("最终adList:"+o),i(o),p(o),o},function(r){v("livew error，再试一次");var e=(new Date).getTime()-n;return v("livew请求失败，进行dp3上报,时间为:"+e),m.reportDp3(2,"WL",e,1,202,0,R,h),n=(new Date).getTime(),s("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+D+"&pu="+T+"&rfid="+K+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+L+"&openid="+R+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+g+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&coverid="+w,{needlogin:!0,header:{Cookie:"appuser="+l+"; Lturn="+d}}).then(function(r){u=r,r.data.adLoc&&r.data.adLoc.tpid&&(O=r.data.adLoc.tpid),h={t:"0",url:"",vid:g,coverid:w,pf:"H5",vptag:"",pid:"",chid:L,tpid:O};var e=(new Date).getTime()-n;v("livew重试请求完成，进行dp3上报,时间为:"+e),m.reportDp3(2,"WL",e,1,100,0,R,h),n=(new Date).getTime();var o=t(r.data.adList);return v("最终adList:"+o),i(o),p(o),o},function(r){var e=(new Date).getTime()-n;return v("livew error，订单获取失败，返回空数组，进行dp3上报,时间为:"+e),m.reportDp3(2,"WL",e,1,202,0,R,h),n=(new Date).getTime(),[]})}).then(function(e){return e=e.map(function(e,t){return function(){var t=[];if(e.reportUrlOther.reportitem)for(o=0;o<e.reportUrlOther.reportitem.length;o++)t[o]={url:e.reportUrlOther.reportitem[o].url,time:e.reportUrlOther.reportitem[o].reporttime,isReported:!1};var i=[];if(e.reportUrlSDK.reportitem)for(var o=0;o<e.reportUrlSDK.reportitem.length;o++)i[o]={url:e.reportUrlSDK.reportitem[o].url,time:e.reportUrlSDK.reportitem[o].reporttime,isReported:!1};return v("当前广告的trueview开关是否打开："+e.trueviewTurn),v("当前广告是否符合trueview条件："+a),a?(v("allAdDuration:"+y),S=y<=5?0:5):S=-1,v("skipable:"+S),{oid:e.order_id,url:e.image[0].url,reportUrl:{url:e.reportUrl,time:e.ReportTime,isReported:!1},reportUrlOther:t,reportUrlSDK:i,skipable:S,duration:e.duration/1e3,allDuration:y,onSkip:function(){v("当前广告被跳过了，上报智慧点10237"),m.reportWisdomPoint(10237,e.order_id,e.order_id,"");var r=(new Date).getTime()-n;v("当前广告被跳过，进行dp3上报,时间为:"+r),m.reportDp3(4,"WL",r,1,"",0,R,h),n=(new Date).getTime()},onTimeupdate:function(r){},onEnd:function(){var r=(new Date).getTime()-n;v("当前广告播放结束，进行dp3上报,时间为:"+r),m.reportDp3(5,"WL",r,1,"",0,R,h),n=(new Date).getTime(),u.data.adLoc&&u.data.adLoc.rfid&&(K=u.data.adLoc.rfid,v("rfid赋值成功："+K))},onStart:function(){v("当前广告开始播放"+e),v("当前广告的oid是："+this.oid);var t=(new Date).getTime()-n;if(v("素材加载完成，开始播放，进行dp3上报,时间为:"+t),m.reportDp3(3,"WL",t,1,"",0,R,h),n=(new Date).getTime(),this.reportUrl.url=m.updateUrlParam(this.reportUrl.url,h),this.reportUrl.time>=0&&!this.reportUrl.isReported){this.reportUrl.isReported=!0;try{r(this.reportUrl.url)}catch(r){}}for(i=0;i<this.reportUrlOther.length;i++)if(this.reportUrlOther[i].url=m.updateUrlParam(this.reportUrlOther[i].url,h),this.reportUrlOther[i].time>=0&&!this.reportUrlOther[i].isReported){this.reportUrlOther[i].isReported=!0;try{m.pingUrl(this.reportUrlOther[i].url)}catch(r){}}for(var i=0;i<this.reportUrlSDK.length;i++)if(this.reportUrlSDK[i].url=m.updateUrlParam(this.reportUrlSDK[i].url,h),this.reportUrlSDK[i].time>=0&&!this.reportUrlSDK[i].isReported){this.reportUrlSDK[i].isReported=!0;try{m.pingUrl(this.reportUrlSDK[i].url)}catch(r){}}},onError:function(){var r=(new Date).getTime()-n;v("当前广告播放出错，进行dp3上报,时间为:"+r),m.reportDp3(4,"WL",r,1,"",0,R,h),n=(new Date).getTime()},onReportEmpty:function(){v("我是空单上报，当前广告的上报地址是："+this.reportUrl.url),this.reportUrl.url=m.updateUrlParam(this.reportUrl.url,h);try{r(this.reportUrl.url)}catch(r){}for(e=0;e<this.reportUrlOther.length;e++)if(this.reportUrlOther[e].url=m.updateUrlParam(this.reportUrlOther[e].url,h),this.reportUrlOther[e].time>=0&&!this.reportUrlOther[e].isReported){this.reportUrlOther[e].isReported=!0;try{m.pingUrl(this.reportUrlOther[e].url)}catch(r){}}for(var e=0;e<this.reportUrlSDK.length;e++)if(this.reportUrlSDK[e].url=m.updateUrlParam(this.reportUrlSDK[e].url,h),this.reportUrlSDK[e].time>=0&&!this.reportUrlSDK[e].isReported){this.reportUrlSDK[e].isReported=!0;try{m.pingUrl(this.reportUrlSDK[e].url)}catch(r){}}}}}}),{adList:e}}).catch(function(r){return{}})}).reporter=m.reporter; 
 			}); 
		define("src/controller-video/flow-getinfo/data/adReport.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){var t=r.indexOf("?"),e=new Object,i=r;if(t>=0)for(var n,o=(i=i.substr(t+1)).split("&"),a=0;a<o.length;a++)(n=o[a].split("=")).length>1?e[n[0]]=n[1]:e[n[0]]="null";return e}var t=require("../../../lib/message"),e=(require("../../../module/cache"),require("../../../module/log")("ad-report")),i=new t;(module.exports={updateUrlParam:function(t,e){try{var i=r(t),n=t,o=!0;if(-1!=t.indexOf("?")){n=t.substring(0,t.indexOf("?"));var a;for(a in e)i[a]=e[a];for(a in i)o?(o=!1,n+="?"+a+"="+i[a]):n+="&"+a+"="+i[a]}}catch(r){n=""}return n},reportDp3:function(r,t,i,n,o,a,p,d){e("开始dp3上报");var s="https://dp3.qq.com/stdlog/?bid=weixin&step="+r+"&merged="+n+"&errorcode="+o+"&trycount="+a+"&openid="+p;s=this.updateUrlParam(s,d);try{this.pingUrl(s)}catch(r){e("dp3上报失败")}},reportWisdomPoint:function(r,t,i,n){e("开始智慧点上报");var o="https://t.l.qq.com?t=s&actid="+r;o+="&oid="+t+"&mid="+i+"&locid="+n;try{this.pingUrl(o)}catch(r){}},pingUrl:function(r,t,n,o){e("ping上报地址："+r);var a=(new Date).getTime();r=this.updateUrlParam(r,{reportTime:a}),i.emit("report",{reportUrl:r}),e("用message抛出上报事件")}}).reporter=i; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo-status.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={};e[10001]=e[50]=e[68]=e[71]=e[73]=e[74]=e[76]=e[77]=e[445]=e[444]="啊哦，没能找到你要的节目信息~",e[51]=e[52]=e[64]=e[61]=e[62]=e[63]=e[65]=e[66]=e[69]=e[81]=e[82]=e[84]=e[86]="啊哦，本来在这儿的视频不见了~",e[94]="经检测您当前登录的账号存在安全问题，为保障您的账号安全，已暂停了您的会员权益。",e[80]=e[83]="啊哦，版权原因，该视频暂时无法播放~",module.exports=e; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,m,d,s,v){if(v&&v.vl&&v.fl)return c.resolve(v);t=m,d=d||"auto";var y=u(),h=i["v4138"==m?"$xx":"$xxf"](p[m],e,t,1,y),g="";h&&(g="encver="+("v4138"==m?2:300)+"&_qv_rmtv2="+h),l("getinfo waiting");var b=0,q="";return c.resolve().then(function(){return s.onBeforeGetinfo(e)}).then(function(e){q="object"==(void 0===e?"undefined":r(e))?e:{},(q=Object.keys(q).map(function(e,t){return-1!=["auth_from","auth_ext","defnpayver","spvideo","spaudio"].indexOf(e)?e+"="+q[e]:""}).filter(function(e){return e}).join("&"))&&(q="&"+q),console.log("getinfo beforeGetinfoParam",q)}).then(function(){return new c(function(e,t){f(function(t){b=t,e()})})}).then(function(){l("request start");var t="https://h5vv.video.qq.com/getinfo?"+g+"&defn="+d+"&platform="+p[m]+"&otype=json&sdtfrom="+m+"&_rnd="+y+"&appVer=7&"+(a?"dtype=3&":"")+"vid="+e+"&newnettype="+b+q;return o(t,{needlogin:!0,needLoginCase:!0})}).catch(function(t){return o("https://bkvv.video.qq.com/getinfo?"+g+"&defn="+d+"&platform="+p[m]+"&otype=json&sdtfrom="+m+"&_rnd="+y+"&appVer=7&"+(a?"dtype=3&":"")+"vid="+e+"&newnettype="+b+q,{needlogin:!0,needLoginCase:!0})}).catch(function(){var e=new Error(n[444]);throw e.em=444,e.code="G.444",e}).then(function(e){return e=e.data,l("getinfo result:",e),e})}var t,r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},n=require("./getinfo-status"),o=require("../../../../lib-inject").request,i=require("../../../lib/algorithm/qvsec"),u=require("../../../lib/algorithm/fillTimeStamp"),f=require("../../../module/network"),l=require("../../../module/log")("getInfo"),c=require("../../../../lib-inject").Promise,a="devtools"!=wx.getSystemInfoSync().platform,p=require("../../../util/platform-config").APP_PLATFORM;module.exports=function(){return e.apply(this,arguments).then(function(e){if(e.em){var t=new Error(n[e.em]||e.msg);throw t.em=e.em,t.code="G."+e.em,t}return e}).then(function(e){var r=e.vl.vi[0],n={duration:+r.td,dltype:e.dltype,fmid:e.fl.fi.filter(function(e){return+e.sl})[0].id,filesize:e.fl.fi.filter(function(e){return+e.sl})[0].fs,preview:e.preview,charge:r.ch,raw:e};return r.ch<1&&(n.preview=e.preview,n.charged=r.ch),3==e.dltype?(n.url=r.ul.ui.map(function(e){return e.hls.pt?e.url+e.hls.pt+"&platform="+p[t]+"&sdtfrom="+t:""}),n.url=n.url.filter(function(e){return e})):n.url=r.ul.ui.map(function(e){return e.url+r.fn+"?vkey="+r.fvkey+"&br="+r.br+"&fmt=auto&level="+r.level+"&platform="+p[t]+"&sdtfrom="+t}),n})}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(n){return typeof n}:function(n){return n&&"function"==typeof Symbol&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n};!function(t){function r(n,t){var r=(65535&n)+(65535&t);return(n>>16)+(t>>16)+(r>>16)<<16|65535&r}function o(n,t){return n<<t|n>>>32-t}function e(n,t,e,u,f,c){return r(o(r(r(t,n),r(u,c)),f),e)}function u(n,t,r,o,u,f,c){return e(t&r|~t&o,n,t,u,f,c)}function f(n,t,r,o,u,f,c){return e(t&o|r&~o,n,t,u,f,c)}function c(n,t,r,o,u,f,c){return e(t^r^o,n,t,u,f,c)}function i(n,t,r,o,u,f,c){return e(r^(t|~o),n,t,u,f,c)}function d(n,t){n[t>>5]|=128<<t%32,n[14+(t+64>>>9<<4)]=t;var o,e,d,l,a,h=1732584193,m=-271733879,y=-1732584194,p=271733878;for(o=0;o<n.length;o+=16)e=h,d=m,l=y,a=p,m=i(m=i(m=i(m=i(m=c(m=c(m=c(m=c(m=f(m=f(m=f(m=f(m=u(m=u(m=u(m=u(m,y=u(y,p=u(p,h=u(h,m,y,p,n[o],7,-680876936),m,y,n[o+1],12,-389564586),h,m,n[o+2],17,606105819),p,h,n[o+3],22,-1044525330),y=u(y,p=u(p,h=u(h,m,y,p,n[o+4],7,-176418897),m,y,n[o+5],12,1200080426),h,m,n[o+6],17,-1473231341),p,h,n[o+7],22,-45705983),y=u(y,p=u(p,h=u(h,m,y,p,n[o+8],7,1770035416),m,y,n[o+9],12,-1958414417),h,m,n[o+10],17,-42063),p,h,n[o+11],22,-1990404162),y=u(y,p=u(p,h=u(h,m,y,p,n[o+12],7,1804603682),m,y,n[o+13],12,-40341101),h,m,n[o+14],17,-1502002290),p,h,n[o+15],22,1236535329),y=f(y,p=f(p,h=f(h,m,y,p,n[o+1],5,-165796510),m,y,n[o+6],9,-1069501632),h,m,n[o+11],14,643717713),p,h,n[o],20,-373897302),y=f(y,p=f(p,h=f(h,m,y,p,n[o+5],5,-701558691),m,y,n[o+10],9,38016083),h,m,n[o+15],14,-660478335),p,h,n[o+4],20,-405537848),y=f(y,p=f(p,h=f(h,m,y,p,n[o+9],5,568446438),m,y,n[o+14],9,-1019803690),h,m,n[o+3],14,-187363961),p,h,n[o+8],20,1163531501),y=f(y,p=f(p,h=f(h,m,y,p,n[o+13],5,-1444681467),m,y,n[o+2],9,-51403784),h,m,n[o+7],14,1735328473),p,h,n[o+12],20,-1926607734),y=c(y,p=c(p,h=c(h,m,y,p,n[o+5],4,-378558),m,y,n[o+8],11,-2022574463),h,m,n[o+11],16,1839030562),p,h,n[o+14],23,-35309556),y=c(y,p=c(p,h=c(h,m,y,p,n[o+1],4,-1530992060),m,y,n[o+4],11,1272893353),h,m,n[o+7],16,-155497632),p,h,n[o+10],23,-1094730640),y=c(y,p=c(p,h=c(h,m,y,p,n[o+13],4,681279174),m,y,n[o],11,-358537222),h,m,n[o+3],16,-722521979),p,h,n[o+6],23,76029189),y=c(y,p=c(p,h=c(h,m,y,p,n[o+9],4,-640364487),m,y,n[o+12],11,-421815835),h,m,n[o+15],16,530742520),p,h,n[o+2],23,-995338651),y=i(y,p=i(p,h=i(h,m,y,p,n[o],6,-198630844),m,y,n[o+7],10,1126891415),h,m,n[o+14],15,-1416354905),p,h,n[o+5],21,-57434055),y=i(y,p=i(p,h=i(h,m,y,p,n[o+12],6,1700485571),m,y,n[o+3],10,-1894986606),h,m,n[o+10],15,-1051523),p,h,n[o+1],21,-2054922799),y=i(y,p=i(p,h=i(h,m,y,p,n[o+8],6,1873313359),m,y,n[o+15],10,-30611744),h,m,n[o+6],15,-1560198380),p,h,n[o+13],21,1309151649),y=i(y,p=i(p,h=i(h,m,y,p,n[o+4],6,-145523070),m,y,n[o+11],10,-1120210379),h,m,n[o+2],15,718787259),p,h,n[o+9],21,-343485551),h=r(h,e),m=r(m,d),y=r(y,l),p=r(p,a);return[h,m,y,p]}function l(n){var t,r="",o=32*n.length;for(t=0;t<o;t+=8)r+=String.fromCharCode(n[t>>5]>>>t%32&255);return r}function a(n){var t,r=[];for(r[(n.length>>2)-1]=void 0,t=0;t<r.length;t+=1)r[t]=0;var o=8*n.length;for(t=0;t<o;t+=8)r[t>>5]|=(255&n.charCodeAt(t/8))<<t%32;return r}function h(n){return l(d(a(n),8*n.length))}function m(n,t){var r,o,e=a(n),u=[],f=[];for(u[15]=f[15]=void 0,e.length>16&&(e=d(e,8*n.length)),r=0;r<16;r+=1)u[r]=909522486^e[r],f[r]=1549556828^e[r];return o=d(u.concat(a(t)),512+8*t.length),l(d(f.concat(o),640))}function y(n){var t,r,o="";for(r=0;r<n.length;r+=1)t=n.charCodeAt(r),o+="0123456789abcdef".charAt(t>>>4&15)+"0123456789abcdef".charAt(15&t);return o}function p(n){return unescape(encodeURIComponent(n))}function g(n){return h(p(n))}function v(n){return y(g(n))}function b(n,t){return m(p(n),p(t))}function s(n,t){return y(b(n,t))}function S(n,t,r){return t?r?b(t,n):s(t,n):r?g(n):v(n)}"function"==typeof define&&define.amd?define(function(){return S}):"object"===("undefined"==typeof module?"undefined":n(module))&&module.exports?module.exports=S:t.md5=S}(void 0); 
 			}); 
		define("src/controller-video/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e){e=e||"";var n=t.test(e);if(n)return n;var r="";return e.replace(f,function(e,n){r=n}),/qq\.com/.test(r)}var n=require("../../../lib-inject").Promise,r=require("./data/ad"),i=require("./data/getinfo"),o=require("../../module/account"),t=/\/\/[^/]*?qq\.com/,f=/\/\/[^/]+?\/([^/]+?)\//;module.exports=function(t,f){var u=(t=t||{}).vid,d=t.cid,c=t.from,a=t.openid,v=t.defn,l=t.videoInfo||{},s=t.chid,q="function"==typeof f.onBeforeGetinfo?f.onBeforeGetinfo:function(){},m=([u,c,v].join("/"),o.isInner()),p=o.canUse(),h=p&&m;if(l.hasOwnProperty("url")&&(h||!p&&e(l.url))){var B=l.vecDefn;return B&&B.length&&(l.fmid=B.filter(function(e){return e.selected})[0].id),n.resolve({videoinfo:l,ad:{}})}if((h||!p)&&l.vl&&l.fl)return i(u,c,v,{onBeforeGetinfo:q},l).then(function(e){return{videoinfo:e,ad:{}}});var G=1===t.scene&&(h||!p&&t.qwer);return n.all([G?n.resolve({}):r({coverid:d,vid:u,live:0,chid:s||41,pu:1,openid:a||""}),i(u,c,v,{onBeforeGetinfo:q})]).then(function(e){return{ad:e[0],videoinfo:e[1]}})}; 
 			}); 
		define("src/controller-video/flow-play/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n=require("../../../lib-inject").Promise,e=require("../../lib/message"),t=require("../../classes/Content"),i=require("../../module/log")("flow-getinfo");module.exports=function(o,r,u){var a={time:0,duration:0,skipable:!1},c={},f={},d=[],s=n.defer(),l=s.promise,p=new e,m=null,v=function(n){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t={currentContent:n=n||m,preloadContents:d.filter(function(e){return!f[e.id]&&e!=n}),extra:e,getinforaw:g.raw};n&&n.isad&&(t.progress=a),m=n,u(t)},h=o.ad,g=o.videoinfo,w=!1;(h.adList||[]).forEach(function(e){var o=e(),r=new t({url:o.url,duration:o.duration,isad:!0}),u=new n(function(n){w||(r.on("end",function(){n(),o.onEnd()},!0),r.on("error",function(){n(),o.onError()},!0),r.on("timeout",function(){n(),o.onError()},!0),r.on("skip",function(){w=!0,n(),o.onSkip()},!0),r.on("start",function(){p.emit("adplaying",r),o.onStart()},!0),r.on("timeupdate",function(n){o.onTimeupdate(n)},!0),p.on("_terminate",function(){n()}))}).then(function(n){return f[r.id]=!0,n});c[r.id]=r,d.push(r),a.duration+=o.duration,a.skipable=o.skipable,l=l.then(function(){return i("playflow: ad."+o.url),"1"==o.oid?(i("这是一个空单，往下走"),void o.onReportEmpty()):(v(r),u.then(function(n){a.time+=r.duration}))})});var y=new t({url:g.url,duration:g.duration,filesize:g.filesize,isad:!1,preview:g.preview,charged:g.charged});c[y.id]=y,d.unshift(y);var E=new n(function(n,e){function t(t){!i&&t.on("start",function(){p.emit("videoplaying",t),i=!0},!0),t.on("start",function(){p.emit("videostart",t)}),t.on("play",function(){p.emit("videoplay",t)}),t.on("pause",function(){p.emit("videopause",t)}),t.on("timeupdate",function(n){p.emit("videotimeupdate",n,g.duration)}),t.on("error",function(n){var t=new Error(n?n.detail&&n.detail.errMsg||n.message:"播放出错");t.code="P.0",e(t)},!0),t.on("end",n,!0),t.on("timeout",function(n){p.emit("videotimeout",n)})}var i=!1;t(y),p.on("_terminate",function(){n()}),p.on("_changevideocontent",function(n){y.off(),f[y.id]=!0,d.every(function(e,t){return e!=y||(d.splice(t,1,n),!1)}),t(n),m==y?v(n):v(null,{isPlayingAd:!0}),c[n.id]=n,y=n})}).then(function(n){return f[y.id]=!0,n});l=l.then(function(){return y.off("change"),y.on("change",function(){v(y)}),p.on("_changevideocontent",function(n){y.off("change"),n.on("change",function(){v(n)})}),v(y),E}).then(function(){p.emit("end")}).catch(function(n){throw p.emit("error",n),n}),v(null);var k={progress:l,stop:function(){return p.emit("_terminate"),p.emit("terminate"),Object.keys(c).forEach(function(n){c[n].off()}),p.off(),this},start:function(){return s.resolve(),l},on:function(){return p.on.apply(p,arguments)},switchVideo:function(n){var e=n.videoinfo;g=e;var i=new t({url:e.url,duration:e.duration,filesize:e.filesize,isad:!1,preview:e.preview,charged:e.charged});p.emit("_changevideocontent",i)}};return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(n){r.on("content"+n.toLowerCase(),function(e){for(var t=e&&c[e]?c[e]:m,i=arguments.length,o=Array(i>1?i-1:0),r=1;r<i;r++)o[r-1]=arguments[r];t&&t["onContent"+n].apply(t,o)})}),k}; 
 			}); 
		define("src/controller-video/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function r(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}var n=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),o=function e(t,r,n){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,r);if(void 0===o){var i=Object.getPrototypeOf(t);return null===i?void 0:e(i,r,n)}if("value"in o)return o.value;var u=o.get;if(void 0!==u)return u.call(n)},i=require("../../lib-inject").Promise,u=require("./flow-getinfo/index"),a=require("./flow-play/index"),c=require("./reporter"),f=require("../module/reporter/index"),l=require("../classes/Controller"),p=require("../module/log")("controller-video-index");require("./flow-getinfo/data/ad").reporter.on("report",function(e){p("url",e),f.any(e)});var s=function(f){function p(){return e(this,p),t(this,(p.__proto__||Object.getPrototypeOf(p)).apply(this,arguments))}return r(p,l),n(p,[{key:"createFlow",value:function(e,t){var r=this;e=e||{},t=t||{};var n=e,o=n.vid,f=n.from,l=n.cid,p=n.defn,s=n.qwer,d=n.scene,y=n.videoInfo,h=t.getReportParam,v=new i(function(e){h?h(function(t,r){e(r&&r.hc_openid||"")}):e("")}),w=c({cid:l,vid:o},{getReportParam:h}),m=this.model,b=v.then(function(e){return u({vid:o,from:f,cid:l,openid:e,defn:p,qwer:s,scene:d,videoInfo:y},t)}).then(function(e){m.state="ready";var t=r.playflow=a(e,r,function(e){m.currentContent=e.currentContent,r.emit("contentchange",e)});return w.setPlayFlow(t),w.setVideoInfo(e.videoinfo),t.on("videotimeupdate",function(){for(var e=arguments.length,t=Array(e),n=0;n<e;n++)t[n]=arguments[n];r.emit.apply(r,["videotimeupdate"].concat(t))}),t.on("videostart",function(){for(var e=arguments.length,t=Array(e),n=0;n<e;n++)t[n]=arguments[n];r.emit.apply(r,["videostart"].concat(t))}),r.started.promise}).then(function(){return m.state="playing",r.playflow.start()}).then(function(e){m.state="ended"}).catch(function(e){throw m.state="error",r.playflow&&r.playflow.stop(),w.error(e),e});return this.switchDefn=function(e){return v.then(function(r){return u({vid:o,from:f,cid:l,openid:r,defn:e},t)}).then(function(e){r.playflow.switchVideo(e)})},b}},{key:"stop",value:function(){this.model.state="ended",o(p.prototype.__proto__||Object.getPrototypeOf(p.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),p}();module.exports=function(e,t){return new s(e,t)}; 
 			}); 
		define("src/controller-video/report-play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},o=require("./../module/reporter/report-queue"),t=require("../../conf"),n=wx.getSystemInfoSync();module.exports=function(r){var i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},c=arguments[2],p=arguments[3];c(function(c,a){c&&(a={}),delete(a=a||{}).val1,delete a.val2,delete a.val3,"object"==e(a[r])&&(["val1","val2","val3"].forEach(function(e){a[e]=a[r][e]}),delete a[r]),(a.isReportNetwork?wx.getNetworkType:function(e){e&&e.success({})})({success:function(e){var c={BossId:4327,Pwd:944465292,app_version:t.version,platform:n.platform,client_model:n.model,wx_version:n.version,network:e&&e.networkType?e.networkType:"",step:r,page_url:a.pageName||"",page_query:a.pageQuery||"",page_ref:a.refName||""};["hc_vuserid","hc_openid","hc_appid","ptag","iformat","duration","defn","tpay","adid","playtime","page_url","page_query","page_ref","cid","vid","isvip","val1","val2","val3","appname","nick","rmd","scene","additional","videourl"].forEach(function(e){e in i&&(c[e]=i[e]),e in a&&(c[e]=a[e]),void 0==c[e]&&(c[e]="")}),p&&"function"==typeof p?p(null,{reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(c).map(function(e){return e in c?e+"="+encodeURIComponent(c[e]):""}).filter(function(e){return e}).join("&")}):o.push({reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(c).map(function(e){return e in c?e+"="+encodeURIComponent(c[e]):""}).filter(function(e){return e}).join("&")})}})})}; 
 			}); 
		define("src/controller-video/reporter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e){return{1:1,2:1,10001:4,10002:3,10003:2,10201:4,10202:3,10203:2,100001:2,320089:2,320091:3,320092:4,320093:5}[e]}var n=require("./report-play"),o=require("../module/reporter/index"),t=require("../util/index").Oncer,r=[5,30];module.exports=function(i,a){function u(){return{iformat:d&&d.dltype?d.dltype:0,duration:d&&d.duration?Math.floor(d.duration):"",defn:d&&d.fmid?e(d.fmid):"",playtime:s+(l?Date.now()-l:0),vid:c||"",cid:v||""}}var l,c=i.vid,v=i.cid,f=a.getReportParam||function(e){return e({})},d=null,p=0,s=0,m=!1,w=!1,y=t(function(e){var o=u();o.val1=0,o.val2=0,o.val3=e,o.videourl=e,n(7,o,f)}),D=t(function(e){var o=u();o.val1=p?Date.now()-p:0,o.val2=m?0:1,o.val3=e,o.videourl=e,n(6,o,f)}),h=t(function(e,o){var t=u();t.val1=p?Date.now()-p:0,t.val2={error:3,complete:1,incomplete:w?2:0}[e],void 0==t.val2&&(t.val2=2),t.val3=o,n(5,t,f)}),g=null,C=t(function(e,t){o.reportCache.del("step30");var r=u();r.val1=e,r.val2=t,n(30,r,f)}),q=function(e,t){if(1e4==e){g=setTimeout(function(){C(e)},11e3);var r=u();r.val1=e,r.val2=t,n(30,r,f,function(e,n){o.reportCache.set("step30",n)})}else clearTimeout(g),C(e)};return n(3,u(),f),o.on("_save",function(){var e=u();e.val1=p?Date.now()-p:0,e.val2=w?2:0,n(5,e,f,function(e,n){o.reportCache.set("step5",n)})}),o.on("_restore",function(){r.forEach(function(e){o.reportCache.del("step"+e)})}),{setPlayFlow:t(function(e){e.on("adplaying",function(e){m=!0,y(e.url)}),e.on("videoplay",function(e){!p&&(p=Date.now()),l=Date.now()}),e.on("videoplaying",function(e){w=!0,D(e.url),q(p?Date.now()-p:0,0)}),e.on("videopause",function(){s+=Date.now()-l,l=0}),e.on("videotimeout",function(e){q(e,1)}),e.on("terminate",function(){h("incomplete")}),e.on("end",function(){h("complete")}),e.on("error",function(e){h("error","1 "+(e.code||"")+" "+e.message)})}),setVideoInfo:t(function(e){d=e}),error:function(e){h("error","2 "+(e.code||"")+" "+e.message)}}}; 
 			}); 
		define("src/lib/algorithm/fillTimeStamp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(r){r=r||10;var t=parseInt(+new Date)+"";if(t.length===r)return t;if(t.length>r)return t.substring(0,r);for(var e=r-t.length;e>0;)t="0"+t,e--;return t}; 
 			}); 
		define("src/lib/algorithm/qvsec.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var r={};r.ha=function(r){function t(r,t){return((r>>1)+(t>>1)<<1)+(1&r)+(1&t)}for(var e=[],n=0;n<64;)e[n]=0|4294967296*Math.abs(Math.sin(++n));return function(r){for(var n,a,o,u,c=[],h=decodeURIComponent(encodeURI(r)),f=h.length,i=[n=1732584193,a=-271733879,~n,~a],d=0;d<=f;)c[d>>2]|=(h.charCodeAt(d)||128)<<d++%4*8;for(c[r=16*(f+8>>6)+14]=8*f,d=0;d<r;d+=16){for(f=i,u=0;u<64;)f=[o=f[3],t(n=f[1],(o=t(t(f[0],[n&(a=f[2])|~n&o,o&n|~o&a,n^a^o,a^(n|~o)][f=u>>4]),t(e[u],c[[u,5*u+1,3*u+5,7*u][f]%16+d])))<<(f=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21][4*f+u++%4])|o>>>32-f),n,a];for(u=4;u;)i[--u]=t(i[u],f[u])}for(r="";u<32;)r+=(i[u>>3]>>4*(1^7&u++)&15).toString(16);return r}}(),r.stringToHex=function(r){for(var t="",e=new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"),n=0;n<r.length;n++)t+=e[r.charCodeAt(n)>>4]+e[15&r.charCodeAt(n)];return t},r.hexToString=function(r){for(var t="",e="0x"==r.substr(0,2)?2:0;e<r.length;e+=2)t+=String.fromCharCode(parseInt(r.substr(e,2),16));return t},r._Seed="#$#@#*ad",r.tempcalc=function(r,t){for(var e="",n=0;n<r.length;n++)e+=String.fromCharCode(r.charCodeAt(n)^t.charCodeAt(n%4));return e},r.u1=function(r,t){for(var e="",n=t;n<r.length;n+=2)e+=r.charAt(n);return e},r._urlStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",r.urlenc=function(t,e,n){for(var a,o,u,c,h,f,i,d="",s=0;s<t.length;)a=t.charCodeAt(s++),o=t.charCodeAt(s++),u=t.charCodeAt(s++),15==s&&(d+="A",d+=e,d+=n),c=a>>2,h=(3&a)<<4|o>>4,f=(15&o)<<2|u>>6,i=63&u,isNaN(o)?f=i=64:isNaN(u)&&(i=64),d=d+r._urlStr.charAt(c)+r._urlStr.charAt(h)+r._urlStr.charAt(f)+r._urlStr.charAt(i);return d},r.$xx=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+e+o+r._Seed+n+"heherand")},r.$xxzb=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+"tmp123"+t+"#$$&c2*KA"+o)},r.$xxf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+"ques"+o+"*&%$(SD!L}"+e+n)},r.$xxzbf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+o+"*#016"+t+"zput")},module.exports=r; 
 			}); 
		define("src/lib/es6-promise.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};!function(e,n){"object"===("undefined"==typeof exports?"undefined":t(exports))&&"undefined"!=typeof module?module.exports=n():"function"==typeof define&&define.amd?define(n):e.ES6Promise=n()}(void 0,function(){function e(e){return"function"==typeof e||"object"===(void 0===e?"undefined":t(e))&&null!==e}function n(t){return"function"==typeof t}function r(){return void 0!==D?function(){D(i)}:o()}function o(){var t=setTimeout;return function(){return t(i,1)}}function i(){for(var t=0;t<F;t+=2)(0,G[t])(G[t+1]),G[t]=void 0,G[t+1]=void 0;F=0}function s(t,e){var n=arguments,r=this,o=new this.constructor(c);void 0===o[I]&&x(o);var i=r._state;return i?function(){var t=n[i-1];L(function(){return j(i,o,t,r._result)})}():w(r,o,t,e),o}function u(e){var n=this;if(e&&"object"===(void 0===e?"undefined":t(e))&&e.constructor===n)return e;var r=new n(c);return _(r,e),r}function c(){}function f(){return new TypeError("You cannot resolve a promise with itself")}function a(){return new TypeError("A promises callback cannot return that same promise.")}function l(t){try{return t.then}catch(t){return V.error=t,V}}function h(t,e,n,r){try{t.call(e,n,r)}catch(t){return t}}function p(t,e,n){L(function(t){var r=!1,o=h(n,e,function(n){r||(r=!0,e!==n?_(t,n):m(t,n))},function(e){r||(r=!0,b(t,e))},"Settle: "+(t._label||" unknown promise"));!r&&o&&(r=!0,b(t,o))},t)}function d(t,e){e._state===Q?m(t,e._result):e._state===R?b(t,e._result):w(e,void 0,function(e){return _(t,e)},function(e){return b(t,e)})}function v(t,e,r){e.constructor===t.constructor&&r===s&&e.constructor.resolve===u?d(t,e):r===V?b(t,V.error):void 0===r?m(t,e):n(r)?p(t,e,r):m(t,e)}function _(t,n){t===n?b(t,f()):e(n)?v(t,n,l(n)):m(t,n)}function y(t){t._onerror&&t._onerror(t._result),g(t)}function m(t,e){t._state===J&&(t._result=e,t._state=Q,0!==t._subscribers.length&&L(g,t))}function b(t,e){t._state===J&&(t._state=R,t._result=e,L(y,t))}function w(t,e,n,r){var o=t._subscribers,i=o.length;t._onerror=null,o[i]=e,o[i+Q]=n,o[i+R]=r,0===i&&t._state&&L(g,t)}function g(t){var e=t._subscribers,n=t._state;if(0!==e.length){for(var r=void 0,o=void 0,i=t._result,s=0;s<e.length;s+=3)r=e[s],o=e[s+n],r?j(n,r,o,i):o(i);t._subscribers.length=0}}function A(){this.error=null}function S(t,e){try{return t(e)}catch(t){return X.error=t,X}}function j(t,e,r,o){var i=n(r),s=void 0,u=void 0,c=void 0,f=void 0;if(i){if((s=S(r,o))===X?(f=!0,u=s.error,s=null):c=!0,e===s)return void b(e,a())}else s=o,c=!0;e._state!==J||(i&&c?_(e,s):f?b(e,u):t===Q?m(e,s):t===R&&b(e,s))}function E(t,e){try{e(function(e){_(t,e)},function(e){b(t,e)})}catch(e){b(t,e)}}function T(){return Z++}function x(t){t[I]=Z++,t._state=void 0,t._result=void 0,t._subscribers=[]}function M(t,e){this._instanceConstructor=t,this.promise=new t(c),this.promise[I]||x(this.promise),q(e)?(this._input=e,this.length=e.length,this._remaining=e.length,this._result=new Array(this.length),0===this.length?m(this.promise,this._result):(this.length=this.length||0,this._enumerate(),0===this._remaining&&m(this.promise,this._result))):b(this.promise,P())}function P(){return new Error("Array Methods must be provided an Array")}function C(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function O(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function k(t){this[I]=T(),this._result=this._state=void 0,this._subscribers=[],c!==t&&("function"!=typeof t&&C(),this instanceof k?E(this,t):O())}var Y=void 0,q=Y=Array.isArray?Array.isArray:function(t){return"[object Array]"===Object.prototype.toString.call(t)},F=0,D=void 0,K=void 0,L=function(t,e){G[F]=t,G[F+1]=e,2===(F+=2)&&(K?K(i):H())},N="undefined"!=typeof window?window:void 0,U=N||{},W=U.MutationObserver||U.WebKitMutationObserver,z="undefined"==typeof self&&"undefined"!=typeof process&&"[object process]"==={}.toString.call(process),B="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,G=new Array(1e3),H=void 0;H=z?function(){return process.nextTick(i)}:W?function(){var t=0,e=new W(i),n=document.createTextNode("");return e.observe(n,{characterData:!0}),function(){n.data=t=++t%2}}():B?function(){var t=new MessageChannel;return t.port1.onmessage=i,function(){return t.port2.postMessage(0)}}():void 0===N&&"function"==typeof require?function(){try{var t=require("vertx");return D=t.runOnLoop||t.runOnContext,r()}catch(t){return o()}}():o();var I=Math.random().toString(36).substring(16),J=void 0,Q=1,R=2,V=new A,X=new A,Z=0;return M.prototype._enumerate=function(){for(var t=this.length,e=this._input,n=0;this._state===J&&n<t;n++)this._eachEntry(e[n],n)},M.prototype._eachEntry=function(t,e){var n=this._instanceConstructor,r=n.resolve;if(r===u){var o=l(t);if(o===s&&t._state!==J)this._settledAt(t._state,e,t._result);else if("function"!=typeof o)this._remaining--,this._result[e]=t;else if(n===k){var i=new n(c);v(i,t,o),this._willSettleAt(i,e)}else this._willSettleAt(new n(function(e){return e(t)}),e)}else this._willSettleAt(r(t),e)},M.prototype._settledAt=function(t,e,n){var r=this.promise;r._state===J&&(this._remaining--,t===R?b(r,n):this._result[e]=n),0===this._remaining&&m(r,this._result)},M.prototype._willSettleAt=function(t,e){var n=this;w(t,void 0,function(t){return n._settledAt(Q,e,t)},function(t){return n._settledAt(R,e,t)})},k.all=function(t){return new M(this,t).promise},k.race=function(t){var e=this;return new e(q(t)?function(n,r){for(var o=t.length,i=0;i<o;i++)e.resolve(t[i]).then(n,r)}:function(t,e){return e(new TypeError("You must pass an array to race."))})},k.resolve=u,k.reject=function(t){var e=new this(c);return b(e,t),e},k._setScheduler=function(t){K=t},k._setAsap=function(t){L=t},k._asap=L,k.prototype={constructor:k,then:s,catch:function(t){return this.then(null,t)}},k.polyfill=function(){var t=void 0;if("undefined"!=typeof global)t=global;else if("undefined"!=typeof self)t=self;else try{t=Function("return this")()}catch(t){throw new Error("polyfill failed because global object is unavailable in this environment")}var e=t.Promise;if(e){var n=null;try{n=Object.prototype.toString.call(e.resolve())}catch(t){}if("[object Promise]"===n&&!e.cast)return}t.Promise=k},k.Promise=k,k.defer=function(){var t={};return t.promise=new k(function(e,n){t.resolve=e,t.reject=n}),t},k}); 
 			}); 
		define("src/lib/message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(){this._evtObjs={},this._outdatedMsgs={}}function e(){}t.prototype.on=function(t,e,s){this._evtObjs[t]||(this._evtObjs[t]=[]),this._evtObjs[t].push({handler:e,once:s});var n=this;return function(){n.off(t,e)}},t.prototype.wait=function(t,s){return this._outdatedMsgs[t]?(s.apply(null,this._outdatedMsgs[t]),e):this.on(t,s,!0)},t.prototype.off=function(t,e){var s=this;return(t?[t]:Object.keys(this._evtObjs)).forEach(function(t){if(e){var n=[];(s._evtObjs[t]||[]).forEach(function(t){t.handler!==e&&n.push(t)}),s._evtObjs[t]=n}else s._evtObjs[t]=[]}),this},t.prototype.emit=function(t){var e=Array.prototype.slice.call(arguments,1);this._outdatedMsgs[t]=e,(this._evtObjs[t]||[]).forEach(function(t){if(!t.once||!t.called){t.called=!0;try{t.handler&&t.handler.apply(null,e)}catch(t){console.error(t.stack||t.message||t)}}})},t.prototype.emitAsync=function(){var t=arguments,e=this;setTimeout(function(){e.emit.apply(e,t)},0)},t.prototype.assign=function(t){var e=this;["on","off","wait","emit","emitAsync"].forEach(function(s){var n=e[s];t[s]=function(){return n.apply(e,arguments)}})},(new t).assign(t),module.exports=t; 
 			}); 
		define("src/lib/parse-body.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(t){if("string"!=typeof t)return t;t&&(t=t.trim()),t&&/^(data|QZOutputJson)=/.test(t)&&(t=t.replace(/^(data|QZOutputJson)=/,"").replace(/;?$/,""));try{return JSON.parse(t)}catch(t){throw new Error("parse jsonp body failed")}}; 
 			}); 
		define("src/lib/request.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./parse-body"),n=require("./es6-promise"),t=require("../module/log")("lib-request"),u=module.exports={request:function(n){return n.success=function(n){return n=n||function(){},function(u){if(t("wx.request success"),u&&200==u.statusCode)try{u.data=e(u.data)}catch(e){}n(u)}}(n.success),t("wx.request",n.url),wx.request(n)},get:function(e,t){return t=t||{},new n(function(n,s){(u.busRequest||u.request)({url:e,data:t.data||{},header:t.header||{},method:"GET",success:function(e){n(e)},fail:function(e){s(e)},needLoginCase:t.needLoginCase,needlogin:t.needlogin})})},post:function(e,t){return t=t||{},new n(function(n,s){(u.busRequest||u.request)({url:e,data:t.data||{},header:t.header||{},method:"POST",success:function(e){n(e)},fail:function(e){s(e)},needLoginCase:t.needLoginCase,needlogin:t.needlogin})})}}; 
 			}); 
		define("src/lib/url.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={queryParse:function(e,n){if(!e)return{};n=n||"&";var r=e.replace(/^\?/,""),t={},i=r?r.split(n):null;return i&&i.length>0&&i.forEach(function(e){var n=(e=e.split("=")).splice(0,1),r=e.join("=");t[n]=decodeURIComponent(r)}),t},queryJoin:function(n){var r=[].slice.call(arguments);r[0]={};var t=e.queryStringify(Object.extend.apply(Object,r));if(!t)return n;var i;return i=/[\?&]$/.test(n)?"":~n.indexOf("?")?"&":"?",n+i+t},queryStringify:function(e,n){return e?Object.keys(e).map(function(n){return n+"="+encodeURIComponent(e[n])}).join(n||"&"):""}};module.exports=e; 
 			}); 
		define("src/module/account.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n=require("../util/appids"),c={canUse:function(){return!!wx.getAccountInfoSync},isInner:function(){if(c.canUse()){var e=wx.getAccountInfoSync();return!!n[e.miniProgram.appId]}return!1},getAccountInfoSync:function(){if(c.canUse())return wx.getAccountInfoSync()},canUseInner:function(){return c.canUse()&&c.isInner()}};module.exports=c; 
 			}); 
		define("src/module/cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={set:function(e,t,a){wx.setStorageSync("_cache_"+e,{expr:a||0,date:+new Date,data:t})},get:function(e){e="_cache_"+e;var t=wx.getStorageSync(e);return t?t.expr&&t.expr?new Date-(t.date+t.expr)<0?t.data:(wx.removeStorageSync(e),null):t.data:null},del:function(e){e="_cache_"+e,wx.removeStorageSync(e)}}; 
 			}); 
		define("src/module/curr-page.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var r;module.exports={getCurrUrl:function(e){if(!(r=e.getCurrentPages||r))return"/pages/default";var t=r();return t[t.length-1].route},getCurrPageQuery:function(e){if(!(r=e.getCurrentPages||r))return"/pages/default";var t=r();return(e=t[t.length-1].options)||{}},getCurrUrlWithQuery:function(){var r=this.getCurrPageQuery(),e=this.getCurrUrl()+"?";for(var t in r)e+=t+"="+r[t]+"&";return e=e.substring(0,e.length-1)}}; 
 			}); 
		define("src/module/gen-guid.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(){return Math.random().toString(16).substring(2)}; 
 			}); 
		define("src/module/guid.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./cache"),r=require("./gen-guid"),t=e.get("tvp_guid");t||(t=r(),e.set("tvp_guid",t)),module.exports=t; 
 			}); 
		define("src/module/log.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function o(a){var t=[Math.floor(50*Math.random()+200),Math.floor(50*Math.random()+150),Math.floor(50*Math.random()+100)].sort(function(){return Math.random()-.5});return t="rgb("+t[0]+", "+t[1]+", "+t[2]+")",n?function(){if(o.isOpenLog){var n=["%c【%s】%c "+a+" %c %s ","background: #ddd",new Date,"background: "+t,"background: #333;color: white"];console.log.apply(console,n.concat([].slice.call(arguments,0)))}}:function(){if(o.isOpenLog){var n=["【%s】 "+a+" %s ",new Date];console.log.apply(console,n.concat([].slice.call(arguments,0)))}}}var n="devtools"==wx.getSystemInfoSync().platform;o.isOpenLog=!1,module.exports=o; 
 			}); 
		define("src/module/network.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={"4g":4,"3g":3,"2g":2,wifi:1};module.exports=function(t,o){wx.getNetworkType({complete:function(r){var i=(o||e)[r&&r.networkType]||0;t&&t(i)}})}; 
 			}); 
		define("src/module/reporter/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=new(require("../../lib/message")),r=require("./report-queue"),t=require("../log")("module-reporter");r.onReport=function(e){s.emit("report",e)};var o=require("./report-cache"),s={};s.any=function(e){r.push(e)},s.saveState=function(){t("reporter.js","saveState"),s.emit("_save")},s.restoreState=function(){t("reporter.js","restoreState"),s.emit("_restore")},s.checkState=function(){t("reporter.js","checkState"),o.getAll().forEach(r.push),o.del()},s.reportCache=o,e.assign(s),module.exports=s; 
 			}); 
		define("src/module/reporter/report-cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../cache"),e=t.get("tvp_report")||{};exports.get=function(t){return e[t]},exports.set=function(r,n){e[r]=n,t.set("tvp_report",e)},exports.del=function(r){r?delete e[r]:e={},t.set("tvp_report",e)},exports.getAll=function(){return Object.keys(e).map(function(t){return e[t]})}; 
 			}); 
		define("src/module/reporter/report-queue.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").request;module.exports=function(t){function n(t){~t.reportUrl.indexOf("btrace.qq.com")?e(t.reportUrl).then(function(){r.release()}).catch(function(){r.onReport&&r.onReport(t)}):r.onReport&&r.onReport(t),c=setTimeout(function(){r.release()},o)}var r,o=3e3,u=!1,i=[],c=null;return r={release:function(e){u&&e&&e!=u||(u=!1,clearTimeout(c),i.length&&n(i.shift()))},push:function(e){u?i.push(e):(u=e,n(e))}}}(); 
 			}); 
		define("src/module/system-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t;module.exports=function(){return t=t||wx.getSystemInfoSync()}; 
 			}); 
		define("src/module/visiable.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e,t=require("./log")("visiable");module.exports=function(o){if(!o.dom){var r=wx.createSelectorQuery().in(o);o.dom=r.select("#"+o.data.playerid)}o.dom.boundingClientRect(function(r){e=e||wx.getSystemInfoSync();var i=!0;(r.top>=e.windowHeight||r.bottom<=0)&&(t(r),i=!1),i||o.isEnterFullscreen||o._controller.pause()}).exec()}; 
 			}); 
		define("src/util/appids.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={wxa75efa648b60994b:!0,wxac48d234d44e23e3:!0}; 
 			}); 
		define("src/util/base64text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports="data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAAAtxtZGF0AAACvAYF//+43EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDEzNSByMjM0NSBmMGMxYzUzIC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAxMyAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTYgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTEwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9YWJyIG1idHJlZT0xIGJpdHJhdGU9NTAgcmF0ZXRvbD0xLjAgcWNvbXA9MC42MCBxcG1pbj0wIHFwbWF4PTY5IHFwc3RlcD00IGlwX3JhdGlvPTEuNDAgYXE9MToxLjAwAIAAAAAQZYiEABr//vfUt8yy8ER/gQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAA8AAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAEAAAAAoAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAZBtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAACgAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE7bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA+3N0YmwAAACXc3RzZAAAAAAAAAABAAAAh2F2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAEAAKAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAAxYXZjQwFkAAn/4QAZZ2QACazZX+TAWyAAAAMAIAAAAwKB4kSywAEABWjr7LIsAAAAGHN0dHMAAAAAAAAAAQAAAAEAAAQAAAAAHHN0c2MAAAAAAAAAAQAAAAEAAAABAAAAAQAAABRzdHN6AAAAAAAAAtQAAAABAAAAFHN0Y28AAAAAAAAAAQAAADAAAABidWR0YQAAAFptZXRhAAAAAAAAACFoZGxyAAAAAAAAAABtZGlyYXBwbAAAAAAAAAAAAAAAAC1pbHN0AAAAJal0b28AAAAdZGF0YQAAAAEAAAAATGF2ZjU1LjEyLjEwMg=="; 
 			}); 
		define("src/util/defn-config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,r,d){return r in e?Object.defineProperty(e,r,{value:d,enumerable:!0,configurable:!0,writable:!0}):e[r]=d,e}var r;module.exports=(r={"流畅":"msd","标清":"sd","高清":"mp4"},e(r,"高清","hd"),e(r,"超清","shd"),e(r,"蓝光","fhd"),e(r,"4K","uhd"),e(r,"杜比","dolby"),r); 
 			}); 
		define("src/util/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={formatDate:function(e,t){if(!e)return"";"string"==typeof e&&(e=new Date(e.replace(/-/g,"/"))),t=t||"yyyy-MM-dd";var n={"M+":e.getMonth()+1,"d+":e.getDate(),"h+":e.getHours(),"m+":e.getMinutes(),"s+":e.getSeconds(),"q+":Math.floor((e.getMonth()+3)/3),S:e.getMilliseconds()};/(y+)/.test(t)&&(t=t.replace(RegExp.$1,(e.getFullYear()+"").substr(4-RegExp.$1.length)));for(var r in n)new RegExp("("+r+")").test(t)&&(t=t.replace(RegExp.$1,1==RegExp.$1.length?n[r]:("00"+n[r]).substr((""+n[r]).length)));return t},Oncer:function(e){var t=!1,n=function(){t||(t=!0,e.done=t,e.apply(this,arguments))};return n.done=t,n}}; 
 			}); 
		define("src/util/platform-config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={APP_NAME:{v4170:"zhihuiwang",v4163:"xiaosongliu",v4162:"dongqiji",v4161:"egame.qq.com",v4169:"plugin",v4160:"sport.qq.com",v4159:"oddjohn",v4158:"sherrygu",v4157:"sophiachang",v4153:"yidiandian",v4152:"pvp.wx.com",v4151:"pipixia",v4150:"wechat_class",v4149:"x5.qq.com",v4148:"auto.qq.com",v4146:"wuxia.qq.com",v4145:"dnf.qq.com",v4144:"pvp.qq.com",v4143:"ke.qq.com",v4142:"qnreading",v4141:"om",v4140:"wx_reader",v4139:"news",v4138:"video"},APP_PLATFORM:{v4170:"4340801",v4163:"4090801",v4162:"4120801",v4161:"3960801",v4169:"4210801",v4160:"40801",v4159:"3810801",v4158:"3710801",v4157:"3690801",v4153:"3500801",v4152:"3470801",v4151:"3450801",v4150:"3310801",v4149:"3280801",v4148:"3170801",v4146:"3140801",v4145:"3110801",v4144:"3100801",v4143:"260801",v4142:"570801",v4141:"3040801",v4140:"60801",v4139:"20801",v4138:"10801"}}; 
 			}); 
		define("src/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./module/reporter/index"),t=require("./controller-video/index"),o=require("./controller-live/index"),n=require("./util/platform-config").APP_NAME,r=module.exports=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},a=r.from,d=void 0===r.autoplay||r.autoplay,f=r.defn||"",c=r.chid||void 0,p="function"==typeof r.getReportParam?r.getReportParam:"function"==typeof r.getLoginData?function(e){r.getLoginData(function(t,o){o.hc_openid=o.openid,delete o.openid,e(t,o)})}:function(e){return e()},u=e.vid;"string"==typeof e&&(u=e);var l,s=e.cid||"",v=e.sid,g=e.pid,m=r.scene,h=r.qwer;return l=u?t({vid:u,cid:s,from:a,chid:c,defn:f,scene:m,qwer:h,videoInfo:i},{onBeforeGetinfo:r.onBeforeGetinfo,getReportParam:function(e){p(function(t,o){o&&(o.appname=n[a]),e(t,o)})}}):o({sid:v,pid:g,from:a,defn:f},{getReportParam:function(e){p(function(t,o){o&&(o.appname=n[a]),e(t,o)})}}),d&&l.start(),l};r.on=function(t){"report"==t&&(e.off("report"),e.on.apply(e,arguments))},r.release=e.release,r.saveState=e.saveState,r.restoreState=e.restoreState,r.checkState=e.checkState; 
 			}); 
		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/live/live.js';global.__wxRouteBegin = true; 	define("component/live/live.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../../index"),e=require("../txv-context"),i=require("../../src/module/log")("txv-live-component"),a=(require("../../src/controller-live/flow-getinfo/live-detail"),require("../../src/controller-live/flow-getinfo/live-poll")),r=(require("../../src/util/index"),require("../../src/util/base64text")),n=require("./properties"),o=require("./data");Component({properties:n,data:o,attached:function(){i("attached",this.data);var t=this;wx.onNetworkStatusChange(function(i){function a(){t.currPlayTime=t.data.progressTime,t.networkChange&&t.networkChange()}t.data.tvpIsAd||(t.data.playerid!=e.getLastPlayId()?t.delayNetworkChangeReq=a:a())})},detached:function(){i("detached",this.data),e.txvDetached(this.data.playerid),clearTimeout(this.livePollTimer),this.networkChange=null,this.livePollTimer=!1},methods:{registerInterface:function(){var t=this,i=this.data.playerid;if(!i)throw new Error("需要为txv-live组件指定一个playerid，可以采用sid+pid组合形成playerid");if(!this._controller){this.videoContext=wx.createVideoContext(i,this);var a=this._controller={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen","sendDanmu"].forEach(function(e){a[e]=function(){for(var i=arguments.length,a=Array(i),r=0;r<i;r++)a[r]=arguments[r];t.videoContext[e].apply(t.videoContext,a)}}),e.txvAttached(i,a),this.mountMore(a)}},mountMore:function(t){var e=this,i={hideVideo:function(){e.setData({isHiddenVideo:!0})},showVideo:function(){e.setData({isHiddenVideo:!1})},hideVideoWithVoice:function(){e.setData({isHiddenWithVoice:!0})},showVideoWithVoice:function(){e.setData({isHiddenWithVoice:!1},function(){})},showContainer:function(){e.setData({isHiddenContainer:!1})},hideContainer:function(){e.setData({isHiddenContainer:!0})}};Object.assign(t,i)},getVideoInfo:function(){if(this.data.sid&&this.data.pid)return t({sid:this.data.sid,pid:this.data.pid},Object.assign({from:"v4169"},this.data.extraParam))},onVideoChange:function(t,e,a){var r=this.data.sid,n=this.data.pid;this.formerPid==n&&this.formerSid==r||(this.formerPid=n,this.formerSid=r,r&&n&&(this.registerInterface(),i("onVideoChange",r,n),clearTimeout(this.livePollTimer),this.livePollTimer=null,this.createPlayer()))},triggerLivePoll:function(t,e){var n=this;if(!this.isPolling)return this.isPolling=!0,a({pollDataKey:t,pollContext:e||""}).then(function(e){n.isPolling=!1,i("@@@@@@@@@@@@@@@",e),e=e&&e.data&&e.data.data,!1!==n.livePollTimer&&(n.livePollTimer=setTimeout(function(){n.triggerLivePoll(t,e.pollContext)},1e3*(e.pollTimeOut||5)));var a={onlineNumber:e.onlineNumber,likeNum:e.likeNum,popularity:e.popularity,playCount:e.playCount,attentNumber:e.attentNumber};2!=e.liveStatus?(clearTimeout(n.livePollTimer),n.livePollTimer=!1,n.triggerEvent("livestatus",{status:3,msg:"直播已结束",data:a}),n.videoContext.pause(),n.setData({getDataError:"",isAfter:!0,isBefore:!1,tvpUrl:r,autoplay:!1})):n.triggerEvent("livestatus",{status:2,msg:"直播中",data:a})}).catch(function(i){n.isPolling=!1,!1!==n.livePollTimer&&(n.livePollTimer=setTimeout(function(){n.triggerLivePoll(t,e)},2e4))})},createPlayer:function(){var t=this;this.video=this.getVideoInfo(),this.video&&(this.networkChange=this.video.switchDefn,this.video.on("contentchange",function(e){if(t.triggerEvent("contentchange",e),e.currentContent){i("tvpUrl",e,e.currentContent);var a=e.currentContent.url,r=e.currentContent.iretcode,n={isBefore:!1,isAfter:!1,getDataError:!1,errCode:""};0===r&&a?(n.tvpUrl=a,t.triggerEvent("livestatus",{status:2,msg:"直播中"}),!t.data.isStopPoll&&t.triggerLivePoll("pid="+t.data.pid)):7==r?(n.isBefore=!0,t.triggerEvent("livestatus",{status:1,msg:"直播未开始"}),t.videoContext.pause()):8==r?(n.isAfter=!0,t.triggerEvent("livestatus",{status:3,msg:"直播已结束"}),t.videoContext.pause()):(n.getDataError=!0,n.errCode=r||8888,t.triggerEvent("livestatus",{status:r,msg:"未知错误"}),t.videoContext.pause()),t.setData(n)}}),this.video.on("error",function(e){t.triggerEvent("contenterror",e)}))},__onTvpPlay:function(t){var i=this.data.playerid,a=e.getLastPlayId();if(e.setTvpPlayState(i,!0),a!=i){if(a){var r=e.getTxvContext(a);this.data.isNeedMutex&&r&&r.pause(),e.setTvpPlayState(a,!1)}e.setLastPlayId(i)}if(this.delayNetworkChangeReq)return this.delayNetworkChangeReq(),void(this.delayNetworkChangeReq=null);try{this.video&&this.video.onContentPlay()}finally{this.triggerEvent("play",t.detail)}},__onTvpPause:function(t){e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentPause()}finally{this.triggerEvent("pause",t.detail)}},__onTvpEnded:function(t){e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentEnd()}finally{this.triggerEvent("ended",t.detail)}},__onTvpTimeupdate:function(t){e.setTvpPlayState(this.data.playerid,!0),this.triggerEvent("timeupdate",t.detail),this.video&&this.video.onContentTimeupdate(null,t)},__onTvpFullScreenChange:function(t){this.isEnterFullscreen=!!t.detail.fullScreen,this.triggerEvent("fullscreenchange",t.detail)},__onTvpError:function(t){e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentError()}finally{this.triggerEvent("error",t.detail)}}}}); 
 			}); 	require("component/live/live.js");
 		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/video/video.js';global.__wxRouteBegin = true; 	define("component/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../../index"),e=require("../txv-context"),i=require("../../src/module/log")("txv-video-component"),n=require("../../src/util/defn-config"),r=require("../../src/module/system-info")(),a=r.system.match(/ios/i),o=require("../../src/util/base64text"),s=require("./properties"),h=require("./data"),c=wx.getStorageSync("tvp_openid");c||(c=["_",Math.random().toString(16).slice(2),Math.random().toString(16).slice(2),Math.random().toString(16).slice(2)].join("").slice(0,28),wx.setStorageSync("tvp_openid",c)),Component({properties:s,data:h,attached:function(){var n=this;i("attached",this.data);var r=this;wx.onNetworkStatusChange(function(t){function i(){r.currPlayTime=r.data.progressTime,r.isNetworkChange=!0,r.networkChange&&r.networkChange()}r.data.tvpIsAd||(r.data.playerid!=e.getLastPlayId()?r.delayNetworkChangeReq=i:i())}),t.on("report",function(t){n.setData({reportUrl:t.reportUrl.replace("https","http")})}),this.initBright(),this.isIpx()},ready:function(){this.register()},moved:function(){},detached:function(){i("detached",this.data),e.txvDetached(this.data.playerid),this._controller=null,this.networkChange=null},methods:{register:function(){this.data.isHiddenStop&&this.registerIntersectionObserver()},registerIntersectionObserver:function(){var t=this;this.createIntersectionObserver().relativeToViewport().observe("#"+this.data.playerid,function(e){var i=e.boundingClientRect;t.isEnterFullscreen||t.data.isHiddenWithVoice||!i||(i.bottom<=0||i.top>=r.windowHeight)&&t.videoContext.pause()})},registerInterface:function(){var t=this;if(!this.data.playerid)throw new Error('需要为txv-video组件指定一个playerid，如果是采用的playerid="{{playerid}}"，请加上wx:if="{{playerid}}"');if(!this._controller){this.videoContext=wx.createVideoContext(this.data.playerid,this);var n=this._controller={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen","sendDanmu"].forEach(function(e){n[e]=function(){for(var i=arguments.length,n=Array(i),r=0;r<i;r++)n[r]=arguments[r];t.videoContext[e].apply(t.videoContext,n)}}),this.mountMore(n),e.txvAttached(this.data.playerid,n),i("!!!!!!!",e)}},mountMore:function(t){var e=this,i=this,n={hideVideo:function(){i.setData({isHiddenVideo:!0})},showVideo:function(){i.setData({isHiddenVideo:!1})},hideVideoWithVoice:function(){i.setData({isHiddenWithVoice:!0})},showVideoWithVoice:function(){i.setData({isHiddenWithVoice:!1},function(){})},showContainer:function(){i.setData({isHiddenContainer:!1})},hideContainer:function(){i.setData({isHiddenContainer:!0})},controller:this.video||null,replay:function(t,i,n){i=i||e.data,n=n||e.data.videoInfo,e.start(t,i,n),setTimeout(function(){e.videoContext.play()})}};Object.assign(t,n)},skipAd:function(){this.video.onContentSkip(0)},onPlayeridChange:function(t,i){i&&e.txvDetached(i),t&&this._controller&&e.txvAttached(t,this._controller)},onVideoChange:function(t,e){this.start(t,this.data,this.data.videoInfo)},getVideoInfo:function(e,r,a){if(e)return i("denf",n[r.defn]),t(e,Object.assign({from:"v4169",defn:n[r.defn]||"",getReportParam:function(t){t(null,{hc_openid:c,hc_vuserid:c})}},r.extraParam),a)},start:function(t,n,r){var s=this;if(t){this.registerInterface();var h={tvpState:""};a||(h.tvpUrl=o),this.setData(h),n=n||{},r=r||{},t=t.replace(/^\s+|\s+$/,""),i("onVideoChange",t),console.log("onVideoCHnage");var c=this.video=this.getVideoInfo(t,n,r);if(c){try{var d=e.getTxvContext(this.data.playerid);d&&(d.controller=c)}catch(t){}this.networkChange=c.switchDefn,c.on("error",function(t){s.triggerEvent("contenterror",t),s.setData({tvpVideoError:t.message+"("+(t.code||"L")+")"})}),c.on("statechange",function(t,e){if(i("onstatechange",t,e),s.triggerEvent("statechange",{newstate:t,oldstate:e}),t!=s.data.tvpState){switch(i("playerstatechange "+s.data.tvpState+" => "+t),s.data.tvpState){case"stop":break;case"error":return}s.setData({tvpState:t})}});var l=!0;c.on("contentchange",function(e){i("contentchange",e);var n=s.isSwitchDefn?1:s.isNetworkChange?2:0;if(e=e||{},e.origin=n,s.triggerEvent("contentchange",e),e.currentContent){var a={};e.extra.isPlayingAd||(a.progressTime=0,e.progress?(a.progressDuration=e.progress.duration,a.progressBaseTime=e.progress.time,a.progressSkipTime=e.progress.skipable):(a.progressDuration=0,a.progressBaseTime=0,a.progressSkipTime=0)),a.tvpUrl=e.currentContent.url;var o=a.tvpIsAd=!!e.currentContent.isad;if(!o&&a.tvpUrl===s.data.tvpUrl){var h=/\?/.test(a.tvpUrl)?"&":"?";a.tvpUrl+=h+"_r="+Math.random()}if(i("tvpUrl",a.tvpUrl),console.log("tvpUrl",a.tvpUrl),-1==a.direction){var c=e.getinforaw&&e.getinforaw.vl&&e.getinforaw.vl.vi;c&&c.length?c.some(function(e){e.vid===t&&e.vh&&e.vw&&(a.direction=e.vh<e.vw?90:0)}):r&&r.vh&&r.vw&&(a.direction=r.vh<r.vw?90:0)}if(!o){var d=e.getinforaw&&e.getinforaw.fl&&e.getinforaw.fl.fi,v="";(d=d||r&&r.vecDefn)&&d.length&&(d.forEach(function(t){t.cname.replace(/([^;]+?);\(([^)]+?)\)/,function(e,i,n){t.cname=i+" "+n,t.cname_short=i}),t.selected=t.selected||!1,v||!t.selected&&!t.sl||(v=t.cname_short||"",t.selected=!0)}),d.reverse(),a.formats=d,a.formats_selected=v)}s.setData(a,function(){l||setTimeout(function(){s.videoContext.play(),s.isNetworkChange&&(s.videoContext.seek(s.currPlayTime),s.isNetworkChange=!1)},200),l=!1}),s.isSwitchDefn&&(s.currPlayTime&&e.currentContent.wait("start",function(){i("seek"),s.videoContext.seek(s.currPlayTime)}),s.isSwitchDefn=!1)}else i("first content change",e)}),c.on("videostart",function(t){s.triggerEvent("videostart",t)})}}},__onTvpPlay:function(t){this.setData({isPlaying:!0});var i=this.data.playerid;e.setTvpPlayState(i,!0);var n=e.getLastPlayId();if(n!=i){if(n&&e.existTxvContext(n)){var r=e.getTxvContext(n);this.data.isNeedMutex&&r&&r.pause(),e.setTvpPlayState(n,!1)}e.setLastPlayId(i)}if(this.delayNetworkChangeReq)return this.delayNetworkChangeReq(),void(this.delayNetworkChangeReq=null);try{this.video&&this.video.onContentPlay()}finally{this.triggerEvent("play",t.detail)}},__onTvpPause:function(t){this.setData({isPlaying:!1}),e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentPause()}finally{this.triggerEvent("pause",t.detail)}},__onTvpEnded:function(t){e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentEnd()}finally{t.detail=t.detail||{},t.detail.isAd=!!this.data.tvpIsAd,this.triggerEvent("ended",t.detail)}},__onTvpTimeupdate:function(t){e.setTvpPlayState(this.data.playerid,!0),this.triggerEvent("timeupdate",t.detail);try{this.setData({progressTime:Math.floor(t.detail.currentTime)}),this.video&&this.video.onContentTimeupdate(null,t)}catch(t){}},__onTvpError:function(t){e.setTvpPlayState(this.data.playerid,!1);try{this.video&&this.video.onContentError()}finally{this.triggerEvent("error",t.detail)}},__onTvpFullScreenChange:function(t){this.isEnterFullscreen=!!t.detail.fullScreen,this.triggerEvent("fullscreenchange",t.detail),this.setData({fullscreen:this.isEnterFullscreen,showControlBtn:!this.data.fullscreen&&this.isEnterFullscreen}),this.showControlBtn()},tapRetry:function(t){},isIpx:function(){var t=this;wx.getSystemInfo({success:function(e){"iPhone X"==e.model.substring(0,e.model.indexOf("X"))+"X"&&t.setData({isIpx:!0})}})},initBright:function(){var t=this;wx.getScreenBrightness({success:function(e){var i=e.value;t.setData({currentBright:i})}})},__onTvpCloseBright:function(){this.setData({showBrightSelector:!1,showControlBtn:!0}),this.showControlBtn()},__onTvpShowBright:function(){this.setData({showBrightSelector:!0,showControlBtn:!0})},setBright:function(t){var e=t.currentTarget.dataset.type,n=this.data.currentBright;0==e?(n-=.125)<0&&(n=0):(n+=.125)>1&&(n=1),wx.setScreenBrightness({value:n,success:function(){i("设置亮度成功",new Date)},fail:function(){i("设置亮度失败",new Date)}}),this.setData({currentBright:n})},__onTvpCloseHD:function(){this.setData({showHDSelector:!1,showControlBtn:!0}),this.showControlBtn()},__onTvpShowHD:function(){this.setData({showHDSelector:!0,showControlBtn:!0})},__onTvpTap:function(){this.data.fullscreen&&(this.setData({showControlBtn:!0}),this.showControlBtn(4500))},selectHD:function(t){if("end"!=this.data.tvpState){var e=t.currentTarget.dataset;e.fname&&!e.selected&&(this.isSwitchDefn=!0,this.currPlayTime=this.data.progressTime,this.video&&this.video.switchDefn&&this.video.switchDefn(e.fname))}},showControlBtn:function(t){var e=this;clearTimeout(this._playerHDSelectorBtnTimer),this._playerHDSelectorBtnTimer=setTimeout(function(){e.setData({showControlBtn:!1})},t||3e3)}}}); 
 			}); 	require("component/video/video.js");
 	
				global.publishDomainComponents({
			"plugin://wxa75efa648b60994b/video":"plugin-private://wxa75efa648b60994b/component/video/video","plugin://wxa75efa648b60994b/live":"plugin-private://wxa75efa648b60994b/component/live/live"
	})
				module.exports = function() {
		return require('component/txv-context.js')
	}
			});
	requirePlugin("plugin://wxa75efa648b60994b");
/*v0.5vv_20190514_syb_scopedata*/global.__wcc_version__='v0.5vv_20190514_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'recommentNotice']]],[[7],[3,'ADmodule']]],[[7],[3,'showFlag']]])
Z([3,'ad'])
Z([[2,'!'],[[6],[[7],[3,'ADmodule']],[1,9]]])
Z([[2,'&&'],[[2,'==='],[[6],[[7],[3,'ADmodule']],[1,1]],[1,'1']],[[2,'=='],[[6],[[7],[3,'ADmodule']],[1,0]],[1,'open']]])
Z([[2,'&&'],[[2,'==='],[[6],[[7],[3,'ADmodule']],[1,1]],[1,'0']],[[2,'=='],[[6],[[7],[3,'ADmodule']],[1,0]],[1,'open']]])
Z([[2,'&&'],[[6],[[7],[3,'ADmodule']],[1,9]],[[2,'=='],[[6],[[7],[3,'ADmodule']],[1,1]],[1,1]]])
Z([[2,'=='],[[6],[[7],[3,'ADmodule']],[1,10]],[1,'1']])
Z(z[3])
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'adModule'])
Z([[7],[3,'adList']])
Z([3,'index'])
Z([[2,'=='],[[6],[[7],[3,'adModule']],[1,'index']],[[7],[3,'_index']]])
Z([3,'ad'])
Z([[2,'&&'],[[2,'==='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,1]],[1,'1']],[[2,'=='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,0]],[1,'open']]])
Z([[2,'&&'],[[2,'==='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,1]],[1,'0']],[[2,'=='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,0]],[1,'open']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'getFormId'])
Z([3,'_form'])
Z([3,'submit'])
Z([3,'true'])
Z([3,'formOutInfo'])
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'element'])
Z([[7],[3,'scroll']])
Z([[8],'nodes',[[7],[3,'nodes']]])
Z([3,'rich-text-floor1'])
Z(z[2])
Z(z[3])
Z(z[3])
Z([[7],[3,'nodes']])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'continue']]])
Z([[8],'item',[[7],[3,'item']]])
Z(z[0])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'name']],[1,'a']])
Z([3,'copyhref'])
Z([3,'tapevent'])
Z([[6],[[6],[[7],[3,'item']],[3,'attrs']],[3,'appid']])
Z([[6],[[6],[[7],[3,'item']],[3,'attrs']],[3,'href']])
Z([3,'view-hover'])
Z([[6],[[6],[[7],[3,'item']],[3,'attrs']],[3,'style']])
Z(z[15])
Z([[8],'nodes',[[6],[[7],[3,'item']],[3,'children']]])
Z([3,'rich-text-floor2'])
Z(z[19])
Z(z[20])
Z(z[20])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[14])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor3'])
Z(z[19])
Z(z[37])
Z(z[37])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[14])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor4'])
Z(z[19])
Z(z[54])
Z(z[54])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[14])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor5'])
Z(z[19])
Z(z[71])
Z(z[71])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor6'])
Z(z[19])
Z(z[87])
Z(z[87])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor7'])
Z(z[19])
Z(z[103])
Z(z[103])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor8'])
Z(z[19])
Z(z[119])
Z(z[119])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor9'])
Z(z[19])
Z(z[135])
Z(z[135])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor10'])
Z(z[19])
Z(z[151])
Z(z[151])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor11'])
Z(z[19])
Z(z[167])
Z(z[167])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor12'])
Z(z[19])
Z(z[183])
Z(z[183])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor13'])
Z(z[19])
Z(z[199])
Z(z[199])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor14'])
Z(z[19])
Z(z[215])
Z(z[215])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor15'])
Z(z[19])
Z(z[231])
Z(z[231])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor16'])
Z(z[19])
Z(z[247])
Z(z[247])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor17'])
Z(z[19])
Z(z[263])
Z(z[263])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor18'])
Z(z[19])
Z(z[279])
Z(z[279])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor19'])
Z(z[19])
Z(z[295])
Z(z[295])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[0])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[15])
Z(z[19])
Z([3,'rich-text-floor20'])
Z(z[19])
Z(z[311])
Z(z[311])
Z(z[7])
Z(z[9])
Z(z[0])
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'html']])
Z([[2,'!'],[[7],[3,'recommentNotice']]])
Z(z[2])
Z([[2,'!'],[[7],[3,'shareCanvas']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'!'],[[7],[3,'userFormIdFlag']]])
Z([3,'getDataFormComp'])
Z([[2,'?:'],[[2,'!'],[[7],[3,'userFormIdFlag']]],[1,'point_none'],[1,'point_auto']])
Z([3,'position:absolute;top:0;left:0;z-index:9;'])
Z([3,'container_back'])
Z([[7],[3,'hidePromptImgFlag']])
Z([3,'point_auto'])
Z(z[1])
Z(z[2])
Z([3,'coorcontainer'])
Z([3,'formOutInfo'])
Z([[7],[3,'btncoor']])
Z(z[12])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD13']],[1,0]],[1,'open']])
Z([[6],[[7],[3,'rendInfo']],[3,'AD']])
Z([3,'backBlack'])
Z([3,'hasAD13'])
Z([[7],[3,'recommentNotice']])
Z([[2,'!'],[[6],[[7],[3,'videosrc']],[3,'vid']]])
Z([[9],[[9],[[9],[[9],[[9],[[9],[[8],'videosrc',[[7],[3,'videosrc']]],[[8],'initialTime',[[7],[3,'initialTime']]]],[[8],'replayMask',[[7],[3,'replayMask']]]],[[8],'scrollHeight',[[7],[3,'scrollHeight']]]],[[8],'selfVideoHight',[[7],[3,'selfVideoHight']]]],[[8],'recommentNotice',[[7],[3,'recommentNotice']]]],[[8],'rendInfo',[[7],[3,'rendInfo']]]])
Z([3,'videoLayout'])
Z(z[20])
Z([3,'tevLayout'])
Z(z[18])
Z([3,'_share point_auto'])
Z(z[1])
Z(z[2])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'<'],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'1.2']]]])
Z([3,'li_info time _flex_mask'])
Z([[2,'!'],[[7],[3,'recommentNotice']]])
Z([[2,'?:'],[[2,'=='],[[7],[3,'fontNumLenght']],[1,4]],[1,'flex10'],[1,'flex9']])
Z([[2,'=='],[[6],[[6],[[7],[3,'rendInfo']],[3,'payInfo']],[1,0]],[1,'open']])
Z([[9],[[8],'rendInfo',[[7],[3,'rendInfo']]],[[8],'userFormIdFlag',[[7],[3,'userFormIdFlag']]]])
Z([3,'reward'])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,0]],[1,'open']])
Z(z[33])
Z([3,'camero'])
Z([[2,'!'],[[7],[3,'findRecomm']]])
Z(z[33])
Z([3,'gorecom'])
Z(z[33])
Z([3,'backHome'])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD1']],[1,0]],[1,'open']])
Z(z[15])
Z([3,'hasAD1'])
Z([3,'container_back mb20 point_auto'])
Z(z[18])
Z([3,'othorPro point_auto'])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD7']],[1,0]],[1,'open']])
Z(z[1])
Z(z[2])
Z([3,'flex1'])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD8']],[1,0]],[1,'open']])
Z(z[1])
Z(z[2])
Z(z[52])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD9']],[1,0]],[1,'open']])
Z(z[1])
Z(z[2])
Z(z[52])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD12']],[1,0]],[1,'open']])
Z(z[1])
Z(z[2])
Z(z[52])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD2']],[1,0]],[1,'open']])
Z(z[15])
Z([3,'hasAD2'])
Z([3,'container_back point_auto'])
Z(z[18])
Z(z[30])
Z([[8],'recommendList',[[7],[3,'recommendList']]])
Z([3,'recommentModule'])
Z([[2,'&&'],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD3']],[1,0]],[1,'open']],[[7],[3,'_border']]])
Z(z[15])
Z([3,'border-bottom'])
Z([3,'hasAD3'])
Z([3,'borderFn'])
Z(z[68])
Z(z[18])
Z([3,'padding-bottom:50rpx;border-bottom:1px solid #efefef;margin:0 30rpx;width:690rpx;display:block;'])
Z(z[30])
Z([[8],'explrecommList',[[7],[3,'explrecommList']]])
Z([3,'explrecommList'])
Z(z[30])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD5']],[1,0]],[1,'open']])
Z(z[15])
Z([3,'hasAD5'])
Z(z[68])
Z(z[18])
Z([3,'backMain'])
Z([3,'backMain point_auto'])
Z([3,'bottom'])
Z(z[1])
Z(z[2])
Z([[2,'!'],[[7],[3,'shareCanvas']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'?:'],[[2,'!'],[[7],[3,'userFormIdFlag']]],[1,'point_none'],[1,'point_auto']])
Z([3,'position:absolute;top:0;left:0;z-index:9;'])
Z([[7],[3,'showAddPrompt']])
Z([[2,'&&'],[[2,'||'],[[2,'!'],[[7],[3,'loadding']]],[[2,'!'],[[7],[3,'animationLoadding']]]],[[2,'!'],[[7],[3,'loaddingMask']]]])
Z([3,'maskLoadding'])
Z([3,'changeSwiperFinish'])
Z([3,'changeSwiper'])
Z([3,'contentSwiper'])
Z([[7],[3,'swiperCurrent']])
Z([3,'500'])
Z([a,[3,'height:'],[[7],[3,'_height']],[3,'px;min-height:'],[[7],[3,'scrollHeight']],[3,'px;']])
Z([3,'item'])
Z([[7],[3,'videoList']])
Z([3,'index'])
Z([a,[3,'swiperItem'],[[7],[3,'index']]])
Z(z[13])
Z([[2,'=='],[[7],[3,'swiperCurrent']],[[7],[3,'index']]])
Z([3,'ul_info'])
Z([a,[3,'ulinfo'],z[14][2]])
Z([[9],[[9],[[8],'item',[[7],[3,'item']]],[[8],'list_style_grund',[[7],[3,'list_style_grund']]]],[[8],'adList',[[7],[3,'adList']]]])
Z([3,'videoModule'])
Z([[9],[[8],'loadFontShowNor',[[7],[3,'loadFontShowNor']]],[[8],'animationLoadding',[[7],[3,'animationLoadding']]]])
Z([3,'swiperLoadding'])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'showAddPrompt']])
Z([[2,'!'],[[7],[3,'_loadding']]])
Z([3,'maskLoadding'])
Z([3,'ul_info'])
Z([[2,'!='],[[7],[3,'clickHot']],[1,'clickHot']])
Z([[9],[[9],[[9],[[8],'item',[[7],[3,'item']]],[[8],'list_style_grund',[[7],[3,'list_style_grund']]]],[[8],'adList',[[7],[3,'adList']]]],[[8],'authorArgs',[[7],[3,'authorArgs']]]])
Z([3,'videoModule'])
Z([[9],[[9],[[8],'videos',[[7],[3,'videos']]],[[8],'list_style_grund',[[7],[3,'list_style_grund']]]],[[8],'adList',[[7],[3,'adList']]]])
Z([3,'hotModule'])
Z([[9],[[8],'loadFontShowNor',[[7],[3,'loadFontShowNor']]],[[8],'_loadding',[[7],[3,'_loadding']]]])
Z([3,'loadding'])
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'ProAD_list'])
Z([3,'adModule'])
Z([[7],[3,'adList']])
Z([3,'index'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[[6],[[7],[3,'adModule']],[1,'ad']]],[[2,'=='],[[6],[[7],[3,'single']],[3,'ad_index']],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,2]]]])
Z([[7],[3,'adModule']])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[1,3]],[1,''],[1,'margint50']])
Z([3,'container_back point_auto'])
Z([3,'ProAD_list_right'])
Z(z[1])
Z(z[2])
Z(z[3])
Z([[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[[6],[[7],[3,'adModule']],[1,'ad']]])
Z([[2,'=='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,0]],[1,'open']])
Z([3,'ad_ point_auto'])
Z([[2,'&&'],[[2,'=='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,1]],[1,1]],[[2,'!'],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,9]]]])
Z([[2,'&&'],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,9]],[[2,'=='],[[6],[[6],[[7],[3,'adModule']],[1,'value']],[1,1]],[1,1]]])
Z([3,'ProAD'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'recommentNotice']]],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']]])
Z([3,'ad'])
Z([[2,'&&'],[[2,'==='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']],[1,1]],[1,'1']],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']],[1,0]],[1,'open']]])
Z([[2,'&&'],[[2,'==='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']],[1,1]],[1,'0']],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']],[1,0]],[1,'open']]])
Z([3,'camero'])
Z([[2,'!'],[[7],[3,'userFormIdFlag']]])
Z([3,'getDataFormComp'])
Z([3,'rewardBtn'])
Z([3,'formOutInfo'])
Z([[2,'&&'],[[2,'!'],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,9]]],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,1]],[1,'1']]])
Z([[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,9]])
Z([[2,'&&'],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,1]],[1,'2']],[[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD10']],[1,0]],[1,'open']]])
Z(z[27])
Z(z[28])
Z(z[29])
Z([3,'reward'])
Z(z[23])
Z(z[24])
Z(z[25])
Z([3,'margin-left:20rpx;'])
Z([3,'gorecom'])
Z([3,'findRecom'])
Z(z[25])
Z(z[39])
Z(z[23])
Z(z[24])
Z([3,'backHome'])
Z([3,'backMain'])
Z([3,'_backMain'])
Z([3,'top'])
Z(z[23])
Z(z[24])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadding'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'show']],[[7],[3,'_loadding']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'noMore']],[[7],[3,'_loadding']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'lowLoadding']],[[7],[3,'_loadding']]])
Z([3,'swiperLoadding'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'show']],[[7],[3,'animationLoadding']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'noMore']],[[7],[3,'animationLoadding']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'lowLoadding']],[[7],[3,'animationLoadding']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'loadFontShowNor']],[1,'noVideo']],[[7],[3,'animationLoadding']]])
Z([3,'maskLoadding'])
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'tevLayout'])
Z([[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']])
Z([3,'videoEnd'])
Z([3,'videoJINDU'])
Z([3,'goods-video'])
Z([3,'90'])
Z([1,false])
Z([[7],[3,'initialTime']])
Z([3,'txv1'])
Z([[6],[[7],[3,'videosrc']],[3,'vid']])
Z([3,'750rpx'])
Z([[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'1']])
Z(z[2])
Z(z[3])
Z(z[4])
Z([3,'0'])
Z(z[6])
Z([a,[[7],[3,'scrollHeight']],[3,'px']])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[10])
Z([[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']])
Z(z[2])
Z(z[3])
Z(z[4])
Z(z[5])
Z(z[6])
Z([a,[[7],[3,'selfVideoHight']],z[17][2]])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[10])
Z([3,'videoLayout'])
Z(z[1])
Z([3,'point_auto layoutVideoFlex'])
Z([3,'height:406.25rpx;'])
Z([[2,'!'],[[7],[3,'replayMask']]])
Z([[9],[[8],'replayMask',[[7],[3,'replayMask']]],[[8],'videosrc',[[7],[3,'videosrc']]]])
Z([3,'maskvideo'])
Z(z[11])
Z(z[35])
Z([a,[3,'height:'],z[17][1],[3,'px;']])
Z(z[37])
Z([[9],[[9],[[8],'replayMask',[[7],[3,'replayMask']]],[[8],'videosrc',[[7],[3,'videosrc']]]],[[8],'rendInfo',[[7],[3,'rendInfo']]]])
Z(z[39])
Z(z[22])
Z(z[35])
Z([a,z[42][1],z[28][1],z[42][3]])
Z(z[37])
Z(z[38])
Z(z[39])
Z(z[39])
Z([[7],[3,'replayMask']])
Z(z[11])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'rendInfo']],[3,'AD']],[3,'hasAD4']],[1,0]],[1,'open']])
Z([[6],[[7],[3,'rendInfo']],[3,'AD']])
Z([3,'hasAD4'])
Z([3,'container_back mb20 point_auto maskbrand'])
Z([[2,'&&'],[[7],[3,'replayMask']],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'<'],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
Z([[2,'&&'],[[7],[3,'replayMask']],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'1']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'>='],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'videoModule'])
Z([3,'module'])
Z([[7],[3,'item']])
Z([[6],[[7],[3,'module']],[3,'id']])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'_index'])
Z([3,'single'])
Z([[6],[[7],[3,'module']],[3,'list']])
Z([[6],[[7],[3,'single']],[3,'id']])
Z([[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[1,3]])
Z([[9],[[9],[[8],'adList',[[7],[3,'adList']]],[[8],'single',[[7],[3,'single']]]],[[8],'_index',[[7],[3,'_index']]]])
Z([3,'ProAD_list'])
Z([a,[[2,'?:'],[[2,'=='],[[7],[3,'list_style_grund']],[1,'default']],[1,'title_time'],[1,'barndTime']],[3,' '],[[2,'?:'],[[2,'==='],[[7],[3,'index']],[1,0]],[1,'mart20'],[1,'']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'index']],[1,0]],[[7],[3,'authorArgs']]])
Z(z[5])
Z(z[6])
Z(z[7])
Z(z[8])
Z([[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[1,4]])
Z(z[10])
Z([3,'ProAD_list_right'])
Z(z[5])
Z(z[6])
Z(z[7])
Z(z[8])
Z([[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[1,1]])
Z(z[10])
Z(z[11])
Z([[2,'=='],[[6],[[7],[3,'single']],[3,'ad']],[1,2]])
Z(z[10])
Z(z[11])
Z([3,'recommentModule'])
Z([3,'explrecommList'])
Z([3,'hotModule'])
Z(z[5])
Z(z[6])
Z([[6],[[7],[3,'videos']],[3,'data']])
Z([[6],[[7],[3,'single']],[3,'time']])
Z(z[25])
Z(z[10])
Z(z[11])
Z(z[28])
Z(z[10])
Z(z[11])
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'?:'],[[2,'!'],[[7],[3,'userFormIdFlag']]],[1,'point_none'],[1,'point_auto']])
Z([3,'position:absolute;top:0;left:0;z-index:9;'])
Z([3,'container_back'])
Z([[2,'!'],[[6],[[7],[3,'videosrc']],[3,'vid']]])
Z([[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']])
Z([3,'point_auto layoutVideoFlex'])
Z([a,[3,'height:'],[[7],[3,'selfVideoHight']],[3,'px;']])
Z([[2,'!'],[[7],[3,'replayMask']]])
Z(z[8])
Z([[7],[3,'replayMask']])
Z([[2,'&&'],[[7],[3,'replayMask']],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'<'],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
Z([[7],[3,'adimage2_close']])
Z([[2,'&&'],[[7],[3,'replayMask']],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'1']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'>='],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
Z(z[12])
Z(z[5])
Z([3,'videoEnd'])
Z([3,'startVideo'])
Z([3,'videoJINDU'])
Z([3,'goods-video'])
Z([3,'90'])
Z([1,false])
Z([a,z[7][2],[3,'px']])
Z([[7],[3,'initialTime']])
Z([3,'txv1'])
Z([[6],[[7],[3,'videosrc']],[3,'vid']])
Z([3,'750rpx'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'replayMask']]],[[2,'!'],[[7],[3,'replayMask1']]]])
Z(z[10])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'replayMask']],[[7],[3,'replayMask1']]],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'<'],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
Z(z[12])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'replayMask']],[[7],[3,'replayMask1']]],[[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'1']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'>='],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'0.8']]]]])
Z(z[12])
Z([[7],[3,'recommentNotice']])
Z(z[27])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'0']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'videosrc']],[3,'videoType']],[1,'2']],[[2,'<'],[[6],[[7],[3,'videosrc']],[3,'videoProportion']],[1,'1.2']]]])
Z([[2,'!'],[[7],[3,'recommentNotice']]])
Z(z[36])
Z(z[36])
Z([[2,'!'],[[7],[3,'shareCanvas']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
function gz$gwx_14(){
if( __WXML_GLOBAL__.ops_cached.$gwx_14)return __WXML_GLOBAL__.ops_cached.$gwx_14
__WXML_GLOBAL__.ops_cached.$gwx_14=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_14);return __WXML_GLOBAL__.ops_cached.$gwx_14
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./pages/compenents/adBrand/adBrand.wxml','./pages/compenents/adcompenent/adcompenent.wxml','./pages/compenents/pushTemplate/pushTemplate.wxml','./pages/compenents/richText/richText.wxml','./pages/imageAd/imageAd.wxml','./pages/newDetails/newDetails.wxml','../template/videoModule/videoModule.wxml','../template/videoLayout/videoLayout.wxml','../template/adBrand/adBrand.wxml','./pages/newVideo/newVideo.wxml','../template/loadding/loadding.wxml','./pages/operatorVideo/operatorVideo.wxml','./pages/template/adBrand/adBrand.wxml','./pages/template/loadding/loadding.wxml','./pages/template/videoLayout/videoLayout.wxml','./videoLayout.wxml','./pages/template/videoModule/videoModule.wxml','../adBrand/adBrand.wxml','./pages/videoAd/videoAd.wxml','./pages/webView/webView.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var xC=_n('view')
_rz(z,xC,'class',1,e,s,gg)
var oD=_v()
_(xC,oD)
if(_oz(z,2,e,s,gg)){oD.wxVkey=1
var fE=_v()
_(oD,fE)
if(_oz(z,3,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oD,cF)
if(_oz(z,4,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(oD,hG)
if(_oz(z,5,e,s,gg)){hG.wxVkey=1
}
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
}
else if(_oz(z,6,e,s,gg)){oD.wxVkey=2
var oH=_v()
_(oD,oH)
if(_oz(z,7,e,s,gg)){oH.wxVkey=1
}
oH.wxXCkey=1
}
else{oD.wxVkey=3
}
oD.wxXCkey=1
_(oB,xC)
}
oB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
var oJ=_v()
_(r,oJ)
var lK=function(tM,aL,eN,gg){
var oP=_v()
_(eN,oP)
if(_oz(z,3,tM,aL,gg)){oP.wxVkey=1
var xQ=_n('view')
_rz(z,xQ,'class',4,tM,aL,gg)
var oR=_v()
_(xQ,oR)
if(_oz(z,5,tM,aL,gg)){oR.wxVkey=1
}
var fS=_v()
_(xQ,fS)
if(_oz(z,6,tM,aL,gg)){fS.wxVkey=1
}
oR.wxXCkey=1
fS.wxXCkey=1
_(oP,xQ)
}
oP.wxXCkey=1
return eN
}
oJ.wxXCkey=2
_2z(z,1,lK,e,s,gg,oJ,'adModule','index','index')
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
var hU=_mz(z,'form',['bindsubmit',0,'class',1,'data-type',1,'reportSubmit',2],[],e,s,gg)
var oV=_n('slot')
_rz(z,oV,'name',4,e,s,gg)
_(hU,oV)
_(r,hU)
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
d_[x[3]]["element"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':element'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor1"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor1'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,8,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,10,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,9,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,1120)
}
else if(_oz(z,11,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',12,'bindtap',1,'data-appid',2,'data-href',3,'hoverClass',4,'style',5,'url',6],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,20,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,19,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,1395)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,22,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,21,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,1541)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,7,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor2"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor2'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,25,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,27,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,26,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,1735)
}
else if(_oz(z,28,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',29,'bindtap',1,'data-appid',2,'data-href',3,'hoverClass',4,'style',5,'url',6],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,37,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,36,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,2010)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,39,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,38,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,2156)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,24,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor3"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor3'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,42,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,44,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,43,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,2350)
}
else if(_oz(z,45,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',46,'bindtap',1,'data-appid',2,'data-href',3,'hoverClass',4,'style',5,'url',6],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,54,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,53,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,2625)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,56,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,55,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,2771)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,41,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor4"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor4'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,59,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,61,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,60,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,2965)
}
else if(_oz(z,62,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',63,'bindtap',1,'data-appid',2,'data-href',3,'hoverClass',4,'style',5,'url',6],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,71,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,70,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,3240)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,73,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,72,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,3386)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,58,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor5"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor5'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,76,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,78,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,77,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,3580)
}
else if(_oz(z,79,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',80,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,87,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,86,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,3821)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,89,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,88,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,3967)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,75,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor6"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor6'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,92,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,94,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,93,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,4161)
}
else if(_oz(z,95,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',96,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,103,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,102,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,4402)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,105,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,104,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,4548)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,91,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor7"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor7'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,108,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,110,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,109,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,4742)
}
else if(_oz(z,111,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',112,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,119,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,118,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,4983)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,121,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,120,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,5129)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,107,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor8"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor8'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,124,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,126,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,125,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,5323)
}
else if(_oz(z,127,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',128,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,135,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,134,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,5564)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,137,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,136,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,5710)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,123,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor9"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor9'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,140,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,142,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,141,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,5904)
}
else if(_oz(z,143,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',144,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,151,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,150,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,6145)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,153,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,152,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,6292)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,139,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor10"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor10'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,156,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,158,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,157,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,6488)
}
else if(_oz(z,159,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',160,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,167,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,166,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,6729)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,169,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,168,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,6876)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,155,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor11"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor11'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,172,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,174,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,173,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,7072)
}
else if(_oz(z,175,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',176,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,183,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,182,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,7313)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,185,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,184,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,7460)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,171,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor12"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor12'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,188,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,190,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,189,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,7656)
}
else if(_oz(z,191,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',192,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,199,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,198,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,7897)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,201,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,200,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,8044)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,187,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor13"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor13'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,204,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,206,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,205,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,8240)
}
else if(_oz(z,207,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',208,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,215,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,214,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,8481)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,217,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,216,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,8628)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,203,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor14"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor14'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,220,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,222,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,221,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,8824)
}
else if(_oz(z,223,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',224,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,231,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,230,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,9065)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,233,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,232,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,9212)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,219,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor15"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor15'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,236,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,238,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,237,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,9408)
}
else if(_oz(z,239,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',240,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,247,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,246,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,9649)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,249,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,248,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,9796)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,235,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor16"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor16'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,252,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,254,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,253,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,9992)
}
else if(_oz(z,255,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',256,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,263,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,262,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,10233)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,265,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,264,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,10380)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,251,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor17"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor17'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,268,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,270,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,269,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,10576)
}
else if(_oz(z,271,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',272,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,279,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,278,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,10817)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,281,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,280,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,10964)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,267,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor18"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor18'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,284,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,286,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,285,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,11160)
}
else if(_oz(z,287,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',288,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,295,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,294,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,11401)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,297,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,296,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,11548)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,283,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor19"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor19'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,300,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=_oz(z,302,fE,oD,gg)
var lK=_gd(x[3],oJ,e_,d_)
if(lK){
var aL=_1z(z,301,fE,oD,gg) || {}
var cur_globalf=gg.f
cI.wxXCkey=3
lK(aL,aL,cI,gg)
gg.f=cur_globalf
}
else _w(oJ,x[3],1,11744)
}
else if(_oz(z,303,fE,oD,gg)){oH.wxVkey=2
var tM=_mz(z,'view',['bindlongpress',304,'bindtap',1,'data-href',2,'hoverClass',3,'style',4,'url',5],[],fE,oD,gg)
var eN=_v()
_(tM,eN)
var bO=_oz(z,311,fE,oD,gg)
var oP=_gd(x[3],bO,e_,d_)
if(oP){
var xQ=_1z(z,310,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[3],1,11985)
_(oH,tM)
}
else{oH.wxVkey=3
var oR=_v()
_(oH,oR)
var fS=_oz(z,313,fE,oD,gg)
var cT=_gd(x[3],fS,e_,d_)
if(cT){
var hU=_1z(z,312,fE,oD,gg) || {}
var cur_globalf=gg.f
oR.wxXCkey=3
cT(hU,hU,oR,gg)
gg.f=cur_globalf
}
else _w(fS,x[3],1,12132)
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,299,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[3]]["rich-text-floor20"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':rich-text-floor20'
r.wxVkey=b
gg.f=$gdc(f_["./pages/compenents/richText/richText.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
var cI=_oz(z,317,fE,oD,gg)
var oJ=_gd(x[3],cI,e_,d_)
if(oJ){
var lK=_1z(z,316,fE,oD,gg) || {}
var cur_globalf=gg.f
oH.wxXCkey=3
oJ(lK,lK,oH,gg)
gg.f=cur_globalf
}
else _w(cI,x[3],1,12301)
return cF
}
oB.wxXCkey=2
_2z(z,315,xC,e,s,gg,oB,'item','index','')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
var oX=_v()
_(r,oX)
if(_oz(z,1,e,s,gg)){oX.wxVkey=1
var lY=_v()
_(oX,lY)
var aZ=_oz(z,3,e,s,gg)
var t1=_gd(x[3],aZ,e_,d_)
if(t1){
var e2=_1z(z,2,e,s,gg) || {}
var cur_globalf=gg.f
lY.wxXCkey=3
t1(e2,e2,lY,gg)
gg.f=cur_globalf
}
else _w(aZ,x[3],1,884)
}
else{oX.wxVkey=2
var b3=_v()
_(oX,b3)
var o4=_oz(z,5,e,s,gg)
var x5=_gd(x[3],o4,e_,d_)
if(x5){
var o6=_1z(z,4,e,s,gg) || {}
var cur_globalf=gg.f
b3.wxXCkey=3
x5(o6,o6,b3,gg)
gg.f=cur_globalf
}
else _w(o4,x[3],1,966)
}
oX.wxXCkey=1
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
var c8=_n('view')
_rz(z,c8,'class',0,e,s,gg)
var oBB=_n('richText')
_rz(z,oBB,'html',1,e,s,gg)
_(c8,oBB)
var h9=_v()
_(c8,h9)
if(_oz(z,2,e,s,gg)){h9.wxVkey=1
}
var o0=_v()
_(c8,o0)
if(_oz(z,3,e,s,gg)){o0.wxVkey=1
}
var cAB=_v()
_(c8,cAB)
if(_oz(z,4,e,s,gg)){cAB.wxVkey=1
}
h9.wxXCkey=1
o0.wxXCkey=1
cAB.wxXCkey=1
_(r,c8)
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
var aDB=e_[x[5]].i
_ai(aDB,x[6],e_,x[5],1,1)
_ai(aDB,x[7],e_,x[5],1,65)
_ai(aDB,x[8],e_,x[5],1,129)
var tEB=_n('view')
_rz(z,tEB,'class',0,e,s,gg)
var eFB=_v()
_(tEB,eFB)
if(_oz(z,1,e,s,gg)){eFB.wxVkey=1
var oHB=_n('pushTemp')
_rz(z,oHB,'bindcustomevent',2,e,s,gg)
_(eFB,oHB)
}
var xIB=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var lQB=_n('view')
_rz(z,lQB,'class',5,e,s,gg)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,6,e,s,gg)){aRB.wxVkey=1
var xWB=_n('view')
_rz(z,xWB,'class',7,e,s,gg)
var oXB=_v()
_(xWB,oXB)
if(_oz(z,8,e,s,gg)){oXB.wxVkey=1
var fYB=_n('pushTemp')
_rz(z,fYB,'bindcustomevent',9,e,s,gg)
var cZB=_mz(z,'view',['class',10,'slot',1],[],e,s,gg)
var h1B=_v()
_(cZB,h1B)
if(_oz(z,12,e,s,gg)){h1B.wxVkey=1
}
h1B.wxXCkey=1
_(fYB,cZB)
_(oXB,fYB)
}
else{oXB.wxVkey=2
var o2B=_v()
_(oXB,o2B)
if(_oz(z,13,e,s,gg)){o2B.wxVkey=1
}
o2B.wxXCkey=1
}
oXB.wxXCkey=1
oXB.wxXCkey=3
_(aRB,xWB)
}
var tSB=_v()
_(lQB,tSB)
if(_oz(z,14,e,s,gg)){tSB.wxVkey=1
var c3B=_mz(z,'adBrand',['ADdata',15,'_class',1,'_index',2,'showFlag',3],[],e,s,gg)
_(tSB,c3B)
}
var eTB=_v()
_(lQB,eTB)
if(_oz(z,19,e,s,gg)){eTB.wxVkey=1
var o4B=_v()
_(eTB,o4B)
var l5B=_oz(z,21,e,s,gg)
var a6B=_gd(x[5],l5B,e_,d_)
if(a6B){
var t7B=_1z(z,20,e,s,gg) || {}
var cur_globalf=gg.f
o4B.wxXCkey=3
a6B(t7B,t7B,o4B,gg)
gg.f=cur_globalf
}
else _w(l5B,x[5],1,1746)
}
else{eTB.wxVkey=2
var e8B=_v()
_(eTB,e8B)
var b9B=_oz(z,23,e,s,gg)
var o0B=_gd(x[5],b9B,e_,d_)
if(o0B){
var xAC=_1z(z,22,e,s,gg) || {}
var cur_globalf=gg.f
e8B.wxXCkey=3
o0B(xAC,xAC,e8B,gg)
gg.f=cur_globalf
}
else _w(b9B,x[5],1,1906)
}
var bUB=_v()
_(lQB,bUB)
if(_oz(z,24,e,s,gg)){bUB.wxVkey=1
}
var oBC=_n('view')
_rz(z,oBC,'class',25,e,s,gg)
var fCC=_v()
_(oBC,fCC)
if(_oz(z,26,e,s,gg)){fCC.wxVkey=1
var cDC=_n('pushTemp')
_rz(z,cDC,'bindcustomevent',27,e,s,gg)
_(fCC,cDC)
}
else{fCC.wxVkey=2
}
fCC.wxXCkey=1
fCC.wxXCkey=3
_(lQB,oBC)
var oVB=_v()
_(lQB,oVB)
if(_oz(z,28,e,s,gg)){oVB.wxVkey=1
}
var hEC=_n('view')
_rz(z,hEC,'class',29,e,s,gg)
var oFC=_v()
_(hEC,oFC)
if(_oz(z,30,e,s,gg)){oFC.wxVkey=1
}
var cGC=_n('view')
_rz(z,cGC,'class',31,e,s,gg)
var oHC=_v()
_(cGC,oHC)
if(_oz(z,32,e,s,gg)){oHC.wxVkey=1
var tKC=_v()
_(oHC,tKC)
var eLC=_oz(z,34,e,s,gg)
var bMC=_gd(x[5],eLC,e_,d_)
if(bMC){
var oNC=_1z(z,33,e,s,gg) || {}
var cur_globalf=gg.f
tKC.wxXCkey=3
bMC(oNC,oNC,tKC,gg)
gg.f=cur_globalf
}
else _w(eLC,x[5],1,3934)
}
var lIC=_v()
_(cGC,lIC)
if(_oz(z,35,e,s,gg)){lIC.wxVkey=1
var xOC=_v()
_(lIC,xOC)
var oPC=_oz(z,37,e,s,gg)
var fQC=_gd(x[5],oPC,e_,d_)
if(fQC){
var cRC=_1z(z,36,e,s,gg) || {}
var cur_globalf=gg.f
xOC.wxXCkey=3
fQC(cRC,cRC,xOC,gg)
gg.f=cur_globalf
}
else _w(oPC,x[5],1,4042)
}
var aJC=_v()
_(cGC,aJC)
if(_oz(z,38,e,s,gg)){aJC.wxVkey=1
var hSC=_v()
_(aJC,hSC)
var oTC=_oz(z,40,e,s,gg)
var cUC=_gd(x[5],oTC,e_,d_)
if(cUC){
var oVC=_1z(z,39,e,s,gg) || {}
var cur_globalf=gg.f
hSC.wxXCkey=3
cUC(oVC,oVC,hSC,gg)
gg.f=cur_globalf
}
else _w(oTC,x[5],1,4153)
}
var lWC=_v()
_(cGC,lWC)
var aXC=_oz(z,42,e,s,gg)
var tYC=_gd(x[5],aXC,e_,d_)
if(tYC){
var eZC=_1z(z,41,e,s,gg) || {}
var cur_globalf=gg.f
lWC.wxXCkey=3
tYC(eZC,eZC,lWC,gg)
gg.f=cur_globalf
}
else _w(aXC,x[5],1,4246)
oHC.wxXCkey=1
lIC.wxXCkey=1
aJC.wxXCkey=1
_(hEC,cGC)
oFC.wxXCkey=1
_(lQB,hEC)
aRB.wxXCkey=1
aRB.wxXCkey=3
tSB.wxXCkey=1
tSB.wxXCkey=3
eTB.wxXCkey=1
bUB.wxXCkey=1
oVB.wxXCkey=1
_(xIB,lQB)
var oJB=_v()
_(xIB,oJB)
if(_oz(z,43,e,s,gg)){oJB.wxVkey=1
var b1C=_mz(z,'adBrand',['ADdata',44,'_index',1,'class',2,'showFlag',3],[],e,s,gg)
_(oJB,b1C)
}
var o2C=_n('view')
_rz(z,o2C,'class',48,e,s,gg)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,49,e,s,gg)){x3C.wxVkey=1
var h7C=_v()
_(x3C,h7C)
if(_oz(z,50,e,s,gg)){h7C.wxVkey=1
var o8C=_mz(z,'pushTemp',['bindcustomevent',51,'class',1],[],e,s,gg)
_(h7C,o8C)
}
else{h7C.wxVkey=2
}
h7C.wxXCkey=1
h7C.wxXCkey=3
}
var o4C=_v()
_(o2C,o4C)
if(_oz(z,53,e,s,gg)){o4C.wxVkey=1
var c9C=_v()
_(o4C,c9C)
if(_oz(z,54,e,s,gg)){c9C.wxVkey=1
var o0C=_mz(z,'pushTemp',['bindcustomevent',55,'class',1],[],e,s,gg)
_(c9C,o0C)
}
else{c9C.wxVkey=2
}
c9C.wxXCkey=1
c9C.wxXCkey=3
}
var f5C=_v()
_(o2C,f5C)
if(_oz(z,57,e,s,gg)){f5C.wxVkey=1
var lAD=_v()
_(f5C,lAD)
if(_oz(z,58,e,s,gg)){lAD.wxVkey=1
var aBD=_mz(z,'pushTemp',['bindcustomevent',59,'class',1],[],e,s,gg)
_(lAD,aBD)
}
else{lAD.wxVkey=2
}
lAD.wxXCkey=1
lAD.wxXCkey=3
}
var c6C=_v()
_(o2C,c6C)
if(_oz(z,61,e,s,gg)){c6C.wxVkey=1
var tCD=_v()
_(c6C,tCD)
if(_oz(z,62,e,s,gg)){tCD.wxVkey=1
var eDD=_mz(z,'pushTemp',['bindcustomevent',63,'class',1],[],e,s,gg)
_(tCD,eDD)
}
else{tCD.wxVkey=2
}
tCD.wxXCkey=1
tCD.wxXCkey=3
}
x3C.wxXCkey=1
x3C.wxXCkey=3
o4C.wxXCkey=1
o4C.wxXCkey=3
f5C.wxXCkey=1
f5C.wxXCkey=3
c6C.wxXCkey=1
c6C.wxXCkey=3
_(xIB,o2C)
var fKB=_v()
_(xIB,fKB)
if(_oz(z,65,e,s,gg)){fKB.wxVkey=1
var bED=_mz(z,'adBrand',['ADdata',66,'_index',1,'class',2,'showFlag',3],[],e,s,gg)
_(fKB,bED)
}
var cLB=_v()
_(xIB,cLB)
if(_oz(z,70,e,s,gg)){cLB.wxVkey=1
var oFD=_v()
_(cLB,oFD)
var xGD=_oz(z,72,e,s,gg)
var oHD=_gd(x[5],xGD,e_,d_)
if(oHD){
var fID=_1z(z,71,e,s,gg) || {}
var cur_globalf=gg.f
oFD.wxXCkey=3
oHD(fID,fID,oFD,gg)
gg.f=cur_globalf
}
else _w(xGD,x[5],1,10266)
}
var hMB=_v()
_(xIB,hMB)
if(_oz(z,73,e,s,gg)){hMB.wxVkey=1
var cJD=_mz(z,'adBrand',['ADdata',74,'_border',1,'_index',2,'bindborderFn',3,'class',4,'showFlag',5,'style',6],[],e,s,gg)
_(hMB,cJD)
}
var oNB=_v()
_(xIB,oNB)
if(_oz(z,81,e,s,gg)){oNB.wxVkey=1
var hKD=_v()
_(oNB,hKD)
var oLD=_oz(z,83,e,s,gg)
var cMD=_gd(x[5],oLD,e_,d_)
if(cMD){
var oND=_1z(z,82,e,s,gg) || {}
var cur_globalf=gg.f
hKD.wxXCkey=3
cMD(oND,oND,hKD,gg)
gg.f=cur_globalf
}
else _w(oLD,x[5],1,10754)
}
var cOB=_v()
_(xIB,cOB)
if(_oz(z,84,e,s,gg)){cOB.wxVkey=1
}
var oPB=_v()
_(xIB,oPB)
if(_oz(z,85,e,s,gg)){oPB.wxVkey=1
var lOD=_mz(z,'adBrand',['ADdata',86,'_index',1,'class',2,'showFlag',3],[],e,s,gg)
_(oPB,lOD)
}
var aPD=_mz(z,'view',['bindtap',90,'class',1,'data-flag',2],[],e,s,gg)
var tQD=_v()
_(aPD,tQD)
if(_oz(z,93,e,s,gg)){tQD.wxVkey=1
var eRD=_n('pushTemp')
_rz(z,eRD,'bindcustomevent',94,e,s,gg)
_(tQD,eRD)
}
else{tQD.wxVkey=2
}
tQD.wxXCkey=1
tQD.wxXCkey=3
_(xIB,aPD)
oJB.wxXCkey=1
oJB.wxXCkey=3
fKB.wxXCkey=1
fKB.wxXCkey=3
cLB.wxXCkey=1
hMB.wxXCkey=1
hMB.wxXCkey=3
oNB.wxXCkey=1
cOB.wxXCkey=1
oPB.wxXCkey=1
oPB.wxXCkey=3
_(tEB,xIB)
var bGB=_v()
_(tEB,bGB)
if(_oz(z,95,e,s,gg)){bGB.wxVkey=1
}
eFB.wxXCkey=1
eFB.wxXCkey=3
bGB.wxXCkey=1
_(r,tEB)
aDB.pop()
aDB.pop()
aDB.pop()
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[x[6],x[7],x[8]],ic:[]}
d_[x[9]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
var oTD=e_[x[9]].i
_ai(oTD,x[6],e_,x[9],1,1)
_ai(oTD,x[10],e_,x[9],1,65)
var xUD=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oVD=_v()
_(xUD,oVD)
if(_oz(z,2,e,s,gg)){oVD.wxVkey=1
}
var fWD=_v()
_(xUD,fWD)
if(_oz(z,3,e,s,gg)){fWD.wxVkey=1
var cXD=_v()
_(fWD,cXD)
var hYD=_oz(z,4,e,s,gg)
var oZD=_gd(x[9],hYD,e_,d_)
if(oZD){
var c1D={}
var cur_globalf=gg.f
cXD.wxXCkey=3
oZD(c1D,c1D,cXD,gg)
gg.f=cur_globalf
}
else _w(hYD,x[9],1,1221)
}
var o2D=_mz(z,'swiper',['circular',-1,'bindanimationfinish',5,'bindchange',1,'class',2,'current',3,'duration',4,'style',5],[],e,s,gg)
var l3D=_v()
_(o2D,l3D)
var a4D=function(e6D,t5D,b7D,gg){
var x9D=_n('swiper-item')
_rz(z,x9D,'id',14,e6D,t5D,gg)
var o0D=_v()
_(x9D,o0D)
if(_oz(z,16,e6D,t5D,gg)){o0D.wxVkey=1
var fAE=_mz(z,'view',['class',17,'id',1],[],e6D,t5D,gg)
var cBE=_v()
_(fAE,cBE)
var hCE=_oz(z,20,e6D,t5D,gg)
var oDE=_gd(x[9],hCE,e_,d_)
if(oDE){
var cEE=_1z(z,19,e6D,t5D,gg) || {}
var cur_globalf=gg.f
cBE.wxXCkey=3
oDE(cEE,cEE,cBE,gg)
gg.f=cur_globalf
}
else _w(hCE,x[9],1,1744)
var oFE=_v()
_(fAE,oFE)
var lGE=_oz(z,22,e6D,t5D,gg)
var aHE=_gd(x[9],lGE,e_,d_)
if(aHE){
var tIE=_1z(z,21,e6D,t5D,gg) || {}
var cur_globalf=gg.f
oFE.wxXCkey=3
aHE(tIE,tIE,oFE,gg)
gg.f=cur_globalf
}
else _w(lGE,x[9],1,1822)
_(o0D,fAE)
}
o0D.wxXCkey=1
_(b7D,x9D)
return b7D
}
l3D.wxXCkey=2
_2z(z,12,a4D,e,s,gg,l3D,'item','index','index')
_(xUD,o2D)
oVD.wxXCkey=1
fWD.wxXCkey=1
_(r,xUD)
oTD.pop()
oTD.pop()
return r
}
e_[x[9]]={f:m6,j:[],i:[],ti:[x[6],x[10]],ic:[]}
d_[x[11]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
var bKE=e_[x[11]].i
_ai(bKE,x[6],e_,x[11],1,1)
_ai(bKE,x[10],e_,x[11],1,65)
var oLE=_n('view')
_rz(z,oLE,'class',0,e,s,gg)
var xME=_v()
_(oLE,xME)
if(_oz(z,1,e,s,gg)){xME.wxVkey=1
}
var oNE=_v()
_(oLE,oNE)
if(_oz(z,2,e,s,gg)){oNE.wxVkey=1
var fOE=_v()
_(oNE,fOE)
var cPE=_oz(z,3,e,s,gg)
var hQE=_gd(x[11],cPE,e_,d_)
if(hQE){
var oRE={}
var cur_globalf=gg.f
fOE.wxXCkey=3
hQE(oRE,oRE,fOE,gg)
gg.f=cur_globalf
}
else _w(cPE,x[11],1,532)
}
var cSE=_n('view')
_rz(z,cSE,'class',4,e,s,gg)
var oTE=_v()
_(cSE,oTE)
if(_oz(z,5,e,s,gg)){oTE.wxVkey=1
var lUE=_v()
_(oTE,lUE)
var aVE=_oz(z,7,e,s,gg)
var tWE=_gd(x[11],aVE,e_,d_)
if(tWE){
var eXE=_1z(z,6,e,s,gg) || {}
var cur_globalf=gg.f
lUE.wxXCkey=3
tWE(eXE,eXE,lUE,gg)
gg.f=cur_globalf
}
else _w(aVE,x[11],1,720)
}
else{oTE.wxVkey=2
var bYE=_v()
_(oTE,bYE)
var oZE=_oz(z,9,e,s,gg)
var x1E=_gd(x[11],oZE,e_,d_)
if(x1E){
var o2E=_1z(z,8,e,s,gg) || {}
var cur_globalf=gg.f
bYE.wxXCkey=3
x1E(o2E,o2E,bYE,gg)
gg.f=cur_globalf
}
else _w(oZE,x[11],1,832)
}
var f3E=_v()
_(cSE,f3E)
var c4E=_oz(z,11,e,s,gg)
var h5E=_gd(x[11],c4E,e_,d_)
if(h5E){
var o6E=_1z(z,10,e,s,gg) || {}
var cur_globalf=gg.f
f3E.wxXCkey=3
h5E(o6E,o6E,f3E,gg)
gg.f=cur_globalf
}
else _w(c4E,x[11],1,918)
oTE.wxXCkey=1
_(oLE,cSE)
xME.wxXCkey=1
oNE.wxXCkey=1
_(r,oLE)
bKE.pop()
bKE.pop()
return r
}
e_[x[11]]={f:m7,j:[],i:[],ti:[x[6],x[10]],ic:[]}
d_[x[12]]={}
d_[x[12]]["ProAD_list"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':ProAD_list'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,4,fE,oD,gg)){oH.wxVkey=1
var cI=_mz(z,'adBrand',['ADdata',5,'_class',1,'class',2],[],fE,oD,gg)
_(oH,cI)
}
oH.wxXCkey=1
oH.wxXCkey=3
return cF
}
oB.wxXCkey=4
_2z(z,2,xC,e,s,gg,oB,'adModule','index','index')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["ProAD_list_right"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':ProAD_list_right'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,12,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
if(_oz(z,13,fE,oD,gg)){cI.wxVkey=1
var oJ=_n('view')
_rz(z,oJ,'class',14,fE,oD,gg)
var lK=_v()
_(oJ,lK)
if(_oz(z,15,fE,oD,gg)){lK.wxVkey=1
}
var aL=_v()
_(oJ,aL)
if(_oz(z,16,fE,oD,gg)){aL.wxVkey=1
}
lK.wxXCkey=1
aL.wxXCkey=1
_(cI,oJ)
}
cI.wxXCkey=1
}
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,10,xC,e,s,gg,oB,'adModule','index','index')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["ProAD"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':ProAD'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,18,e,s,gg)){oB.wxVkey=1
var xC=_n('view')
_rz(z,xC,'class',19,e,s,gg)
var oD=_v()
_(xC,oD)
if(_oz(z,20,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(xC,fE)
if(_oz(z,21,e,s,gg)){fE.wxVkey=1
}
oD.wxXCkey=1
fE.wxXCkey=1
_(oB,xC)
}
oB.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["camero"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':camero'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,23,e,s,gg)){oB.wxVkey=1
var xC=_mz(z,'pushTemp',['bindcustomevent',24,'class',1],[],e,s,gg)
var oD=_n('view')
_rz(z,oD,'slot',26,e,s,gg)
var fE=_v()
_(oD,fE)
if(_oz(z,27,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oD,cF)
if(_oz(z,28,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(oD,hG)
if(_oz(z,29,e,s,gg)){hG.wxVkey=1
}
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
_(xC,oD)
_(oB,xC)
}
else{oB.wxVkey=2
var oH=_v()
_(oB,oH)
if(_oz(z,30,e,s,gg)){oH.wxVkey=1
}
var cI=_v()
_(oB,cI)
if(_oz(z,31,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(oB,oJ)
if(_oz(z,32,e,s,gg)){oJ.wxVkey=1
}
oH.wxXCkey=1
cI.wxXCkey=1
oJ.wxXCkey=1
}
oB.wxXCkey=1
oB.wxXCkey=3
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["reward"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':reward'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,34,e,s,gg)){oB.wxVkey=1
var xC=_mz(z,'pushTemp',['bindcustomevent',35,'class',1,'style',2],[],e,s,gg)
_(oB,xC)
}
else{oB.wxVkey=2
}
oB.wxXCkey=1
oB.wxXCkey=3
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["gorecom"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':gorecom'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_mz(z,'view',['bindtap',39,'class',1,'id',2],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,42,e,s,gg)){xC.wxVkey=1
var oD=_n('pushTemp')
_rz(z,oD,'bindcustomevent',43,e,s,gg)
_(xC,oD)
}
else{xC.wxVkey=2
}
xC.wxXCkey=1
xC.wxXCkey=3
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[12]]["backHome"]=function(e,s,r,gg){
var z=gz$gwx_9()
var b=x[12]+':backHome'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/adBrand/adBrand.wxml"],"",1)
if(p_[b]){_wl(b,x[12]);return}
p_[b]=true
try{
var oB=_mz(z,'view',['bindtap',45,'class',1,'data-flag',2],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,48,e,s,gg)){xC.wxVkey=1
var oD=_n('pushTemp')
_rz(z,oD,'bindcustomevent',49,e,s,gg)
_(xC,oD)
}
else{xC.wxVkey=2
}
xC.wxXCkey=1
xC.wxXCkey=3
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
return r
}
e_[x[12]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
d_[x[13]]["loadding"]=function(e,s,r,gg){
var z=gz$gwx_10()
var b=x[13]+':loadding'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/loadding/loadding.wxml"],"",1)
if(p_[b]){_wl(b,x[13]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,1,e,s,gg)){oB.wxVkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,2,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(r,oD)
if(_oz(z,3,e,s,gg)){oD.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[13]]["swiperLoadding"]=function(e,s,r,gg){
var z=gz$gwx_10()
var b=x[13]+':swiperLoadding'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/loadding/loadding.wxml"],"",1)
if(p_[b]){_wl(b,x[13]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,5,e,s,gg)){oB.wxVkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,6,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(r,oD)
if(_oz(z,7,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(r,fE)
if(_oz(z,8,e,s,gg)){fE.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[13]]["maskLoadding"]=function(e,s,r,gg){
var z=gz$gwx_10()
var b=x[13]+':maskLoadding'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/loadding/loadding.wxml"],"",1)
if(p_[b]){_wl(b,x[13]);return}
p_[b]=true
try{
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
return r
}
e_[x[13]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
d_[x[14]]["tevLayout"]=function(e,s,r,gg){
var z=gz$gwx_11()
var b=x[14]+':tevLayout'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoLayout/videoLayout.wxml"],"",1)
if(p_[b]){_wl(b,x[14]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,1,e,s,gg)){oB.wxVkey=1
var fE=_mz(z,'txv-video',['autoplay',-1,'bindended',2,'bindtimeupdate',1,'class',2,'direction',3,'enableProgressGesture',4,'initialTime',5,'playerid',6,'vid',7,'width',8],[],e,s,gg)
_(oB,fE)
}
var xC=_v()
_(r,xC)
if(_oz(z,11,e,s,gg)){xC.wxVkey=1
var cF=_mz(z,'txv-video',['autoplay',-1,'bindended',12,'bindtimeupdate',1,'class',2,'direction',3,'enableProgressGesture',4,'height',5,'initialTime',6,'playerid',7,'vid',8,'width',9],[],e,s,gg)
_(xC,cF)
}
var oD=_v()
_(r,oD)
if(_oz(z,22,e,s,gg)){oD.wxVkey=1
var hG=_mz(z,'txv-video',['autoplay',-1,'bindended',23,'bindtimeupdate',1,'class',2,'direction',3,'enableProgressGesture',4,'height',5,'initialTime',6,'playerid',7,'vid',8,'width',9],[],e,s,gg)
_(oD,hG)
}
oB.wxXCkey=1
oB.wxXCkey=3
xC.wxXCkey=1
xC.wxXCkey=3
oD.wxXCkey=1
oD.wxXCkey=3
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[14]]["videoLayout"]=function(e,s,r,gg){
var z=gz$gwx_11()
var b=x[14]+':videoLayout'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoLayout/videoLayout.wxml"],"",1)
if(p_[b]){_wl(b,x[14]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,34,e,s,gg)){oB.wxVkey=1
var fE=_mz(z,'view',['class',35,'style',1],[],e,s,gg)
var cF=_v()
_(fE,cF)
if(_oz(z,37,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(fE,hG)
var oH=_oz(z,39,e,s,gg)
var cI=_gd(x[14],oH,e_,d_)
if(cI){
var oJ=_1z(z,38,e,s,gg) || {}
var cur_globalf=gg.f
hG.wxXCkey=3
cI(oJ,oJ,hG,gg)
gg.f=cur_globalf
}
else _w(oH,x[14],1,1576)
cF.wxXCkey=1
_(oB,fE)
}
var xC=_v()
_(r,xC)
if(_oz(z,40,e,s,gg)){xC.wxVkey=1
var lK=_mz(z,'view',['class',41,'style',1],[],e,s,gg)
var aL=_v()
_(lK,aL)
if(_oz(z,43,e,s,gg)){aL.wxVkey=1
}
var tM=_v()
_(lK,tM)
var eN=_oz(z,45,e,s,gg)
var bO=_gd(x[14],eN,e_,d_)
if(bO){
var oP=_1z(z,44,e,s,gg) || {}
var cur_globalf=gg.f
tM.wxXCkey=3
bO(oP,oP,tM,gg)
gg.f=cur_globalf
}
else _w(eN,x[14],1,2046)
aL.wxXCkey=1
_(xC,lK)
}
var oD=_v()
_(r,oD)
if(_oz(z,46,e,s,gg)){oD.wxVkey=1
var xQ=_mz(z,'view',['class',47,'style',1],[],e,s,gg)
var oR=_v()
_(xQ,oR)
if(_oz(z,49,e,s,gg)){oR.wxVkey=1
}
var fS=_v()
_(xQ,fS)
var cT=_oz(z,51,e,s,gg)
var hU=_gd(x[14],cT,e_,d_)
if(hU){
var oV=_1z(z,50,e,s,gg) || {}
var cur_globalf=gg.f
fS.wxXCkey=3
hU(oV,oV,fS,gg)
gg.f=cur_globalf
}
else _w(cT,x[14],1,2552)
oR.wxXCkey=1
_(oD,xQ)
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[14]]["maskvideo"]=function(e,s,r,gg){
var z=gz$gwx_11()
var b=x[14]+':maskvideo'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoLayout/videoLayout.wxml"],"",1)
if(p_[b]){_wl(b,x[14]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,53,e,s,gg)){oB.wxVkey=1
var fE=_v()
_(oB,fE)
if(_oz(z,54,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oB,cF)
if(_oz(z,55,e,s,gg)){cF.wxVkey=1
var hG=_mz(z,'adBrand',['ADdata',56,'_index',1,'class',2],[],e,s,gg)
_(cF,hG)
}
fE.wxXCkey=1
cF.wxXCkey=1
cF.wxXCkey=3
}
var xC=_v()
_(r,xC)
if(_oz(z,59,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(r,oD)
if(_oz(z,60,e,s,gg)){oD.wxVkey=1
}
oB.wxXCkey=1
oB.wxXCkey=3
xC.wxXCkey=1
oD.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
var a0E=e_[x[14]].i
_ai(a0E,x[15],e_,x[14],1,1)
a0E.pop()
return r
}
e_[x[14]]={f:m10,j:[],i:[],ti:[x[15]],ic:[]}
d_[x[16]]={}
d_[x[16]]["videoModule"]=function(e,s,r,gg){
var z=gz$gwx_12()
var b=x[16]+':videoModule'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoModule/videoModule.wxml"],"",1)
if(p_[b]){_wl(b,x[16]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,4,fE,oD,gg)){oH.wxVkey=1
var cI=_v()
_(oH,cI)
var oJ=function(aL,lK,tM,gg){
var bO=_v()
_(tM,bO)
if(_oz(z,9,aL,lK,gg)){bO.wxVkey=1
var oP=_v()
_(bO,oP)
var xQ=_oz(z,11,aL,lK,gg)
var oR=_gd(x[16],xQ,e_,d_)
if(oR){
var fS=_1z(z,10,aL,lK,gg) || {}
var cur_globalf=gg.f
oP.wxXCkey=3
oR(fS,fS,oP,gg)
gg.f=cur_globalf
}
else _w(xQ,x[16],1,284)
}
bO.wxXCkey=1
return tM
}
cI.wxXCkey=2
_2z(z,7,oJ,fE,oD,gg,cI,'single','_index','{{single.id}}')
}
var cT=_n('view')
_rz(z,cT,'class',12,fE,oD,gg)
var hU=_v()
_(cT,hU)
if(_oz(z,13,fE,oD,gg)){hU.wxVkey=1
}
else{hU.wxVkey=2
var oV=_v()
_(hU,oV)
var cW=function(lY,oX,aZ,gg){
var e2=_v()
_(aZ,e2)
if(_oz(z,18,lY,oX,gg)){e2.wxVkey=1
var b3=_v()
_(e2,b3)
var o4=_oz(z,20,lY,oX,gg)
var x5=_gd(x[16],o4,e_,d_)
if(x5){
var o6=_1z(z,19,lY,oX,gg) || {}
var cur_globalf=gg.f
b3.wxXCkey=3
x5(o6,o6,b3,gg)
gg.f=cur_globalf
}
else _w(o4,x[16],1,1159)
}
e2.wxXCkey=1
return aZ
}
oV.wxXCkey=2
_2z(z,16,cW,fE,oD,gg,oV,'single','_index','{{single.id}}')
}
hU.wxXCkey=1
_(cF,cT)
var f7=_v()
_(cF,f7)
var c8=function(o0,h9,cAB,gg){
var lCB=_v()
_(cAB,lCB)
if(_oz(z,25,o0,h9,gg)){lCB.wxVkey=1
var tEB=_v()
_(lCB,tEB)
var eFB=_oz(z,27,o0,h9,gg)
var bGB=_gd(x[16],eFB,e_,d_)
if(bGB){
var oHB=_1z(z,26,o0,h9,gg) || {}
var cur_globalf=gg.f
tEB.wxXCkey=3
bGB(oHB,oHB,tEB,gg)
gg.f=cur_globalf
}
else _w(eFB,x[16],1,1363)
}
var aDB=_v()
_(cAB,aDB)
if(_oz(z,28,o0,h9,gg)){aDB.wxVkey=1
var xIB=_v()
_(aDB,xIB)
var oJB=_oz(z,30,o0,h9,gg)
var fKB=_gd(x[16],oJB,e_,d_)
if(fKB){
var cLB=_1z(z,29,o0,h9,gg) || {}
var cur_globalf=gg.f
xIB.wxXCkey=3
fKB(cLB,cLB,xIB,gg)
gg.f=cur_globalf
}
else _w(oJB,x[16],1,1457)
}
lCB.wxXCkey=1
aDB.wxXCkey=1
return cAB
}
f7.wxXCkey=2
_2z(z,23,c8,fE,oD,gg,f7,'single','_index','{{single.id}}')
oH.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,2,xC,e,s,gg,oB,'module','index','{{module.id}}')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[16]]["recommentModule"]=function(e,s,r,gg){
var z=gz$gwx_12()
var b=x[16]+':recommentModule'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoModule/videoModule.wxml"],"",1)
if(p_[b]){_wl(b,x[16]);return}
p_[b]=true
try{
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[16]]["explrecommList"]=function(e,s,r,gg){
var z=gz$gwx_12()
var b=x[16]+':explrecommList'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoModule/videoModule.wxml"],"",1)
if(p_[b]){_wl(b,x[16]);return}
p_[b]=true
try{
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
d_[x[16]]["hotModule"]=function(e,s,r,gg){
var z=gz$gwx_12()
var b=x[16]+':hotModule'
r.wxVkey=b
gg.f=$gdc(f_["./pages/template/videoModule/videoModule.wxml"],"",1)
if(p_[b]){_wl(b,x[16]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
if(_oz(z,38,fE,oD,gg)){oH.wxVkey=1
var oJ=_v()
_(oH,oJ)
var lK=_oz(z,40,fE,oD,gg)
var aL=_gd(x[16],lK,e_,d_)
if(aL){
var tM=_1z(z,39,fE,oD,gg) || {}
var cur_globalf=gg.f
oJ.wxXCkey=3
aL(tM,tM,oJ,gg)
gg.f=cur_globalf
}
else _w(lK,x[16],1,4349)
}
var cI=_v()
_(cF,cI)
if(_oz(z,41,fE,oD,gg)){cI.wxVkey=1
var eN=_v()
_(cI,eN)
var bO=_oz(z,43,fE,oD,gg)
var oP=_gd(x[16],bO,e_,d_)
if(oP){
var xQ=_1z(z,42,fE,oD,gg) || {}
var cur_globalf=gg.f
eN.wxXCkey=3
oP(xQ,xQ,eN,gg)
gg.f=cur_globalf
}
else _w(bO,x[16],1,4443)
}
oH.wxXCkey=1
cI.wxXCkey=1
return cF
}
oB.wxXCkey=2
_2z(z,36,xC,e,s,gg,oB,'single','_index','{{single.time}}')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
var eBF=e_[x[16]].i
_ai(eBF,x[17],e_,x[16],1,1)
eBF.pop()
return r
}
e_[x[16]]={f:m11,j:[],i:[],ti:[x[17]],ic:[]}
d_[x[18]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var oDF=_n('view')
_rz(z,oDF,'class',0,e,s,gg)
var oFF=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var hIF=_n('view')
_rz(z,hIF,'class',3,e,s,gg)
var oJF=_v()
_(hIF,oJF)
if(_oz(z,4,e,s,gg)){oJF.wxVkey=1
var tOF=_v()
_(oJF,tOF)
if(_oz(z,5,e,s,gg)){tOF.wxVkey=1
var ePF=_mz(z,'view',['class',6,'style',1],[],e,s,gg)
var bQF=_v()
_(ePF,bQF)
if(_oz(z,8,e,s,gg)){bQF.wxVkey=1
}
var oRF=_v()
_(ePF,oRF)
if(_oz(z,9,e,s,gg)){oRF.wxVkey=1
}
var xSF=_v()
_(ePF,xSF)
if(_oz(z,10,e,s,gg)){xSF.wxVkey=1
}
var oTF=_v()
_(ePF,oTF)
if(_oz(z,11,e,s,gg)){oTF.wxVkey=1
var cVF=_v()
_(oTF,cVF)
if(_oz(z,12,e,s,gg)){cVF.wxVkey=1
}
cVF.wxXCkey=1
}
var fUF=_v()
_(ePF,fUF)
if(_oz(z,13,e,s,gg)){fUF.wxVkey=1
var hWF=_v()
_(fUF,hWF)
if(_oz(z,14,e,s,gg)){hWF.wxVkey=1
}
hWF.wxXCkey=1
}
bQF.wxXCkey=1
oRF.wxXCkey=1
xSF.wxXCkey=1
oTF.wxXCkey=1
fUF.wxXCkey=1
_(tOF,ePF)
}
tOF.wxXCkey=1
}
else{oJF.wxVkey=2
var oXF=_v()
_(oJF,oXF)
if(_oz(z,15,e,s,gg)){oXF.wxVkey=1
var cYF=_mz(z,'txv-video',['autoplay',-1,'bindended',16,'bindplay',1,'bindtimeupdate',2,'class',3,'direction',4,'enableProgressGesture',5,'height',6,'initialTime',7,'playerid',8,'vid',9,'width',10],[],e,s,gg)
var oZF=_v()
_(cYF,oZF)
if(_oz(z,27,e,s,gg)){oZF.wxVkey=1
}
var l1F=_v()
_(cYF,l1F)
if(_oz(z,28,e,s,gg)){l1F.wxVkey=1
}
var a2F=_v()
_(cYF,a2F)
if(_oz(z,29,e,s,gg)){a2F.wxVkey=1
var e4F=_v()
_(a2F,e4F)
if(_oz(z,30,e,s,gg)){e4F.wxVkey=1
}
e4F.wxXCkey=1
}
var t3F=_v()
_(cYF,t3F)
if(_oz(z,31,e,s,gg)){t3F.wxVkey=1
var b5F=_v()
_(t3F,b5F)
if(_oz(z,32,e,s,gg)){b5F.wxVkey=1
}
b5F.wxXCkey=1
}
oZF.wxXCkey=1
l1F.wxXCkey=1
a2F.wxXCkey=1
t3F.wxXCkey=1
_(oXF,cYF)
}
oXF.wxXCkey=1
oXF.wxXCkey=3
}
var cKF=_v()
_(hIF,cKF)
if(_oz(z,33,e,s,gg)){cKF.wxVkey=1
}
var oLF=_v()
_(hIF,oLF)
if(_oz(z,34,e,s,gg)){oLF.wxVkey=1
}
var lMF=_v()
_(hIF,lMF)
if(_oz(z,35,e,s,gg)){lMF.wxVkey=1
}
var aNF=_v()
_(hIF,aNF)
if(_oz(z,36,e,s,gg)){aNF.wxVkey=1
}
oJF.wxXCkey=1
oJF.wxXCkey=3
cKF.wxXCkey=1
oLF.wxXCkey=1
lMF.wxXCkey=1
aNF.wxXCkey=1
_(oFF,hIF)
var fGF=_v()
_(oFF,fGF)
if(_oz(z,37,e,s,gg)){fGF.wxVkey=1
}
var cHF=_v()
_(oFF,cHF)
if(_oz(z,38,e,s,gg)){cHF.wxVkey=1
}
fGF.wxXCkey=1
cHF.wxXCkey=1
_(oDF,oFF)
var xEF=_v()
_(oDF,xEF)
if(_oz(z,39,e,s,gg)){xEF.wxVkey=1
}
xEF.wxXCkey=1
_(r,oDF)
return r
}
e_[x[18]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[19]]={}
var m13=function(e,s,r,gg){
var z=gz$gwx_14()
return r
}
e_[x[19]]={f:m13,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['pages/compenents/adBrand/adBrand.json'] = {"component":true,"usingComponents":{"pushTemp":"../pushTemplate/pushTemplate"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/adBrand/adBrand.wxml'] = [$gwx, './pages/compenents/adBrand/adBrand.wxml'];else __wxAppCode__['pages/compenents/adBrand/adBrand.wxml'] = $gwx( './pages/compenents/adBrand/adBrand.wxml' );
		__wxAppCode__['pages/compenents/adcompenent/adcompenent.json'] = {"component":true};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/adcompenent/adcompenent.wxml'] = [$gwx, './pages/compenents/adcompenent/adcompenent.wxml'];else __wxAppCode__['pages/compenents/adcompenent/adcompenent.wxml'] = $gwx( './pages/compenents/adcompenent/adcompenent.wxml' );
		__wxAppCode__['pages/compenents/layoutPlace/layoutPlace.json'] = {
  "component": true
};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/layoutPlace/layoutPlace.wxml'] = [$gwx, './pages/compenents/layoutPlace/layoutPlace.wxml'];else __wxAppCode__['pages/compenents/layoutPlace/layoutPlace.wxml'] = $gwx( './pages/compenents/layoutPlace/layoutPlace.wxml' );
		__wxAppCode__['pages/compenents/navTab/navTab.json'] = {
  "component": true
};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/navTab/navTab.wxml'] = [$gwx, './pages/compenents/navTab/navTab.wxml'];else __wxAppCode__['pages/compenents/navTab/navTab.wxml'] = $gwx( './pages/compenents/navTab/navTab.wxml' );
		__wxAppCode__['pages/compenents/pushTemplate/pushTemplate.json'] = {"component":true};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/pushTemplate/pushTemplate.wxml'] = [$gwx, './pages/compenents/pushTemplate/pushTemplate.wxml'];else __wxAppCode__['pages/compenents/pushTemplate/pushTemplate.wxml'] = $gwx( './pages/compenents/pushTemplate/pushTemplate.wxml' );
		__wxAppCode__['pages/compenents/richText/richText.json'] = {"component":true};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/compenents/richText/richText.wxml'] = [$gwx, './pages/compenents/richText/richText.wxml'];else __wxAppCode__['pages/compenents/richText/richText.wxml'] = $gwx( './pages/compenents/richText/richText.wxml' );
		__wxAppCode__['pages/imageAd/imageAd.json'] = {"enablePullDownRefresh":false,"usingComponents":{"richText":"../compenents/richText/richText","adBrand":"../compenents/adBrand/adBrand","pushTemp":"../compenents/pushTemplate/pushTemplate","txv-video":"plugin://wxa75efa648b60994b/video"},"backgroundColor":"#000"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/imageAd/imageAd.wxml'] = [$gwx, './pages/imageAd/imageAd.wxml'];else __wxAppCode__['pages/imageAd/imageAd.wxml'] = $gwx( './pages/imageAd/imageAd.wxml' );
		__wxAppCode__['pages/index/index.json'] = {"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx( './pages/index/index.wxml' );
		__wxAppCode__['pages/logs/logs.json'] = {"navigationBarTitleText":"查看启动日志","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/logs/logs.wxml'] = [$gwx, './pages/logs/logs.wxml'];else __wxAppCode__['pages/logs/logs.wxml'] = $gwx( './pages/logs/logs.wxml' );
		__wxAppCode__['pages/newDetails/newDetails.json'] = {"enablePullDownRefresh":true,"usingComponents":{"pushTemp":"../compenents/pushTemplate/pushTemplate","adBrand":"../compenents/adBrand/adBrand","txv-video":"plugin://wxa75efa648b60994b/video"},"backgroundColor":"#000"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/newDetails/newDetails.wxml'] = [$gwx, './pages/newDetails/newDetails.wxml'];else __wxAppCode__['pages/newDetails/newDetails.wxml'] = $gwx( './pages/newDetails/newDetails.wxml' );
		__wxAppCode__['pages/newVideo/newVideo.json'] = {"enablePullDownRefresh":true,"usingComponents":{"pushTemp":"../compenents/pushTemplate/pushTemplate","adBrand":"../compenents/adBrand/adBrand"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/newVideo/newVideo.wxml'] = [$gwx, './pages/newVideo/newVideo.wxml'];else __wxAppCode__['pages/newVideo/newVideo.wxml'] = $gwx( './pages/newVideo/newVideo.wxml' );
		__wxAppCode__['pages/videoAd/videoAd.json'] = {"enablePullDownRefresh":true,"usingComponents":{"pushTemp":"../compenents/pushTemplate/pushTemplate","adBrand":"../compenents/adBrand/adBrand","txv-video":"plugin://wxa75efa648b60994b/video"},"backgroundColor":"#000"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/videoAd/videoAd.wxml'] = [$gwx, './pages/videoAd/videoAd.wxml'];else __wxAppCode__['pages/videoAd/videoAd.wxml'] = $gwx( './pages/videoAd/videoAd.wxml' );
		__wxAppCode__['pages/webView/webView.json'] = {"usingComponents":{},"backgroundTextStyle":"dark","navigationBarBackgroundColor":"#000","navigationBarTitleText":"小音视频","navigationBarTextStyle":"white"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/webView/webView.wxml'] = [$gwx, './pages/webView/webView.wxml'];else __wxAppCode__['pages/webView/webView.wxml'] = $gwx( './pages/webView/webView.wxml' );
	
	define("Parser/DomHandler.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,a){this.imgList=[],this.nodes=[],this._style=e(t,a||{}),this._tagStack=[]}function e(t,e){if(t){var a=t.match(/[^\{\}]+?\{([^\{\}]*?({[\s\S]*?})*)*?\}/g);if(a){var r=!0,i=!1,o=void 0;try{for(var n,l=a[Symbol.iterator]();!(r=(n=l.next()).done);r=!0){var s=n.value;try{var c=s.match(/(\S.*?)\{/)[1];if(c=c.replace(/\s*$/g,""),/[\s@>:]/.test(c))continue;var d=s.match(/\{([\s\S]*?)\}/)[1];if(/,/.test(s)){var h=c.split(","),p=!0,y=!1,f=void 0;try{for(var u,g=h[Symbol.iterator]();!(p=(u=g.next()).done);p=!0){var b=u.value;e[b=b[0]+b.substring(1).replace(/\./g," ")]=d}}catch(t){y=!0,f=t}finally{try{!p&&g.return&&g.return()}finally{if(y)throw f}}}else e[c=c[0]+c.substring(1).replace(/\./g," ")]=d}catch(t){continue}}}catch(t){i=!0,o=t}finally{try{!r&&l.return&&l.return()}finally{if(i)throw o}}}}return e.blockquote||(e.blockquote="background-color:#f6f6f6;border-left:3px solid #dbdbdb;color:#6c6c6c;padding:5px 0 5px 10px"),e.code||(e.code="padding:0 1px 0 1px;margin-left:2px;margin-right:2px;background-color:#f8f8f8;border:1px solid #cccccc;border-radius:3px"),e}var a={a:2,abbr:1,audio:2,b:1,blockquote:1,br:2,code:2,col:2,colgroup:2,dd:1,del:1,div:1,dl:1,dt:1,em:1,fieldset:1,font:1,h1:2,h2:2,h3:2,h4:2,h5:2,h6:2,hr:2,i:1,img:1,ins:1,label:1,legend:1,li:2,ol:2,p:1,pre:1,q:1,source:2,span:1,strong:1,sub:2,sup:2,table:2,tbody:2,td:2,tfoot:2,th:2,thead:2,tr:2,u:1,ul:2,video:1},r={b:!0,del:!0,em:!0,i:!0,ins:!0,q:!0,span:!0,strong:!0},i={head:!0,area:!0,base:!0,basefont:!0,command:!0,embed:!0,iframe:!0,frame:!0,input:!0,textarea:!0,isindex:!0,keygen:!0,link:!0,meta:!0,param:!0,track:!0,wbr:!0,path:!0,circle:!0,ellipse:!0,line:!0,rect:!0,use:!0,stop:!0,polyline:!0,polygon:!0,map:!0,canvas:!0};t.prototype._addDomElement=function(t){var e=this._tagStack[this._tagStack.length-1];(e?e.children:this.nodes).push(t)},t.prototype.onopentag=function(t,e){if(!i[t]){var o={children:[]};switch(this._style[t]&&(e.style+=";"+this._style[t]),this._style["."+e.class]&&(e.style+=";"+this._style["."+e.class]),this._style["#"+e.id]&&(e.style+=";"+this._style["#"+e.id]),a[t]||(t="div"),r[t]&&(o.continue=!0),t){case"div":case"p":e.align&&(e.style+=";text-align:"+e.align,delete e.align);break;case"img":e["data-src"]&&(e.src=e.src||e["data-src"],delete e["data-src"]);var n=e.style.match(/display:([^;]*)/i);if(e.display=n?n[1]:"inline-block",!e.hasOwnProperty("ignore")&&e.src){this.imgList.push(e.src);var l=!0,s=!1,c=void 0;try{for(var d,h=this._tagStack[Symbol.iterator]();!(l=(d=h.next()).done);l=!0){_=d.value;if(1!=a[_.name]){"a"==_.name&&(e.ignore="");break}_.continue=!0}}catch(t){s=!0,c=t}finally{try{!l&&h.return&&h.return()}finally{if(s)throw c}}}e.style="max-width:100%;"+e.style;break;case"font":t="span",e.color&&(e.style+=";color:"+e.color,delete e.color),e.face&&(e.style+=";font-family:"+e.face,delete e.face);break;case"a":o.continue=!0;var p=!0,y=!1,f=void 0;try{for(var u,g=this._tagStack[Symbol.iterator]();!(p=(u=g.next()).done);p=!0){_=u.value;if(1!=a[_.name])break;_.continue=!0}}catch(t){y=!0,f=t}finally{try{!p&&g.return&&g.return()}finally{if(y)throw f}}e.style="color:#366092;display:inline;word-break:break-all;overflow:auto;"+e.style;break;case"video":case"audio":e.loop=e.hasOwnProperty("loop"),e.controls=e.hasOwnProperty("controls");var b=!0,v=!1,m=void 0;try{for(var k,x=this._tagStack[Symbol.iterator]();!(b=(k=x.next()).done);b=!0){var _=k.value;if(1!=a[_.name])break;_.continue=!0}}catch(t){v=!0,m=t}finally{try{!b&&x.return&&x.return()}finally{if(v)throw m}}break;case"source":var S=this._tagStack[this._tagStack.length-1];return void(!S||"video"!=S.name&&"audio"!=S.name||(S.attrs.src=e.src));case"center":t="div",e.style="text-align:center;"+e.style;break;case"pre":t="div",e.style="background-color:#f6f8fa;padding:5px;margin:5px 0 5px 0;border-radius:5px;font-family:monospace;white-space:pre;overflow:scroll"+e.style;break;case"u":t="span",e.style="text-decoration:underline;"+e.style}o.name=t,o.attrs=e,this._addDomElement(o),this._tagStack.push(o)}},t.prototype.ontext=function(t){var e;if(!this._tagStack.length&&this.nodes.length&&"text"===(e=this.nodes[this.nodes.length-1]).type)e.data+=t;else if(this._tagStack.length&&(e=this._tagStack[this._tagStack.length-1])&&(e=e.children[e.children.length-1])&&"text"===e.type)e.data+=t;else{var a={text:t,type:"text"};if(/&#*((?!sp|lt|gt).){2,5};/.test(t)){a.decode=!0;var r=this._tagStack[this._tagStack.length-1];r&&r.continue&&delete r.continue}this._addDomElement(a)}},t.prototype.onclosetag=function(t){i[t]||this._tagStack.pop()},module.exports=t; 
 			}); 
		define("Parser/Parser.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,i){this._cbs=t,this._callback=i,this._tagname="",this._attribname="",this._attribvalue="",this._attribs=null,this._stack=[],this._tokenizer=new e(this)}var e=require("./Tokenizer.js"),i=require("./DomHandler.js"),s={align:!0,alt:!0,author:!0,class:!0,color:!0,colspan:!0,controls:!0,"data-src":!0,face:!0,height:!0,href:!0,id:!0,ignore:!0,language:!0,loop:!0,name:!0,poster:!0,rowspan:!0,span:!0,src:!0,start:!0,style:!0,type:!0,width:!0},a={area:!0,base:!0,basefont:!0,br:!0,col:!0,command:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,isindex:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0,path:!0,circle:!0,ellipse:!0,line:!0,rect:!0,use:!0,stop:!0,polyline:!0,polygon:!0};t.prototype.ontext=function(t){this._cbs.ontext(t)},t.prototype.onopentagname=function(t){t=t.toLowerCase(),this._tagname=t,this._attribs={style:""},a[t]||this._stack.push(t)},t.prototype.onopentagend=function(){if(this._attribs){if(this._cbs.onopentag(this._tagname,this._attribs),"pre"==this._tagname&&this._attribs.language)try{var t=require("./prism.js");if(t.languages[this._attribs.language]){var e=this._tokenizer._buffer.indexOf("</pre>",this._tokenizer._index);-1==e&&(e=this._tokenizer._buffer.length);var i=this._tokenizer._buffer.substring(this._tokenizer._index+1,e),s=t.highlight(i,t.languages[this._attribs.language],this._attribs.language);s=s.replace(/\n/g,"<br />"),this._tokenizer._buffer=this._tokenizer._buffer.replace(i,s)}}catch(t){console.warn("未装载代码高亮支持包")}this._attribs=null}a[this._tagname]&&this._cbs.onclosetag(this._tagname),this._tagname=""},t.prototype.onclosetag=function(t){if(t=t.toLowerCase(),this._stack.length&&!a[t]){var e=this._stack.lastIndexOf(t);if(-1!==e)for(e=this._stack.length-e;e--;)this._cbs.onclosetag(this._stack.pop());else"p"===t&&(this.onopentagname(t),this._closeCurrentTag())}else"br"!==t&&"hr"!==t&&"p"!==t||(this.onopentagname(t),this._closeCurrentTag())},t.prototype._closeCurrentTag=function(){var t=this._tagname;this.onopentagend(),this._stack[this._stack.length-1]===t&&(this._cbs.onclosetag(t),this._stack.pop())},t.prototype.onattribname=function(t){this._attribname=t},t.prototype.onattribdata=function(t){this._attribvalue+=t},t.prototype.onattribend=function(){this._attribname=this._attribname.toLowerCase(),this._attribvalue=this._attribvalue.replace(/(^\s*)|(\s*$)/g,"").replace("quot;",'"'),this._attribs&&s[this._attribname]&&(this._attribs[this._attribname]=this._attribvalue),this._attribname="",this._attribvalue=""},t.prototype.onend=function(){for(var t=this._stack.length;t>0;this._cbs.onclosetag(this._stack[--t]));this._callback({nodes:this._cbs.nodes,title:this._tokenizer._title,imgList:this._cbs.imgList})},t.prototype.write=function(t){this._tokenizer.parse(t)},module.exports=function(e,s){return new Promise(function(a,n){var r="";e=e.replace(/<style.*?>([\s\S]*?)<\/style>/gi,function(){return r+=arguments[1],""}),r=r.toLowerCase(),new t(new i(r,s),function(t){a(t)}).write(e)})}; 
 			}); 
		define("Parser/Tokenizer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){this._state="TEXT",this._title="",this._buffer="",this._sectionStart=0,this._index=0,this._cbs=t}t.prototype.TEXT=function(t){var e=this._buffer.indexOf("<",this._index);if(-1!=e){this._index=e;var i=this._getSection();/\S/.test(i)&&this._cbs.ontext(i),this._state="BeforeTag",this._sectionStart=this._index}else this._index=this._buffer.length},t.prototype.BeforeTag=function(t){switch(t){case"/":this._state="BeforeCloseTag";break;case"!":this._state="BeforeDeclaration";break;case"?":var e=this._buffer.indexOf(">",this._index);-1!=e?(this._index=e,this._sectionStart=this._index+1):this._sectionStart=this._index=this._buffer.length,this._state="TEXT";break;case">":this._state="TEXT";break;case"<":this._cbs.ontext(this._getSection()),this._sectionStart=this._index;break;default:/\s/.test(t)?this._state="TEXT":(this._state="InTag",this._sectionStart=this._index)}},t.prototype.InTag=function(t){if("/"===t||">"===t||/\s/.test(t)){var e=this._getSection().toLowerCase();if("script"==e)-1!=(i=this._buffer.indexOf("<\/script>",this._index))?(this._index=i+8,this._sectionStart=this._index+1):this._sectionStart=this._index=this._buffer.length,this._state="TEXT";else if("title"==e){var i=this._buffer.indexOf("</title>",this._index);if(-1!=i){this._index=i+7;var s=this._getSection().match(/>(.*?)</);s&&(this._title=s[1]),this._sectionStart=this._index+1}else this._sectionStart=this._index=this._buffer.length;this._state="TEXT"}else this._emitToken("onopentagname"),this._state="BeforeAttrsName",this._index--}},t.prototype.BeforeAttrsName=function(t){">"===t?(this._cbs.onopentagend(),this._state="TEXT",this._sectionStart=this._index+1):"/"===t?this._state="InSelfCloseTag":/\s/.test(t)||(this._state="InAttrsName",this._sectionStart=this._index)},t.prototype.InAttrsName=function(t){("="===t||"/"===t||">"===t||/\s/.test(t))&&(this._cbs.onattribname(this._getSection()),this._sectionStart=-1,this._state="AfterAttrsName",this._index--)},t.prototype.AfterAttrsName=function(t){"="===t?this._state="BeforeAttrsValue":"/"===t||">"===t?(this._cbs.onattribend(),this._state="BeforeAttrsName",this._index--):/\s/.test(t)||(this._cbs.onattribend(),this._state="InAttrsName",this._sectionStart=this._index)},t.prototype.BeforeAttrsValue=function(t){'"'===t?(this._state="InAttrsValueDQ",this._sectionStart=this._index+1):"'"===t?(this._state="InAttrsValueSQ",this._sectionStart=this._index+1):/\s/.test(t)||(this._state="InAttrsValueNQ",this._sectionStart=this._index,this._index--)},t.prototype.InAttrsValueDQ=function(t){'"'===t&&(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state="BeforeAttrsName")},t.prototype.InAttrsValueSQ=function(t){"'"===t&&(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state="BeforeAttrsName")},t.prototype.InAttrsValueNQ=function(t){(/\s/.test(t)||">"===t)&&(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state="BeforeAttrsName",this._index--)},t.prototype.BeforeCloseTag=function(t){/\s/.test(t)||(">"===t?this._state="TEXT":(this._state="InCloseTag",this._sectionStart=this._index))},t.prototype.InCloseTag=function(t){(">"===t||/\s/.test(t))&&(this._emitToken("onclosetag"),this._state="AfterCloseTag",this._index--)},t.prototype.InSelfCloseTag=function(t){">"===t?(this._cbs.onopentagend(),this._state="TEXT",this._sectionStart=this._index+1):/\s/.test(t)||(this._state="BeforeAttrsName",this._index--)},t.prototype.AfterCloseTag=function(t){">"===t&&(this._state="TEXT",this._sectionStart=this._index+1)},t.prototype.BeforeDeclaration=function(t){this._state="-"==t?"InComment":"["==t?"BeforeCDATA1":"InDeclaration"},t.prototype.InDeclaration=function(t){var e=this._buffer.indexOf(">",this._index);-1!=e?(this._index=e,this._sectionStart=e+1):this._sectionStart=this._index=this._buffer.length,this._state="TEXT"},t.prototype.InComment=function(t){var e="-"==t?"--\x3e":">",i=this._buffer.indexOf(e,this._index);-1!=i?(this._index=i+e.length-1,this._sectionStart=this._index+1):this._sectionStart=this._index=this._buffer.length,this._state="TEXT"},t.prototype.BeforeCDATA1=function(t){this._state="C"==t?"BeforeCDATA2":"InDeclaration"},t.prototype.BeforeCDATA2=function(t){this._state="D"==t?"BeforeCDATA3":"InDeclaration"},t.prototype.BeforeCDATA3=function(t){this._state="A"==t?"BeforeCDATA4":"InDeclaration"},t.prototype.BeforeCDATA4=function(t){this._state="T"==t?"BeforeCDATA5":"InDeclaration"},t.prototype.BeforeCDATA5=function(t){this._state="A"==t?"InCDATA":"InDeclaration"},t.prototype.InCDATA=function(t){var e="["==t?"]]>":">",i=this._buffer.indexOf(e,this._index);-1!=i?(this._index=i+e.length-1,this._sectionStart=this._index+1):this._sectionStart=this._index=this._buffer.length,this._state="TEXT"},t.prototype.parse=function(t){for(this._buffer+=t;this._index<this._buffer.length;)this[this._state](this._buffer.charAt(this._index)),this._index++;"TEXT"===this._state&&this._sectionStart!==this._index&&this._cbs.ontext(this._buffer.substr(this._sectionStart)),this._cbs.onend()},t.prototype._getSection=function(){return this._buffer.substring(this._sectionStart,this._index)},t.prototype._emitToken=function(t){this._cbs[t](this._getSection()),this._sectionStart=-1},module.exports=t; 
 			}); 
		define("Parser/prism.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){function a(e,a,n,t,r){this.type=e,this.content=a,this.alias=n,this.length=0|(t||"").length,this.greedy=!!r}var n=/\blang(?:uage)?-([\w-]+)\b/i,t=0,r={manual:e.Prism&&e.Prism.manual,disableWorkerMessageHandler:e.Prism&&e.Prism.disableWorkerMessageHandler,util:{encode:function(e){return e instanceof a?new a(e.type,r.util.encode(e.content),e.alias):Array.isArray(e)?e.map(r.util.encode):e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/\u00a0/g," ")},type:function(e){return Object.prototype.toString.call(e).slice(8,-1)},objId:function(e){return e.__id||Object.defineProperty(e,"__id",{value:++t}),e.__id},clone:function e(a,n){var t,s,i=r.util.type(a);switch(n=n||{},i){case"Object":if(s=r.util.objId(a),n[s])return n[s];for(var l in t={},n[s]=t,a)a.hasOwnProperty(l)&&(t[l]=e(a[l],n));return t;case"Array":return s=r.util.objId(a),n[s]?n[s]:(t=[],n[s]=t,a.forEach(function(a,r){t[r]=e(a,n)}),t);default:return a}}},languages:{extend:function(e,a){var n=r.util.clone(r.languages[e]);for(var t in a)n[t]=a[t];return n},insertBefore:function(e,a,n,t){var s=(t=t||r.languages)[e],i={};for(var l in s)if(s.hasOwnProperty(l)){if(l==a)for(var o in n)n.hasOwnProperty(o)&&(i[o]=n[o]);n.hasOwnProperty(l)||(i[l]=s[l])}var u=t[e];return t[e]=i,r.languages.DFS(r.languages,function(a,n){n===u&&a!=e&&(this[a]=i)}),i},DFS:function e(a,n,t,s){s=s||{};var i=r.util.objId;for(var l in a)if(a.hasOwnProperty(l)){n.call(a,l,a[l],t||l);var o=a[l],u=r.util.type(o);"Object"!==u||s[i(o)]?"Array"!==u||s[i(o)]||(s[i(o)]=!0,e(o,n,l,s)):(s[i(o)]=!0,e(o,n,null,s))}}},plugins:{},highlightAll:function(e,a){r.highlightAllUnder(document,e,a)},highlightAllUnder:function(e,a,n){var t={callback:n,selector:'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'};r.hooks.run("before-highlightall",t);for(var s,i=t.elements||e.querySelectorAll(t.selector),l=0;s=i[l++];)r.highlightElement(s,!0===a,t.callback)},highlightElement:function(a,t,s){for(var i,l="none",o=a;o&&!n.test(o.className);)o=o.parentNode;o&&(l=(o.className.match(n)||[,"none"])[1].toLowerCase(),i=r.languages[l]),a.className=a.className.replace(n,"").replace(/\s+/g," ")+" language-"+l,a.parentNode&&(o=a.parentNode,/pre/i.test(o.nodeName)&&(o.className=o.className.replace(n,"").replace(/\s+/g," ")+" language-"+l));var u={element:a,language:l,grammar:i,code:a.textContent},g=function(e){u.highlightedCode=e,r.hooks.run("before-insert",u),u.element.innerHTML=u.highlightedCode,r.hooks.run("after-highlight",u),r.hooks.run("complete",u),s&&s.call(u.element)};if(r.hooks.run("before-sanity-check",u),u.code)if(r.hooks.run("before-highlight",u),u.grammar)if(t&&e.Worker){var c=new Worker(r.filename);c.onmessage=function(e){g(e.data)},c.postMessage(JSON.stringify({language:u.language,code:u.code,immediateClose:!0}))}else g(r.highlight(u.code,u.grammar,u.language));else g(r.util.encode(u.code));else r.hooks.run("complete",u)},highlight:function(e,n,t){var s={code:e,grammar:n,language:t};return r.hooks.run("before-tokenize",s),s.tokens=r.tokenize(s.code,s.grammar),r.hooks.run("after-tokenize",s),a.stringify(r.util.encode(s.tokens),s.language)},matchGrammar:function(e,n,t,s,i,l,o){for(var u in t)if(t.hasOwnProperty(u)&&t[u]){if(u==o)return;var g=t[u];g="Array"===r.util.type(g)?g:[g];for(var c=0;c<g.length;++c){var d=g[c],p=d.inside,f=!!d.lookbehind,h=!!d.greedy,m=0,y=d.alias;if(h&&!d.pattern.global){var F=d.pattern.toString().match(/[imuy]*$/)[0];d.pattern=RegExp(d.pattern.source,F+"g")}d=d.pattern||d;for(var b=s,k=i;b<n.length;k+=n[b].length,++b){var v=n[b];if(n.length>e.length)return;if(!(v instanceof a)){if(h&&b!=n.length-1){if(d.lastIndex=k,!(j=d.exec(e)))break;for(var w=j.index+(f?j[1].length:0),A=j.index+j[0].length,x=b,$=k,S=n.length;x<S&&($<A||!n[x].type&&!n[x-1].greedy);++x)($+=n[x].length)<=w&&(++b,k=$);if(n[b]instanceof a)continue;_=x-b,v=e.slice(k,$),j.index-=k}else{d.lastIndex=0;var j=d.exec(v),_=1}if(j){f&&(m=j[1]?j[1].length:0),A=(w=j.index+m)+(j=j[0].slice(m)).length;var O=v.slice(0,w),N=v.slice(A),P=[b,_];O&&(++b,k+=O.length,P.push(O));var z=new a(u,p?r.tokenize(j,p):j,y,j,h);if(P.push(z),N&&P.push(N),Array.prototype.splice.apply(n,P),1!=_&&r.matchGrammar(e,n,t,b,k,!0,u),l)break}else if(l)break}}}}},tokenize:function(e,a){var n=[e],t=a.rest;if(t){for(var s in t)a[s]=t[s];delete a.rest}return r.matchGrammar(e,n,a,0,0,!1),n},hooks:{all:{},add:function(e,a){var n=r.hooks.all;n[e]=n[e]||[],n[e].push(a)},run:function(e,a){var n=r.hooks.all[e];if(n&&n.length)for(var t,s=0;t=n[s++];)t(a)}},Token:a};if(e.Prism=r,a.stringify=function(e,n){if("string"==typeof e)return e;if(Array.isArray(e))return e.map(function(e){return a.stringify(e,n)}).join("");var t={type:e.type,content:a.stringify(e.content,n),tag:"span",classes:["token",e.type],attributes:{},language:n};if(e.alias){var s=Array.isArray(e.alias)?e.alias:[e.alias];Array.prototype.push.apply(t.classes,s)}r.hooks.run("wrap",t);var i=Object.keys(t.attributes).map(function(e){return e+'="'+(t.attributes[e]||"").replace(/"/g,"&quot;")+'"'}).join(" ");return"<"+t.tag+' class="'+t.classes.join(" ")+'"'+(i?" "+i:"")+">"+t.content+"</"+t.tag+">"},!e.document)return e.addEventListener&&(r.disableWorkerMessageHandler||e.addEventListener("message",function(a){var n=JSON.parse(a.data),t=n.language,s=n.code,i=n.immediateClose;e.postMessage(r.highlight(s,r.languages[t],t)),i&&e.close()},!1)),r;var s=document.currentScript||[].slice.call(document.getElementsByTagName("script")).pop();return s&&(r.filename=s.src,r.manual||s.hasAttribute("data-manual")||("loading"!==document.readyState?window.requestAnimationFrame?window.requestAnimationFrame(r.highlightAll):window.setTimeout(r.highlightAll,16):document.addEventListener("DOMContentLoaded",r.highlightAll))),r}("undefined"!=typeof window?window:"undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?self:{});"undefined"!=typeof module&&module.exports&&(module.exports=e),"undefined"!=typeof global&&(global.Prism=e),e.languages.markup={comment:/<!--[\s\S]*?-->/,prolog:/<\?[\s\S]+?\?>/,doctype:/<!DOCTYPE[\s\S]+?>/i,cdata:/<!\[CDATA\[[\s\S]*?]]>/i,tag:{pattern:/<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/i,greedy:!0,inside:{tag:{pattern:/^<\/?[^\s>\/]+/i,inside:{punctuation:/^<\/?/,namespace:/^[^\s>\/:]+:/}},"attr-value":{pattern:/=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/i,inside:{punctuation:[/^=/,{pattern:/^(\s*)["']|["']$/,lookbehind:!0}]}},punctuation:/\/?>/,"attr-name":{pattern:/[^\s>\/]+/,inside:{namespace:/^[^\s>\/:]+:/}}}},entity:/&#?[\da-z]{1,8};/i},e.languages.markup.tag.inside["attr-value"].inside.entity=e.languages.markup.entity,e.hooks.add("wrap",function(e){"entity"===e.type&&(e.attributes.title=e.content.replace(/&amp;/,"&"))}),Object.defineProperty(e.languages.markup.tag,"addInlined",{value:function(a,n){var t={};t["language-"+n]={pattern:/(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,lookbehind:!0,inside:e.languages[n]},t.cdata=/^<!\[CDATA\[|\]\]>$/i;var r={"included-cdata":{pattern:/<!\[CDATA\[[\s\S]*?\]\]>/i,inside:t}};r["language-"+n]={pattern:/[\s\S]+/,inside:e.languages[n]};var s={};s[a]={pattern:RegExp("(<__[\\s\\S]*?>)(?:<!\\[CDATA\\[[\\s\\S]*?\\]\\]>\\s*|[\\s\\S])*?(?=<\\/__>)".replace(/__/g,a),"i"),lookbehind:!0,greedy:!0,inside:r},e.languages.insertBefore("markup","cdata",s)}}),e.languages.xml=e.languages.extend("markup",{}),e.languages.html=e.languages.markup,e.languages.mathml=e.languages.markup,e.languages.svg=e.languages.markup,function(e){var a=/("|')(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/;e.languages.css={comment:/\/\*[\s\S]*?\*\//,atrule:{pattern:/@[\w-]+?[\s\S]*?(?:;|(?=\s*\{))/i,inside:{rule:/@[\w-]+/}},url:RegExp("url\\((?:"+a.source+"|.*?)\\)","i"),selector:RegExp("[^{}\\s](?:[^{};\"']|"+a.source+")*?(?=\\s*\\{)"),string:{pattern:a,greedy:!0},property:/[-_a-z\xA0-\uFFFF][-\w\xA0-\uFFFF]*(?=\s*:)/i,important:/!important\b/i,function:/[-a-z0-9]+(?=\()/i,punctuation:/[(){};:,]/},e.languages.css.atrule.inside.rest=e.languages.css;var n=e.languages.markup;n&&(n.tag.addInlined("style","css"),e.languages.insertBefore("inside","attr-value",{"style-attr":{pattern:/\s*style=("|')(?:\\[\s\S]|(?!\1)[^\\])*\1/i,inside:{"attr-name":{pattern:/^\s*style/i,inside:n.tag.inside},punctuation:/^\s*=\s*['"]|['"]\s*$/,"attr-value":{pattern:/.+/i,inside:e.languages.css}},alias:"language-css"}},n.tag))}(e),e.languages.clike={comment:[{pattern:/(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,lookbehind:!0},{pattern:/(^|[^\\:])\/\/.*/,lookbehind:!0,greedy:!0}],string:{pattern:/(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,greedy:!0},"class-name":{pattern:/((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[\w.\\]+/i,lookbehind:!0,inside:{punctuation:/[.\\]/}},keyword:/\b(?:if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,boolean:/\b(?:true|false)\b/,function:/\w+(?=\()/,number:/\b0x[\da-f]+\b|(?:\b\d+\.?\d*|\B\.\d+)(?:e[+-]?\d+)?/i,operator:/--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,punctuation:/[{}[\];(),.:]/},e.languages.javascript=e.languages.extend("clike",{"class-name":[e.languages.clike["class-name"],{pattern:/(^|[^$\w\xA0-\uFFFF])[_$A-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\.(?:prototype|constructor))/,lookbehind:!0}],keyword:[{pattern:/((?:^|})\s*)(?:catch|finally)\b/,lookbehind:!0},{pattern:/(^|[^.])\b(?:as|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,lookbehind:!0}],number:/\b(?:(?:0[xX][\dA-Fa-f]+|0[bB][01]+|0[oO][0-7]+)n?|\d+n|NaN|Infinity)\b|(?:\b\d+\.?\d*|\B\.\d+)(?:[Ee][+-]?\d+)?/,function:/[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,operator:/-[-=]?|\+[+=]?|!=?=?|<<?=?|>>?>?=?|=(?:==?|>)?|&[&=]?|\|[|=]?|\*\*?=?|\/=?|~|\^=?|%=?|\?|\.{3}/}),e.languages.javascript["class-name"][0].pattern=/(\b(?:class|interface|extends|implements|instanceof|new)\s+)[\w.\\]+/,e.languages.insertBefore("javascript","keyword",{regex:{pattern:/((?:^|[^$\w\xA0-\uFFFF."'\])\s])\s*)\/(\[(?:[^\]\\\r\n]|\\.)*]|\\.|[^/\\\[\r\n])+\/[gimyus]{0,6}(?=\s*($|[\r\n,.;})\]]))/,lookbehind:!0,greedy:!0},"function-variable":{pattern:/[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*)\s*=>))/,alias:"function"},parameter:[{pattern:/(function(?:\s+[_$A-Za-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*)?\s*\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\))/,lookbehind:!0,inside:e.languages.javascript},{pattern:/[_$a-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*=>)/i,inside:e.languages.javascript},{pattern:/(\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\)\s*=>)/,lookbehind:!0,inside:e.languages.javascript},{pattern:/((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:[_$A-Za-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*\s*)\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\)\s*\{)/,lookbehind:!0,inside:e.languages.javascript}],constant:/\b[A-Z](?:[A-Z_]|\dx?)*\b/}),e.languages.insertBefore("javascript","string",{"template-string":{pattern:/`(?:\\[\s\S]|\${(?:[^{}]|{(?:[^{}]|{[^}]*})*})+}|[^\\`])*`/,greedy:!0,inside:{interpolation:{pattern:/\${(?:[^{}]|{(?:[^{}]|{[^}]*})*})+}/,inside:{"interpolation-punctuation":{pattern:/^\${|}$/,alias:"punctuation"},rest:e.languages.javascript}},string:/[\s\S]+/}}}),e.languages.markup&&e.languages.markup.tag.addInlined("script","javascript"),e.languages.js=e.languages.javascript; 
 			}); 
		define("pages/template/adBrand/adBrand.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}}); 
 			}); 
		define("pages/template/loadding/loadding.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}}); 
 			}); 
		define("pages/template/videoLayout/videoLayout.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}}); 
 			}); 
		define("pages/template/videoModule/videoModule.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}}); 
 			}); 
		define("utils/aes.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=t||function(t,e){var r={},i=r.lib={},n=function(){},s=i.Base={extend:function(t){n.prototype=this;var e=new n;return t&&e.mixIn(t),e.hasOwnProperty("init")||(e.init=function(){e.$super.init.apply(this,arguments)}),e.init.prototype=e,e.$super=this,e},create:function(){var t=this.extend();return t.init.apply(t,arguments),t},init:function(){},mixIn:function(t){for(var e in t)t.hasOwnProperty(e)&&(this[e]=t[e]);t.hasOwnProperty("toString")&&(this.toString=t.toString)},clone:function(){return this.init.prototype.extend(this)}},o=i.WordArray=s.extend({init:function(t,e){t=this.words=t||[],this.sigBytes=void 0!=e?e:4*t.length},toString:function(t){return(t||a).stringify(this)},concat:function(t){var e=this.words,r=t.words,i=this.sigBytes;if(t=t.sigBytes,this.clamp(),i%4)for(var n=0;n<t;n++)e[i+n>>>2]|=(r[n>>>2]>>>24-n%4*8&255)<<24-(i+n)%4*8;else if(65535<r.length)for(n=0;n<t;n+=4)e[i+n>>>2]=r[n>>>2];else e.push.apply(e,r);return this.sigBytes+=t,this},clamp:function(){var e=this.words,r=this.sigBytes;e[r>>>2]&=4294967295<<32-r%4*8,e.length=t.ceil(r/4)},clone:function(){var t=s.clone.call(this);return t.words=this.words.slice(0),t},random:function(e){for(var r=[],i=0;i<e;i+=4)r.push(4294967296*t.random()|0);return new o.init(r,e)}}),c=r.enc={},a=c.Hex={stringify:function(t){var e=t.words;t=t.sigBytes;for(var r=[],i=0;i<t;i++){var n=e[i>>>2]>>>24-i%4*8&255;r.push((n>>>4).toString(16)),r.push((15&n).toString(16))}return r.join("")},parse:function(t){for(var e=t.length,r=[],i=0;i<e;i+=2)r[i>>>3]|=parseInt(t.substr(i,2),16)<<24-i%8*4;return new o.init(r,e/2)}},f=c.Latin1={stringify:function(t){var e=t.words;t=t.sigBytes;for(var r=[],i=0;i<t;i++)r.push(String.fromCharCode(e[i>>>2]>>>24-i%4*8&255));return r.join("")},parse:function(t){for(var e=t.length,r=[],i=0;i<e;i++)r[i>>>2]|=(255&t.charCodeAt(i))<<24-i%4*8;return new o.init(r,e)}},h=c.Utf8={stringify:function(t){try{return decodeURIComponent(escape(f.stringify(t)))}catch(t){throw Error("Malformed UTF-8 data")}},parse:function(t){return f.parse(unescape(encodeURIComponent(t)))}},u=i.BufferedBlockAlgorithm=s.extend({reset:function(){this._data=new o.init,this._nDataBytes=0},_append:function(t){"string"==typeof t&&(t=h.parse(t)),this._data.concat(t),this._nDataBytes+=t.sigBytes},_process:function(e){var r=this._data,i=r.words,n=r.sigBytes,s=this.blockSize,c=n/(4*s);if(e=(c=e?t.ceil(c):t.max((0|c)-this._minBufferSize,0))*s,n=t.min(4*e,n),e){for(var a=0;a<e;a+=s)this._doProcessBlock(i,a);a=i.splice(0,e),r.sigBytes-=n}return new o.init(a,n)},clone:function(){var t=s.clone.call(this);return t._data=this._data.clone(),t},_minBufferSize:0});i.Hasher=u.extend({cfg:s.extend(),init:function(t){this.cfg=this.cfg.extend(t),this.reset()},reset:function(){u.reset.call(this),this._doReset()},update:function(t){return this._append(t),this._process(),this},finalize:function(t){return t&&this._append(t),this._doFinalize()},blockSize:16,_createHelper:function(t){return function(e,r){return new t.init(r).finalize(e)}},_createHmacHelper:function(t){return function(e,r){return new p.HMAC.init(t,r).finalize(e)}}});var p=r.algo={};return r}(Math);!function(){var e=t,r=e.lib.WordArray;e.enc.Base64={stringify:function(t){var e=t.words,r=t.sigBytes,i=this._map;t.clamp(),t=[];for(var n=0;n<r;n+=3)for(var s=(e[n>>>2]>>>24-n%4*8&255)<<16|(e[n+1>>>2]>>>24-(n+1)%4*8&255)<<8|e[n+2>>>2]>>>24-(n+2)%4*8&255,o=0;4>o&&n+.75*o<r;o++)t.push(i.charAt(s>>>6*(3-o)&63));if(e=i.charAt(64))for(;t.length%4;)t.push(e);return t.join("")},parse:function(t){var e=t.length,i=this._map;(n=i.charAt(64))&&-1!=(n=t.indexOf(n))&&(e=n);for(var n=[],s=0,o=0;o<e;o++)if(o%4){var c=i.indexOf(t.charAt(o-1))<<o%4*2,a=i.indexOf(t.charAt(o))>>>6-o%4*2;n[s>>>2]|=(c|a)<<24-s%4*8,s++}return r.create(n,s)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="}}(),function(e){function r(t,e,r,i,n,s,o){return((t=t+(e&r|~e&i)+n+o)<<s|t>>>32-s)+e}function i(t,e,r,i,n,s,o){return((t=t+(e&i|r&~i)+n+o)<<s|t>>>32-s)+e}function n(t,e,r,i,n,s,o){return((t=t+(e^r^i)+n+o)<<s|t>>>32-s)+e}function s(t,e,r,i,n,s,o){return((t=t+(r^(e|~i))+n+o)<<s|t>>>32-s)+e}for(var o=t,c=(f=o.lib).WordArray,a=f.Hasher,f=o.algo,h=[],u=0;64>u;u++)h[u]=4294967296*e.abs(e.sin(u+1))|0;f=f.MD5=a.extend({_doReset:function(){this._hash=new c.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(t,e){for(o=0;16>o;o++){a=t[c=e+o];t[c]=16711935&(a<<8|a>>>24)|4278255360&(a<<24|a>>>8)}var o=this._hash.words,c=t[e+0],a=t[e+1],f=t[e+2],u=t[e+3],p=t[e+4],d=t[e+5],l=t[e+6],y=t[e+7],_=t[e+8],v=t[e+9],g=t[e+10],B=t[e+11],x=t[e+12],m=t[e+13],k=t[e+14],S=t[e+15],z=o[0],w=o[1],C=o[2],D=o[3],w=s(w=s(w=s(w=s(w=n(w=n(w=n(w=n(w=i(w=i(w=i(w=i(w=r(w=r(w=r(w=r(w,C=r(C,D=r(D,z=r(z,w,C,D,c,7,h[0]),w,C,a,12,h[1]),z,w,f,17,h[2]),D,z,u,22,h[3]),C=r(C,D=r(D,z=r(z,w,C,D,p,7,h[4]),w,C,d,12,h[5]),z,w,l,17,h[6]),D,z,y,22,h[7]),C=r(C,D=r(D,z=r(z,w,C,D,_,7,h[8]),w,C,v,12,h[9]),z,w,g,17,h[10]),D,z,B,22,h[11]),C=r(C,D=r(D,z=r(z,w,C,D,x,7,h[12]),w,C,m,12,h[13]),z,w,k,17,h[14]),D,z,S,22,h[15]),C=i(C,D=i(D,z=i(z,w,C,D,a,5,h[16]),w,C,l,9,h[17]),z,w,B,14,h[18]),D,z,c,20,h[19]),C=i(C,D=i(D,z=i(z,w,C,D,d,5,h[20]),w,C,g,9,h[21]),z,w,S,14,h[22]),D,z,p,20,h[23]),C=i(C,D=i(D,z=i(z,w,C,D,v,5,h[24]),w,C,k,9,h[25]),z,w,u,14,h[26]),D,z,_,20,h[27]),C=i(C,D=i(D,z=i(z,w,C,D,m,5,h[28]),w,C,f,9,h[29]),z,w,y,14,h[30]),D,z,x,20,h[31]),C=n(C,D=n(D,z=n(z,w,C,D,d,4,h[32]),w,C,_,11,h[33]),z,w,B,16,h[34]),D,z,k,23,h[35]),C=n(C,D=n(D,z=n(z,w,C,D,a,4,h[36]),w,C,p,11,h[37]),z,w,y,16,h[38]),D,z,g,23,h[39]),C=n(C,D=n(D,z=n(z,w,C,D,m,4,h[40]),w,C,c,11,h[41]),z,w,u,16,h[42]),D,z,l,23,h[43]),C=n(C,D=n(D,z=n(z,w,C,D,v,4,h[44]),w,C,x,11,h[45]),z,w,S,16,h[46]),D,z,f,23,h[47]),C=s(C,D=s(D,z=s(z,w,C,D,c,6,h[48]),w,C,y,10,h[49]),z,w,k,15,h[50]),D,z,d,21,h[51]),C=s(C,D=s(D,z=s(z,w,C,D,x,6,h[52]),w,C,u,10,h[53]),z,w,g,15,h[54]),D,z,a,21,h[55]),C=s(C,D=s(D,z=s(z,w,C,D,_,6,h[56]),w,C,S,10,h[57]),z,w,l,15,h[58]),D,z,m,21,h[59]),C=s(C,D=s(D,z=s(z,w,C,D,p,6,h[60]),w,C,B,10,h[61]),z,w,f,15,h[62]),D,z,v,21,h[63]);o[0]=o[0]+z|0,o[1]=o[1]+w|0,o[2]=o[2]+C|0,o[3]=o[3]+D|0},_doFinalize:function(){var t=this._data,r=t.words,i=8*this._nDataBytes,n=8*t.sigBytes;r[n>>>5]|=128<<24-n%32;var s=e.floor(i/4294967296);for(r[15+(n+64>>>9<<4)]=16711935&(s<<8|s>>>24)|4278255360&(s<<24|s>>>8),r[14+(n+64>>>9<<4)]=16711935&(i<<8|i>>>24)|4278255360&(i<<24|i>>>8),t.sigBytes=4*(r.length+1),this._process(),r=(t=this._hash).words,i=0;4>i;i++)n=r[i],r[i]=16711935&(n<<8|n>>>24)|4278255360&(n<<24|n>>>8);return t},clone:function(){var t=a.clone.call(this);return t._hash=this._hash.clone(),t}}),o.MD5=a._createHelper(f),o.HmacMD5=a._createHmacHelper(f)}(Math),function(){var e=t,r=e.lib,i=r.Base,n=r.WordArray,s=(r=e.algo).EvpKDF=i.extend({cfg:i.extend({keySize:4,hasher:r.MD5,iterations:1}),init:function(t){this.cfg=this.cfg.extend(t)},compute:function(t,e){for(var r=(c=this.cfg).hasher.create(),i=n.create(),s=i.words,o=c.keySize,c=c.iterations;s.length<o;){a&&r.update(a);var a=r.update(t).finalize(e);r.reset();for(var f=1;f<c;f++)a=r.finalize(a),r.reset();i.concat(a)}return i.sigBytes=4*o,i}});e.EvpKDF=function(t,e,r){return s.create(r).compute(t,e)}}(),t.lib.Cipher||function(e){var r=(l=t).lib,i=r.Base,n=r.WordArray,s=r.BufferedBlockAlgorithm,o=l.enc.Base64,c=l.algo.EvpKDF,a=r.Cipher=s.extend({cfg:i.extend(),createEncryptor:function(t,e){return this.create(this._ENC_XFORM_MODE,t,e)},createDecryptor:function(t,e){return this.create(this._DEC_XFORM_MODE,t,e)},init:function(t,e,r){this.cfg=this.cfg.extend(r),this._xformMode=t,this._key=e,this.reset()},reset:function(){s.reset.call(this),this._doReset()},process:function(t){return this._append(t),this._process()},finalize:function(t){return t&&this._append(t),this._doFinalize()},keySize:4,ivSize:4,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:function(t){return{encrypt:function(e,r,i){return("string"==typeof r?y:d).encrypt(t,e,r,i)},decrypt:function(e,r,i){return("string"==typeof r?y:d).decrypt(t,e,r,i)}}}});r.StreamCipher=a.extend({_doFinalize:function(){return this._process(!0)},blockSize:1});var f=l.mode={},h=function(t,e,r){var i=this._iv;i?this._iv=void 0:i=this._prevBlock;for(var n=0;n<r;n++)t[e+n]^=i[n]},u=(r.BlockCipherMode=i.extend({createEncryptor:function(t,e){return this.Encryptor.create(t,e)},createDecryptor:function(t,e){return this.Decryptor.create(t,e)},init:function(t,e){this._cipher=t,this._iv=e}})).extend();u.Encryptor=u.extend({processBlock:function(t,e){var r=this._cipher,i=r.blockSize;h.call(this,t,e,i),r.encryptBlock(t,e),this._prevBlock=t.slice(e,e+i)}}),u.Decryptor=u.extend({processBlock:function(t,e){var r=this._cipher,i=r.blockSize,n=t.slice(e,e+i);r.decryptBlock(t,e),h.call(this,t,e,i),this._prevBlock=n}}),f=f.CBC=u,u=(l.pad={}).Pkcs7={pad:function(t,e){for(var r=4*e,i=(r=r-t.sigBytes%r)<<24|r<<16|r<<8|r,s=[],o=0;o<r;o+=4)s.push(i);r=n.create(s,r),t.concat(r)},unpad:function(t){t.sigBytes-=255&t.words[t.sigBytes-1>>>2]}},r.BlockCipher=a.extend({cfg:a.cfg.extend({mode:f,padding:u}),reset:function(){a.reset.call(this);var t=(e=this.cfg).iv,e=e.mode;if(this._xformMode==this._ENC_XFORM_MODE)var r=e.createEncryptor;else r=e.createDecryptor,this._minBufferSize=1;this._mode=r.call(e,this,t&&t.words)},_doProcessBlock:function(t,e){this._mode.processBlock(t,e)},_doFinalize:function(){var t=this.cfg.padding;if(this._xformMode==this._ENC_XFORM_MODE){t.pad(this._data,this.blockSize);var e=this._process(!0)}else e=this._process(!0),t.unpad(e);return e},blockSize:4});var p=r.CipherParams=i.extend({init:function(t){this.mixIn(t)},toString:function(t){return(t||this.formatter).stringify(this)}}),f=(l.format={}).OpenSSL={stringify:function(t){var e=t.ciphertext;return((t=t.salt)?n.create([1398893684,1701076831]).concat(t).concat(e):e).toString(o)},parse:function(t){var e=(t=o.parse(t)).words;if(1398893684==e[0]&&1701076831==e[1]){var r=n.create(e.slice(2,4));e.splice(0,4),t.sigBytes-=16}return p.create({ciphertext:t,salt:r})}},d=r.SerializableCipher=i.extend({cfg:i.extend({format:f}),encrypt:function(t,e,r,i){i=this.cfg.extend(i);var n=t.createEncryptor(r,i);return e=n.finalize(e),n=n.cfg,p.create({ciphertext:e,key:r,iv:n.iv,algorithm:t,mode:n.mode,padding:n.padding,blockSize:t.blockSize,formatter:i.format})},decrypt:function(t,e,r,i){return i=this.cfg.extend(i),e=this._parse(e,i.format),t.createDecryptor(r,i).finalize(e.ciphertext)},_parse:function(t,e){return"string"==typeof t?e.parse(t,this):t}}),l=(l.kdf={}).OpenSSL={execute:function(t,e,r,i){return i||(i=n.random(8)),t=c.create({keySize:e+r}).compute(t,i),r=n.create(t.words.slice(e),4*r),t.sigBytes=4*e,p.create({key:t,iv:r,salt:i})}},y=r.PasswordBasedCipher=d.extend({cfg:d.cfg.extend({kdf:l}),encrypt:function(t,e,r,i){return i=this.cfg.extend(i),r=i.kdf.execute(r,t.keySize,t.ivSize),i.iv=r.iv,(t=d.encrypt.call(this,t,e,r.key,i)).mixIn(r),t},decrypt:function(t,e,r,i){return i=this.cfg.extend(i),e=this._parse(e,i.format),r=i.kdf.execute(r,t.keySize,t.ivSize,e.salt),i.iv=r.iv,d.decrypt.call(this,t,e,r.key,i)}})}(),function(){for(var e=t,r=e.lib.BlockCipher,i=e.algo,n=[],s=[],o=[],c=[],a=[],f=[],h=[],u=[],p=[],d=[],l=[],y=0;256>y;y++)l[y]=128>y?y<<1:y<<1^283;for(var _=0,v=0,y=0;256>y;y++){var g=(g=v^v<<1^v<<2^v<<3^v<<4)>>>8^255&g^99;n[_]=g,s[g]=_;var B=l[_],x=l[B],m=l[x],k=257*l[g]^16843008*g;o[_]=k<<24|k>>>8,c[_]=k<<16|k>>>16,a[_]=k<<8|k>>>24,f[_]=k,k=16843009*m^65537*x^257*B^16843008*_,h[g]=k<<24|k>>>8,u[g]=k<<16|k>>>16,p[g]=k<<8|k>>>24,d[g]=k,_?(_=B^l[l[l[m^B]]],v^=l[l[v]]):_=v=1}var S=[0,1,2,4,8,16,32,64,128,27,54],i=i.AES=r.extend({_doReset:function(){for(var t=(r=this._key).words,e=r.sigBytes/4,r=4*((this._nRounds=e+6)+1),i=this._keySchedule=[],s=0;s<r;s++)if(s<e)i[s]=t[s];else{var o=i[s-1];s%e?6<e&&4==s%e&&(o=n[o>>>24]<<24|n[o>>>16&255]<<16|n[o>>>8&255]<<8|n[255&o]):(o=o<<8|o>>>24,o=n[o>>>24]<<24|n[o>>>16&255]<<16|n[o>>>8&255]<<8|n[255&o],o^=S[s/e|0]<<24),i[s]=i[s-e]^o}for(t=this._invKeySchedule=[],e=0;e<r;e++)s=r-e,o=e%4?i[s]:i[s-4],t[e]=4>e||4>=s?o:h[n[o>>>24]]^u[n[o>>>16&255]]^p[n[o>>>8&255]]^d[n[255&o]]},encryptBlock:function(t,e){this._doCryptBlock(t,e,this._keySchedule,o,c,a,f,n)},decryptBlock:function(t,e){var r=t[e+1];t[e+1]=t[e+3],t[e+3]=r,this._doCryptBlock(t,e,this._invKeySchedule,h,u,p,d,s),r=t[e+1],t[e+1]=t[e+3],t[e+3]=r},_doCryptBlock:function(t,e,r,i,n,s,o,c){for(var a=this._nRounds,f=t[e]^r[0],h=t[e+1]^r[1],u=t[e+2]^r[2],p=t[e+3]^r[3],d=4,l=1;l<a;l++)var y=i[f>>>24]^n[h>>>16&255]^s[u>>>8&255]^o[255&p]^r[d++],_=i[h>>>24]^n[u>>>16&255]^s[p>>>8&255]^o[255&f]^r[d++],v=i[u>>>24]^n[p>>>16&255]^s[f>>>8&255]^o[255&h]^r[d++],p=i[p>>>24]^n[f>>>16&255]^s[h>>>8&255]^o[255&u]^r[d++],f=y,h=_,u=v;y=(c[f>>>24]<<24|c[h>>>16&255]<<16|c[u>>>8&255]<<8|c[255&p])^r[d++],_=(c[h>>>24]<<24|c[u>>>16&255]<<16|c[p>>>8&255]<<8|c[255&f])^r[d++],v=(c[u>>>24]<<24|c[p>>>16&255]<<16|c[f>>>8&255]<<8|c[255&h])^r[d++],p=(c[p>>>24]<<24|c[f>>>16&255]<<16|c[h>>>8&255]<<8|c[255&u])^r[d++],t[e]=y,t[e+1]=_,t[e+2]=v,t[e+3]=p},keySize:8});e.AES=r._createHelper(i)}(),module.exports={CryptoJS:t}; 
 			}); 
		define("utils/ald-stat-conf.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";exports.app_key="78118201f6bd10c6a797c04addd62ea1",exports.getLocation=!1,exports.plugin=!0; 
 			}); 
		define("utils/ald-stat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(n){return typeof n}:function(n){return n&&"function"==typeof Symbol&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n};!function(t,e){"object"==("undefined"==typeof exports?"undefined":n(exports))&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):t.Ald=e()}(void 0,function(){function t(n){this.app=n}function e(n){H=g(),T=n,this.aldstat=new t(this)}function o(n){var t;t=n.scene!=rn,rn=n.scene,B=0,T=n,Q=n.query.ald_share_src,G=n.query.aldsrc||"",K=n.query.ald_share_src,I=Date.now(),en||(N=!1),en=!1,on||(0!==U&&Date.now()-U>3e4?k=g():t&&(k=g())),0!==U&&Date.now()-U<3e4&&(X=!0),n.query.ald_share_src&&"1044"==n.scene&&n.shareTicket?wx.getShareInfo({shareTicket:n.shareTicket,success:function(n){W=n,D("event","ald_share_click",JSON.stringify(n))}}):n.query.ald_share_src&&D("event","ald_share_click",1),""===$&&wx.getSetting({withCredentials:!0,success:function(n){n.authSetting["scope.userInfo"]&&wx.getUserInfo({withCredentials:!0,success:function(n){var t=v();$=n,t.ufo=y(n),E=w(n.userInfo.avatarUrl.split("/")),p(t)}})}}),_("app","show")}function r(){U=Date.now(),""===$&&wx.getSetting({success:function(n){n.authSetting["scope.userInfo"]&&wx.getUserInfo({withCredentials:!0,success:function(n){$=n,E=w(n.userInfo.avatarUrl.split("/"));var t=v();t.ufo=y(n),p(t)}})}}),_("app","hide")}function i(n){V++,D("event","ald_error_message",n)}function s(n){nn=n}function a(){Y=R?this.$mp.page.route:this.route,x("page","show"),X=!1}function u(){Z=Y}function c(){Z=Y}function f(){D("event","ald_pulldownrefresh",1)}function l(){D("event","ald_reachbottom",1)}function h(n){on=!0;var t=S(n.path),e={};for(var o in T.query)"ald_share_src"===o&&(e[o]=T.query[o]);var r="";if(r=-1==n.path.indexOf("?")?n.path+"?":n.path.substr(0,n.path.indexOf("?"))+"?",""!==t)for(var o in t)e[o]=t[o];e.ald_share_src?-1==e.ald_share_src.indexOf(j)&&e.ald_share_src.length<200&&(e.ald_share_src=e.ald_share_src+","+j):e.ald_share_src=j;for(var i in e)-1==i.indexOf("ald")&&(r+=i+"="+e[i]+"&");return n.path=r+"ald_share_src="+e.ald_share_src,D("event","ald_share_status",n),n}function d(){function n(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)}return n()+n()+n()+n()+n()+n()+n()+n()}function p(n){B++,n.at=k,n.et=Date.now(),n.uu=j,n.v=L,n.ak=q.app_key.replace(/(\t)|(\s)/g,""),n.wsr=T,n.ifo=N,n.rq_c=B,n.ls=H,wx.Queue.push(function(){return new Promise(function(t,e){wx.request({url:"https://"+P+".aldwx.com/d.html",data:n,header:{AldStat:"MiniApp-Stat",se:C||"",op:O||"",img:E},method:"GET",success:function(n){t(200==n.statusCode?"":"status error")},fail:function(){t("fail")}})})})}function v(){var n={};for(var t in z)n[t]=z[t];return n}function w(n){for(var t="",e=0;e<n.length;e++)n[e].length>t.length&&(t=n[e]);return t}function g(){return""+Date.now()+Math.floor(1e7*Math.random())}function y(n){var t={};for(var e in n)"rawData"!=e&&"errMsg"!=e&&(t[e]=n[e]);return t}function S(n){if(-1==n.indexOf("?"))return"";var t={};return n.split("?")[1].split("&").forEach(function(n){var e=n.split("=")[1];t[n.split("=")[0]]=e}),t}function m(t){for(var e in t)if("object"==n(t[e])&&null!==t[e])return!0;return!1}function _(n,t){var e=v();e.ev=n,e.life=t,e.ec=V,e.st=Date.now(),e.dr=Date.now()-I,G&&(e.qr=G,e.sr=G),Q&&(e.usr=Q),p(e)}function x(n,t){var e=v();e.ev=n,e.st=Date.now(),e.life=t,e.pp=Y,e.pc=Z,e.dr=Date.now()-I,on&&(e.so=1),on=!1,nn&&"{}"!=JSON.stringify(nn)&&(e.ag=nn),G&&(e.qr=G,e.sr=G),Q&&(e.usr=Q),X&&(e.ps=1),F||(tn=Y,F=!0,e.ifp=F,e.fp=Y),p(e)}function D(n,t,e){var o=v();o.ev=n,o.tp=t,o.st=J,o.dr=Date.now()-I,e&&(o.ct=e),p(o)}function A(n,t,e){if(n[t]){var o=n[t];n[t]=function(n){e.call(this,n,t),o.call(this,n)}}else n[t]=function(n){e.call(this,n,t)}}function M(n){var t={};for(var s in n)"onLaunch"!==s&&"onShow"!==s&&"onHide"!==s&&"onError"!==s&&(t[s]=n[s]);return t.onLaunch=function(t){e.call(this,t),"function"==typeof n.onLaunch&&n.onLaunch.call(this,t)},t.onShow=function(t){o.call(this,t),n.onShow&&"function"==typeof n.onShow&&n.onShow.call(this,t)},t.onHide=function(){r.call(this),n.onHide&&"function"==typeof n.onHide&&n.onHide.call(this)},t.onError=function(t){i.call(this,t),n.onError&&"function"==typeof n.onError&&n.onError.call(this,t)},t}function b(n){var t={};for(var e in n)"onLoad"!==e&&"onShow"!==e&&"onHide"!==e&&"onUnload"!==e&&"onPullDownRefresh"!==e&&"onReachBottom"!==e&&"onShareAppMessage"!==e&&(t[e]=n[e]);return t.onLoad=function(t){s.call(this,t),"function"==typeof n.onLoad&&n.onLoad.call(this,t)},t.onShow=function(t){a.call(this),"function"==typeof n.onShow&&n.onShow.call(this,t)},t.onHide=function(t){u.call(this),"function"==typeof n.onHide&&n.onHide.call(this,t)},t.onUnload=function(t){c.call(this),"function"==typeof n.onUnload&&n.onUnload.call(this,t)},t.onReachBottom=function(t){l(),n.onReachBottom&&"function"==typeof n.onReachBottom&&n.onReachBottom.call(this,t)},t.onPullDownRefresh=function(t){f(),n.onPullDownRefresh&&"function"==typeof n.onPullDownRefresh&&n.onPullDownRefresh.call(this,t)},n.onShareAppMessage&&"function"==typeof n.onShareAppMessage&&(t.onShareAppMessage=function(t){var e=n.onShareAppMessage.call(this,t);return void 0===e?(e={},e.path=this.route):void 0===e.path&&(e.path=this.route),h.call(this,e)}),t}void 0===wx.Queue&&(wx.Queue=new function(){this.concurrency=4,this.queue=[],this.tasks=[],this.activeCount=0;var n=this;this.push=function(t){this.tasks.push(new Promise(function(e,o){var r=function(){n.activeCount++,t().then(function(n){e(n)}).then(function(){n.next()})};n.activeCount<n.concurrency?r():n.queue.push(r)}))},this.all=function(){return Promise.all(this.tasks)},this.next=function(){n.activeCount--,n.queue.length>0&&n.queue.shift()()}},wx.Queue.all());var q=require("./ald-stat-conf"),L="7.2.2",P="log",R=!1,k="",H="",I=0,U=0,C="",O="",E="",B=0,T="",N="",j=function(){var n="";try{n=wx.getStorageSync("aldstat_uuid")}catch(t){n="uuid_getstoragesync"}if(n)N=!1;else{n=d();try{wx.setStorageSync("aldstat_uuid",n),N=!0}catch(n){wx.setStorageSync("aldstat_uuid","uuid_getstoragesync")}}return n}(),J=Date.now(),Q="",G="",K="",V=0,W="",$="",z={},F=!1,X=!1,Y="",Z="",nn="",tn="",en=!0,on=!1,rn="";wx.request({url:"https://"+P+".aldwx.com/config/app.json",header:{AldStat:"MiniApp-Stat"},method:"GET",success:function(n){200===n.statusCode&&(L<n.data.version&&console.warn("您的SDK不是最新版本，请尽快升级！"),n.data.warn&&console.warn(n.data.warn),n.data.error&&console.error(n.data.error))}});try{var sn=wx.getSystemInfoSync();z.br=sn.brand,z.pm=sn.model,z.pr=sn.pixelRatio,z.ww=sn.windowWidth,z.wh=sn.windowHeight,z.lang=sn.language,z.wv=sn.version,z.wvv=sn.platform,z.wsdk=sn.SDKVersion,z.sv=sn.system}catch(n){}return wx.getNetworkType({success:function(n){z.nt=n.networkType}}),wx.getSetting({success:function(n){n.authSetting["scope.userLocation"]?wx.getLocation({type:"wgs84",success:function(n){z.lat=n.latitude,z.lng=n.longitude,z.spd=n.speed}}):q.getLocation&&wx.getLocation({type:"wgs84",success:function(n){z.lat=n.latitude,z.lng=n.longitude,z.spd=n.speed}})}}),t.prototype.sendEvent=function(t,e){if(""!==t&&"string"==typeof t&&t.length<=255)if("string"==typeof e&&e.length<=255)D("event",t,e);else if("object"==(void 0===e?"undefined":n(e))){if(JSON.stringify(e).length>=255)return void console.error("自定义事件参数不能超过255个字符");if(m(e))return void console.error("事件参数，参数内部只支持Number,String等类型，请参考接入文档");D("event",t,JSON.stringify(e))}else void 0===e?D("event",t,!1):console.error("事件参数必须为String,Object类型,且参数长度不能超过255个字符");else console.error("事件名称必须为String类型且不能超过255个字符")},t.prototype.sendSession=function(n){if(""!==n&&n){C=n;var t=v();t.st=Date.now(),t.tp="session",t.ct="session",t.ev="event",""===$?wx.getSetting({success:function(n){n.authSetting["scope.userInfo"]?wx.getUserInfo({success:function(n){t.ufo=y(n),E=w(n.userInfo.avatarUrl.split("/")),""!==W&&(t.gid=W),p(t)}}):""!==W&&(t.gid=W,p(t))}}):(t.ufo=$,""!==W&&(t.gid=W),p(t))}else console.error("请传入从后台获取的session_key")},t.prototype.sendOpenid=function(n){if(""!==n&&n){O=n;var t=v();t.st=Date.now(),t.tp="openid",t.ev="event",t.ct="openid",p(t)}else console.error("openID不能为空")},q.plugin?{App:function(n){return App(M(n))},Page:function(n){return Page(b(n))},MpvueApp:function(n){return R=!0,M(n)},MpvuePage:function(n){return b(n)}}:void function(){var n=App,t=Page,d=Component;App=function(t){A(t,"onLaunch",e),A(t,"onShow",o),A(t,"onHide",r),A(t,"onError",i),n(t)},Page=function(n){var e=n.onShareAppMessage;A(n,"onLoad",s),A(n,"onUnload",c),A(n,"onShow",a),A(n,"onHide",u),A(n,"onReachBottom",l),A(n,"onPullDownRefresh",f),void 0!==e&&null!==e&&(n.onShareAppMessage=function(n){if(void 0!==e){var t=e.call(this,n);return void 0===t?(t={},t.path=Y):void 0===t.path&&(t.path=Y),h(t)}}),t(n)},Component=function(n){var t=n.methods.onShareAppMessage;A(n.methods,"onLoad",s),A(n.methods,"onUnload",c),A(n.methods,"onShow",a),A(n.methods,"onHide",u),A(n.methods,"onReachBottom",l),A(n.methods,"onPullDownRefresh",f),void 0!==t&&null!==t&&(n.methods.onShareAppMessage=function(n){if(void 0!==t){var e=t.call(this,n);return void 0===e?(e={},e.path=Y):void 0===e.path&&(e.path=Y),h(e)}}),d(n)}}()}); 
 			}); 
		define("utils/hintInfomation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t={shareContentTitle:"您可以编辑此篇文章的头部信息，分享他人时可以得到展示（不超过24个字）",swiperPropt:["如何将欣欣图文添加到桌面？首先打开欣欣图文小程序进入主页面","然后点击右上角的“三个点”的图标，然后点击下方弹出的“添加到桌面”即可","如果桌面上没有生成图标，则需要去手机设置中添加相应权限，打开手机设置，点击授权管理","找到应用权限管理","找到微信选项","选择桌面快捷方式，将其勾选，再次去欣欣图文中设置“添加到桌面”即可"]};module.exports={hintInfo:t}; 
 			}); 
		define("utils/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function n(n,r){var t=(65535&n)+(65535&r);return(n>>16)+(r>>16)+(t>>16)<<16|65535&t}function r(n,r){return n<<r|n>>>32-r}function t(t,e,u,o,c,f){return n(r(n(n(e,t),n(o,f)),c),u)}function e(n,r,e,u,o,c,f){return t(r&e|~r&u,n,r,o,c,f)}function u(n,r,e,u,o,c,f){return t(r&u|e&~u,n,r,o,c,f)}function o(n,r,e,u,o,c,f){return t(r^e^u,n,r,o,c,f)}function c(n,r,e,u,o,c,f){return t(e^(r|~u),n,r,o,c,f)}function f(r){for(var t=1732584193,f=-271733879,i=-1732584194,a=271733878,h=0;h<r.length;h+=16){var l=t,g=f,v=i,d=a;f=c(f=c(f=c(f=c(f=o(f=o(f=o(f=o(f=u(f=u(f=u(f=u(f=e(f=e(f=e(f=e(f,i=e(i,a=e(a,t=e(t,f,i,a,r[h+0],7,-680876936),f,i,r[h+1],12,-389564586),t,f,r[h+2],17,606105819),a,t,r[h+3],22,-1044525330),i=e(i,a=e(a,t=e(t,f,i,a,r[h+4],7,-176418897),f,i,r[h+5],12,1200080426),t,f,r[h+6],17,-1473231341),a,t,r[h+7],22,-45705983),i=e(i,a=e(a,t=e(t,f,i,a,r[h+8],7,1770035416),f,i,r[h+9],12,-1958414417),t,f,r[h+10],17,-42063),a,t,r[h+11],22,-1990404162),i=e(i,a=e(a,t=e(t,f,i,a,r[h+12],7,1804603682),f,i,r[h+13],12,-40341101),t,f,r[h+14],17,-1502002290),a,t,r[h+15],22,1236535329),i=u(i,a=u(a,t=u(t,f,i,a,r[h+1],5,-165796510),f,i,r[h+6],9,-1069501632),t,f,r[h+11],14,643717713),a,t,r[h+0],20,-373897302),i=u(i,a=u(a,t=u(t,f,i,a,r[h+5],5,-701558691),f,i,r[h+10],9,38016083),t,f,r[h+15],14,-660478335),a,t,r[h+4],20,-405537848),i=u(i,a=u(a,t=u(t,f,i,a,r[h+9],5,568446438),f,i,r[h+14],9,-1019803690),t,f,r[h+3],14,-187363961),a,t,r[h+8],20,1163531501),i=u(i,a=u(a,t=u(t,f,i,a,r[h+13],5,-1444681467),f,i,r[h+2],9,-51403784),t,f,r[h+7],14,1735328473),a,t,r[h+12],20,-1926607734),i=o(i,a=o(a,t=o(t,f,i,a,r[h+5],4,-378558),f,i,r[h+8],11,-2022574463),t,f,r[h+11],16,1839030562),a,t,r[h+14],23,-35309556),i=o(i,a=o(a,t=o(t,f,i,a,r[h+1],4,-1530992060),f,i,r[h+4],11,1272893353),t,f,r[h+7],16,-155497632),a,t,r[h+10],23,-1094730640),i=o(i,a=o(a,t=o(t,f,i,a,r[h+13],4,681279174),f,i,r[h+0],11,-358537222),t,f,r[h+3],16,-722521979),a,t,r[h+6],23,76029189),i=o(i,a=o(a,t=o(t,f,i,a,r[h+9],4,-640364487),f,i,r[h+12],11,-421815835),t,f,r[h+15],16,530742520),a,t,r[h+2],23,-995338651),i=c(i,a=c(a,t=c(t,f,i,a,r[h+0],6,-198630844),f,i,r[h+7],10,1126891415),t,f,r[h+14],15,-1416354905),a,t,r[h+5],21,-57434055),i=c(i,a=c(a,t=c(t,f,i,a,r[h+12],6,1700485571),f,i,r[h+3],10,-1894986606),t,f,r[h+10],15,-1051523),a,t,r[h+1],21,-2054922799),i=c(i,a=c(a,t=c(t,f,i,a,r[h+8],6,1873313359),f,i,r[h+15],10,-30611744),t,f,r[h+6],15,-1560198380),a,t,r[h+13],21,1309151649),i=c(i,a=c(a,t=c(t,f,i,a,r[h+4],6,-145523070),f,i,r[h+11],10,-1120210379),t,f,r[h+2],15,718787259),a,t,r[h+9],21,-343485551),t=n(t,l),f=n(f,g),i=n(i,v),a=n(a,d)}return[t,f,i,a]}function i(n){for(var r="",t=0;t<4*n.length;t++)r+="0123456789abcdef".charAt(n[t>>2]>>t%4*8+4&15)+"0123456789abcdef".charAt(n[t>>2]>>t%4*8&15);return r}function a(n){for(var r=1+(n.length+8>>6),t=new Array(16*r),e=0;e<16*r;e++)t[e]=0;for(e=0;e<n.length;e++)t[e>>2]|=(255&n.charCodeAt(e))<<e%4*8;return t[e>>2]|=128<<e%4*8,t[16*r-2]=8*n.length,t}module.exports={hexMD5:function(n){return i(f(a(n)))}}; 
 			}); 
		define("utils/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x=["/sendformid","header","downloadFile","lfqFe","tempFilePath","createCanvasContext","shareCanvas","drawImage","../../img/shipinbofang.png","draw","canvasToTempFilePath","dKbpn","setData","gLxRW","forEach","removeStorageSync","authorSpaceVideo","newDetails","exports","./md5.js","./aes.js","getFullYear","getMonth","getDate","getHours","getMinutes","getSeconds","map","join","toString","BPxcO","yepPG","login","code","wxdeb8cc46902cefcc","request","data","apiUrl","/code","globalData","_header","POST","openId","请求code接口返回成功","aldstat","sendEvent","重新请求接口获取openid","log","通过util获取code","请求code接口返回失败","time","getTime","hexMD5","%cykj*^=#","stringify","length","split","day","yeasM","month","January","February","March","April","May","June","July","August","September","October","November","December","_time","_data","getSystemInfo","getSystemInfoSync","payInfo","wfByq","HCFXf","china_cy@2019!@#","get","parse","CryptoJS","AES","decrypt","enc","Utf8","encrypt","********rendFlag***********","system","indexOf","iOS","close","open","name","openFlag","type","_index","addId","path","imgsrc","rendInfo","adModuleArgs","ciphertext","Base64","salt","replace","lib","CipherParams","create","Hex","warn","当前调试基础库为：","SDKVersion",";\n\n当前系统为：",";\n\n当前微信版本为：","version",";\n\n当前apiurl为：",";\n\n默认线上api为：https://wxapi.xabbp.com/api","https://wxapi.xabbp.com/api","showModal","！！！警告！！！","apiUrl与默认值不一样","马上确认","red"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(x,394);var e=function(e,n){return x[e-=0]},n=require(e("0x0")),a=require(e("0x1")),t=function(x){return(x=x[e("0xa")]())[1]?x:"0"+x},r={stringify:function(x){var n={ct:x[e("0x54")][e("0xa")](a[e("0x3f")][e("0x42")][e("0x55")])};return x.iv&&(n.iv=x.iv[e("0xa")]()),x[e("0x56")]&&(n.s=x[e("0x56")][e("0xa")]()),JSON[e("0x23")](n)[e("0x57")](/\s/g,"")},parse:function(x){x=JSON[e("0x3e")](x);var n=a[e("0x3f")][e("0x58")][e("0x59")][e("0x5a")]({ciphertext:a[e("0x3f")][e("0x42")][e("0x55")][e("0x3e")](x.ct)});return x.iv&&(n.iv=a[e("0x3f")][e("0x42")][e("0x5b")][e("0x3e")](x.iv)),x.s&&(n[e("0x56")]=a[e("0x3f")][e("0x42")][e("0x5b")][e("0x3e")](x.s)),n}};module[e("0x7c")]={formatTime:function(x){var n=x[e("0x2")](),a=x[e("0x3")]()+1,r=x[e("0x4")](),o=x[e("0x5")](),c=x[e("0x6")]();return x=x[e("0x7")](),[n,a,r][e("0x8")](t)[e("0x9")]("/")+" "+[o,c,x][e("0x8")](t)[e("0x9")](":")},timeFormat:function(x){function n(x){if(e("0xb")!==e("0xc"))return 10>x?"0"+x:x;wx[e("0xd")]({success:function(n){var a={data:{code:n[e("0xe")],appId:e("0xf")}};wx[e("0x10")]({url:getApp()[e("0x11")][e("0x12")]+e("0x13"),header:getApp()[e("0x14")][e("0x15")],data:a,method:e("0x16"),success:function(n){x[c]=n[e("0x11")],getApp()[e("0x14")][c]=n[e("0x11")][e("0x17")]||n[e("0x11")],n={code:a[e("0x11")][e("0xe")]?"有":"无",openId:n[e("0x11")]?"有":"无","状态":e("0x18")},getApp()[e("0x19")][e("0x1a")](e("0x1b"),n),t(),console[e("0x1c")](e("0x1d"))},fail:function(x){x={code:a[e("0x11")][e("0xe")]?"有":"无",openId:res[e("0x11")]?"有":"无","状态":e("0x1e")},getApp()[e("0x19")][e("0x1a")](e("0x1b"),x)}})}})}var a=new Date(x[e("0x1f")]),t=a[e("0x2")](),r=a[e("0x3")]()+1,o=a[e("0x4")](),c=a[e("0x5")](),i=a[e("0x6")]();return a=a[e("0x7")](),x[e("0x1f")]=t+"-"+n(r)+"-"+n(o)+" "+n(c)+":"+n(i)+":"+n(a),x},Permissions:function(){var x=(new Date)[e("0x20")](),a=n[e("0x21")](e("0x22")+x);return JSON[e("0x23")]({ciphertext:a,times:x})},_timeFormat:function(x){for(var n=0;n<x[e("0x24")];n++){var a=x[n][e("0x1f")][e("0x25")]("-"),t={};t[e("0x26")]=a[2],t[e("0x27")]=a[0]+"年"+a[1]+"月",t[e("0x28")]={"01":e("0x29"),"02":e("0x2a"),"03":e("0x2b"),"04":e("0x2c"),"05":e("0x2d"),"06":e("0x2e"),"07":e("0x2f"),"08":e("0x30"),"09":e("0x31"),10:e("0x32"),11:e("0x33"),12:e("0x34")}[a[1]],x[n][e("0x35")]=t}return x},openFlag:function(x,n){x.AD=x.AD||{};var t={},o=n[e("0x36")][e("0x37")]||wx[e("0x38")](),c={AD:{}};c[e("0x39")]=x[e("0x39")][e("0x25")]("|");for(var i in x.AD){if(e("0x3a")===e("0x3b"))return t=t||e("0x3c"),e("0x3d")==n?JSON[e("0x3e")](a[e("0x3f")][e("0x40")][e("0x41")](JSON[e("0x23")](x),t,{format:r})[e("0xa")](a[e("0x3f")][e("0x42")][e("0x43")])):a[e("0x3f")][e("0x40")][e("0x44")](JSON[e("0x23")](x),t,{format:r})[e("0xa")]();var f=x.AD[i][e("0x25")]("|");c.AD[i]=f}if(console[e("0x1c")](e("0x45")),console[e("0x1c")](c),1==c[e("0x39")][0]&&(x=c[e("0x39")][1][e("0x25")]("&"),f=c[e("0x39")][2][e("0x25")]("&"),1<x[e("0x24")]&&(-1<o[e("0x46")][e("0x47")](e("0x48"))?(c[e("0x39")][1]=x[1],c[e("0x39")][2]=f[1]):(c[e("0x39")][1]=x[0],c[e("0x39")][2]=f[0]))),-1<o[e("0x46")][e("0x47")](e("0x48")))for(i in c[e("0x39")][0]=e(0==c[e("0x39")][0]||"2"==c[e("0x39")][0]?"0x49":"0x4a"),c.AD)o={},c.AD[i][0]=e(0==c.AD[i][0]||"2"==c.AD[i][0]?"0x49":"0x4a"),o[e("0x4b")]=i,o[e("0x4c")]=c.AD[i][0],o[e("0x4d")]=c.AD[i][1],o[e("0x4e")]=c.AD[i][2],o[e("0x4f")]=c.AD[i][3],o[e("0x50")]=c.AD[i][4],o[e("0x51")]=c.AD[i][5],t[e("0x4b")]=o;else for(i in c[e("0x39")][0]=e(0==c[e("0x39")][0]||"3"==c[e("0x39")][0]?"0x49":"0x4a"),c.AD)o={},c.AD[i][0]=e(0==c.AD[i][0]||"3"==c.AD[i][0]?"0x49":"0x4a"),o[e("0x4b")]=i,o[e("0x4c")]=c.AD[i][0],o[e("0x4d")]=c.AD[i][1],o[e("0x4e")]=c.AD[i][2],o[e("0x4f")]=c.AD[i][3],o[e("0x50")]=c.AD[i][4],o[e("0x51")]=c.AD[i][5],t[e("0x4b")]=o;n[e("0x36")][e("0x52")]=c,n[e("0x36")][e("0x53")]=t},getMouthAndDay:function(){var x=new Date,n=x[e("0x3")]()+1;return x=x[e("0x4")](),n+"/"+x},aes:function(x,n,t){return t=t||e("0x3c"),e("0x3d")==n?JSON[e("0x3e")](a[e("0x3f")][e("0x40")][e("0x41")](JSON[e("0x23")](x),t,{format:r})[e("0xa")](a[e("0x3f")][e("0x42")][e("0x43")])):a[e("0x3f")][e("0x40")][e("0x44")](JSON[e("0x23")](x),t,{format:r})[e("0xa")]()},test:function(x){var n=wx[e("0x38")]();console[e("0x5c")](e("0x5d")+n[e("0x5e")]+e("0x5f")+n[e("0x46")]+e("0x60")+n[e("0x61")]+e("0x62")+x+e("0x63")),e("0x64")!==x&&wx[e("0x65")]({title:e("0x66"),content:e("0x67"),showCancel:!1,confirmText:e("0x68"),confirmColor:e("0x69")})},sendFormId:function(x,n,a){wx[e("0x10")]({url:a[e("0x11")][e("0x12")]+e("0x6a"),header:a[e("0x14")][e("0x6b")],method:e("0x16"),data:{formid:x,date:n},success:function(x){},fail:function(){}})},formatShareImg:function(x,n){var a="";wx[e("0x6c")]({url:x,success:function(x){e("0x6d")===e("0x6d")?(a=x[e("0x6e")],(x=wx[e("0x6f")](e("0x70")))[e("0x71")](a,0,0,375,300),x[e("0x71")](e("0x72"),147.5,110,80,80),x[e("0x73")](!0,function(){wx[e("0x74")]({x:0,y:0,width:375,height:320,canvasId:e("0x70"),success:function(x){e("0x75")===e("0x75")?(x=x[e("0x6e")],n[e("0x76")]({shareCanvas:x}),n[e("0x36")][e("0x70")]=x):(x={code:n[e("0x11")][e("0xe")]?"有":"无",openId:res[e("0x11")]?"有":"无","状态":e("0x1e")},getApp()[e("0x19")][e("0x1a")](e("0x1b"),x))},fail:function(x){console[e("0x1c")](x)}})})):console[e("0x1c")](x)}})},filterArgs:function(x,n,a,t){var r=!1;a=!1;for(var o in x)if(!x[o]||""==x[o])if(n[e("0x78")](function(x){x==o&&(r=!0)}),r)r=!1;else switch(a=!0,o){case e("0x17"):wx[e("0xd")]({success:function(n){var a={data:{code:n[e("0xe")],appId:e("0xf")}};wx[e("0x10")]({url:getApp()[e("0x11")][e("0x12")]+e("0x13"),header:getApp()[e("0x14")][e("0x15")],data:a,method:e("0x16"),success:function(n){x[o]=n[e("0x11")],getApp()[e("0x14")][o]=n[e("0x11")][e("0x17")]||n[e("0x11")],n={code:a[e("0x11")][e("0xe")]?"有":"无",openId:n[e("0x11")]?"有":"无","状态":e("0x18")},getApp()[e("0x19")][e("0x1a")](e("0x1b"),n),t(),console[e("0x1c")](e("0x1d"))},fail:function(x){if(e("0x77")!==e("0x77")){x.AD=x.AD||{};var n={},t=a[e("0x36")][e("0x37")]||wx[e("0x38")](),r={AD:{}};r[e("0x39")]=x[e("0x39")][e("0x25")]("|");for(var o in x.AD){var c=x.AD[o][e("0x25")]("|");r.AD[o]=c}if(console[e("0x1c")](e("0x45")),console[e("0x1c")](r),1==r[e("0x39")][0]&&(x=r[e("0x39")][1][e("0x25")]("&"),c=r[e("0x39")][2][e("0x25")]("&"),1<x[e("0x24")]&&(-1<t[e("0x46")][e("0x47")](e("0x48"))?(r[e("0x39")][1]=x[1],r[e("0x39")][2]=c[1]):(r[e("0x39")][1]=x[0],r[e("0x39")][2]=c[0]))),-1<t[e("0x46")][e("0x47")](e("0x48")))for(o in r[e("0x39")][0]=e(0==r[e("0x39")][0]||"2"==r[e("0x39")][0]?"0x49":"0x4a"),r.AD)t={},r.AD[o][0]=e(0==r.AD[o][0]||"2"==r.AD[o][0]?"0x49":"0x4a"),t[e("0x4b")]=o,t[e("0x4c")]=r.AD[o][0],t[e("0x4d")]=r.AD[o][1],t[e("0x4e")]=r.AD[o][2],t[e("0x4f")]=r.AD[o][3],t[e("0x50")]=r.AD[o][4],t[e("0x51")]=r.AD[o][5],n[e("0x4b")]=t;else for(o in r[e("0x39")][0]=e(0==r[e("0x39")][0]||"3"==r[e("0x39")][0]?"0x49":"0x4a"),r.AD)t={},r.AD[o][0]=e(0==r.AD[o][0]||"3"==r.AD[o][0]?"0x49":"0x4a"),t[e("0x4b")]=o,t[e("0x4c")]=r.AD[o][0],t[e("0x4d")]=r.AD[o][1],t[e("0x4e")]=r.AD[o][2],t[e("0x4f")]=r.AD[o][3],t[e("0x50")]=r.AD[o][4],t[e("0x51")]=r.AD[o][5],n[e("0x4b")]=t;a[e("0x36")][e("0x52")]=r,a[e("0x36")][e("0x53")]=n}else x={code:a[e("0x11")][e("0xe")]?"有":"无",openId:res[e("0x11")]?"有":"无","状态":e("0x1e")},getApp()[e("0x19")][e("0x1a")](e("0x1b"),x)}})}});break;default:return}a||t()},storageAdmin:function(){wx[e("0x79")](e("0x7a")),wx[e("0x79")](e("0x7b"))}}; 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(x){return typeof x}:function(x){return x&&"function"==typeof Symbol&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},e=["scope","arrayIteratorImpl","length","arrayIterator","ASSUME_ES5","ASSUME_NO_NATIVE_MAP","ASSUME_NO_NATIVE_SET","SIMPLE_FROUND_POLYFILL","defineProperty","function","defineProperties","prototype","value","getGlobal","undefined","global","SYMBOL_PREFIX","jscomp_symbol_","initSymbol","Symbol","dIiUB","initSymbolIterator","iterator","iteratorPrototype","initSymbolAsyncIterator","asyncIterator","iteratorFromArray","pCpgr","VfyRh","openId","openid","未发现openId","formidlistLength","globalData","formIdList","request","data","apiUrl","/savemessage","header","POST","getMouthAndDay","log","接口返回值","saveFormId","hasSaveList","userFormIdTime","userFormIdFlag","updataFormId","error","接收到7个formid，返回非10000","apiBackCode","aldstat","sendEvent","用户获取formid","next","aCNVc","ZfDXj","polyfill","split","Array.prototype.keys","es6","es3","./utils/ald-stat.js","App","./utils/ald-stat-conf.js","./utils/util","https://wxapi.xabbp.com/api","getMenuButtonBoundingClientRect","btncoor","left","storageAdmin","_scene","scene","_curl","query","curl","_testApiFlag","test","getSeconds","_ald_inAppTime","_dataInfo","login","iyQTZ","/code","_header","code","wxdeb8cc46902cefcc","get code","versionUpdate","获取openId事件","获取openId成功","success","获取openId失败","wtvmJ","RMuAG","dcTLc","getUpdateManager","onCheckForUpdate","hasUpdate","showLoading","新版本更新中","onUpdateReady","applyUpdate","onUpdateFailed","新版本更新失败，请检查网络","cIdGR","hideLoading","https://wxapi.xabbp.com/api/version","BTXfo","getStorageSync","userFormId","parse","_flag","_time","上传savemessage参数","getDataFormComp","filterArgs","keys","forEach","observe","ELlTw","default1","12/17"," application/json","Permissions","1548915445202","1001"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(e,256);var t=function(x,t){return e[x-=0]},n=n||{};n[t("0x0")]={},n[t("0x1")]=function(x){var e=0;return function(){return e<x[t("0x2")]?{done:!1,value:x[e++]}:{done:!0}}},n[t("0x3")]=function(x){return{next:n[t("0x1")](x)}},n[t("0x4")]=!1,n[t("0x5")]=!1,n[t("0x6")]=!1,n[t("0x7")]=!1,n[t("0x8")]=n[t("0x4")]||t("0x9")==x(Object[t("0xa")])?Object[t("0x8")]:function(x,e,n){x!=Array[t("0xb")]&&x!=Object[t("0xb")]&&(x[e]=n[t("0xc")])},n[t("0xd")]=function(e){return t("0xe")!=("undefined"==typeof window?"undefined":x(window))&&window===e?e:t("0xe")!=("undefined"==typeof global?"undefined":x(global))&&null!=global?global:e},n[t("0xf")]=n[t("0xd")](void 0),n[t("0x10")]=t("0x11"),n[t("0x12")]=function(){n[t("0x12")]=function(){},n[t("0xf")][t("0x13")]||(n[t("0xf")][t("0x13")]=n[t("0x13")])},n[t("0x13")]=function(){var x=0;return function(e){if(t("0x14")===t("0x14"))return n[t("0x10")]+(e||"")+x++;x!=Array[t("0xb")]&&x!=Object[t("0xb")]&&(x[e]=c[t("0xc")])}}(),n[t("0x15")]=function(){n[t("0x12")]();var e=n[t("0xf")][t("0x13")][t("0x16")];e||(e=n[t("0xf")][t("0x13")][t("0x16")]=n[t("0xf")][t("0x13")](t("0x16"))),t("0x9")!=x(Array[t("0xb")][e])&&n[t("0x8")](Array[t("0xb")],e,{configurable:!0,writable:!0,value:function(){return n[t("0x17")](n[t("0x1")](this))}}),n[t("0x15")]=function(){}},n[t("0x18")]=function(){n[t("0x12")]();var x=n[t("0xf")][t("0x13")][t("0x19")];x||(x=n[t("0xf")][t("0x13")][t("0x19")]=n[t("0xf")][t("0x13")](t("0x19"))),n[t("0x18")]=function(){}},n[t("0x17")]=function(x){return n[t("0x15")](),x={next:x},x[n[t("0xf")][t("0x13")][t("0x16")]]=function(){return this},x},n[t("0x1a")]=function(x,e){n[t("0x15")](),x instanceof String&&(x+="");var o=0,r={next:function(){if(t("0x1b")!==t("0x1c")){if(o<x[t("0x2")]){var n=o++;return{value:e(n,x[n]),done:!1}}return r[t("0x37")]=function(){return t("0x38")!==t("0x39")?{done:!0,value:void 0}:r},r[t("0x37")]()}o[t("0x1d")]=e[t("0x1e")]||t("0x1f"),o[t("0x20")]=x[t("0x21")][t("0x22")][t("0x2")],wx[t("0x23")]({url:x[t("0x24")][t("0x25")]+t("0x26"),header:x[t("0x21")][t("0x27")],method:t("0x28"),data:e,success:function(e){var n=a[t("0x29")](new Date);console[t("0x2a")](t("0x2b")+e[t("0x24")][t("0x2c")]),1e4!=e[t("0x24")][t("0x2c")]&&(o[t("0x2d")]=x[t("0x21")][t("0x22")][t("0x2")]),x[t("0x21")][t("0x22")]=[],1e4==e[t("0x24")][t("0x2c")]&&(x[t("0x21")][t("0x2e")]=n,x[t("0x21")][t("0x2f")]=!0,x[t("0x21")][t("0x30")]=!1),7==o[t("0x20")]&&1e4!=e[t("0x24")][t("0x2c")]&&(o[t("0x31")]=t("0x32")),o[t("0x33")]=e[t("0x24")][t("0x2c")],getApp()[t("0x34")][t("0x35")](t("0x36"),o)}})}};return r[Symbol[t("0x16")]]=function(){return r},r},n[t("0x3a")]=function(x,e,o,a){if(e){for(o=n[t("0xf")],x=x[t("0x3b")]("."),a=0;a<x[t("0x2")]-1;a++){var r=x[a];r in o||(o[r]={}),o=o[r]}(e=e(a=o[x=x[x[t("0x2")]-1]]))!=a&&null!=e&&n[t("0x8")](o,x,{configurable:!0,writable:!0,value:e})}},n[t("0x3a")](t("0x3c"),function(x){return x||function(){return n[t("0x1a")](this,function(x){return x})}},t("0x3d"),t("0x3e"));var o=require(t("0x3f"))[t("0x40")],a=(require(t("0x41")),require(t("0x42")));o({data:{apiUrl:t("0x43")},onLaunch:function(x){var e=this;console[t("0x2a")](x),wx[t("0x44")]&&(e[t("0x21")][t("0x45")]=wx[t("0x44")]()[t("0x46")]),a[t("0x47")](),e[t("0x21")][t("0x48")]=x[t("0x49")],e[t("0x21")][t("0x4a")]=x[t("0x4b")][t("0x4c")],this[t("0x21")][t("0x4d")]&&a[t("0x4e")](this[t("0x24")][t("0x25")]),x=(new Date)[t("0x4f")](),this[t("0x21")][t("0x50")]=x,e[t("0x51")](),wx[t("0x52")]({success:function(x){if(t("0x53")!==t("0x53")){var n=this;console[t("0x2a")](x),wx[t("0x44")]&&(n[t("0x21")][t("0x45")]=wx[t("0x44")]()[t("0x46")]),a[t("0x47")](),n[t("0x21")][t("0x48")]=x[t("0x49")],n[t("0x21")][t("0x4a")]=x[t("0x4b")][t("0x4c")],this[t("0x21")][t("0x4d")]&&a[t("0x4e")](this[t("0x24")][t("0x25")]),x=(new Date)[t("0x4f")](),this[t("0x21")][t("0x50")]=x,n[t("0x51")](),wx[t("0x52")]({success:function(x){wx[t("0x23")]({url:n[t("0x24")][t("0x25")]+t("0x54"),header:n[t("0x21")][t("0x55")],data:{data:{code:x[t("0x56")],appId:t("0x57")}},method:t("0x28"),success:function(x){console[t("0x2a")](t("0x58")),n[t("0x59")](x),n[t("0x21")][t("0x1d")]=x[t("0x24")][t("0x1d")]||x[t("0x24")],n[t("0x34")][t("0x35")](t("0x5a"),{"请求code结果":t("0x5b"),"原因":t("0x5c")})},fail:function(x){n[t("0x34")][t("0x35")](t("0x5a"),{"请求code结果":t("0x5d"),"原因":x})}})}})}else wx[t("0x23")]({url:e[t("0x24")][t("0x25")]+t("0x54"),header:e[t("0x21")][t("0x55")],data:{data:{code:x[t("0x56")],appId:t("0x57")}},method:t("0x28"),success:function(x){if(t("0x5e")!==t("0x5f"))console[t("0x2a")](t("0x58")),e[t("0x59")](x),e[t("0x21")][t("0x1d")]=x[t("0x24")][t("0x1d")]||x[t("0x24")],e[t("0x34")][t("0x35")](t("0x5a"),{"请求code结果":t("0x5b"),"原因":t("0x5c")});else{var n=x[d];n in c||(c[n]={}),c=c[n]}},fail:function(x){e[t("0x34")][t("0x35")](t("0x5a"),{"请求code结果":t("0x5d"),"原因":x})}})}})},versionUpdate:function(){function x(){if(t("0x60")!==t("0x60"))return n[t("0x1a")](this,function(x){return x});wx[t("0x61")]()[t("0x62")](function(x){x[t("0x63")]&&(wx[t("0x64")]({title:t("0x65"),mask:!0}),wx[t("0x61")]()[t("0x66")](function(){wx[t("0x61")]()[t("0x67")]()}),wx[t("0x61")]()[t("0x68")](function(){wx[t("0x64")]({title:t("0x69"),mask:!0}),setTimeout(function(){t("0x6a")!==t("0x6a")?b[t("0x34")][t("0x35")](t("0x5a"),{"请求code结果":t("0x5d"),"原因":x}):wx[t("0x6b")]()},1e3)}))})}wx[t("0x23")]({url:t("0x6c"),success:function(e){if(t("0x6d")!==t("0x6d"))return x;"1"==e[t("0x24")]&&x()}})},_dataInfo:function(){var x=wx[t("0x6e")](t("0x6f"));x&&(x=JSON[t("0x70")](x),this[t("0x21")][t("0x2f")]=x[t("0x71")],this[t("0x21")][t("0x2e")]=x[t("0x72")])},onHide:function(){console[t("0x2a")](t("0x73")),console[t("0x2a")](this[t("0x21")][t("0x30")]),console[t("0x2a")](this[t("0x21")][t("0x22")]),this[t("0x21")][t("0x30")]&&this[t("0x21")][t("0x22")][t("0x2")]&&this[t("0x74")]()},getDataFormComp:function(){var x=this,e={formidlist:x[t("0x21")][t("0x22")],openid:x[t("0x21")][t("0x1d")]},n={};a[t("0x75")](e,[],x,function(){n[t("0x1d")]=e[t("0x1e")]||t("0x1f"),n[t("0x20")]=x[t("0x21")][t("0x22")][t("0x2")],wx[t("0x23")]({url:x[t("0x24")][t("0x25")]+t("0x26"),header:x[t("0x21")][t("0x27")],method:t("0x28"),data:e,success:function(e){var o=a[t("0x29")](new Date);console[t("0x2a")](t("0x2b")+e[t("0x24")][t("0x2c")]),1e4!=e[t("0x24")][t("0x2c")]&&(n[t("0x2d")]=x[t("0x21")][t("0x22")][t("0x2")]),x[t("0x21")][t("0x22")]=[],1e4==e[t("0x24")][t("0x2c")]&&(x[t("0x21")][t("0x2e")]=o,x[t("0x21")][t("0x2f")]=!0,x[t("0x21")][t("0x30")]=!1),7==n[t("0x20")]&&1e4!=e[t("0x24")][t("0x2c")]&&(n[t("0x31")]=t("0x32")),n[t("0x33")]=e[t("0x24")][t("0x2c")],getApp()[t("0x34")][t("0x35")](t("0x36"),n)}})})},setWatcher:function(x,e,n){var o=this;Object[t("0x76")](e)[t("0x77")](function(a){o[t("0x78")](x,a,e[a],n)})},observe:function(x,e,o,a){var r=x[e];Object[t("0x8")](x,e,{configurable:!0,enumerable:!0,set:function(x){t("0x79")===t("0x79")?r!=x&&(r=x,o(x,a)):(n[t("0x12")]=function(){},n[t("0xf")][t("0x13")]||(n[t("0xf")][t("0x13")]=n[t("0x13")]))},get:function(){return r}})},globalData:{userInfo:null,openId:"",nav_title_self:!1,list_style_grund:t("0x7a"),userFormIdFlag:!1,userFormIdTime:t("0x7b"),_ald_inAppTime:0,_ald_hadcalcu:!1,btncoor:"",header:{"content-type":t("0x7c"),Permissions:a[t("0x7d")](),isencry:!0,key:t("0x7e")},_header:{"content-type":t("0x7c"),isencry:!0},_testApiFlag:!0,_scene:t("0x7f"),_curl:"",updataFormId:!0,formIdList:[],backListFlag:!1}}); 
 			}); 	require("app.js");
 		__wxRoute = 'pages/compenents/adcompenent/adcompenent';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/compenents/adcompenent/adcompenent.js';	define("pages/compenents/adcompenent/adcompenent.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=["system","indexOf","iOS","close","open","setData","myPrivateData","openFlag","getSystemInfoSync","payInfo","split"];!function(t,n){!function(n){for(;--n;)t.push(t.shift())}(++n)}(t,271);var n=function(n,e){return t[n-=0]};Component({behaviors:[],properties:{adList:{type:Array,value:"",observer:function(t,n,e){}},_index:Number,topArgs:Object},data:{},lifetimes:{attached:function(){},moved:function(){},detached:function(){}},attached:function(){},ready:function(){this[n("0x0")]()},openFlag:function(t,e){t=topArgs.AD;var o=wx[n("0x1")](),i={AD:{}};i[n("0x2")]=t[n("0x2")][n("0x3")]("|");for(var a in t.AD){var x=t.AD[a][n("0x3")]("|");i.AD[a]=x}if(-1<o[n("0x4")][n("0x5")](n("0x6")))for(a in i[n("0x2")][0]=n(0==i[n("0x2")][0]||"2"==i[n("0x2")][0]?"0x7":"0x8"),i.AD)i.AD[a][0]=n(0==i.AD[a][0]||"2"==i.AD[a][0]?"0x7":"0x8");else for(a in i[n("0x2")][0]=n(0==i[n("0x2")][0]||"3"==i[n("0x2")][0]?"0x7":"0x8"),i.AD)i.AD[a][0]=n(0==i.AD[a][0]||"3"==i.AD[a][0]?"0x7":"0x8");e[n("0x9")]({rendInfo:i})},pageLifetimes:{show:function(){},hide:function(){},resize:function(){}},methods:{onMyButtonTap:function(){this[n("0x9")]({})},_myPrivateMethod:function(){this[n("0x9")]({"A[0].B":n("0xa")})},_propertyChange:function(t,n){}}}); 
 			}); 	require("pages/compenents/adcompenent/adcompenent.js");
 		__wxRoute = 'pages/compenents/navTab/navTab';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/compenents/navTab/navTab.js';	define("pages/compenents/navTab/navTab.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({behaviors:[],properties:{myProperty:{type:String,value:"",observer:function(t,e,n){}},myProperty2:String},data:{},lifetimes:{attached:function(){},moved:function(){},detached:function(){}},attached:function(){},ready:function(){},pageLifetimes:{show:function(){},hide:function(){},resize:function(){}},methods:{}}); 
 			}); 	require("pages/compenents/navTab/navTab.js");
 		__wxRoute = 'pages/compenents/richText/richText';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/compenents/richText/richText.js';	define("pages/compenents/richText/richText.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(x){return typeof x}:function(x){return x&&"function"==typeof Symbol&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},e=["navigateToMiniProgram","XokOw","DxPnX","selectable","setClipboardData","showToast","内容已复制","request","apiUrl","/goodsclick","header","POST","log","aldstat","sendEvent","图文类广告点击图片购买","点击按钮","indexOf","http","navigateTo","../webView/webView?srcView=","target","hasOwnProperty","ignore","previewImage","src","length","../../../Parser/Parser.js","string","ZafVL","LJUzG","triggerEvent","parse","imgList","title","setNavigationBarTitle","setData","nodes","data","tagStyle","then","gYKaf","HdLJM","constructor","object","currentTarget","dataset","appid","href","globalData","openId"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(e,129);var t=function(x,t){return e[x-=0]},n=require(t("0x0")),o=[];Component({properties:{html:{type:null,value:"",observer:function(e){if(e)if(t("0x1")==(void 0===e?"undefined":x(e)))if(t("0x2")===t("0x3"))i[t("0x4")](t("0x5"),e),o=e[t("0x6")],e[t("0x7")]&&wx[t("0x8")]({title:e[t("0x7")]}),i[t("0x9")]({nodes:e[t("0xa")]});else{var i=this;n(e,this[t("0xb")][t("0xc")])[t("0xd")](function(e){if(t("0xe")===t("0xf"))if(e)if(t("0x1")==(void 0===e?"undefined":x(e))){var s=this;n(e,this[t("0xb")][t("0xc")])[t("0xd")](function(x){s[t("0x4")](t("0x5"),x),o=x[t("0x6")],x[t("0x7")]&&wx[t("0x8")]({title:x[t("0x7")]}),s[t("0x9")]({nodes:x[t("0xa")]})})}else e[t("0x10")]==Array?(o=[],this[t("0x9")]({nodes:e})):t("0x11")==(void 0===e?"undefined":x(e))&&(o=e[t("0x6")]||[],e[t("0x7")]&&wx[t("0x8")]({title:e[t("0x7")]}),this[t("0x9")]({nodes:JSON[t("0x5")](e[t("0xa")])}));else this[t("0x9")]({nodes:[]});else i[t("0x4")](t("0x5"),e),o=e[t("0x6")],e[t("0x7")]&&wx[t("0x8")]({title:e[t("0x7")]}),i[t("0x9")]({nodes:e[t("0xa")]})})}else e[t("0x10")]==Array?(o=[],this[t("0x9")]({nodes:e})):t("0x11")==(void 0===e?"undefined":x(e))&&(o=e[t("0x6")]||[],e[t("0x7")]&&wx[t("0x8")]({title:e[t("0x7")]}),this[t("0x9")]({nodes:JSON[t("0x5")](e[t("0xa")])}));else this[t("0x9")]({nodes:[]})}},scroll:{type:Boolean,value:!0},selectable:{type:Boolean,value:!0},tagStyle:{type:Object,value:{}}},methods:{tapevent:function(x){if(x[t("0x12")][t("0x13")][t("0x14")]){var e={appId:x[t("0x12")][t("0x13")][t("0x14")],path:x[t("0x12")][t("0x13")][t("0x15")],openid:getApp()[t("0x16")][t("0x17")]};wx[t("0x18")]({appId:x[t("0x12")][t("0x13")][t("0x14")],path:x[t("0x12")][t("0x13")][t("0x15")],success:function(x){t("0x19")===t("0x1a")?this[t("0xb")][t("0x1b")]&&wx[t("0x1c")]({data:x[t("0x12")][t("0x13")][t("0x15")],success:function(x){wx[t("0x1d")]({title:t("0x1e")})}}):(wx[t("0x1f")]({url:getApp()[t("0xb")][t("0x20")]+t("0x21"),header:getApp()[t("0x16")][t("0x22")],data:e,method:t("0x23"),success:function(x){console[t("0x24")](x)}}),getApp()[t("0x25")][t("0x26")](t("0x27"),t("0x28")))}})}else-1<x[t("0x12")][t("0x13")][t("0x15")][t("0x29")](t("0x2a"))?wx[t("0x2b")]({url:t("0x2c")+x[t("0x12")][t("0x13")][t("0x15")]}):x[t("0x12")][t("0x13")][t("0x15")]&&wx[t("0x2b")]({url:x[t("0x12")][t("0x13")][t("0x15")]})},copyhref:function(x){this[t("0xb")][t("0x1b")]&&wx[t("0x1c")]({data:x[t("0x12")][t("0x13")][t("0x15")],success:function(x){wx[t("0x1d")]({title:t("0x1e")})}})},previewImg:function(x){x[t("0x2d")][t("0x13")][t("0x2e")](t("0x2f"))||wx[t("0x30")]({current:x[t("0x2d")][t("0x13")][t("0x31")],urls:o[t("0x32")]?o:[x[t("0x2d")][t("0x13")][t("0x31")]],success:function(x){},fail:function(x){}})}}}); 
 			}); 	require("pages/compenents/richText/richText.js");
 		__wxRoute = 'pages/newVideo/newVideo';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/newVideo/newVideo.js';	define("pages/newVideo/newVideo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x=["_ald_hadcalcu","_ald_inAppTime","model","version","SDKVersion","aldstat","sendEvent","用户加载事件","timeOver","shareImgCanvas","img","indexOf","https","replace","http","formatShareImg","time","tONja","LFPdG","rendInfo","continue","ad_index","hasAD2","hasAD3","value","windowWidth","nav_title_self","windowHeight","self_navContext","navContext","list_style_grund","loadFontShowNor","pageSize","show","loadNav","SFkMF","mpHOr","showLoading","跳转中","currentTarget","上传数据","/details","200","permisFlag","showModal","暂无权限访问","hideLoading","通过点击列表进入","introduce","operator","用户浏览详情信息","setStorage","newDetails","&fromList=flagList","loadIcon","degRa","srcView","websrc","imgSrc","title","../webView/webView?externalArgs=","judgeGetFormid","backListFlag","用户左上角返回列表事件","用户通过点击左上角返回列表","小猫祝福-更多更好看的视频","imageUrl","clickHot","shareCanvas","path","/pages/newVideo/newVideo","../../utils/ald-stat.js","Page","../../utils/util.js","lowLoadding","default","setWatcher","globalData","watch","date","formid","sendFormId","_data","prevInfo","hasInLoad","getSystemInfo","getSystemInfoSync","calculation","otherProm","fromList","navigateTo","../newDetails/newDetails?id=","&fromList=otherProm","getNetwork","getSeconds","_ald_ReadyTime","data","loadding","animationLoadding","oxzeM","setData","target","dataset","index","_key","coord","newCoord","args","type","freshContent","changeSwiperFlag","fkFEY","HctAO","detail","current","oldCoord","getProvData","adStroageList","length","videoList","noVideo","nav","getSwiperHeight","swiper","swiperCurrent","PageCount","firstNewId","dataFresh","getNetworkType","none","networkType","getStorage","dataList","swiper0","createSelectorQuery","select","boundingClientRect","selectViewport","scrollOffset","exec","height","zTLQh","Qyzbo","list","audittime","auditObj","oldAudit","newAudit","loadDataFlag","loadOver","upFresh","firstIdList","log","firstNewId的值为+","freshTime","getTime","请求list接口发送的数据","filterArgs","lastId","author","request","apiUrl","/list","POST","header","aes","stringify","set","get","statusCode","bNbYf","Listpush","navDataInfo","navList","totalCount","initSwiperFlag","openFlag","_timeFormat","addInDataList","openId","/savemessage","10000","saveFormId","userFormIdFlag","userFormIdTime","getMouthAndDay","ujWWM","vkizy","push","lowFresh","_dataInfo","unshift","freshDownFlag","goDown","freshBackDown","BrTBn","addAd","adList","freshAddCount","stopPullDownRefresh","pageScrollTo","noMore"];!function(x,t){!function(t){for(;--t;)x.push(x.shift())}(++t)}(x,475);var t=function(t,i){return x[t-=0]},i=require(t("0x0"))[t("0x1")],a=require(t("0x2"));i({data:{dataList:[],scrollHeight:"",goDown:"",totalCount:"",loadIcon:"",_index:0,swiperCurrent:0,loadding:!0,topArgs:{},navList:[],videoList:[],AD:[],loadFontShowNor:t("0x3"),animationLoadding:!1,loaddingMask:!1,list_style_grund:t("0x4"),_scene:"",_curl:""},_data:{args:{pageSize:"10",PageCount:"1",firstNewId:"",type:"0",author:""},coord:{newCoord:0,oldCoord:""},totalCount:0,loadDataFlag:{timeOver:!1,loadOver:!1},adStroageList:[],firstIdList:[],getSystemInfo:{},touchMove:{strat:"",end:""},audittime:"",_ald_ReadyTime:0,loadNav:!1,initSwiperFlag:!1,shareImgCanvas:!0,prevInfo:{},hasInLoad:!1,getProvData:!1,auditObj:{newAudit:0,oldAudit:0},FirstAuditObj:{newAudit:0,oldAudit:0},changeSwiperFlag:!1},onLoad:function(x){getApp()[t("0x5")](getApp()[t("0x6")],this[t("0x7")],this),x[t("0x8")]&&x[t("0x9")]&&a[t("0xa")](x[t("0x9")],x[t("0x8")],getApp()),this[t("0xb")][t("0xc")]=x,this[t("0xb")][t("0xd")]=!0},onReady:function(){if(this[t("0xb")][t("0xe")]=wx[t("0xf")](),this[t("0x10")](),t("0x11")===this[t("0xb")][t("0xc")][t("0x12")])this[t("0xb")][t("0xc")].id&&wx[t("0x13")]({url:t("0x14")+this[t("0xb")][t("0xc")].id+t("0x15")});else{this[t("0x16")]();var x=(new Date)[t("0x17")]();this[t("0xb")][t("0x18")]=x}},clickNav:function(x){if(this[t("0x19")][t("0x1a")]&&this[t("0x19")][t("0x1b")])if(t("0x1c")!==t("0x1c"))x[t("0x1d")]({dataList:i[t("0x19")]});else{x=x[t("0x1e")][t("0x1f")][t("0x20")];var i=this[t("0xb")][t("0x21")][x];this[t("0xb")][t("0x22")][t("0x23")]==x&&(this[t("0xb")][t("0x24")][t("0x25")]=i,this[t("0x26")]()),this[t("0x1d")]({_index:x,swiperCurrent:x})}},changeSwiper:function(x){if(this[t("0xb")][t("0x27")]=!0,this[t("0x19")][t("0x1a")]&&this[t("0x19")][t("0x1b")])if(t("0x28")!==t("0x29")){var i=this[t("0xb")][t("0x22")];if(this[t("0x1d")]({loadFontShowNor:""}),this[t("0xb")][t("0x24")][t("0x25")]=this[t("0xb")][t("0x21")][x[t("0x2a")][t("0x2b")]],i[t("0x2c")]==x[t("0x2a")][t("0x2b")]){this[t("0xb")][t("0x2d")]=!0;for(var a=this[t("0xb")][t("0x2e")],e=0;e<a[t("0x2f")];e++)a[e][t("0x20")]==x[t("0x2a")][t("0x2b")]&&this[t("0x1d")]({animationLoadding:!1,adList:a[e][t("0x19")]});this[t("0x19")][t("0x30")][x[t("0x2a")][t("0x2b")]][t("0x2f")]?this[t("0x1d")]({loadFontShowNor:t("0x3")}):this[t("0x1d")]({loadFontShowNor:t("0x31")}),a=t("0x32")+(0==+x[t("0x2a")][t("0x2b")]?0:+x[t("0x2a")][t("0x2b")]-1),this[t("0x1d")]({_index:x[t("0x2a")][t("0x2b")],navId:a,swiperCurrent:x[t("0x2a")][t("0x2b")]}),this[t("0x33")](t("0x34")+this[t("0x19")][t("0x35")])}else this[t("0xb")][t("0x2d")]=!1,this[t("0xb")][t("0x24")][t("0x36")]=1,this[t("0xb")][t("0x24")][t("0x37")]="",a=t("0x32")+(0==+x[t("0x2a")][t("0x2b")]?0:+x[t("0x2a")][t("0x2b")]-1),this[t("0x1d")]({_index:x[t("0x2a")][t("0x2b")],navId:a,swiperCurrent:x[t("0x2a")][t("0x2b")],animationLoadding:!1}),this[t("0x38")]();i[t("0x2c")]=i[t("0x23")],i[t("0x23")]=x[t("0x2a")][t("0x2b")]}else{var o=this;wx[t("0x39")]({success:function(x){t("0x3a")==x[t("0x3b")]?wx[t("0x3c")]({key:t("0x3d"),success:function(x){o[t("0x1d")]({dataList:x[t("0x19")]})}}):o[t("0x38")]()}})}},changeSwiperFinish:function(x){this[t("0x1d")]({animationLoadding:!0})},getSwiperHeight:function(x){var i=this,a=x||t("0x3e");(x=wx[t("0x3f")]())[t("0x40")]("#"+a)[t("0x41")](),x[t("0x42")]()[t("0x43")](),x[t("0x44")](function(x){x[0]&&i[t("0x1d")]({_height:x[0][t("0x45")]})}),setTimeout(function(){if(t("0x46")===t("0x46")){var x=wx[t("0x3f")]();x[t("0x40")]("#"+a)[t("0x41")](),x[t("0x42")]()[t("0x43")](),x[t("0x44")](function(x){x[0]&&i[t("0x1d")]({_height:x[0][t("0x45")]})})}else{var e=this,o=x||t("0x3e");(x=wx[t("0x3f")]())[t("0x40")]("#"+o)[t("0x41")](),x[t("0x42")]()[t("0x43")](),x[t("0x44")](function(x){x[0]&&e[t("0x1d")]({_height:x[0][t("0x45")]})}),setTimeout(function(){var x=wx[t("0x3f")]();x[t("0x40")]("#"+o)[t("0x41")](),x[t("0x42")]()[t("0x43")](),x[t("0x44")](function(x){x[0]&&e[t("0x1d")]({_height:x[0][t("0x45")]})})},500)}},500)},getNetwork:function(){var x=this;wx[t("0x39")]({success:function(i){t("0x3a")==i[t("0x3b")]?wx[t("0x3c")]({key:t("0x3d"),success:function(i){if(t("0x47")!==t("0x47")){if(this[t("0xb")][t("0x27")]=!0,this[t("0x19")][t("0x1a")]&&this[t("0x19")][t("0x1b")]){var a=this[t("0xb")][t("0x22")];if(this[t("0x1d")]({loadFontShowNor:""}),this[t("0xb")][t("0x24")][t("0x25")]=this[t("0xb")][t("0x21")][x[t("0x2a")][t("0x2b")]],a[t("0x2c")]==x[t("0x2a")][t("0x2b")]){this[t("0xb")][t("0x2d")]=!0;for(var e=this[t("0xb")][t("0x2e")],o=0;o<e[t("0x2f")];o++)e[o][t("0x20")]==x[t("0x2a")][t("0x2b")]&&this[t("0x1d")]({animationLoadding:!1,adList:e[o][t("0x19")]});this[t("0x19")][t("0x30")][x[t("0x2a")][t("0x2b")]][t("0x2f")]?this[t("0x1d")]({loadFontShowNor:t("0x3")}):this[t("0x1d")]({loadFontShowNor:t("0x31")}),e=t("0x32")+(0==+x[t("0x2a")][t("0x2b")]?0:+x[t("0x2a")][t("0x2b")]-1),this[t("0x1d")]({_index:x[t("0x2a")][t("0x2b")],navId:e,swiperCurrent:x[t("0x2a")][t("0x2b")]}),this[t("0x33")](t("0x34")+this[t("0x19")][t("0x35")])}else this[t("0xb")][t("0x2d")]=!1,this[t("0xb")][t("0x24")][t("0x36")]=1,this[t("0xb")][t("0x24")][t("0x37")]="",e=t("0x32")+(0==+x[t("0x2a")][t("0x2b")]?0:+x[t("0x2a")][t("0x2b")]-1),this[t("0x1d")]({_index:x[t("0x2a")][t("0x2b")],navId:e,swiperCurrent:x[t("0x2a")][t("0x2b")],animationLoadding:!1}),this[t("0x38")]();a[t("0x2c")]=a[t("0x23")],a[t("0x23")]=x[t("0x2a")][t("0x2b")]}}else x[t("0x1d")]({dataList:i[t("0x19")]})}}):x[t("0x38")]()}})},Listpush:function(x){x[x[t("0x2f")]-1]&&x[x[t("0x2f")]-1][t("0x48")]&&x[x[t("0x2f")]-1][t("0x48")][x[x[t("0x2f")]-1][t("0x48")][t("0x2f")]-1]&&(x=x[x[t("0x2f")]-1][t("0x48")][x[x[t("0x2f")]-1][t("0x48")][t("0x2f")]-1][t("0x49")],this[t("0xb")][t("0x27")]&&(this[t("0xb")][t("0x4a")][t("0x4b")]=this[t("0xb")][t("0x4a")][t("0x4c")]),this[t("0xb")][t("0x4a")][t("0x4c")]=x,this[t("0xb")][t("0x27")]=!1)},dataFresh:function(x){var i=this;i[t("0xb")][t("0x4d")][t("0x4e")]=!1,t("0x4f")==x&&(i[t("0xb")][t("0x24")][t("0x37")]=i[t("0xb")][t("0x50")][i[t("0xb")][t("0x24")][t("0x25")]],console[t("0x51")](t("0x52")+i[t("0xb")][t("0x24")][t("0x37")]),i[t("0xb")][t("0x53")]=(new Date)[t("0x54")]()),x?i[t("0x1d")]({loadding:!1,loaddingMask:!0}):i[t("0x1d")]({loadding:!1,loaddingMask:!1});var e={data:i[t("0xb")][t("0x24")]};console[t("0x51")](t("0x55")),console[t("0x51")](e),a[t("0x56")](i[t("0xb")][t("0x24")],[t("0x57"),t("0x25"),t("0x58"),t("0x37")],i,function(){wx[t("0x59")]({url:getApp()[t("0x19")][t("0x5a")]+t("0x5b"),method:t("0x5c"),header:getApp()[t("0x6")][t("0x5d")],data:a[t("0x5e")](JSON[t("0x5f")](e),t("0x60")),success:function(e){if(e[t("0x19")]=a[t("0x5e")](e[t("0x19")],t("0x61")),console[t("0x51")](e[t("0x19")]),200==e[t("0x62")])if(t("0x63")===t("0x63")){var o=e[t("0x19")];t("0x4f")!=x&&i[t("0x64")](o[t("0x19")]),i[t("0xb")][t("0x50")][t("0x2f")]||i[t("0x65")](o[t("0x66")]),i[t("0xb")][t("0x67")]=e[t("0x19")][t("0x67")]||i[t("0xb")][t("0x67")],(e=e[t("0x19")][t("0x21")])&&!i[t("0xb")][t("0x68")]&&(i[t("0xb")][t("0x24")][t("0x25")]=e,i[t("0xb")][t("0x22")][t("0x23")]=e,i[t("0xb")][t("0x68")]=!0,i[t("0x1d")]({_index:e,navId:t("0x32")+(e-1),swiperCurrent:e})),a[t("0x69")](o.AD,i),a[t("0x6a")](o[t("0x19")]),i[t("0x6b")](x,o)}else{var d=this,n={formidlist:x[t("0x2a")],openid:getApp()[t("0x6")][t("0x6c")]};a[t("0x56")](n,[],d,function(){wx[t("0x59")]({url:getApp()[t("0x19")][t("0x5a")]+t("0x6d"),header:getApp()[t("0x6")][t("0x5d")],method:t("0x5c"),data:n,success:function(x){x[t("0x19")]&&t("0x6e")==x[t("0x19")][t("0x6f")]&&(d[t("0x1d")]({userFormIdFlag:!0}),getApp()[t("0x6")][t("0x70")]=!0,getApp()[t("0x6")][t("0x71")]=a[t("0x72")]())}})})}},fail:function(x){t("0x73"),t("0x74"),i[t("0x1d")]({loadding:!0})}})})},navDataInfo:function(x){var i,a=[],e=[],o=[];for(i in x)a[t("0x75")](x[i]),e[t("0x75")](i);for(this[t("0xb")][t("0x21")]=e,x=0;x<e[t("0x2f")];x++)o[x]=[],this[t("0xb")][t("0x50")][e[x]]="";this[t("0xb")][t("0x24")][t("0x25")]=e[0],this[t("0x1d")]({videoList:o,navList:a})},addInDataList:function(x,i){function e(){t("0x76")==x?i[t("0x19")][t("0x2f")]&&(n=o[t("0x77")](n,i[t("0x19")],t("0x75"))):t("0x4f")==x&&(i[t("0x19")][t("0x2f")]&&(n=o[t("0x77")](n,i[t("0x19")],t("0x78"))),o[t("0xb")][t("0x79")]&&(setTimeout(function(){o[t("0x1d")]({goDown:t("0x7a"),showAddPrompt:!0,freshBackDown:t("0x7b")})},1e3),setTimeout(function(){t("0x7c")===t("0x7c")?o[t("0x1d")]({goDown:"",showAddPrompt:!1}):(t("0x76")==x?i[t("0x19")][t("0x2f")]&&(n=o[t("0x77")](n,i[t("0x19")],t("0x75"))):t("0x4f")==x&&(i[t("0x19")][t("0x2f")]&&(n=o[t("0x77")](n,i[t("0x19")],t("0x78"))),o[t("0xb")][t("0x79")]&&(setTimeout(function(){o[t("0x1d")]({goDown:t("0x7a"),showAddPrompt:!0,freshBackDown:t("0x7b")})},1e3),setTimeout(function(){o[t("0x1d")]({goDown:"",showAddPrompt:!1})},3500))),n=o[t("0x7d")](n),d[o[t("0x19")][t("0x35")]]=n,n[t("0x2f")]?o[t("0x1d")]({topArgs:s,videoList:d,animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")]}):o[t("0x1d")]({topArgs:s,videoList:d,loadFontShowNor:t("0x31"),animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")]}))},3500))),n=o[t("0x7d")](n),d[o[t("0x19")][t("0x35")]]=n,n[t("0x2f")]?o[t("0x1d")]({topArgs:s,videoList:d,animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")]}):o[t("0x1d")]({topArgs:s,videoList:d,loadFontShowNor:t("0x31"),animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")]})}var o=this,d=o[t("0x19")][t("0x30")],n=d[o[t("0x19")][t("0x35")]],s={AD:i.Ad,freshAddCount:i[t("0x7f")]};if(t("0x76")==x)e();else if(t("0x4f")==x)i[t("0x37")]&&(o[t("0xb")][t("0x50")][o[t("0xb")][t("0x24")][t("0x25")]]=i[t("0x37")]),e(),o[t("0xb")][t("0x79")]&&(wx[t("0x80")](),wx[t("0x81")]({scrollTop:0,duration:0}));else{if(o[t("0xb")][t("0x53")]=(new Date)[t("0x54")](),i[t("0x19")]=o[t("0x7d")](i[t("0x19")]),d[o[t("0x19")][t("0x35")]]=i[t("0x19")],0==i[t("0x19")][t("0x2f")])o[t("0x1d")]({topArgs:s,videoList:d,loadFontShowNor:t("0x31"),animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")],userFormIdFlag:getApp()[t("0x6")][t("0x70")]});else{for(var r=[],f=0;f<i[t("0x19")][t("0x2f")];f++)for(var h=0;h<i[t("0x19")][f][t("0x48")][t("0x2f")];h++)r[t("0x75")](i[t("0x19")][f][t("0x48")][h]);r=t(10>r[t("0x2f")]?"0x82":"0x3"),o[t("0xb")][t("0x50")][o[t("0xb")][t("0x24")][t("0x25")]]=i[t("0x37")],o[t("0x1d")]({topArgs:s,videoList:d,loadFontShowNor:r,animationLoadding:!0,loadding:!0,adList:o[t("0xb")][t("0x7e")],userFormIdFlag:getApp()[t("0x6")][t("0x70")]})}wx[t("0x81")]({scrollTop:0,duration:0}),getApp()[t("0x6")][t("0x83")]||(f=(new Date)[t("0x17")](),r=0<=o[t("0xb")][t("0x18")]-getApp()[t("0x6")][t("0x84")]?o[t("0xb")][t("0x18")]-getApp()[t("0x6")][t("0x84")]:o[t("0xb")][t("0x18")]-getApp()[t("0x6")][t("0x84")]+60,f=0<=f-o[t("0xb")][t("0x18")]?f-o[t("0xb")][t("0x18")]:f-o[t("0xb")][t("0x18")]+60,h=o[t("0xb")][t("0xe")]||wx[t("0xf")](),r={"进入时间":r,"渲染时间":f,"page地址":"首页","用户机型":h[t("0x85")],"微信版本":h[t("0x86")],"基础库版本":h[t("0x87")]},getApp()[t("0x88")][t("0x89")](t("0x8a"),r),getApp()[t("0x6")][t("0x83")]=!0)}o[t("0xb")][t("0x4d")][t("0x4e")]=!0,o[t("0xb")][t("0x4d")][t("0x8b")]&&(o[t("0x1d")]({loadIcon:""}),o[t("0xb")][t("0x4d")][t("0x8b")]=!1),this[t("0x33")](t("0x34")+o[t("0x19")][t("0x35")]),o[t("0xb")][t("0x8c")]||(o[t("0xb")][t("0x8c")]=!0,f=r=d[o[t("0x19")][t("0x35")]][0][t("0x48")][0][t("0x8d")],0>r[t("0x8e")](t("0x8f"))&&(f=r[t("0x90")](t("0x91"),t("0x8f"))),a[t("0x92")](f,o))},_dataInfo:function(x,i,a){switch(a){case t("0x75"):a=x[x[t("0x2f")]-1][t("0x93")];var e=i[0][t("0x93")];if(a==e){for(e=0;e<i[0][t("0x48")][t("0x2f")];e++){a=!1;for(var o=0;o<x[x[t("0x2f")]-1][t("0x48")][t("0x2f")];o++)if(x[x[t("0x2f")]-1][t("0x48")][o].id==i[0][t("0x48")][e].id){a=!0;break}a||x[x[t("0x2f")]-1][t("0x48")][t("0x75")](i[0][t("0x48")][e])}for(a=0;a<i[t("0x2f")];a++)0!=a&&x[t("0x75")](i[a])}else for(a=0;a<i[t("0x2f")];a++)x[t("0x75")](i[a]);break;case t("0x78"):if(a=x[0][t("0x93")],e=i[i[t("0x2f")]-1][t("0x93")],a==e){for(e=0;e<i[i[t("0x2f")]-1][t("0x48")][t("0x2f")];e++)if(t("0x94")!==t("0x95")){for(a=!1,o=0;o<x[0][t("0x48")][t("0x2f")];o++)if(x[0][t("0x48")][o].id==i[i[t("0x2f")]-1][t("0x48")][e].id){a=!0;break}a||x[0][t("0x48")][t("0x78")](i[i[t("0x2f")]-1][t("0x48")][e])}else{var d=x[t("0xb")][t("0x4d")];d[t("0x4e")]?x[t("0x1d")]({loadIcon:""}):d[t("0x8b")]=!0}for(a=0;a<i[t("0x2f")];a++)a!=i[t("0x2f")]-1&&x[t("0x78")](i[i[t("0x2f")]-1-a])}else for(a=0;a<i[t("0x2f")];a++)x[t("0x78")](i[i[t("0x2f")]-1-a])}return x},addAd:function(x){for(var i=[],a=[],e=this[t("0xb")][t("0x96")].AD,o=0;o<x[t("0x2f")];o++)for(var d=0;d<x[o][t("0x48")][t("0x2f")];d++)x[o][t("0x48")][d].ad=0,i[t("0x75")](x[o][t("0x48")][d]);for(d=0;d<i[t("0x2f")];d++)for(var n in e)-1<n[t("0x8e")](t("0x97"))?i[d].ad&&0!=i[d].ad||(i[d].ad=d%10==(e[n]?e[n][2]||0:0)?2:i[d].ad?i[d].ad:0,i[d][t("0x98")]=2==i[d].ad?d%10:i[d][t("0x98")]?i[d][t("0x98")]:t("0x3a")):t("0x99")==n?(i[d].ad=d==(e[n]?e[n][2]||0:0)?3:i[d].ad?i[d].ad:0,i[d][t("0x98")]=3==i[d].ad?d:i[d][t("0x98")]?i[d][t("0x98")]:t("0x3a")):t("0x9a")==n?(i[d].ad=d==(e[n]?e[n][2]||0:0)?4:i[d].ad?i[d].ad:0,i[d][t("0x98")]=4==i[d].ad?d:i[d][t("0x98")]?i[d][t("0x98")]:t("0x3a")):(i[d].ad=d==(e[n]?e[n][2]||0:0)?1:i[d].ad?i[d].ad:0,i[d][t("0x98")]=1==i[d].ad?d:i[d][t("0x98")]?i[d][t("0x98")]:t("0x3a"));for(n in e)(i={})[t("0x9b")]=e[n],-1<n[t("0x8e")](t("0x97"))?i.ad=2:i.ad=t("0x99")==n?3:t("0x9a")==n?4:1,a[t("0x75")](i);return this[t("0xb")][t("0x7e")]=a[t("0x2f")]?a:this[t("0xb")][t("0x7e")],this[t("0xb")][t("0x2e")][t("0x75")]({index:this[t("0xb")][t("0x24")][t("0x25")],data:a}),x},calculation:function(){var x=wx[t("0xf")](),i=x[t("0x9c")];x=1==getApp()[t("0x6")][t("0x9d")]?+x[t("0x9e")]-+i/750*160:+x[t("0x9e")]-+i/750*80,i=t(getApp()[t("0x6")][t("0x9d")]?"0x9f":"0xa0"),this[t("0x1d")]({navContext:i,scrollHeight:+x,list_style_grund:getApp()[t("0x6")][t("0xa1")]})},lowFresh:function(){if(t("0x31")!=this[t("0x19")][t("0xa2")]&&this[t("0x19")][t("0x1a")]&&this[t("0x19")][t("0x1b")]){var x=this[t("0xb")][t("0x24")];x[t("0x37")]="_0",x[t("0x57")]=this[t("0xb")][t("0x2d")]?this[t("0xb")][t("0x4a")][t("0x4b")]:this[t("0xb")][t("0x4a")][t("0x4c")];var i=this[t("0xb")][t("0x67")];console[t("0x51")](i),+x[t("0x36")]*+x[t("0xa3")]>=+i?this[t("0x1d")]({loadFontShowNor:t("0x82")}):(this[t("0x1d")]({loadFontShowNor:t("0xa4")}),x[t("0x36")]++,this[t("0x38")](t("0x76")))}},goDetails:function(x){if(!this[t("0xb")][t("0xa5")])if(t("0xa6")===t("0xa7"))wx[t("0x59")]({url:getApp()[t("0x19")][t("0x5a")]+t("0x5b"),method:t("0x5c"),header:getApp()[t("0x6")][t("0x5d")],data:a[t("0x5e")](JSON[t("0x5f")](e),t("0x60")),success:function(e){if(e[t("0x19")]=a[t("0x5e")](e[t("0x19")],t("0x61")),console[t("0x51")](e[t("0x19")]),200==e[t("0x62")]){var o=e[t("0x19")];t("0x4f")!=x&&i[t("0x64")](o[t("0x19")]),i[t("0xb")][t("0x50")][t("0x2f")]||i[t("0x65")](o[t("0x66")]),i[t("0xb")][t("0x67")]=e[t("0x19")][t("0x67")]||i[t("0xb")][t("0x67")],(e=e[t("0x19")][t("0x21")])&&!i[t("0xb")][t("0x68")]&&(i[t("0xb")][t("0x24")][t("0x25")]=e,i[t("0xb")][t("0x22")][t("0x23")]=e,i[t("0xb")][t("0x68")]=!0,i[t("0x1d")]({_index:e,navId:t("0x32")+(e-1),swiperCurrent:e})),a[t("0x69")](o.AD,i),a[t("0x6a")](o[t("0x19")]),i[t("0x6b")](x,o)}},fail:function(x){i[t("0x1d")]({loadding:!0})}});else{wx[t("0xa8")]({title:t("0xa9"),mask:!0}),this[t("0xb")][t("0xa5")]=!0;var i=x[t("0xaa")][t("0x1f")].id,e={id:i,openId:getApp()[t("0x6")][t("0x6c")]};a[t("0x56")](e,[],this,function(){var x=e[t("0x6c")]?"是":"否";console[t("0x51")](t("0xab")),console[t("0x51")](e),wx[t("0x59")]({url:getApp()[t("0x19")][t("0x5a")]+t("0xac"),header:getApp()[t("0x6")][t("0x5d")],data:a[t("0x5e")](JSON[t("0x5f")](e),t("0x60")),method:t("0x5c"),success:function(e){if(e[t("0x19")]=a[t("0x5e")](e[t("0x19")],t("0x61")),t("0xad")==e[t("0x62")])if(!1===e[t("0x19")][t("0xae")])wx[t("0xaf")]({title:"提示",content:t("0xb0"),showCancel:!1}),wx[t("0xb1")]();else{var o={"进入详情方式":t("0xb2"),"视频ID":i,"视频标题":e[t("0x19")][t("0x19")][t("0xb3")],"详情接口是否上传的openId":x,"视频作者":e[t("0x19")][t("0x19")][t("0xb4")]};getApp()[t("0x88")][t("0x89")](t("0xb5"),o),wx[t("0xb6")]({key:t("0xb7"),data:e[t("0x19")]}),wx[t("0x13")]({url:t("0x14")+i+t("0xb8")})}}})})}},freshContent:function(){var x=this;t("0xb9")!=x[t("0x19")][t("0xb9")]&&x[t("0x19")][t("0x1a")]&&x[t("0x19")][t("0x1b")]&&(x[t("0x1d")]({loadIcon:t("0xb9")}),x[t("0x38")](t("0x4f")),setTimeout(function(){var i=x[t("0xb")][t("0x4d")];i[t("0x4e")]?x[t("0x1d")]({loadIcon:""}):i[t("0x8b")]=!0},3e3))},getDataFormComp:function(x){var i=this,e={formidlist:x[t("0x2a")],openid:getApp()[t("0x6")][t("0x6c")]};a[t("0x56")](e,[],i,function(){wx[t("0x59")]({url:getApp()[t("0x19")][t("0x5a")]+t("0x6d"),header:getApp()[t("0x6")][t("0x5d")],method:t("0x5c"),data:e,success:function(x){t("0xba")===t("0xba")?x[t("0x19")]&&t("0x6e")==x[t("0x19")][t("0x6f")]&&(i[t("0x1d")]({userFormIdFlag:!0}),getApp()[t("0x6")][t("0x70")]=!0,getApp()[t("0x6")][t("0x71")]=a[t("0x72")]()):c[t("0x1d")]({goDown:"",showAddPrompt:!1})}})})},goWebView:function(x){x=x[t("0xaa")][t("0x1f")];var i={};i[t("0xbb")]=x[t("0xbc")],i[t("0xbd")]=x[t("0x8d")],i[t("0xbe")]=x[t("0xbe")],-1<i[t("0xbb")][t("0x8e")](t("0x91"))&&wx[t("0x13")]({url:t("0xbf")+encodeURIComponent(JSON[t("0x5f")](i))})},judgeGetFormid:function(){a[t("0x72")]()!=getApp()[t("0x6")][t("0x71")]?(this[t("0x1d")]({userFormIdFlag:!1}),getApp()[t("0x6")][t("0x70")]=!1):(this[t("0x1d")]({userFormIdFlag:!0}),getApp()[t("0x6")][t("0x70")]=!0)},watch:{userFormIdTime:function(x,i){i[t("0xc0")]()}},onShow:function(){if(!this[t("0xb")][t("0x18")]&&t("0x11")===this[t("0xb")][t("0xc")][t("0x12")]&&!this[t("0xb")][t("0xd")]){this[t("0x16")]();var x=(new Date)[t("0x17")]();this[t("0xb")][t("0x18")]=x}this[t("0xb")][t("0xa5")]=!1,this[t("0xc0")](),this[t("0xb")][t("0x53")]&&6e5<=(new Date)[t("0x54")]()-this[t("0xb")][t("0x53")]&&(this[t("0xb")][t("0x79")]=!1,this[t("0x38")](t("0x4f"))),this[t("0xb")][t("0xd")]=!1,getApp()[t("0x6")][t("0xc1")]&&getApp()[t("0x88")][t("0x89")](t("0xc2"),t("0xc3"))},onHide:function(){wx[t("0xb1")]()},onUnload:function(){},onPullDownRefresh:function(){if(t("0x7a")==this[t("0x19")][t("0x7a")])return wx[t("0x80")](),!1;this[t("0xb")][t("0x79")]=!0,this[t("0x26")]()},onReachBottom:function(){this[t("0x76")]()},onShareAppMessage:function(){var x=this[t("0x19")][t("0x30")][this[t("0x19")][t("0x35")]][0],i={title:t("0xc4")};return i[t("0xc5")]=t("0xc6")==this[t("0x19")][t("0xc6")]?x[t("0x8d")]:this[t("0xb")][t("0xc7")]||x[t("0x48")][0][t("0x8d")],i[t("0xc8")]=t("0xc9"),i}}); 
 			}); 	require("pages/newVideo/newVideo.js");
 		__wxRoute = 'pages/newDetails/newDetails';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/newDetails/newDetails.js';	define("pages/newDetails/newDetails.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(x){return typeof x}:function(x){return x&&"function"==typeof Symbol&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},a=["exec","top","onClose","插屏广告关闭","onError","YNlqy","RHYgj","插屏广告加载失败","play","详情页重播按钮","detail","currentTime","windowHeight","windowWidth","scale","width","filterArgs","上传数据","request","apiUrl","/details","header","aes","stringify","set","POST","fjxak","hlYPx","get","200","statusCode","通过分享卡片或者外部链接进入","introduce","operator","用户浏览详情信息","calculation","详情数据","path","swiperObj","slideFlag","leftId","findRecomm","openFlag","ADlist","rendInfo","hasAD7_1","open","recommendList","videoProportion","videoType","scrollHeight","HgFHr","maskList","marMaskVideo","elite_img","img0","img1","img2","hasAD10","data_src","explrecommList","stopPullDownRefresh","getTxvContext","txv1","authorArgs","operatorId","operatorImg","title","imgSrc","AxxKl","PiTaK","JsGJo","statisTraf","reLaunch","/pages/newVideo/newVideo","timeGroupId","上传参数","/videoclick","code","视频播放统计","vidPathObj","vidPathOpenFlag","vidPath","headNum","footNum","&defn=shd","GET","substr","url","fvkey","_vid","?vkey=","ANAeE","yBZqO","loadNav","showLoading","跳转中","permisFlag","showModal","暂无权限访问","OygPO","通过点击推荐进入","setStorage","页面跳转达到上限，清除页面栈","../newDetails/newDetails?id=","&fromList=flagDetails","navigateTo","hideLoading","pause","operatorid","请求list接口发送的数据","firstNewId","UZbAf","/list","authorSpaceVideo","../operatorVideo/operatorVideo?authorArgs=","canvasToTempFilePath","shareFrendCanvas","tempFilePath","getCodeUnlimit","详情页进入作者空间按钮","广告出现异常","push","join","createCanvasContext","drawImage","shareCanvas","strokeRect","setFillStyle","#efefef","setLineWidth","fill","rect","rgba(0,0,0,.6)","#ffffff","setFontSize","fillText","imgurl","draw","nTEhH","vBBBl","downloadFile","http://code.xafpz.com/api/getACodeUnlimit","saveImageToPhotosAlbum","shareFrendSrc","vibrateLong","clickBakBtn","flag","上方返回","下方返回","flagList","navigateBack","详情页返回主页按钮","srcView","websrc","img","indexOf","http","../webView/webView?externalArgs=","getMouthAndDay","userFormIdTime","judgeGetFormid","appid","ZwSWQ","CdJgz","/adinfo","getVideoSession","backListFlag","target","group","发送到群","friend","发送朋友","imageUrl","/pages/newVideo/newVideo?id=","&fromList=otherProm","详情页分享按钮","scope","owns","prototype","hasOwnProperty","call","assign","function","length","drdff","getSeconds","_data","_ald_ReadyTime","globalData","_ald_inAppTime","getSystemInfo","getSystemInfoSync","详情页","model","version","SDKVersion","detailsOpenId","aldstat","sendEvent","用户加载事件","log","_ald_hadcalcu","ASSUME_ES5","ASSUME_NO_NATIVE_MAP","ASSUME_NO_NATIVE_SET","SIMPLE_FROUND_POLYFILL","defineProperty","defineProperties","value","getGlobal","undefined","global","polyfill","aEPTR","max","split","Object.assign","es6","es3","Array.prototype.fill","../../utils/ald-stat.js","Page","../../utils/util.js","../../utils/hintInfomation.js","myPlugin","565rpx","btncoor","getMenuButtonBoundingClientRect","left","setData","setWatcher","watch","externalArgs","parse","fromList","fromPrevArgs","date","formid","sendFormId","otherProm","openId","inDataInfoFnFlag","dataInfo","getStorage","newDetails","_renderInfo","removeStorage","2.0.7","navigateToMiniProgram","currentTarget","dataset","recomTop","pageScrollTo","详情页相关推荐按钮","点击按钮","userFormIdFlag","getStorageSync","storageVideoList","storageVideo","splice","videoContext","createVideoContext","myvideo","suspendTime","txvContext","exitFullScreen","data","videosrc","vid","adunitId","intersitialAd","createInterstitialAd","show","catch","errMsg","showMsg","插屏广告事件","onLoad","BmbYh","插屏广告成功加载","createSelectorQuery","select","#findRecom","boundingClientRect","selectViewport","scrollOffset"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(a,177);var t=function(x,e){return a[x-=0]},i=i||{};i[t("0x0")]={},i[t("0x1")]=function(x,e){return Object[t("0x2")][t("0x3")][t("0x4")](x,e)},i[t("0x5")]=t("0x6")==x(Object[t("0x5")])?Object[t("0x5")]:function(x,e){for(var a=1;a<arguments[t("0x7")];a++)if(t("0x8")!==t("0x8")){var o=(new Date)[t("0x9")](),n=0<=e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]?e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]:e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]+60;o=0<=o-e[t("0xa")][t("0xb")]?o-e[t("0xa")][t("0xb")]:o-e[t("0xa")][t("0xb")]+60;var s=e[t("0xa")][t("0xe")]||wx[t("0xf")]();n={"进入时间":n,"渲染时间":o,"page地址":t("0x10"),"用户机型":s[t("0x11")],"微信版本":s[t("0x12")],"基础库版本":s[t("0x13")],"详情接口是否上传的openId":e[t("0xa")][t("0x14")]},getApp()[t("0x15")][t("0x16")](t("0x17"),n),console[t("0x18")](n),getApp()[t("0xc")][t("0x19")]=!0}else{var c=arguments[a];if(c)for(var r in c)i[t("0x1")](c,r)&&(x[r]=c[r])}return x},i[t("0x1a")]=!1,i[t("0x1b")]=!1,i[t("0x1c")]=!1,i[t("0x1d")]=!1,i[t("0x1e")]=i[t("0x1a")]||t("0x6")==x(Object[t("0x1f")])?Object[t("0x1e")]:function(x,e,a){x!=Array[t("0x2")]&&x!=Object[t("0x2")]&&(x[e]=a[t("0x20")])},i[t("0x21")]=function(e){return t("0x22")!=("undefined"==typeof window?"undefined":x(window))&&window===e?e:t("0x22")!=("undefined"==typeof global?"undefined":x(global))&&null!=global?global:e},i[t("0x23")]=i[t("0x21")](void 0),i[t("0x24")]=function(x,e,a,o){if(e){if(t("0x25")!==t("0x25"))return x||function(x,e,a){var i=this[t("0x7")]||0;for(0>e&&(e=Math[t("0x26")](0,i+e)),(null==a||a>i)&&(a=i),0>(a=Number(a))&&(a=Math[t("0x26")](0,i+a)),e=Number(e||0);e<a;e++)this[e]=x;return this};for(a=i[t("0x23")],x=x[t("0x27")]("."),o=0;o<x[t("0x7")]-1;o++){var n=x[o];n in a||(a[n]={}),a=a[n]}(e=e(o=a[x=x[x[t("0x7")]-1]]))!=o&&null!=e&&i[t("0x1e")](a,x,{configurable:!0,writable:!0,value:e})}},i[t("0x24")](t("0x28"),function(x){return x||i[t("0x5")]},t("0x29"),t("0x2a")),i[t("0x24")](t("0x2b"),function(x){return x||function(x,e,a){var i=this[t("0x7")]||0;for(0>e&&(e=Math[t("0x26")](0,i+e)),(null==a||a>i)&&(a=i),0>(a=Number(a))&&(a=Math[t("0x26")](0,i+a)),e=Number(e||0);e<a;e++)this[e]=x;return this}},t("0x29"),t("0x2a"));var o=require(t("0x2c"))[t("0x2d")],n=require(t("0x2e")),s=(require(t("0x2f")),require(t("0x2e")),requirePlugin(t("0x30")));o({data:{newModule:{},scrollHeight:"",recommendList:[],recommentNotice:!0,fontSizeDefinition:!1,currentTime:"",time:"",initialTime:"",videosrc:{},replayMask:!1,pageHeight:"",rendInfo:{},srcView:"",fontNumLenght:4,explrecommList:[],hidePromptImgFlag:!1,_border:!0},_data:{loadNav:!1,storageVideoList:[],storageVideo:{},fromPrevArgs:{},rendInfo:{},authorArgs:{},_ald_ReadyTime:0,inDataInfoFnFlag:!1,swiperObj:{},shareImgCanvas:!1,recomTop:0,adunitId:"",clickBakBtn:!1},onLoad:function(x){var e=this,a=t("0x31");!getApp()[t("0xc")][t("0x32")]&&wx[t("0x33")]?(getApp()[t("0xc")][t("0x32")]=wx[t("0x33")]()[t("0x34")],a=getApp()[t("0xc")][t("0x32")]+20+"px"):getApp()[t("0xc")][t("0x32")]&&(a=getApp()[t("0xc")][t("0x32")]+20+"px"),e[t("0x35")]({btncoor:a}),a={},getApp()[t("0x36")](getApp()[t("0xc")],e[t("0x37")],e),x[t("0x38")]?Object[t("0x5")](a,JSON[t("0x39")](decodeURIComponent(x[t("0x38")]))):(a.id=x.id,a[t("0x3a")]=x[t("0x3a")]),this[t("0xa")][t("0x3b")]=a,x[t("0x3c")]&&x[t("0x3d")]&&n[t("0x3e")](x[t("0x3d")],x[t("0x3c")],getApp()),t("0x3f")==x[t("0x3a")]?getApp()[t("0xc")][t("0x40")]&&!e[t("0xa")][t("0x41")]&&e[t("0x42")]():wx[t("0x43")]({key:t("0x44"),success:function(x){e[t("0x45")](x),wx[t("0x46")]({key:t("0x44"),success:function(x){}})},fail:function(){getApp()[t("0xc")][t("0x40")]&&!e[t("0xa")][t("0x41")]&&e[t("0x42")]()}})},_naviOtherApp:function(x){t("0x47")<=this[t("0xa")][t("0xe")][t("0x13")]||wx[t("0x48")]({appId:x[t("0x49")][t("0x4a")].id,success:function(x){},fail:function(x){}})},findRecom:function(){this[t("0xa")][t("0x4b")]&&(wx[t("0x4c")]({scrollTop:this[t("0xa")][t("0x4b")],duration:0}),getApp()[t("0x15")][t("0x16")](t("0x4d"),t("0x4e")))},getDataFormComp:function(x){this[t("0x35")]({userFormIdFlag:!0}),getApp()[t("0xc")][t("0x4f")]=!0},getVideoSession:function(x){var e=wx[t("0x50")](t("0x51"));for(this[t("0xa")][t("0x51")]=e||[],this[t("0xa")][t("0x52")].id=x,e=0;e<this[t("0xa")][t("0x51")][t("0x7")];e++)this[t("0xa")][t("0x51")][e]&&this[t("0xa")][t("0x51")][e].id==x&&(this[t("0xa")][t("0x52")]=this[t("0xa")][t("0x51")][e],this[t("0xa")][t("0x51")][t("0x53")](e,1))},createVideoContext:function(){this[t("0x54")]=wx[t("0x55")](t("0x56"))},videoEnd:function(x){this[t("0xa")][t("0x52")][t("0x57")]=0,this[t("0x58")][t("0x59")](),this[t("0x5a")][t("0x5b")][t("0x5c")]||(this[t("0x35")]({replayMask:!0}),this[t("0xa")][t("0x5d")]&&(this[t("0xa")][t("0x5e")]=wx[t("0x5f")]({adUnitId:this[t("0xa")][t("0x5d")]}),this[t("0xa")][t("0x5e")][t("0x60")]()[t("0x61")](function(x){console[t("0x18")](x[t("0x62")]);var e={};e[t("0x63")]=x[t("0x62")],getApp()[t("0x15")][t("0x16")](t("0x64"),e)}),this[t("0xa")][t("0x5e")][t("0x65")](function(x){if(t("0x66")===t("0x66"))console[t("0x18")](t("0x67")),getApp()[t("0x15")][t("0x16")](t("0x64"),{successFlag:t("0x67")});else{var e=wx[t("0x68")]();e[t("0x69")](t("0x6a"))[t("0x6b")](),e[t("0x6c")]()[t("0x6d")](),e[t("0x6e")](function(e){e[0]&&(x[t("0xa")][t("0x4b")]=e[0][t("0x6f")]-10)})}}),this[t("0xa")][t("0x5e")][t("0x70")](function(x){console[t("0x18")](t("0x71")),getApp()[t("0x15")][t("0x16")](t("0x64"),{closeFlag:t("0x71")})}),this[t("0xa")][t("0x5e")][t("0x72")](function(x){t("0x73")===t("0x74")?this[t("0xa")][t("0x4b")]&&(wx[t("0x4c")]({scrollTop:this[t("0xa")][t("0x4b")],duration:0}),getApp()[t("0x15")][t("0x16")](t("0x4d"),t("0x4e"))):(console[t("0x18")](t("0x75")),getApp()[t("0x15")][t("0x16")](t("0x64"),{failFlag:t("0x75")}))})))},replay:function(){this[t("0x58")][t("0x76")](),this[t("0x35")]({initialTime:0,replayMask:!1}),getApp()[t("0x15")][t("0x16")](t("0x77"),t("0x4e"))},videoJINDU:function(x){this[t("0xa")][t("0x52")][t("0x57")]=x[t("0x78")][t("0x79")]},calculation:function(){var x=wx[t("0xf")](),e=x[t("0x7a")];this[t("0x35")]({scrollHeight:+e-+x[t("0x7b")]/750*210,pageHeight:e}),this[t("0xa")][t("0x7c")]=x[t("0x7b")]/750,this[t("0xa")][t("0x7d")]=x[t("0x7b")]},dataInfo:function(){var x=this;x[t("0xa")][t("0x41")]=!0;var e=x[t("0xa")][t("0x3b")],a={id:e.id,openId:getApp()[t("0xc")][t("0x40")]};n[t("0x7e")](a,[],x,function(){x[t("0xa")][t("0x14")]=a[t("0x40")]?"是":"否",console[t("0x18")](t("0x7f")),console[t("0x18")](a),wx[t("0x80")]({url:getApp()[t("0x5a")][t("0x81")]+t("0x82"),header:getApp()[t("0xc")][t("0x83")],data:n[t("0x84")](JSON[t("0x85")](a),t("0x86")),method:t("0x87"),success:function(a){if(t("0x88")===t("0x89")){var i=wx[t("0xf")](),o=i[t("0x7a")];this[t("0x35")]({scrollHeight:+o-+i[t("0x7b")]/750*210,pageHeight:o}),this[t("0xa")][t("0x7c")]=i[t("0x7b")]/750,this[t("0xa")][t("0x7d")]=i[t("0x7b")]}else a[t("0x5a")]=n[t("0x84")](a[t("0x5a")],t("0x8a")),t("0x8b")==a[t("0x8c")]&&(x[t("0x45")](a),a={"进入详情方式":t("0x8d"),"视频ID":e.id,"视频标题":a[t("0x5a")][t("0x5a")][t("0x8e")],"详情接口是否上传的openId":x[t("0xa")][t("0x14")],"视频作者":a[t("0x5a")][t("0x5a")][t("0x8f")]},getApp()[t("0x15")][t("0x16")](t("0x90"),a))}})})},_renderInfo:function(x){var e=this;this[t("0x91")]();var a=x[t("0x5a")][t("0x5a")];if(console[t("0x18")](t("0x92")),console[t("0x18")](a),a[t("0x5c")]||a[t("0x93")]){e[t("0xa")][t("0x94")][t("0x95")]=a[t("0x95")],e[t("0xa")][t("0x94")][t("0x96")]=a[t("0x96")],e[t("0xa")][t("0x97")]=a[t("0x97")],n[t("0x98")](a[t("0x99")],e),e[t("0xa")][t("0x9a")].AD[t("0x9b")]&&t("0x9c")==e[t("0xa")][t("0x9a")].AD[t("0x9b")][0]&&wx[t("0x5f")]&&(e[t("0xa")][t("0x5d")]=e[t("0xa")][t("0x9a")].AD[t("0x9b")][3]);var o=a[t("0x9d")],c="";for(a[t("0x9e")]&&(a[t("0x9f")]="2",e[t("0xa")][t("0x9e")]=a[t("0x9e")],c=e[t("0x5a")][t("0xa0")]/e[t("0xa")][t("0x7c")]<750*a[t("0x9e")]?e[t("0x5a")][t("0xa0")]:750*a[t("0x9e")]*e[t("0xa")][t("0x7c")]),function(){if(t("0xa1")!==t("0xa1")){var x=this[t("0x7")]||0;for(0>i&&(i=Math[t("0x26")](0,x+i)),(null==o||o>x)&&(o=x),0>(o=Number(o))&&(o=Math[t("0x26")](0,x+o)),i=Number(i||0);i<o;i++)this[i]=e;return this}var i=a[t("0xa2")]||[],o="0"==a[t("0x9f")]?266:"1"==a[t("0x9f")]?e[t("0x5a")][t("0xa0")]/e[t("0xa")][t("0x7c")]-140:c/e[t("0xa")][t("0x7c")]-140;972<=o?o=(o-872)/5:734<=o?(o=(o-654)/4,i[t("0x53")](3,1)):436<=o?(o=(o-436)/3,i[t("0x53")](2,2)):(o=(o-218)/2,i[t("0x53")](1,3)),a[t("0xa3")]=o,a[t("0xa2")]=i}(),x=0;x<o[t("0x7")];x++){var r=JSON[t("0x39")](o[x][t("0xa4")]||"[]");o[x][t("0xa5")]=r[0]||o[x][t("0xa5")],o[x][t("0xa6")]=r[1],o[x][t("0xa7")]=r[2]}var d=e[t("0xa")][t("0x9a")].AD[t("0xa8")]?e[t("0xa")][t("0x9a")].AD[t("0xa8")][8][t("0x7")]:0;e[t("0xa9")](a,function(){if(e[t("0x35")]({videosrc:a,recommendList:o,recommentNotice:!1,fontNumLenght:d,explrecommList:a[t("0xaa")]||[],rendInfo:e[t("0xa")][t("0x9a")],userFormIdFlag:getApp()[t("0xc")][t("0x4f")],selfVideoHight:c,replayMask:!1}),wx[t("0xab")](),e[t("0x58")]=a[t("0x5c")]?s[t("0xac")](t("0xad")):wx[t("0x55")](t("0x56")),e[t("0xa")][t("0xae")][t("0xaf")]=a[t("0xaf")],e[t("0xa")][t("0xae")][t("0xb0")]=a[t("0xb0")],e[t("0xa")][t("0xae")][t("0x8f")]=a[t("0x8f")],e[t("0xa")][t("0xb1")]=a[t("0x8e")],e[t("0xa")][t("0xb2")]=a[t("0xb2")],!getApp()[t("0xc")][t("0x19")])if(t("0xb3")!==t("0xb3")){var x=arguments[a];if(x)for(var n in x)i[t("0x1")](x,n)&&(r[n]=x[n])}else{var r=(new Date)[t("0x9")](),f=0<=e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]?e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]:e[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]+60;r=0<=r-e[t("0xa")][t("0xb")]?r-e[t("0xa")][t("0xb")]:r-e[t("0xa")][t("0xb")]+60;var l=e[t("0xa")][t("0xe")]||wx[t("0xf")]();f={"进入时间":f,"渲染时间":r,"page地址":t("0x10"),"用户机型":l[t("0x11")],"微信版本":l[t("0x12")],"基础库版本":l[t("0x13")],"详情接口是否上传的openId":e[t("0xa")][t("0x14")]},getApp()[t("0x15")][t("0x16")](t("0x17"),f),console[t("0x18")](f),getApp()[t("0xc")][t("0x19")]=!0}}),setTimeout(function(){var x=wx[t("0x68")]();x[t("0x69")](t("0x6a"))[t("0x6b")](),x[t("0x6c")]()[t("0x6d")](),x[t("0x6e")](function(x){t("0xb4")!==t("0xb5")?x[0]&&(e[t("0xa")][t("0x4b")]=x[0][t("0x6f")]-10):x!=Array[t("0x2")]&&x!=Object[t("0x2")]&&(x[e]=a[t("0x20")])})},800),e[t("0xb6")](a)}else wx[t("0xb7")]({url:t("0xb8")})},statisTraf:function(x){var e=this,a={id:e[t("0xa")][t("0x3b")].id,timeGroupId:x[t("0xb9")],openID:getApp()[t("0xc")][t("0x40")]};n[t("0x7e")](a,[t("0xb9")],e,function(){console[t("0x18")](t("0xba")),console[t("0x18")](a),wx[t("0x80")]({url:getApp()[t("0x5a")][t("0x81")]+t("0xbb"),header:getApp()[t("0xc")][t("0x83")],data:a,method:t("0x87"),success:function(a){"1"==a[t("0x5a")][t("0xbc")]&&(a={"视频ID":e[t("0xa")][t("0x3b")].id,"视频标题":x[t("0x8e")],"视频作者":x[t("0x8f")]},getApp()[t("0x15")][t("0x16")](t("0xbd"),a))}})})},videoerr:function(x){},data_src:function(x,e){var a=x[t("0xbe")]?JSON[t("0x39")](x[t("0xbe")]):{},i=x[t("0x5c")],o=a[t("0xbf")],n=a[t("0xc0")],s=+a[t("0xc1")],c=+a[t("0xc2")];0!=o&&o&&n?wx[t("0x80")]({url:n+i+t("0xc3"),method:t("0xc4"),success:function(a){var i=a[t("0x5a")]?JSON[t("0x39")](a[t("0x5a")][t("0xc5")](s,a[t("0x5a")][t("0x7")]-c)):"";if(i&&i.vl&&i.vl.vi[0]&&i.vl.vi[0].ul&&i.vl.vi[0].ul.ui[0]){a=i.vl.vi[0].ul.ui[0][t("0xc6")];var o=i.vl.vi[0].fn;i=i.vl.vi[0][t("0xc7")],x[t("0xc8")]=x[t("0x5c")],x[t("0x5c")]="",x[t("0x93")]=a+o+t("0xc9")+i}e()},fail:function(x){t("0xca")!==t("0xcb")?e():console[t("0x18")](x)}}):e()},goRecommDetails:function(x){var a=this;if(!a[t("0xa")][t("0xcc")]){wx[t("0xcd")]({title:t("0xce"),mask:!0});var i=x[t("0x49")][t("0x4a")].id;a[t("0xa")][t("0xcc")]=!0;var o={id:i,openId:getApp()[t("0xc")][t("0x40")]};n[t("0x7e")](o,[],a,function(){a[t("0xa")][t("0x14")]=o[t("0x40")]?"是":"否",console[t("0x18")](t("0x7f")),console[t("0x18")](o),wx[t("0x80")]({url:getApp()[t("0x5a")][t("0x81")]+t("0x82"),header:getApp()[t("0xc")][t("0x83")],data:n[t("0x84")](JSON[t("0x85")](o),t("0x86")),method:t("0x87"),success:function(x){if(x[t("0x5a")]=n[t("0x84")](x[t("0x5a")],t("0x8a")),t("0x8b")==x[t("0x8c")])if(!1===x[t("0x5a")][t("0xcf")])wx[t("0xd0")]({title:"提示",content:t("0xd1"),showCancel:!1});else if(t("0xd2")===t("0xd2")){var o={"进入详情方式":t("0xd3"),"视频ID":a[t("0xa")][t("0x3b")].id,"视频标题":x[t("0x5a")][t("0x5a")][t("0x8e")],"详情接口是否上传的openId":a[t("0xa")][t("0x14")],"视频作者":x[t("0x5a")][t("0x5a")][t("0x8f")]};getApp()[t("0x15")][t("0x16")](t("0x90"),o),console[t("0x18")](o),wx[t("0xd4")]({key:t("0x44"),data:x[t("0x5a")]}),x=getCurrentPages(),console[t("0x18")](x),10==x[t("0x7")]?(console[t("0x18")](t("0xd5")),wx[t("0xb7")]({url:t("0xd6")+i+t("0xd7")})):wx[t("0xd8")]({url:t("0xd6")+i+t("0xd7")}),a[t("0xa")][t("0xcc")]=!1,wx[t("0xd9")]()}else if(a[t("0x35")]({videosrc:i,recommendList:o,recommentNotice:!1,fontNumLenght:k,explrecommList:i[t("0xaa")]||[],rendInfo:a[t("0xa")][t("0x9a")],userFormIdFlag:getApp()[t("0xc")][t("0x4f")],selfVideoHight:e,replayMask:!1}),wx[t("0xab")](),a[t("0x58")]=i[t("0x5c")]?s[t("0xac")](t("0xad")):wx[t("0x55")](t("0x56")),a[t("0xa")][t("0xae")][t("0xaf")]=i[t("0xaf")],a[t("0xa")][t("0xae")][t("0xb0")]=i[t("0xb0")],a[t("0xa")][t("0xae")][t("0x8f")]=i[t("0x8f")],a[t("0xa")][t("0xb1")]=i[t("0x8e")],a[t("0xa")][t("0xb2")]=i[t("0xb2")],!getApp()[t("0xc")][t("0x19")]){var c=(new Date)[t("0x9")](),r=0<=a[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]?a[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]:a[t("0xa")][t("0xb")]-getApp()[t("0xc")][t("0xd")]+60;c=0<=c-a[t("0xa")][t("0xb")]?c-a[t("0xa")][t("0xb")]:c-a[t("0xa")][t("0xb")]+60;var d=a[t("0xa")][t("0xe")]||wx[t("0xf")]();r={"进入时间":r,"渲染时间":c,"page地址":t("0x10"),"用户机型":d[t("0x11")],"微信版本":d[t("0x12")],"基础库版本":d[t("0x13")],"详情接口是否上传的openId":a[t("0xa")][t("0x14")]},getApp()[t("0x15")][t("0x16")](t("0x17"),r),console[t("0x18")](r),getApp()[t("0xc")][t("0x19")]=!0}}})})}},onReady:function(x){x=(new Date)[t("0x9")](),this[t("0xa")][t("0xb")]=x,this[t("0xa")][t("0xe")]=wx[t("0xf")]()},loadVideoOldProces:function(){var x=this[t("0xa")][t("0x52")][t("0x57")];x?this[t("0x35")]({initialTime:x}):this[t("0x35")]({initialTime:0})},goAuthorSpace:function(x){var e=this;if(!e[t("0xa")][t("0xcc")]){this[t("0x58")]&&this[t("0x58")][t("0xda")](),e[t("0xa")][t("0xcc")]=!0;var a={data:{pageSize:"10",PageCount:"1",firstNewId:"",author:x[t("0x49")][t("0x4a")][t("0xdb")]}};console[t("0x18")](t("0xdc")),console[t("0x18")](a),n[t("0x7e")](a[t("0x5a")],[t("0xdd")],e,function(){t("0xde")===t("0xde")?wx[t("0x80")]({url:getApp()[t("0x5a")][t("0x81")]+t("0xdf"),method:t("0x87"),header:getApp()[t("0xc")][t("0x83")],data:n[t("0x84")](JSON[t("0x85")](a),t("0x86")),success:function(x){x[t("0x5a")]=n[t("0x84")](x[t("0x5a")],t("0x8a")),200==x[t("0x8c")]&&(wx[t("0xd4")]({key:t("0xe0"),data:x[t("0x5a")]}),e[t("0xa")][t("0xcc")]=!1,wx[t("0xd8")]({url:t("0xe1")+encodeURIComponent(JSON[t("0x85")](e[t("0xa")][t("0xae")]))}))},fail:function(x){e[t("0xa")][t("0xcc")]=!1}}):wx[t("0xe2")]({x:0,y:0,width:320,height:510,canvasId:t("0xe3"),success:function(x){e[t("0x35")]({width:a,shareFrendSrc:x[t("0xe4")]}),e[t("0x35")]({showACodeUnlimit:!0}),e[t("0xa")][t("0xe5")]=!0},fail:function(x){console[t("0x18")](x)}})}),getApp()[t("0x15")][t("0x16")](t("0xe6"),t("0x4e"))}},borderFn:function(){console[t("0x18")](t("0xe7")),this[t("0x35")]({_border:!1})},shareFrend:function(){function x(){var x=e[t("0xa")][t("0xb1")],i=[],o=[],n=!1;if(13<x[t("0x7")]){n=!0;for(var s=x[t("0x27")](""),c=0;c<s[t("0x7")];c++)13>=c?i[t("0xe8")](s[c]):o[t("0xe8")](s[c]);i=i[t("0xe9")](""),o=o[t("0xe9")]("")}(s=wx[t("0xea")](t("0xe3")))[t("0xeb")](e[t("0xa")][t("0xec")],10,10,300,240),s[t("0xed")](0,5,320,505),s[t("0xee")](t("0xef")),s[t("0xf0")](1),s[t("0xf1")](),s[t("0xf2")](10,200,300,50),s[t("0xee")](t("0xf3")),s[t("0xf1")](),s[t("0xee")](t("0xf4")),s[t("0xf5")](20),n?(s[t("0xf6")](i,20,220,280),s[t("0xf6")](o,20,243,280)):s[t("0xf6")](x,20,230,280),s[t("0xeb")](e[t("0x5a")][t("0xf7")],37.5,260,245,245),s[t("0xf8")](!0,function(){wx[t("0xe2")]({x:0,y:0,width:320,height:510,canvasId:t("0xe3"),success:function(x){e[t("0x35")]({width:a,shareFrendSrc:x[t("0xe4")]}),e[t("0x35")]({showACodeUnlimit:!0}),e[t("0xa")][t("0xe5")]=!0},fail:function(x){t("0xf9")===t("0xfa")?this[t("0xa")][t("0x94")][t("0x95")]&&0!=this[t("0xa")][t("0x94")][t("0x95")]&&this[t("0xa")][t("0x94")][t("0x96")]&&"0"!=this[t("0xa")][t("0x94")][t("0x96")]?(this[t("0xa")][t("0x3b")].id=this[t("0xa")][t("0x94")][t("0x96")],this[t("0x42")]()):wx[t("0xab")]():console[t("0x18")](x)}})})}var e=this,a=e[t("0xa")][t("0xe")][t("0x7b")];this[t("0x58")][t("0xda")](),e[t("0xa")][t("0xe5")]&&e[t("0x35")]({showACodeUnlimit:!0}),wx[t("0xfb")]({url:t("0xfc"),success:function(a){e[t("0x35")]({imgurl:a[t("0xe4")]}),x()}})},reset:function(){this[t("0x35")]({showACodeUnlimit:!1})},save:function(){wx[t("0xfd")]({filePath:this[t("0x5a")][t("0xfe")],success:function(x){wx[t("0xff")]({})}})},backMain:function(x){this[t("0xa")][t("0x100")]=!0,x=t(t("0x6f")==x[t("0x49")][t("0x4a")][t("0x101")]?"0x102":"0x103"),t("0x104")==this[t("0xa")][t("0x3b")][t("0x3a")]?wx[t("0x105")]({}):wx[t("0xb7")]({url:t("0xb8")}),getApp()[t("0x15")][t("0x16")](t("0x106"),x)},goWebView:function(x){x=x[t("0x49")][t("0x4a")];var e={};e[t("0x107")]=x[t("0x108")],e[t("0xb2")]=x[t("0x109")],e[t("0xb1")]=x[t("0xb1")],-1<e[t("0x107")][t("0x10a")](t("0x10b"))&&wx[t("0xd8")]({url:t("0x10c")+encodeURIComponent(JSON[t("0x85")](e))})},judgeGetFormid:function(){n[t("0x10d")]()!=getApp()[t("0xc")][t("0x10e")]&&(getApp()[t("0xc")][t("0x4f")]=!1),this[t("0x35")]({userFormIdFlag:getApp()[t("0xc")][t("0x4f")]})},watch:{userFormIdTime:function(x,e){e[t("0x10f")]()},openId:function(x,e){e[t("0xa")][t("0x41")]||e[t("0x42")]()}},beforeContact:function(x){var e={id:x[t("0x49")][t("0x4a")][t("0x110")],openid:getApp()[t("0xc")][t("0x40")]};n[t("0x7e")](e,[],self,function(){t("0x111")===t("0x112")?wx[t("0xfd")]({filePath:this[t("0x5a")][t("0xfe")],success:function(x){wx[t("0xff")]({})}}):wx[t("0x80")]({url:getApp()[t("0x5a")][t("0x81")]+t("0x113"),method:t("0x87"),header:getApp()[t("0xc")][t("0x83")],data:e,success:function(x){}})})},hidePromptImg:function(){this[t("0x35")]({hidePromptImgFlag:!1,scrollHeight:this[t("0x5a")][t("0xa0")]+.08*this[t("0xa")][t("0x7d")]})},onShow:function(){n[t("0x10d")](),this[t("0x114")](this[t("0xa")][t("0x3b")].id),this[t("0x10f")](),getApp()[t("0xc")][t("0x115")]=!1},onHide:function(){this[t("0x58")]&&this[t("0x58")][t("0xda")](),this[t("0xa")][t("0x51")][t("0xe8")](this[t("0xa")][t("0x52")]),wx[t("0xd4")]({key:t("0x51"),data:this[t("0xa")][t("0x51")]})},onUnload:function(x){this[t("0x58")]&&this[t("0x58")][t("0xda")](),this[t("0xa")][t("0x51")][t("0xe8")](this[t("0xa")][t("0x52")]),wx[t("0xd4")]({key:t("0x51"),data:this[t("0xa")][t("0x51")]}),t("0x3f")!=this[t("0xa")][t("0x3b")][t("0x3a")]||this[t("0xa")][t("0x100")]||(getApp()[t("0xc")][t("0x115")]=!0)},onPullDownRefresh:function(){this[t("0xa")][t("0x94")][t("0x95")]&&0!=this[t("0xa")][t("0x94")][t("0x95")]&&this[t("0xa")][t("0x94")][t("0x96")]&&"0"!=this[t("0xa")][t("0x94")][t("0x96")]?(this[t("0xa")][t("0x3b")].id=this[t("0xa")][t("0x94")][t("0x96")],this[t("0x42")]()):wx[t("0xab")]()},onReachBottom:function(){},onShareAppMessage:function(x){var e="";x[t("0x116")]&&x[t("0x116")][t("0x4a")]&&(e=x[t("0x116")][t("0x4a")][t("0x101")]),x=t("0x117")==e?t("0x118"):t("0x119")==e?t("0x11a"):"其它",console[t("0x18")](x),console[t("0x18")](this[t("0xa")]),e=this[t("0xa")][t("0x3b")],console[t("0x18")](e);var a={};return a[t("0xb1")]=this[t("0xa")][t("0xb1")]||e[t("0xb1")],a[t("0x11b")]=this[t("0xa")][t("0xb2")]||e[t("0xb2")],a[t("0x93")]=t("0x11c")+e.id+t("0x11d"),getApp()[t("0x15")][t("0x16")](t("0x11e"),x),a}}); 
 			}); 	require("pages/newDetails/newDetails.js");
 		__wxRoute = 'pages/operatorVideo/operatorVideo';__wxRouteBegin = true; 	define("pages/operatorVideo/operatorVideo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x=["OSYIx","time","rendInfo","indexOf","continue","value","nOBtr","qOtAk","NjvfF","WTvKY","loadIcon","freshContent","title","的视频 ——小猫祝福","imageUrl","img","path","/pages/operatorVideo/operatorVideo?authorArgs=","../../utils/ald-stat.js","Page","../../utils/util.js","lowLoadding","default","over","parse","authorArgs","_data","args","author","operatorId","date","formid","sendFormId","getSystemInfo","getSystemInfoSync","calculation","getNetwork","clickHot","data","type","hot","setData","dataFresh","tabclick","normal","currentTarget","dataset","flag","aldstat","sendEvent","作者页首页按钮","点击按钮","作者页热门按钮","getStorage","authorSpaceVideo","log","firstId","firstNewId","openFlag","_timeFormat","addAd","totalCount","length","noMore","Listpush","adList","removeStorage","loading","running","loadDataFlag","loadOver","upFresh","请求list接口发送的数据","filterArgs","dIPTE","bWtSa","lastId","audittime","PageCount","pageSize","show","lowFresh","request","apiUrl","/list","POST","globalData","header","aes","stringify","set","qSTCk","get","statusCode","OPDKc","hideLoading","addInDataList","ASLsx","list","push","fail","_dataInfo","unshift","GEVoz","showLoading","跳转中","loadNav","openId","/details","200","permisFlag","showModal","暂无权限访问","通过点击作者列表进入","introduce","operator","用户浏览详情信息","setStorage","newDetails","navigateTo","../newDetails/newDetails?id=","&fromList=flagSelfList","goDown","freshBackDown","CIQJA","YMcUq","stopPullDownRefresh","pageScrollTo","videos","hAhJo","timeOver","windowHeight","windowWidth","list_style_grund","noVideo","loadFontShowNor","yrNck"];!function(x,t){!function(t){for(;--t;)x.push(x.shift())}(++t)}(x,155);var t=function(t,o){return x[t-=0]},o=require(t("0x0"))[t("0x1")],e=require(t("0x2"));o({data:{dataList:[],scrollHeight:"",goDown:"",totalCount:"",loadIcon:"",_index:0,swiperCurrent:0,loadding:!1,videos:{},loadFontShowNor:t("0x3"),clickHot:"",_loadding:!1,list_style_grund:t("0x4"),authorArgs:{}},_data:{args:{pageSize:"10",PageCount:"1",firstNewId:"",type:"0",author:""},coord:{newCoord:0,oldCoord:""},totalCount:0,loadDataFlag:{timeOver:!1,loadOver:!1},firstId:"",authorArgs:{},loadNav:!1,loading:t("0x5"),audittime:"",tabclick:!1},onLoad:function(x){var o=JSON[t("0x6")](decodeURIComponent(x[t("0x7")]));this[t("0x8")][t("0x9")][t("0xa")]=o[t("0xb")],this[t("0x8")][t("0x7")]=o,x[t("0xc")]&&x[t("0xd")]&&e[t("0xe")](x[t("0xd")],x[t("0xc")],getApp())},onReady:function(){this[t("0x8")][t("0xf")]=wx[t("0x10")](),this[t("0x11")](),this[t("0x12")]()},tabClick:function(x){t("0x13")!=this[t("0x14")][t("0x13")]&&(this[t("0x8")][t("0x9")][t("0x15")]=t("0x16"),this[t("0x17")]({clickHot:t("0x13"),_loadding:!1,videos:{}}),this[t("0x8")][t("0x9")]={pageSize:"10",PageCount:"1",firstNewId:"",type:t("0x16"),author:""},this[t("0x18")](),this[t("0x8")][t("0x19")]=!0,t("0x1a")==x[t("0x1b")][t("0x1c")][t("0x1d")]?getApp()[t("0x1e")][t("0x1f")](t("0x20"),t("0x21")):getApp()[t("0x1e")][t("0x1f")](t("0x22"),t("0x21")))},getNetwork:function(){var x=this;wx[t("0x23")]({key:t("0x24"),success:function(o){console[t("0x25")](o[t("0x14")]),x[t("0x8")][t("0x26")]=o[t("0x14")][t("0x27")],e[t("0x28")](o[t("0x14")].AD,x),e[t("0x29")](o[t("0x14")][t("0x14")]),o[t("0x14")][t("0x14")]=x[t("0x2a")](o[t("0x14")][t("0x14")]),x[t("0x8")][t("0x2b")]=o[t("0x14")][t("0x2b")];var a=t(10<x[t("0x8")][t("0x2b")][t("0x2c")]?"0x3":"0x2d");console[t("0x25")](o[t("0x14")]),x[t("0x2e")](o[t("0x14")][t("0x14")]),x[t("0x17")]({videos:o[t("0x14")],loadFontShowNor:a,_loadding:!0,item:o[t("0x14")][t("0x14")],adList:x[t("0x8")][t("0x2f")],authorArgs:x[t("0x8")][t("0x7")]}),wx[t("0x30")]({key:t("0x24"),success:function(x){}})},fail:function(){x[t("0x18")]()}})},dataFresh:function(x){var o=this;o[t("0x8")][t("0x31")]=t("0x32"),o[t("0x8")][t("0x33")][t("0x34")]=!1,t("0x35")==x&&(o[t("0x8")][t("0x9")][t("0x27")]=o[t("0x8")][t("0x26")]);var a={data:o[t("0x8")][t("0x9")]};console[t("0x25")](t("0x36")),console[t("0x25")](a),e[t("0x37")](o[t("0x8")][t("0x9")],[t("0x27"),t("0x15"),t("0xa")],o,function(){if(t("0x38")===t("0x39")){var i=this[t("0x8")][t("0x9")];i[t("0x27")]="_0",i[t("0x3a")]=this[t("0x8")][t("0x3b")],+i[t("0x3c")]*+i[t("0x3d")]>=+this[t("0x8")][t("0x2b")]?this[t("0x17")]({loadFontShowNor:t("0x2d")}):(this[t("0x17")]({loadFontShowNor:t("0x3e")}),i[t("0x3c")]++,this[t("0x18")](t("0x3f")))}else wx[t("0x40")]({url:getApp()[t("0x14")][t("0x41")]+t("0x42"),method:t("0x43"),header:getApp()[t("0x44")][t("0x45")],data:e[t("0x46")](JSON[t("0x47")](a),t("0x48")),success:function(a){if(t("0x49")===t("0x49")){if(a[t("0x14")]=e[t("0x46")](a[t("0x14")],t("0x4a")),200==a[t("0x4b")])if(t("0x4c")!==t("0x4c"))wx[t("0x4d")]();else{var i=a[t("0x14")];console[t("0x25")](i),t("0x35")!=x&&o[t("0x2e")](i[t("0x14")]),o[t("0x8")][t("0x2b")]=a[t("0x14")][t("0x2b")]||o[t("0x8")][t("0x2b")],e[t("0x28")](i.AD,o),e[t("0x29")](i[t("0x14")]),o[t("0x4e")](x,i),o[t("0x8")][t("0x31")]=t("0x5")}}else t("0x13")!=this[t("0x14")][t("0x13")]&&(this[t("0x8")][t("0x9")][t("0x15")]=t("0x16"),this[t("0x17")]({clickHot:t("0x13"),_loadding:!1,videos:{}}),this[t("0x8")][t("0x9")]={pageSize:"10",PageCount:"1",firstNewId:"",type:t("0x16"),author:""},this[t("0x18")](),this[t("0x8")][t("0x19")]=!0,t("0x1a")==x[t("0x1b")][t("0x1c")][t("0x1d")]?getApp()[t("0x1e")][t("0x1f")](t("0x20"),t("0x21")):getApp()[t("0x1e")][t("0x1f")](t("0x22"),t("0x21")))},fail:function(x){if(t("0x4f")!==t("0x4f")){for(a=0;a<o[0][t("0x50")][t("0x2c")];a++)x[x[t("0x2c")]-1][t("0x50")][t("0x51")](o[0][t("0x50")][a]);for(a=0;a<o[t("0x2c")];a++)0!=a&&x[t("0x51")](o[a])}else console[t("0x25")](t("0x52")),o[t("0x8")][t("0x31")]=t("0x5")}})})},addInDataList:function(x,o){function a(){if(t("0x3f")==x){if(o[t("0x14")][t("0x2c")]&&t("0x16")!=i[t("0x8")][t("0x9")][t("0x15")])s=i[t("0x53")](s,o[t("0x14")],t("0x51"));else if(o[t("0x14")][t("0x2c")]&&t("0x16")==i[t("0x8")][t("0x9")][t("0x15")])for(var a=0;a<o[t("0x14")][t("0x2c")];a++)s[t("0x51")](o[t("0x14")][a])}else t("0x35")==x&&(o[t("0x14")][t("0x2c")]&&t("0x16")!=i[t("0x8")][t("0x9")][t("0x15")]&&(s=i[t("0x53")](s,o[t("0x14")],t("0x54"))),setTimeout(function(){if(t("0x55")!==t("0x55")){wx[t("0x56")]({title:t("0x57"),mask:!0});var o=x[t("0x1b")][t("0x1c")].id;this[t("0x8")][t("0x58")]=!0;var a={id:o,openId:getApp()[t("0x44")][t("0x59")]};e[t("0x37")](a,[],this,function(){var x=a[t("0x59")]?"是":"否";wx[t("0x40")]({url:getApp()[t("0x14")][t("0x41")]+t("0x5a"),header:getApp()[t("0x44")][t("0x45")],data:e[t("0x46")](JSON[t("0x47")](a),t("0x48")),method:t("0x43"),success:function(a){if(a[t("0x14")]=e[t("0x46")](a[t("0x14")],t("0x4a")),t("0x5b")==a[t("0x4b")])if(!1===a[t("0x14")][t("0x5c")])wx[t("0x5d")]({title:"提示",content:t("0x5e"),showCancel:!1}),wx[t("0x4d")]();else{var i={"进入详情方式":t("0x5f"),"视频ID":o,"视频标题":a[t("0x14")][t("0x14")][t("0x60")],"详情接口是否上传的openId":x,"视频作者":a[t("0x14")][t("0x14")][t("0x61")]};getApp()[t("0x1e")][t("0x1f")](t("0x62"),i),console[t("0x25")](i),wx[t("0x63")]({key:t("0x64"),data:a[t("0x14")]}),wx[t("0x65")]({url:t("0x66")+o+t("0x67")})}}})})}else i[t("0x17")]({goDown:t("0x68"),showAddPrompt:!0,freshBackDown:t("0x69")})},500),setTimeout(function(){if(t("0x6a")!==t("0x6b"))i[t("0x17")]({goDown:"",showAddPrompt:!1});else{if(t("0x35")==x)o[t("0x27")]&&(i[t("0x8")][t("0x26")]=o[t("0x27")]),a(),wx[t("0x6c")]();else{if(o[t("0x14")]=i[t("0x2a")](o[t("0x14")]),t("0x16")==i[t("0x8")][t("0x9")][t("0x15")])var e=t(o[t("0x14")][0]&&o[t("0x14")][0][t("0x50")]&&10>o[t("0x14")][0][t("0x50")][t("0x2c")]?"0x2d":"0x3");else{e=[];for(var s=0;s<o[t("0x14")][t("0x2c")];s++)for(var n=0;n<o[t("0x14")][s][t("0x50")][t("0x2c")];n++)e[t("0x51")](o[t("0x14")][s][t("0x50")][n]);e=t(10>e[t("0x2c")]?"0x2d":"0x3")}i[t("0x8")][t("0x26")]=o[t("0x27")],i[t("0x17")]({videos:o,loadFontShowNor:e,_loadding:!0,item:o[t("0x14")],adList:i[t("0x8")][t("0x2f")]})}wx[t("0x6d")]({scrollTop:0,duration:0})}},3500));s=i[t("0x2a")](s),o[t("0x14")]=s,i[t("0x17")]({videos:o,_loadding:!0,item:o[t("0x14")],adList:i[t("0x8")][t("0x2f")]})}var i=this,s=i[t("0x14")][t("0x6e")][t("0x14")];if(i[t("0x17")]({authorArgs:i[t("0x8")][t("0x7")]}),t("0x3f")==x)a();else{if(t("0x35")==x)o[t("0x27")]&&(i[t("0x8")][t("0x26")]=o[t("0x27")]),a(),wx[t("0x6c")]();else{if(o[t("0x14")]=i[t("0x2a")](o[t("0x14")]),t("0x16")==i[t("0x8")][t("0x9")][t("0x15")])var n=t(o[t("0x14")][0]&&o[t("0x14")][0][t("0x50")]&&10>o[t("0x14")][0][t("0x50")][t("0x2c")]?"0x2d":"0x3");else if(t("0x6f")===t("0x6f")){n=[];for(var r=0;r<o[t("0x14")][t("0x2c")];r++)for(var d=0;d<o[t("0x14")][r][t("0x50")][t("0x2c")];d++)n[t("0x51")](o[t("0x14")][r][t("0x50")][d]);n=t(10>n[t("0x2c")]?"0x2d":"0x3")}else if(a[t("0x14")]=e[t("0x46")](a[t("0x14")],t("0x4a")),t("0x5b")==a[t("0x4b")])if(!1===a[t("0x14")][t("0x5c")])wx[t("0x5d")]({title:"提示",content:t("0x5e"),showCancel:!1}),wx[t("0x4d")]();else{var c={"进入详情方式":t("0x5f"),"视频ID":o,"视频标题":a[t("0x14")][t("0x14")][t("0x60")],"详情接口是否上传的openId":x,"视频作者":a[t("0x14")][t("0x14")][t("0x61")]};getApp()[t("0x1e")][t("0x1f")](t("0x62"),c),console[t("0x25")](c),wx[t("0x63")]({key:t("0x64"),data:a[t("0x14")]}),wx[t("0x65")]({url:t("0x66")+o+t("0x67")})}i[t("0x8")][t("0x26")]=o[t("0x27")],i[t("0x17")]({videos:o,loadFontShowNor:n,_loadding:!0,item:o[t("0x14")],adList:i[t("0x8")][t("0x2f")]})}wx[t("0x6d")]({scrollTop:0,duration:0})}i[t("0x8")][t("0x33")][t("0x34")]=!0,i[t("0x8")][t("0x33")][t("0x70")]&&(i[t("0x17")]({loadIcon:""}),i[t("0x8")][t("0x33")][t("0x70")]=!1)},calculation:function(){var x=wx[t("0x10")]();this[t("0x17")]({scrollHeight:+x[t("0x71")]-+x[t("0x72")]/750*80,list_style_grund:getApp()[t("0x44")][t("0x73")]})},lowFresh:function(){if(t("0x74")!=this[t("0x14")][t("0x75")]&&t("0x5")==this[t("0x8")][t("0x31")])if(t("0x76")===t("0x77"))d[t("0x17")]({goDown:t("0x68"),showAddPrompt:!0,freshBackDown:t("0x69")});else{var x=this[t("0x8")][t("0x9")];x[t("0x27")]="_0",x[t("0x3a")]=this[t("0x8")][t("0x3b")],+x[t("0x3c")]*+x[t("0x3d")]>=+this[t("0x8")][t("0x2b")]?this[t("0x17")]({loadFontShowNor:t("0x2d")}):(this[t("0x17")]({loadFontShowNor:t("0x3e")}),x[t("0x3c")]++,this[t("0x18")](t("0x3f")))}},Listpush:function(x){x[x[t("0x2c")]-1]&&x[x[t("0x2c")]-1][t("0x50")]&&x[x[t("0x2c")]-1][t("0x50")][x[x[t("0x2c")]-1][t("0x50")][t("0x2c")]-1]?this[t("0x8")][t("0x3b")]=x[x[t("0x2c")]-1][t("0x50")][x[x[t("0x2c")]-1][t("0x50")][t("0x2c")]-1][t("0x3b")]:this[t("0x8")][t("0x19")]&&(this[t("0x8")][t("0x3b")]=x[x[t("0x2c")]-1][t("0x3b")])},_dataInfo:function(x,o,e){switch(e){case t("0x51"):e=x[x[t("0x2c")]-1][t("0x78")];var a=o[0][t("0x78")];if(e==a){for(e=0;e<o[0][t("0x50")][t("0x2c")];e++)x[x[t("0x2c")]-1][t("0x50")][t("0x51")](o[0][t("0x50")][e]);for(e=0;e<o[t("0x2c")];e++)0!=e&&x[t("0x51")](o[e])}else for(e=0;e<o[t("0x2c")];e++)x[t("0x51")](o[e]);break;case t("0x54"):if(e=x[0][t("0x78")],a=o[o[t("0x2c")]-1][t("0x78")],e==a){for(e=0;e<o[0][t("0x50")][t("0x2c")];e++)x[0][t("0x50")][t("0x54")](o[o[t("0x2c")]-1][t("0x50")][e]);for(e=0;e<o[t("0x2c")];e++)e!=o[t("0x2c")]-1&&x[t("0x54")](o[o[t("0x2c")]-1-e])}else for(e=0;e<o[t("0x2c")];e++)x[t("0x54")](o[o[t("0x2c")]-1-e])}return x},addAd:function(x){var o=[],e=[],a=this[t("0x8")][t("0x79")].AD;if(t("0x16")==this[t("0x8")][t("0x9")][t("0x15")])o=x||[];else for(var i=0;i<x[t("0x2c")];i++)for(var s=0;s<x[i][t("0x50")][t("0x2c")];s++)o[t("0x51")](x[i][t("0x50")][s]);for(s=0;s<o[t("0x2c")];s++)for(var n in a)-1<n[t("0x7a")](t("0x7b"))?0==o[s].ad&&(o[s].ad=s%10==(a[n]?a[n][2]||0:0)?2:0):o[s].ad=s==(a[n]?a[n][2]||0:0)?1:0;for(n in a)(o={})[t("0x7c")]=a[n],-1<n[t("0x7a")](t("0x7b"))?o.ad=2:o.ad=1,e[t("0x51")](o);return this[t("0x8")][t("0x2f")]=e,x},goDetails:function(x){if(!this[t("0x8")][t("0x58")]){wx[t("0x56")]({title:t("0x57"),mask:!0});var o=x[t("0x1b")][t("0x1c")].id;this[t("0x8")][t("0x58")]=!0;var a={id:o,openId:getApp()[t("0x44")][t("0x59")]};e[t("0x37")](a,[],this,function(){if(t("0x7d")===t("0x7e")){if(o[t("0x14")][t("0x2c")]&&t("0x16")==d[t("0x8")][t("0x9")][t("0x15")])for(var x=0;x<o[t("0x14")][t("0x2c")];x++)f[t("0x51")](o[t("0x14")][x])}else{var i=a[t("0x59")]?"是":"否";wx[t("0x40")]({url:getApp()[t("0x14")][t("0x41")]+t("0x5a"),header:getApp()[t("0x44")][t("0x45")],data:e[t("0x46")](JSON[t("0x47")](a),t("0x48")),method:t("0x43"),success:function(x){if(t("0x7f")===t("0x80")){var a=i[t("0x8")][t("0x33")];a[t("0x34")]?i[t("0x17")]({loadIcon:""}):a[t("0x70")]=!0}else if(x[t("0x14")]=e[t("0x46")](x[t("0x14")],t("0x4a")),t("0x5b")==x[t("0x4b")])if(!1===x[t("0x14")][t("0x5c")])wx[t("0x5d")]({title:"提示",content:t("0x5e"),showCancel:!1}),wx[t("0x4d")]();else{var s={"进入详情方式":t("0x5f"),"视频ID":o,"视频标题":x[t("0x14")][t("0x14")][t("0x60")],"详情接口是否上传的openId":i,"视频作者":x[t("0x14")][t("0x14")][t("0x61")]};getApp()[t("0x1e")][t("0x1f")](t("0x62"),s),console[t("0x25")](s),wx[t("0x63")]({key:t("0x64"),data:x[t("0x14")]}),wx[t("0x65")]({url:t("0x66")+o+t("0x67")})}}})}})}},freshContent:function(){var x=this;t("0x13")==x[t("0x14")][t("0x13")]?wx[t("0x6d")]({scrollTop:0,duration:0}):t("0x81")!=x[t("0x14")][t("0x81")]&&(x[t("0x17")]({loadIcon:t("0x81")}),x[t("0x18")](t("0x35")),setTimeout(function(){var o=x[t("0x8")][t("0x33")];o[t("0x34")]?x[t("0x17")]({loadIcon:""}):o[t("0x70")]=!0},3e3))},onShow:function(){this[t("0x8")][t("0x58")]=!1},onHide:function(){wx[t("0x4d")]()},onUnload:function(){},onPullDownRefresh:function(){t("0x13")==this[t("0x14")][t("0x13")]||t("0x68")==this[t("0x14")][t("0x68")]?wx[t("0x6c")]():this[t("0x82")]()},onReachBottom:function(){this[t("0x3f")]()},onShareAppMessage:function(){var x={},o=this[t("0x14")][t("0x6e")];return x[t("0x83")]=this[t("0x8")][t("0x7")][t("0x61")]+t("0x84"),x[t("0x85")]=t("0x13")==this[t("0x14")][t("0x13")]?o[t("0x14")][0][t("0x86")]:o[t("0x14")][0][t("0x50")][0][t("0x86")],x[t("0x87")]=t("0x88")+encodeURIComponent(JSON[t("0x47")](this[t("0x8")][t("0x7")])),x}}); 
 			}); 	require("pages/operatorVideo/operatorVideo.js");
 		__wxRoute = 'pages/webView/webView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/webView/webView.js';	define("pages/webView/webView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},n=["defineProperties","value","getGlobal","undefined","global","polyfill","oAODd","navigateBack","split","WBIbp","WeajH","Object.assign","es6","es3","../../utils/util.js","date","formid","sendFormId","externalArgs","parse","srcView","_data","fromPrevArgs","setData","#wechat_redirect","setNavigationBarTitle","小音视频","title","imageUrl","imgSrc","path","/pages/webView/webView?externalArgs=","stringify","scope","owns","prototype","hasOwnProperty","call","assign","function","length","ASSUME_ES5","ASSUME_NO_NATIVE_MAP","ASSUME_NO_NATIVE_SET","SIMPLE_FROUND_POLYFILL","defineProperty"];!function(e,n){!function(n){for(;--n;)e.push(e.shift())}(++n)}(n,263);var t=function(e,t){return n[e-=0]},o=o||{};o[t("0x0")]={},o[t("0x1")]=function(e,n){return Object[t("0x2")][t("0x3")][t("0x4")](e,n)},o[t("0x5")]=t("0x6")==e(Object[t("0x5")])?Object[t("0x5")]:function(e,n){for(var x=1;x<arguments[t("0x7")];x++){var r=arguments[x];if(r)for(var i in r)o[t("0x1")](r,i)&&(e[i]=r[i])}return e},o[t("0x8")]=!1,o[t("0x9")]=!1,o[t("0xa")]=!1,o[t("0xb")]=!1,o[t("0xc")]=o[t("0x8")]||t("0x6")==e(Object[t("0xd")])?Object[t("0xc")]:function(e,n,o){e!=Array[t("0x2")]&&e!=Object[t("0x2")]&&(e[n]=o[t("0xe")])},o[t("0xf")]=function(n){return t("0x10")!=("undefined"==typeof window?"undefined":e(window))&&window===n?n:t("0x10")!=("undefined"==typeof global?"undefined":e(global))&&null!=global?global:n},o[t("0x11")]=o[t("0xf")](void 0),o[t("0x12")]=function(e,n,x,r){if(n)if(t("0x13")!==t("0x13"))wx[t("0x14")]({});else{for(x=o[t("0x11")],e=e[t("0x15")]("."),r=0;r<e[t("0x7")]-1;r++)if(t("0x16")!==t("0x17")){var i=e[r];i in x||(x[i]={}),x=x[i]}else e!=Array[t("0x2")]&&e!=Object[t("0x2")]&&(e[n]=x[t("0xe")]);(n=n(r=x[e=e[e[t("0x7")]-1]]))!=r&&null!=n&&o[t("0xc")](x,e,{configurable:!0,writable:!0,value:n})}},o[t("0x12")](t("0x18"),function(e){return e||o[t("0x5")]},t("0x19"),t("0x1a"));var x=require(t("0x1b"));Page({data:{srcView:""},_data:{fromPrevArgs:{}},onLoad:function(e){e[t("0x1c")]&&e[t("0x1d")]&&x[t("0x1e")](e[t("0x1d")],e[t("0x1c")],getApp());var n={};e[t("0x1f")]?Object[t("0x5")](n,JSON[t("0x20")](decodeURIComponent(e[t("0x1f")]))):n[t("0x21")]=e[t("0x21")],this[t("0x22")][t("0x23")]=n,this[t("0x24")]({srcView:n[t("0x21")]+t("0x25")})},onReady:function(){wx[t("0x26")]({title:t("0x27"),success:function(e){}})},error:function(){wx[t("0x14")]({})},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){var e=this[t("0x22")][t("0x23")],n={};n[t("0x28")]=e[t("0x28")];var o={};return Object[t("0x5")](o,e),n[t("0x29")]=e[t("0x2a")],n[t("0x2b")]=t("0x2c")+JSON[t("0x2d")](o),n}}); 
 			}); 	require("pages/webView/webView.js");
 		__wxRoute = 'pages/compenents/adBrand/adBrand';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/compenents/adBrand/adBrand.js';	define("pages/compenents/adBrand/adBrand.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=["srcView","websrc","imgSrc","img","title","indexOf","http","navigateTo","../webView/webView?externalArgs=","stringify","data","ADdata","ADdatasmall","_index","value","setData","_class","globalData","userFormIdFlag","border-bottom","_border","log","广告出现异常","triggerEvent","borderFn","currentTarget","dataset"];!function(t,e){!function(e){for(;--e;)t.push(t.shift())}(++e)}(t,361);var e=function(e,i){return t[e-=0]};Component({behaviors:[],properties:{ADdata:{type:Object},_index:{type:String},_class:{type:String},_border:{type:String}},data:{showFlag:!0},lifetimes:{attached:function(){},moved:function(){},detached:function(){}},attached:function(){},ready:function(){var t=this[e("0x0")][e("0x1")],i=this[e("0x0")][e("0x2")],x=this[e("0x0")][e("0x3")];t?t[e("0x4")]&&!this[e("0x3")]?this[e("0x5")]({ADmodule:t[e("0x4")],_class:this[e("0x0")][e("0x6")]}):this[e("0x5")]({ADmodule:t[x],_class:this[e("0x0")][e("0x6")]}):i&&this[e("0x5")]({ADmodulesmall:i[x],_class:this[e("0x0")][e("0x6")]}),this[e("0x5")]({userFormIdFlag:getApp()[e("0x7")][e("0x8")]})},pageLifetimes:{show:function(){},hide:function(){},resize:function(){}},methods:{binderror:function(t){this[e("0x5")]({showFlag:!1}),e("0x9")==this[e("0x0")][e("0xa")]&&(console[e("0xb")](e("0xc")),this[e("0xd")](e("0xe"),e("0x9")))},goWebView:function(t){t=t[e("0xf")][e("0x10")];var i={};i[e("0x11")]=t[e("0x12")],i[e("0x13")]=t[e("0x14")],i[e("0x15")]=t[e("0x15")],-1<i[e("0x11")][e("0x16")](e("0x17"))&&wx[e("0x18")]({url:e("0x19")+encodeURIComponent(JSON[e("0x1a")](i))})}}}); 
 			}); 	require("pages/compenents/adBrand/adBrand.js");
 		__wxRoute = 'pages/compenents/pushTemplate/pushTemplate';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/compenents/pushTemplate/pushTemplate.js';	define("pages/compenents/pushTemplate/pushTemplate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=["length","triggerEvent","customevent","push","detail","formId","globalData","formIdList"];!function(t,e){!function(e){for(;--e;)t.push(t.shift())}(++e)}(t,462);var e=function(e,n){return t[e-=0]};Component({behaviors:[],options:{multipleSlots:!0},properties:{},data:{formIdList:[]},lifetimes:{attached:function(){},moved:function(){},detached:function(){}},attached:function(){},ready:function(){},pageLifetimes:{show:function(){},hide:function(){},resize:function(){}},methods:{getFormId:function(t){var n=getApp()[e("0x0")][e("0x1")]||[];7<=n[e("0x2")]?this[e("0x3")](e("0x4"),n):(n[e("0x5")](t[e("0x6")][e("0x7")]),getApp()[e("0x0")][e("0x1")]=n)}}}); 
 			}); 	require("pages/compenents/pushTemplate/pushTemplate.js");
 		__wxRoute = 'pages/videoAd/videoAd';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/videoAd/videoAd.js';	define("pages/videoAd/videoAd.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(x){return typeof x}:function(x){return x&&"function"==typeof Symbol&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},e=["img2","data_src","explrecommList","rendInfo","stopPullDownRefresh","getTxvContext","txv1","authorArgs","operatorId","operatorImg","title","imgSrc","shareImgCanvas","indexOf","https","replace","http","formatShareImg","tYSie","MAoks","createSelectorQuery","select","#findRecom","boundingClientRect","selectViewport","scrollOffset","exec","top","statisTraf","reLaunch","/pages/newVideo/newVideo","timeGroupId","/contentadclick","dfDID","getSeconds","_ald_ReadyTime","getSystemInfo","code","视频播放统计","vidPathObj","vidPathOpenFlag","vidPath","headNum","footNum","&defn=shd","GET","substr","FYyHI","url","fvkey","_vid","?vkey=","temFilePath","tempFilePath","REuXL","loadNav","showLoading","跳转中","currentTarget","dataset","isvideo","permisFlag","showModal","暂无权限访问","is_video","navigateTo","../videoAd/videoAd?id=","../imageAd/imageAd?id=","hideLoading","pause","operatorid","请求list接口发送的数据","firstNewId","/list","setStorage","authorSpaceVideo","../operatorVideo/operatorVideo?authorArgs=","详情页进入作者空间按钮","push","join","createCanvasContext","shareFrendCanvas","drawImage","shareCanvas","strokeRect","setFillStyle","#efefef","setLineWidth","fill","rect","rgba(0,0,0,.6)","#ffffff","setFontSize","fillText","imgurl","draw","canvasToTempFilePath","OztKm","flagList","navigateBack","详情页返回主页按钮","getCodeUnlimit","downloadFile","http://code.xafpz.com/api/getACodeUnlimit","saveImageToPhotosAlbum","shareFrendSrc","srcView","websrc","img","../webView/webView?externalArgs=","getMouthAndDay","userFormIdTime","judgeGetFormid","/adinfo","getVideoSession","goodsImg","target","flag","group","播放完成后转发","imageUrl","/pages/videoAd/videoAd?id=","&fromList=otherProm","视频类广告分享按钮","scope","owns","prototype","hasOwnProperty","call","assign","function","length","ASSUME_ES5","ASSUME_NO_NATIVE_MAP","ASSUME_NO_NATIVE_SET","SIMPLE_FROUND_POLYFILL","defineProperty","defineProperties","value","getGlobal","undefined","global","polyfill","xWtkC","cqFrG","split","vibrateLong","Object.assign","es6","es3","Array.prototype.fill","max","../../utils/ald-stat.js","Page","../../utils/util.js","../../utils/hintInfomation.js","myPlugin","565rpx","globalData","btncoor","getMenuButtonBoundingClientRect","left","setData","setWatcher","watch","externalArgs","parse","fromList","_data","fromPrevArgs","date","formid","sendFormId","otherProm","openId","inDataInfoFnFlag","dataInfo","aldstat","sendEvent","详情页视频播放完成分享按钮","点击按钮","data","videosrc","appid","link_url","navigateToMiniProgram","oIjOf","hIqSW","log","触发videoEND","txvStartVideo","storageVideo","suspendTime","txvContext","exitFullScreen","vid","request","apiUrl","/goodsclick","header","POST","veDjl","hBQVo","视频类广告播放完成购买按钮","recomTop","pageScrollTo","详情页相关推荐按钮","userFormIdFlag","getStorageSync","storageVideoList","splice","videoContext","createVideoContext","myvideo","play","详情页重播按钮","detail","currentTime","getSystemInfoSync","windowHeight","windowWidth","scale","width","filterArgs","detailsOpenId","上传参数","/contentAd","aes","stringify","set","gyNMm","JDgew","视频类广告视频下方购买按钮","get","200","statusCode","_renderInfo","通过分享卡片或者外部链接进入","introduce","operator","用户浏览详情信息","calculation","详情数据","path","swiperObj","slideFlag","leftId","findRecomm","recommendList","videoProportion","videoType","scrollHeight","maskList","marMaskVideo","elite_img","img0","img1"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(e,124);var t=function(x,t){return e[x-=0]},i=i||{};i[t("0x0")]={},i[t("0x1")]=function(x,e){return Object[t("0x2")][t("0x3")][t("0x4")](x,e)},i[t("0x5")]=t("0x6")==x(Object[t("0x5")])?Object[t("0x5")]:function(x,e){for(var o=1;o<arguments[t("0x7")];o++){var a=arguments[o];if(a)for(var c in a)i[t("0x1")](a,c)&&(x[c]=a[c])}return x},i[t("0x8")]=!1,i[t("0x9")]=!1,i[t("0xa")]=!1,i[t("0xb")]=!1,i[t("0xc")]=i[t("0x8")]||t("0x6")==x(Object[t("0xd")])?Object[t("0xc")]:function(x,e,i){x!=Array[t("0x2")]&&x!=Object[t("0x2")]&&(x[e]=i[t("0xe")])},i[t("0xf")]=function(e){return t("0x10")!=("undefined"==typeof window?"undefined":x(window))&&window===e?e:t("0x10")!=("undefined"==typeof global?"undefined":x(global))&&null!=global?global:e},i[t("0x11")]=i[t("0xf")](void 0),i[t("0x12")]=function(x,e,o,a){if(e)if(t("0x13")!==t("0x14")){for(o=i[t("0x11")],x=x[t("0x15")]("."),a=0;a<x[t("0x7")]-1;a++){var c=x[a];c in o||(o[c]={}),o=o[c]}(e=e(a=o[x=x[x[t("0x7")]-1]]))!=a&&null!=e&&i[t("0xc")](o,x,{configurable:!0,writable:!0,value:e})}else wx[t("0x16")]({})},i[t("0x12")](t("0x17"),function(x){return x||i[t("0x5")]},t("0x18"),t("0x19")),i[t("0x12")](t("0x1a"),function(x){return x||function(x,e,i){var o=this[t("0x7")]||0;for(0>e&&(e=Math[t("0x1b")](0,o+e)),(null==i||i>o)&&(i=o),0>(i=Number(i))&&(i=Math[t("0x1b")](0,o+i)),e=Number(e||0);e<i;e++)this[e]=x;return this}},t("0x18"),t("0x19"));var o=require(t("0x1c"))[t("0x1d")],a=require(t("0x1e")),c=(require(t("0x1f")),requirePlugin(t("0x20")));o({data:{newModule:{},scrollHeight:"",recommendList:[],recommentNotice:!0,fontSizeDefinition:!1,currentTime:"",time:"",initialTime:"",videosrc:{},replayMask:!1,replayMask1:!1,pageHeight:"",rendInfo:{},srcView:"",fontNumLenght:4,explrecommList:[],hidePromptImgFlag:!1,adimage:!0,adimage2_close:!0},_data:{loadNav:!1,storageVideoList:[],storageVideo:{},fromPrevArgs:{},rendInfo:{},authorArgs:{},_ald_ReadyTime:0,inDataInfoFnFlag:!1,swiperObj:{},shareImgCanvas:!0,recomTop:0,adunitId:"",txvStartVideo:!1},onLoad:function(x){var e=t("0x21");!getApp()[t("0x22")][t("0x23")]&&wx[t("0x24")]&&wx[t("0x24")]()?(getApp()[t("0x22")][t("0x23")]=wx[t("0x24")]()[t("0x25")],e=getApp()[t("0x22")][t("0x23")]+20+"px"):getApp()[t("0x22")][t("0x23")]&&(e=getApp()[t("0x22")][t("0x23")]+20+"px"),this[t("0x26")]({btncoor:e}),e={},getApp()[t("0x27")](getApp()[t("0x22")],this[t("0x28")],this),x[t("0x29")]?Object[t("0x5")](e,JSON[t("0x2a")](decodeURIComponent(x[t("0x29")]))):(e.id=x.id,e[t("0x2b")]=x[t("0x2b")]),this[t("0x2c")][t("0x2d")]=e,x[t("0x2e")]&&x[t("0x2f")]&&a[t("0x30")](x[t("0x2f")],x[t("0x2e")],getApp()),t("0x31")==x[t("0x2b")]?getApp()[t("0x22")][t("0x32")]&&!this[t("0x2c")][t("0x33")]&&this[t("0x34")]():this[t("0x34")]()},videoEndShare:function(){getApp()[t("0x35")][t("0x36")](t("0x37"),t("0x38"))},buy:function(){var x={appId:this[t("0x39")][t("0x3a")][t("0x3b")],path:this[t("0x39")][t("0x3a")][t("0x3c")],openid:getApp()[t("0x22")][t("0x32")]};wx[t("0x3d")]({appId:this[t("0x39")][t("0x3a")][t("0x3b")],path:this[t("0x39")][t("0x3a")][t("0x3c")],success:function(e){t("0x3e")===t("0x3f")?(console[t("0x40")](t("0x41")),this[t("0x2c")][t("0x42")]&&(this[t("0x2c")][t("0x43")][t("0x44")]=0,this[t("0x45")][t("0x46")](),this[t("0x39")][t("0x3a")][t("0x47")]?this[t("0x26")]({replayMask1:!0}):this[t("0x26")]({replayMask:!0}))):(wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0x4a"),header:getApp()[t("0x22")][t("0x4b")],data:x,method:t("0x4c"),success:function(x){if(t("0x4d")===t("0x4e")){for(var e=1;e<arguments[t("0x7")];e++){var o=arguments[e];if(o)for(var a in o)i[t("0x1")](o,a)&&(x[a]=o[a])}return x}console[t("0x40")](x)}}),getApp()[t("0x35")][t("0x36")](t("0x4f"),t("0x38")))},fail:function(x){}})},findRecom:function(){this[t("0x2c")][t("0x50")]&&(wx[t("0x51")]({scrollTop:this[t("0x2c")][t("0x50")],duration:0}),getApp()[t("0x35")][t("0x36")](t("0x52"),t("0x38")))},getDataFormComp:function(x){this[t("0x26")]({userFormIdFlag:!0}),getApp()[t("0x22")][t("0x53")]=!0},getVideoSession:function(x){var e=wx[t("0x54")](t("0x55"));for(this[t("0x2c")][t("0x55")]=e||[],this[t("0x2c")][t("0x43")].id=x,e=0;e<this[t("0x2c")][t("0x55")][t("0x7")];e++)this[t("0x2c")][t("0x55")][e]&&this[t("0x2c")][t("0x55")][e].id==x&&(this[t("0x2c")][t("0x43")]=this[t("0x2c")][t("0x55")][e],this[t("0x2c")][t("0x55")][t("0x56")](e,1))},createVideoContext:function(){this[t("0x57")]=wx[t("0x58")](t("0x59"))},startVideo:function(){this[t("0x39")][t("0x3a")][t("0x47")]?this[t("0x26")]({replayMask1:!1}):this[t("0x26")]({replayMask:!1})},videoEnd:function(x){console[t("0x40")](t("0x41")),this[t("0x2c")][t("0x42")]&&(this[t("0x2c")][t("0x43")][t("0x44")]=0,this[t("0x45")][t("0x46")](),this[t("0x39")][t("0x3a")][t("0x47")]?this[t("0x26")]({replayMask1:!0}):this[t("0x26")]({replayMask:!0}))},replay:function(){this[t("0x45")][t("0x5a")](),this[t("0x26")]({initialTime:0,replayMask:!1}),getApp()[t("0x35")][t("0x36")](t("0x5b"),t("0x38"))},videoJINDU:function(x){this[t("0x2c")][t("0x42")]=!0,this[t("0x2c")][t("0x43")][t("0x44")]=x[t("0x5c")][t("0x5d")]},calculation:function(){var x=wx[t("0x5e")](),e=x[t("0x5f")];this[t("0x26")]({scrollHeight:+e-+x[t("0x60")]/750*210,pageHeight:e}),this[t("0x2c")][t("0x61")]=x[t("0x60")]/750,this[t("0x2c")][t("0x62")]=x[t("0x60")]},dataInfo:function(){var x=this;x[t("0x2c")][t("0x33")]=!0;var e=x[t("0x2c")][t("0x2d")],i={id:e.id,isvideo:"1"};a[t("0x63")](i,[],x,function(){x[t("0x2c")][t("0x64")]=i[t("0x32")]?"是":"否",console[t("0x40")](t("0x65")),console[t("0x40")](i),wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0x66"),header:getApp()[t("0x22")][t("0x4b")],data:a[t("0x67")](JSON[t("0x68")](i),t("0x69")),method:t("0x4c"),success:function(i){t("0x6a")===t("0x6b")?(wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0x4a"),header:getApp()[t("0x22")][t("0x4b")],data:e,method:t("0x4c"),success:function(x){console[t("0x40")](x)}}),getApp()[t("0x35")][t("0x36")](t("0x6c"),t("0x38"))):(i[t("0x39")]=a[t("0x67")](i[t("0x39")],t("0x6d")),t("0x6e")==i[t("0x6f")]&&(console[t("0x40")](i[t("0x39")]),x[t("0x70")](i),i={"进入详情方式":t("0x71"),"视频ID":e.id,"视频标题":i[t("0x39")][t("0x39")][t("0x72")],"详情接口是否上传的openId":x[t("0x2c")][t("0x64")],"视频作者":i[t("0x39")][t("0x39")][t("0x73")]},getApp()[t("0x35")][t("0x36")](t("0x74"),i)))}})})},_renderInfo:function(x){var e=this,i=x[t("0x39")][t("0x39")];if(this[t("0x75")](),console[t("0x40")](x[t("0x39")]),console[t("0x40")](t("0x76")),console[t("0x40")](i),i[t("0x47")]||i[t("0x77")]){e[t("0x2c")][t("0x78")][t("0x79")]=i[t("0x79")],e[t("0x2c")][t("0x78")][t("0x7a")]=i[t("0x7a")],e[t("0x2c")][t("0x7b")]=i[t("0x7b")];var o=i[t("0x7c")],n="";for(i[t("0x7d")]&&(i[t("0x7e")]="2",e[t("0x2c")][t("0x7d")]=i[t("0x7d")],n=(n=e[t("0x39")][t("0x7f")]/e[t("0x2c")][t("0x61")]<750*i[t("0x7d")]?e[t("0x39")][t("0x7f")]:750*i[t("0x7d")]*e[t("0x2c")][t("0x61")])||750*e[t("0x2c")][t("0x61")]),function(){var x=i[t("0x80")]||[],o="0"==i[t("0x7e")]?266:"1"==i[t("0x7e")]?e[t("0x39")][t("0x7f")]/e[t("0x2c")][t("0x61")]-140:n/e[t("0x2c")][t("0x61")]-140;972<=o?o=(o-872)/5:734<=o?(o=(o-654)/4,x[t("0x56")](3,1)):436<=o?(o=(o-436)/3,x[t("0x56")](2,2)):(o=(o-218)/2,x[t("0x56")](1,3)),i[t("0x81")]=o,i[t("0x80")]=x}(),x=0;x<o[t("0x7")];x++){var s=JSON[t("0x2a")](o[x][t("0x82")]||"[]");o[x][t("0x83")]=s[0]||o[x][t("0x83")],o[x][t("0x84")]=s[1],o[x][t("0x85")]=s[2]}e[t("0x86")](i,function(){e[t("0x26")]({videosrc:i,recommendList:o,explrecommList:i[t("0x87")]||[],recommentNotice:!1,rendInfo:e[t("0x2c")][t("0x88")],userFormIdFlag:getApp()[t("0x22")][t("0x53")],selfVideoHight:n,replayMask:!1}),wx[t("0x89")](),e[t("0x45")]=i[t("0x47")]?c[t("0x8a")](t("0x8b")):wx[t("0x58")](t("0x59")),e[t("0x2c")][t("0x8c")][t("0x8d")]=i[t("0x8d")],e[t("0x2c")][t("0x8c")][t("0x8e")]=i[t("0x8e")],e[t("0x2c")][t("0x8c")][t("0x73")]=i[t("0x73")],e[t("0x2c")][t("0x8f")]=i[t("0x72")],e[t("0x2c")][t("0x90")]=i[t("0x90")]}),e[t("0x2c")][t("0x91")]||(e[t("0x2c")][t("0x91")]=!0,s=x=i[t("0x90")]||"",0>x[t("0x92")](t("0x93"))&&(s=x[t("0x94")](t("0x95"),t("0x93"))),a[t("0x96")](s,e)),setTimeout(function(){if(t("0x97")===t("0x98"))this[t("0x26")]({adimage2_close:!1});else{var x=wx[t("0x99")]();x[t("0x9a")](t("0x9b"))[t("0x9c")](),x[t("0x9d")]()[t("0x9e")](),x[t("0x9f")](function(x){x[0]&&(e[t("0x2c")][t("0x50")]=x[0][t("0xa0")]-10)})}},800),e[t("0xa1")](i)}else wx[t("0xa2")]({url:t("0xa3")})},statisTraf:function(x){var e=this,i={id:e[t("0x2c")][t("0x2d")].id,openID:getApp()[t("0x22")][t("0x32")]};a[t("0x63")](i,[t("0xa4")],e,function(){console[t("0x40")](t("0x65")),console[t("0x40")](i),wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0xa5"),header:getApp()[t("0x22")][t("0x4b")],data:i,method:t("0x4c"),success:function(i){t("0xa6")!==t("0xa6")?(x=(new Date)[t("0xa7")](),this[t("0x2c")][t("0xa8")]=x,this[t("0x2c")][t("0xa9")]=wx[t("0x5e")]()):"1"==i[t("0x39")][t("0xaa")]&&(i={"视频ID":e[t("0x2c")][t("0x2d")].id,"视频标题":x[t("0x72")],"视频作者":x[t("0x73")]},getApp()[t("0x35")][t("0x36")](t("0xab"),i))}})})},data_src:function(x,e){var i=x[t("0xac")]?JSON[t("0x2a")](x[t("0xac")]):{},o=x[t("0x47")],a=i[t("0xad")],c=i[t("0xae")],n=+i[t("0xaf")],s=+i[t("0xb0")];0!=a&&a&&c?wx[t("0x48")]({url:c+o+t("0xb1"),method:t("0xb2"),success:function(i){var o=i[t("0x39")]?JSON[t("0x2a")](i[t("0x39")][t("0xb3")](n,i[t("0x39")][t("0x7")]-s)):"";if(o&&o.vl&&o.vl.vi[0]&&o.vl.vi[0].ul&&o.vl.vi[0].ul.ui[0])if(t("0xb4")===t("0xb4")){i=o.vl.vi[0].ul.ui[0][t("0xb5")];var a=o.vl.vi[0].fn;o=o.vl.vi[0][t("0xb6")],x[t("0xb7")]=x[t("0x47")],x[t("0x47")]="",x[t("0x77")]=i+a+t("0xb8")+o}else console[t("0x40")](i[t("0xb9")]),e[t("0x26")]({imgurl:i[t("0xba")]}),x();e()},fail:function(x){t("0xbb"),t("0xbb"),e()}}):e()},goRecommDetails:function(x){var e=this;if(!e[t("0x2c")][t("0xbc")]){wx[t("0xbd")]({title:t("0xbe"),mask:!0});var i=(x=x[t("0xbf")][t("0xc0")]).id;x=x[t("0xc1")],e[t("0x2c")][t("0xbc")]=!0;var o={id:i,isvideo:x};console[t("0x40")](o),a[t("0x63")](o,[t("0xc1")],e,function(){e[t("0x2c")][t("0x64")]=o[t("0x32")]?"是":"否",console[t("0x40")](t("0x65")),console[t("0x40")](o),wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0x66"),header:getApp()[t("0x22")][t("0x4b")],data:a[t("0x67")](JSON[t("0x68")](o),t("0x69")),method:t("0x4c"),success:function(x){x[t("0x39")]=a[t("0x67")](x[t("0x39")],t("0x6d")),t("0x6e")==x[t("0x6f")]&&(!1===x[t("0x39")][t("0xc2")]?wx[t("0xc3")]({title:"提示",content:t("0xc4"),showCancel:!1}):("1"==x[t("0x39")][t("0x39")][t("0xc5")]?wx[t("0xc6")]({url:t("0xc7")+i}):"0"==x[t("0x39")][t("0x39")][t("0xc5")]&&wx[t("0xc6")]({url:t("0xc8")+i}),e[t("0x2c")][t("0xbc")]=!1,wx[t("0xc9")]()))}})})}},onReady:function(x){x=(new Date)[t("0xa7")](),this[t("0x2c")][t("0xa8")]=x,this[t("0x2c")][t("0xa9")]=wx[t("0x5e")]()},loadVideoOldProces:function(){var x=this[t("0x2c")][t("0x43")][t("0x44")];x?this[t("0x26")]({initialTime:x}):this[t("0x26")]({initialTime:0})},_naviOtherApp:function(x){if(console[t("0x40")](x),x[t("0x5c")][t("0x3b")]){var e={appId:x[t("0x5c")][t("0x3b")],path:x[t("0x5c")][t("0x77")],openid:getApp()[t("0x22")][t("0x32")]};wx[t("0x3d")]({appId:x[t("0x5c")][t("0x3b")],path:x[t("0x5c")][t("0x77")],success:function(x){wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0x4a"),header:getApp()[t("0x22")][t("0x4b")],data:e,method:t("0x4c"),success:function(x){console[t("0x40")](x)}}),getApp()[t("0x35")][t("0x36")](t("0x6c"),t("0x38"))},fail:function(x){}})}},ADclose:function(x){this[t("0x26")]({adimage:!1})},adimage2_close:function(x){this[t("0x26")]({adimage2_close:!1})},goAuthorSpace:function(x){var e=this;if(!e[t("0x2c")][t("0xbc")]){this[t("0x45")]&&this[t("0x45")][t("0xca")](),e[t("0x2c")][t("0xbc")]=!0;var i={data:{pageSize:"10",PageCount:"1",firstNewId:"",author:x[t("0xbf")][t("0xc0")][t("0xcb")]}};console[t("0x40")](t("0xcc")),console[t("0x40")](i),a[t("0x63")](i[t("0x39")],[t("0xcd")],e,function(){wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0xce"),method:t("0x4c"),header:getApp()[t("0x22")][t("0x4b")],data:a[t("0x67")](JSON[t("0x68")](i),t("0x69")),success:function(x){x[t("0x39")]=a[t("0x67")](x[t("0x39")],t("0x6d")),200==x[t("0x6f")]&&(wx[t("0xcf")]({key:t("0xd0"),data:x[t("0x39")]}),e[t("0x2c")][t("0xbc")]=!1,wx[t("0xc6")]({url:t("0xd1")+encodeURIComponent(JSON[t("0x68")](e[t("0x2c")][t("0x8c")]))}))},fail:function(x){e[t("0x2c")][t("0xbc")]=!1}})}),getApp()[t("0x35")][t("0x36")](t("0xd2"),t("0x38"))}},shareFrend:function(){function x(){var x=e[t("0x2c")][t("0x8f")],o=[],a=[],c=!1;if(13<x[t("0x7")]){c=!0;for(var n=x[t("0x15")](""),s=0;s<n[t("0x7")];s++)13>=s?o[t("0xd3")](n[s]):a[t("0xd3")](n[s]);o=o[t("0xd4")](""),a=a[t("0xd4")]("")}(n=wx[t("0xd5")](t("0xd6")))[t("0xd7")](e[t("0x2c")][t("0xd8")],10,10,300,240),n[t("0xd9")](0,5,320,505),n[t("0xda")](t("0xdb")),n[t("0xdc")](1),n[t("0xdd")](),n[t("0xde")](10,200,300,50),n[t("0xda")](t("0xdf")),n[t("0xdd")](),n[t("0xda")](t("0xe0")),n[t("0xe1")](20),c?(n[t("0xe2")](o,20,220,280),n[t("0xe2")](a,20,243,280)):n[t("0xe2")](x,20,230,280),n[t("0xd7")](e[t("0x39")][t("0xe3")],37.5,260,245,245),n[t("0xe4")](!0,function(){wx[t("0xe5")]({x:0,y:0,width:320,height:510,canvasId:t("0xd6"),success:function(x){t("0xe6")!==t("0xe6")?(t("0xe7")==this[t("0x2c")][t("0x2d")][t("0x2b")]?wx[t("0xe8")]({}):wx[t("0xa2")]({url:t("0xa3")}),getApp()[t("0x35")][t("0x36")](t("0xe9"),t("0x38"))):(e[t("0x26")]({width:i,shareFrendSrc:x[t("0xba")]}),e[t("0x26")]({showACodeUnlimit:!0}),e[t("0x2c")][t("0xea")]=!0)},fail:function(x){console[t("0x40")](x)}})})}var e=this,i=e[t("0x2c")][t("0xa9")][t("0x60")];this[t("0x45")][t("0xca")](),e[t("0x2c")][t("0xea")]&&e[t("0x26")]({showACodeUnlimit:!0}),wx[t("0xeb")]({url:t("0xec"),success:function(i){console[t("0x40")](i[t("0xb9")]),e[t("0x26")]({imgurl:i[t("0xba")]}),x()}})},reset:function(){this[t("0x26")]({showACodeUnlimit:!1})},save:function(){wx[t("0xed")]({filePath:this[t("0x39")][t("0xee")],success:function(x){wx[t("0x16")]({})}})},backMain:function(){t("0xe7")==this[t("0x2c")][t("0x2d")][t("0x2b")]?wx[t("0xe8")]({}):wx[t("0xa2")]({url:t("0xa3")}),getApp()[t("0x35")][t("0x36")](t("0xe9"),t("0x38"))},goWebView:function(x){x=x[t("0xbf")][t("0xc0")];var e={};e[t("0xef")]=x[t("0xf0")],e[t("0x90")]=x[t("0xf1")],e[t("0x8f")]=x[t("0x8f")],-1<e[t("0xef")][t("0x92")](t("0x95"))&&wx[t("0xc6")]({url:t("0xf2")+encodeURIComponent(JSON[t("0x68")](e))})},judgeGetFormid:function(){a[t("0xf3")]()!=getApp()[t("0x22")][t("0xf4")]&&(getApp()[t("0x22")][t("0x53")]=!1),this[t("0x26")]({userFormIdFlag:getApp()[t("0x22")][t("0x53")]})},watch:{userFormIdTime:function(x,e){e[t("0xf5")]()},openId:function(x,e){e[t("0x2c")][t("0x33")]||e[t("0x34")]()}},beforeContact:function(x){var e={id:x[t("0xbf")][t("0xc0")][t("0x3b")],openid:getApp()[t("0x22")][t("0x32")]};a[t("0x63")](e,[],self,function(){wx[t("0x48")]({url:getApp()[t("0x39")][t("0x49")]+t("0xf6"),method:t("0x4c"),header:getApp()[t("0x22")][t("0x4b")],data:e,success:function(x){}})})},hidePromptImg:function(){this[t("0x26")]({hidePromptImgFlag:!1,scrollHeight:this[t("0x39")][t("0x7f")]+.08*this[t("0x2c")][t("0x62")]})},onShow:function(){a[t("0xf3")](),this[t("0xf7")](this[t("0x2c")][t("0x2d")].id),this[t("0xf5")]()},onHide:function(){this[t("0x45")]&&this[t("0x45")][t("0xca")](),this[t("0x2c")][t("0x55")][t("0xd3")](this[t("0x2c")][t("0x43")]),wx[t("0xcf")]({key:t("0x55"),data:this[t("0x2c")][t("0x55")]})},onUnload:function(x){this[t("0x45")]&&this[t("0x45")][t("0xca")](),this[t("0x2c")][t("0x55")][t("0xd3")](this[t("0x2c")][t("0x43")]),wx[t("0xcf")]({key:t("0x55"),data:this[t("0x2c")][t("0x55")]})},onPullDownRefresh:function(){this[t("0x2c")][t("0x78")][t("0x79")]&&0!=this[t("0x2c")][t("0x78")][t("0x79")]&&this[t("0x2c")][t("0x78")][t("0x7a")]&&"0"!=this[t("0x2c")][t("0x78")][t("0x7a")]?(this[t("0x2c")][t("0x2d")].id=this[t("0x2c")][t("0x78")][t("0x7a")],this[t("0x34")]()):wx[t("0x89")]()},onReachBottom:function(){},onShareAppMessage:function(x){console[t("0x40")](this[t("0x39")][t("0x3a")][t("0xf8")]);var e=this[t("0x2c")][t("0x2d")],i={},o="";return x[t("0xf9")]&&x[t("0xf9")][t("0xc0")]&&(o=x[t("0xf9")][t("0xc0")][t("0xfa")]),console[t("0x40")](t("0xfb")==o?t("0xfc"):"其它"),i[t("0x8f")]=this[t("0x2c")][t("0x8f")]||e[t("0x8f")],i[t("0xfd")]=this[t("0x39")][t("0x3a")][t("0xf8")],i[t("0x77")]=t("0xfe")+e.id+t("0xff"),getApp()[t("0x35")][t("0x36")](t("0x100"),t("0x38")),i}}); 
 			}); 	require("pages/videoAd/videoAd.js");
 		__wxRoute = 'pages/imageAd/imageAd';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/imageAd/imageAd.js';	define("pages/imageAd/imageAd.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var x="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(x){return typeof x}:function(x){return x&&"function"==typeof Symbol&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},e=["substr","ZenwS","loadNav","showLoading","跳转中","isvideo","permisFlag","showModal","暂无权限访问","is_video","navigateTo","../videoAd/videoAd?id=","../imageAd/imageAd?id=","hideLoading","url","fvkey","_vid","path","?vkey=","bErFT","calculation","suspendTime","pause","operatorid","请求list接口发送的数据","firstNewId","VzoGq","LmFWy","/list","setStorage","authorSpaceVideo","../operatorVideo/operatorVideo?authorArgs=","详情页进入作者空间按钮","push","join","createCanvasContext","shareFrendCanvas","drawImage","shareCanvas","strokeRect","setFillStyle","#efefef","setLineWidth","fill","rect","rgba(0,0,0,.6)","#ffffff","setFontSize","fillText","imgurl","draw","pGnaB","canvasToTempFilePath","tempFilePath","getCodeUnlimit","downloadFile","http://code.xafpz.com/api/getACodeUnlimit","AsvFI","vNdsi","temFilePath","flagList","navigateBack","reLaunch","/pages/newVideo/newVideo","详情页返回主页按钮","srcView","websrc","img","../webView/webView?externalArgs=","judgeGetFormid","appid","WLRDZ","ZcquH","/adinfo","getVideoSession","imageUrl","videosrc","/pages/imageAd/imageAd?id=","&fromList=otherProm","图文类广告分享按钮","scope","owns","prototype","hasOwnProperty","call","assign","function","length","ASSUME_ES5","ASSUME_NO_NATIVE_MAP","ASSUME_NO_NATIVE_SET","SIMPLE_FROUND_POLYFILL","defineProperty","defineProperties","value","getGlobal","undefined","global","polyfill","split","jxAHo","Object.assign","es6","es3","Array.prototype.fill","max","../../utils/ald-stat.js","Page","../../utils/util.js","../../utils/hintInfomation.js","myPlugin","565rpx","globalData","btncoor","getMenuButtonBoundingClientRect","left","setData","setWatcher","watch","externalArgs","parse","fromList","_data","fromPrevArgs","date","formid","sendFormId","otherProm","openId","inDataInfoFnFlag","dataInfo","2.0.7","getSystemInfo","SDKVersion","navigateToMiniProgram","currentTarget","dataset","recomTop","pageScrollTo","aldstat","sendEvent","详情页相关推荐按钮","点击按钮","getStorageSync","storageVideoList","storageVideo","splice","videoContext","createVideoContext","myvideo","getSystemInfoSync","windowHeight","windowWidth","scale","width","filterArgs","detailsOpenId","log","上传参数","request","data","apiUrl","/contentAd","header","aes","stringify","set","POST","get","200","statusCode","_renderInfo","详情数据","node","swiperObj","slideFlag","leftId","findRecomm","recommendList","videoProportion","videoType","scrollHeight","maskList","marMaskVideo","elite_img","img0","img1","img2","data_src","pNyPw","explrecommList","rendInfo","userFormIdFlag","stopPullDownRefresh","txvContext","vid","getTxvContext","txv1","authorArgs","operatorId","operatorImg","operator","title","introduce","imgSrc","_ald_hadcalcu","ddqfu","getSeconds","_ald_ReadyTime","_ald_inAppTime","详情页","model","version","用户加载事件","shareImgCanvas","indexOf","https","replace","http","formatShareImg","createSelectorQuery","select","#findRecom","boundingClientRect","selectViewport","scrollOffset","exec","top","statisTraf","timeGroupId","/contentadclick","code","文章浏览统计","vidPathObj","vidPathOpenFlag","vidPath","headNum","footNum","&defn=shd","GET","HllTO","TAzGI","getMouthAndDay","userFormIdTime"];!function(x,e){!function(e){for(;--e;)x.push(x.shift())}(++e)}(e,324);var t=function(x,t){return e[x-=0]},a=a||{};a[t("0x0")]={},a[t("0x1")]=function(x,e){return Object[t("0x2")][t("0x3")][t("0x4")](x,e)},a[t("0x5")]=t("0x6")==x(Object[t("0x5")])?Object[t("0x5")]:function(x,e){for(var i=1;i<arguments[t("0x7")];i++){var o=arguments[i];if(o)for(var n in o)a[t("0x1")](o,n)&&(x[n]=o[n])}return x},a[t("0x8")]=!1,a[t("0x9")]=!1,a[t("0xa")]=!1,a[t("0xb")]=!1,a[t("0xc")]=a[t("0x8")]||t("0x6")==x(Object[t("0xd")])?Object[t("0xc")]:function(x,e,a){x!=Array[t("0x2")]&&x!=Object[t("0x2")]&&(x[e]=a[t("0xe")])},a[t("0xf")]=function(e){return t("0x10")!=("undefined"==typeof window?"undefined":x(window))&&window===e?e:t("0x10")!=("undefined"==typeof global?"undefined":x(global))&&null!=global?global:e},a[t("0x11")]=a[t("0xf")](void 0),a[t("0x12")]=function(x,e,i,o){if(e){for(i=a[t("0x11")],x=x[t("0x13")]("."),o=0;o<x[t("0x7")]-1;o++){if(t("0x14")!==t("0x14"))return Object[t("0x2")][t("0x3")][t("0x4")](x,e);var n=x[o];n in i||(i[n]={}),i=i[n]}(e=e(o=i[x=x[x[t("0x7")]-1]]))!=o&&null!=e&&a[t("0xc")](i,x,{configurable:!0,writable:!0,value:e})}},a[t("0x12")](t("0x15"),function(x){return x||a[t("0x5")]},t("0x16"),t("0x17")),a[t("0x12")](t("0x18"),function(x){return x||function(x,e,a){var i=this[t("0x7")]||0;for(0>e&&(e=Math[t("0x19")](0,i+e)),(null==a||a>i)&&(a=i),0>(a=Number(a))&&(a=Math[t("0x19")](0,i+a)),e=Number(e||0);e<a;e++)this[e]=x;return this}},t("0x16"),t("0x17"));var i=require(t("0x1a"))[t("0x1b")],o=require(t("0x1c")),n=(require(t("0x1d")),requirePlugin(t("0x1e")));i({data:{newModule:{},scrollHeight:"",recommendList:[],recommentNotice:!0,fontSizeDefinition:!1,currentTime:"",time:"",initialTime:"",videosrc:{},replayMask:!1,pageHeight:"",rendInfo:{},srcView:"",fontNumLenght:4,explrecommList:[],hidePromptImgFlag:!1,adimage:!0,adimage2_close:!0},_data:{loadNav:!1,storageVideoList:[],storageVideo:{},fromPrevArgs:{},rendInfo:{},authorArgs:{},_ald_ReadyTime:0,inDataInfoFnFlag:!1,swiperObj:{},shareImgCanvas:!0,recomTop:0,adunitId:""},onLoad:function(x){var e=t("0x1f");!getApp()[t("0x20")][t("0x21")]&&wx[t("0x22")]&&wx[t("0x22")]()?(getApp()[t("0x20")][t("0x21")]=wx[t("0x22")]()[t("0x23")],e=getApp()[t("0x20")][t("0x21")]+20+"px"):getApp()[t("0x20")][t("0x21")]&&(e=getApp()[t("0x20")][t("0x21")]+20+"px"),this[t("0x24")]({btncoor:e}),e={},getApp()[t("0x25")](getApp()[t("0x20")],this[t("0x26")],this),x[t("0x27")]?Object[t("0x5")](e,JSON[t("0x28")](decodeURIComponent(x[t("0x27")]))):(e.id=x.id,e[t("0x29")]=x[t("0x29")]),this[t("0x2a")][t("0x2b")]=e,x[t("0x2c")]&&x[t("0x2d")]&&o[t("0x2e")](x[t("0x2d")],x[t("0x2c")],getApp()),t("0x2f")==x[t("0x29")]?getApp()[t("0x20")][t("0x30")]&&!this[t("0x2a")][t("0x31")]&&this[t("0x32")]():this[t("0x32")]()},_naviOtherApp:function(x){t("0x33")<=this[t("0x2a")][t("0x34")][t("0x35")]||wx[t("0x36")]({appId:x[t("0x37")][t("0x38")].id,success:function(x){},fail:function(x){}})},findRecom:function(){this[t("0x2a")][t("0x39")]&&(wx[t("0x3a")]({scrollTop:this[t("0x2a")][t("0x39")],duration:0}),getApp()[t("0x3b")][t("0x3c")](t("0x3d"),t("0x3e")))},getVideoSession:function(x){var e=wx[t("0x3f")](t("0x40"));for(this[t("0x2a")][t("0x40")]=e||[],this[t("0x2a")][t("0x41")].id=x,e=0;e<this[t("0x2a")][t("0x40")][t("0x7")];e++)this[t("0x2a")][t("0x40")][e]&&this[t("0x2a")][t("0x40")][e].id==x&&(this[t("0x2a")][t("0x41")]=this[t("0x2a")][t("0x40")][e],this[t("0x2a")][t("0x40")][t("0x42")](e,1))},createVideoContext:function(){this[t("0x43")]=wx[t("0x44")](t("0x45"))},calculation:function(){var x=wx[t("0x46")](),e=x[t("0x47")];this[t("0x24")]({scrollHeight:+e-+x[t("0x48")]/750*210,pageHeight:e}),this[t("0x2a")][t("0x49")]=x[t("0x48")]/750,this[t("0x2a")][t("0x4a")]=x[t("0x48")]},dataInfo:function(){var x=this;x[t("0x2a")][t("0x31")]=!0;var e={id:x[t("0x2a")][t("0x2b")].id,isvideo:"0"};o[t("0x4b")](e,[],x,function(){x[t("0x2a")][t("0x4c")]=e[t("0x30")]?"是":"否",console[t("0x4d")](t("0x4e")),console[t("0x4d")](e),wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0x52"),header:getApp()[t("0x20")][t("0x53")],data:o[t("0x54")](JSON[t("0x55")](e),t("0x56")),method:t("0x57"),success:function(e){e[t("0x50")]=o[t("0x54")](e[t("0x50")],t("0x58")),t("0x59")==e[t("0x5a")]&&x[t("0x5b")](e)}})})},_renderInfo:function(x){var e=this,a=x[t("0x50")][t("0x50")];console[t("0x4d")](x[t("0x50")]),console[t("0x4d")](t("0x5c")),console[t("0x4d")](a),x=a[t("0x5d")],x=JSON[t("0x28")](x),e[t("0x24")]({html:x}),e[t("0x2a")][t("0x5e")][t("0x5f")]=a[t("0x5f")],e[t("0x2a")][t("0x5e")][t("0x60")]=a[t("0x60")],e[t("0x2a")][t("0x61")]=a[t("0x61")];var i=a[t("0x62")],d="";for(a[t("0x63")]&&(a[t("0x64")]="2",e[t("0x2a")][t("0x63")]=a[t("0x63")],d=e[t("0x50")][t("0x65")]/e[t("0x2a")][t("0x49")]<750*a[t("0x63")]?e[t("0x50")][t("0x65")]:750*a[t("0x63")]*e[t("0x2a")][t("0x49")]),function(){var x=a[t("0x66")]||[],i="0"==a[t("0x64")]?266:"1"==a[t("0x64")]?e[t("0x50")][t("0x65")]/e[t("0x2a")][t("0x49")]-140:d/e[t("0x2a")][t("0x49")]-140;972<=i?i=(i-872)/5:734<=i?(i=(i-654)/4,x[t("0x42")](3,1)):436<=i?(i=(i-436)/3,x[t("0x42")](2,2)):(i=(i-218)/2,x[t("0x42")](1,3)),a[t("0x67")]=i,a[t("0x66")]=x}(),x=0;x<i[t("0x7")];x++){var s=JSON[t("0x28")](i[x][t("0x68")]||"[]");i[x][t("0x69")]=s[0]||i[x][t("0x69")],i[x][t("0x6a")]=s[1],i[x][t("0x6b")]=s[2]}e[t("0x6c")](a,function(){if(t("0x6d")!==t("0x6d"))e();else if(e[t("0x24")]({videosrc:a,recommendList:i,explrecommList:a[t("0x6e")]||[],recommentNotice:!1,rendInfo:e[t("0x2a")][t("0x6f")],userFormIdFlag:getApp()[t("0x20")][t("0x70")],selfVideoHight:d,replayMask:!1}),wx[t("0x71")](),e[t("0x72")]=a[t("0x73")]?n[t("0x74")](t("0x75")):wx[t("0x44")](t("0x45")),e[t("0x2a")][t("0x76")][t("0x77")]=a[t("0x77")],e[t("0x2a")][t("0x76")][t("0x78")]=a[t("0x78")],e[t("0x2a")][t("0x76")][t("0x79")]=a[t("0x79")],e[t("0x2a")][t("0x7a")]=a[t("0x7b")],e[t("0x2a")][t("0x7c")]=a[t("0x7c")],!getApp()[t("0x20")][t("0x7d")])if(t("0x7e")!==t("0x7e"))x!=Array[t("0x2")]&&x!=Object[t("0x2")]&&(x[e]=a[t("0xe")]);else{var x=(new Date)[t("0x7f")](),o=0<=e[t("0x2a")][t("0x80")]-getApp()[t("0x20")][t("0x81")]?e[t("0x2a")][t("0x80")]-getApp()[t("0x20")][t("0x81")]:e[t("0x2a")][t("0x80")]-getApp()[t("0x20")][t("0x81")]+60;x=0<=x-e[t("0x2a")][t("0x80")]?x-e[t("0x2a")][t("0x80")]:x-e[t("0x2a")][t("0x80")]+60;var s=e[t("0x2a")][t("0x34")]||wx[t("0x46")]();o={"进入时间":o,"渲染时间":x,"page地址":t("0x82"),"用户机型":s[t("0x83")],"微信版本":s[t("0x84")],"基础库版本":s[t("0x35")],"详情接口是否上传的openId":e[t("0x2a")][t("0x4c")]},getApp()[t("0x3b")][t("0x3c")](t("0x85"),o),console[t("0x4d")](o),getApp()[t("0x20")][t("0x7d")]=!0}}),e[t("0x2a")][t("0x86")]||(e[t("0x2a")][t("0x86")]=!0,s=x=a[t("0x7c")]||"",0>x[t("0x87")](t("0x88"))&&(s=x[t("0x89")](t("0x8a"),t("0x88"))),o[t("0x8b")](s,e)),setTimeout(function(){var x=wx[t("0x8c")]();x[t("0x8d")](t("0x8e"))[t("0x8f")](),x[t("0x90")]()[t("0x91")](),x[t("0x92")](function(x){x[0]&&(e[t("0x2a")][t("0x39")]=x[0][t("0x93")]-10)})},800),e[t("0x94")](a)},statisTraf:function(x){var e=this,a={id:e[t("0x2a")][t("0x2b")].id,openID:getApp()[t("0x20")][t("0x30")]};o[t("0x4b")](a,[t("0x95")],e,function(){console[t("0x4d")](t("0x4e")),console[t("0x4d")](a),wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0x96"),header:getApp()[t("0x20")][t("0x53")],data:a,method:t("0x57"),success:function(a){"1"==a[t("0x50")][t("0x97")]&&(a={"视频ID":e[t("0x2a")][t("0x2b")].id,"视频标题":x[t("0x7b")],"视频作者":x[t("0x79")]},getApp()[t("0x3b")][t("0x3c")](t("0x98"),a))}})})},data_src:function(x,e){var a=x[t("0x99")]?JSON[t("0x28")](x[t("0x99")]):{},i=x[t("0x73")],n=a[t("0x9a")],d=a[t("0x9b")],s=+a[t("0x9c")],r=+a[t("0x9d")];0!=n&&n&&d?wx[t("0x4f")]({url:d+i+t("0x9e"),method:t("0x9f"),success:function(a){if(t("0xa0")===t("0xa1"))o[t("0xa2")]()!=getApp()[t("0x20")][t("0xa3")]&&(getApp()[t("0x20")][t("0x70")]=!1),this[t("0x24")]({userFormIdFlag:getApp()[t("0x20")][t("0x70")]});else{var i=a[t("0x50")]?JSON[t("0x28")](a[t("0x50")][t("0xa4")](s,a[t("0x50")][t("0x7")]-r)):"";if(i&&i.vl&&i.vl.vi[0]&&i.vl.vi[0].ul&&i.vl.vi[0].ul.ui[0])if(t("0xa5")!==t("0xa5")){var n=this;if(!n[t("0x2a")][t("0xa6")]){wx[t("0xa7")]({title:t("0xa8"),mask:!0});var d=(x=x[t("0x37")][t("0x38")]).id;x=x[t("0xa9")],n[t("0x2a")][t("0xa6")]=!0,console[t("0x4d")](x);var c={id:d,isvideo:x};o[t("0x4b")](c,[t("0xa9")],n,function(){n[t("0x2a")][t("0x4c")]=c[t("0x30")]?"是":"否",console[t("0x4d")](t("0x4e")),console[t("0x4d")](c),wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0x52"),header:getApp()[t("0x20")][t("0x53")],data:o[t("0x54")](JSON[t("0x55")](c),t("0x56")),method:t("0x57"),success:function(x){x[t("0x50")]=o[t("0x54")](x[t("0x50")],t("0x58")),console[t("0x4d")](x[t("0x50")]),t("0x59")==x[t("0x5a")]&&(!1===x[t("0x50")][t("0xaa")]?wx[t("0xab")]({title:"提示",content:t("0xac"),showCancel:!1}):("1"==x[t("0x50")][t("0x50")][t("0xad")]?wx[t("0xae")]({url:t("0xaf")+d}):"0"==x[t("0x50")][t("0x50")][t("0xad")]&&wx[t("0xae")]({url:t("0xb0")+d}),n[t("0x2a")][t("0xa6")]=!1,wx[t("0xb1")]()))}})})}}else{a=i.vl.vi[0].ul.ui[0][t("0xb2")];var l=i.vl.vi[0].fn;i=i.vl.vi[0][t("0xb3")],x[t("0xb4")]=x[t("0x73")],x[t("0x73")]="",x[t("0xb5")]=a+l+t("0xb6")+i}e()}},fail:function(x){e()}}):e()},goRecommDetails:function(x){var e=this;if(!e[t("0x2a")][t("0xa6")])if(t("0xb7")===t("0xb7")){wx[t("0xa7")]({title:t("0xa8"),mask:!0});var a=(x=x[t("0x37")][t("0x38")]).id;x=x[t("0xa9")],e[t("0x2a")][t("0xa6")]=!0,console[t("0x4d")](x);var i={id:a,isvideo:x};o[t("0x4b")](i,[t("0xa9")],e,function(){e[t("0x2a")][t("0x4c")]=i[t("0x30")]?"是":"否",console[t("0x4d")](t("0x4e")),console[t("0x4d")](i),wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0x52"),header:getApp()[t("0x20")][t("0x53")],data:o[t("0x54")](JSON[t("0x55")](i),t("0x56")),method:t("0x57"),success:function(x){x[t("0x50")]=o[t("0x54")](x[t("0x50")],t("0x58")),console[t("0x4d")](x[t("0x50")]),t("0x59")==x[t("0x5a")]&&(!1===x[t("0x50")][t("0xaa")]?wx[t("0xab")]({title:"提示",content:t("0xac"),showCancel:!1}):("1"==x[t("0x50")][t("0x50")][t("0xad")]?wx[t("0xae")]({url:t("0xaf")+a}):"0"==x[t("0x50")][t("0x50")][t("0xad")]&&wx[t("0xae")]({url:t("0xb0")+a}),e[t("0x2a")][t("0xa6")]=!1,wx[t("0xb1")]()))}})})}else x[0]&&(e[t("0x2a")][t("0x39")]=x[0][t("0x93")]-10)},onReady:function(x){x=(new Date)[t("0x7f")](),this[t("0x2a")][t("0x80")]=x,this[t("0x2a")][t("0x34")]=wx[t("0x46")](),this[t("0xb8")]()},loadVideoOldProces:function(){var x=this[t("0x2a")][t("0x41")][t("0xb9")];x?this[t("0x24")]({initialTime:x}):this[t("0x24")]({initialTime:0})},goAuthorSpace:function(x){var e=this;if(!e[t("0x2a")][t("0xa6")]){this[t("0x72")]&&this[t("0x72")][t("0xba")](),e[t("0x2a")][t("0xa6")]=!0;var a={data:{pageSize:"10",PageCount:"1",firstNewId:"",author:x[t("0x37")][t("0x38")][t("0xbb")]}};console[t("0x4d")](t("0xbc")),console[t("0x4d")](a),o[t("0x4b")](a[t("0x50")],[t("0xbd")],e,function(){if(t("0xbe")===t("0xbf")){var i=JSON[t("0x28")](d[x][t("0x68")]||"[]");d[x][t("0x69")]=i[0]||d[x][t("0x69")],d[x][t("0x6a")]=i[1],d[x][t("0x6b")]=i[2]}else wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0xc0"),method:t("0x57"),header:getApp()[t("0x20")][t("0x53")],data:o[t("0x54")](JSON[t("0x55")](a),t("0x56")),success:function(x){x[t("0x50")]=o[t("0x54")](x[t("0x50")],t("0x58")),200==x[t("0x5a")]&&(wx[t("0xc1")]({key:t("0xc2"),data:x[t("0x50")]}),e[t("0x2a")][t("0xa6")]=!1,wx[t("0xae")]({url:t("0xc3")+encodeURIComponent(JSON[t("0x55")](e[t("0x2a")][t("0x76")]))}))},fail:function(x){e[t("0x2a")][t("0xa6")]=!1}})}),getApp()[t("0x3b")][t("0x3c")](t("0xc4"),t("0x3e"))}},shareFrend:function(){function x(){var x=e[t("0x2a")][t("0x7a")],i=[],o=[],n=!1;if(13<x[t("0x7")]){n=!0;for(var d=x[t("0x13")](""),s=0;s<d[t("0x7")];s++)13>=s?i[t("0xc5")](d[s]):o[t("0xc5")](d[s]);i=i[t("0xc6")](""),o=o[t("0xc6")]("")}(d=wx[t("0xc7")](t("0xc8")))[t("0xc9")](e[t("0x2a")][t("0xca")],10,10,300,240),d[t("0xcb")](0,5,320,505),d[t("0xcc")](t("0xcd")),d[t("0xce")](1),d[t("0xcf")](),d[t("0xd0")](10,200,300,50),d[t("0xcc")](t("0xd1")),d[t("0xcf")](),d[t("0xcc")](t("0xd2")),d[t("0xd3")](20),n?(d[t("0xd4")](i,20,220,280),d[t("0xd4")](o,20,243,280)):d[t("0xd4")](x,20,230,280),d[t("0xc9")](e[t("0x50")][t("0xd5")],37.5,260,245,245),d[t("0xd6")](!0,function(){t("0xd7")!==t("0xd7")?e[t("0x2a")][t("0xa6")]=!1:wx[t("0xd8")]({x:0,y:0,width:320,height:510,canvasId:t("0xc8"),success:function(x){e[t("0x24")]({width:a,shareFrendSrc:x[t("0xd9")]}),e[t("0x24")]({showACodeUnlimit:!0}),e[t("0x2a")][t("0xda")]=!0},fail:function(x){console[t("0x4d")](x)}})})}var e=this,a=e[t("0x2a")][t("0x34")][t("0x48")];this[t("0x72")][t("0xba")](),e[t("0x2a")][t("0xda")]&&e[t("0x24")]({showACodeUnlimit:!0}),wx[t("0xdb")]({url:t("0xdc"),success:function(a){if(t("0xdd")===t("0xde")){k=!0;for(var i=x[t("0x13")](""),o=0;o<i[t("0x7")];o++)13>=o?f[t("0xc5")](i[o]):g[t("0xc5")](i[o]);f=f[t("0xc6")](""),g=g[t("0xc6")]("")}else console[t("0x4d")](a[t("0xdf")]),e[t("0x24")]({imgurl:a[t("0xd9")]}),x()}})},backMain:function(){t("0xe0")==this[t("0x2a")][t("0x2b")][t("0x29")]?wx[t("0xe1")]({}):wx[t("0xe2")]({url:t("0xe3")}),getApp()[t("0x3b")][t("0x3c")](t("0xe4"),t("0x3e"))},goWebView:function(x){x=x[t("0x37")][t("0x38")];var e={};e[t("0xe5")]=x[t("0xe6")],e[t("0x7c")]=x[t("0xe7")],e[t("0x7a")]=x[t("0x7a")],-1<e[t("0xe5")][t("0x87")](t("0x8a"))&&wx[t("0xae")]({url:t("0xe8")+encodeURIComponent(JSON[t("0x55")](e))})},judgeGetFormid:function(){o[t("0xa2")]()!=getApp()[t("0x20")][t("0xa3")]&&(getApp()[t("0x20")][t("0x70")]=!1),this[t("0x24")]({userFormIdFlag:getApp()[t("0x20")][t("0x70")]})},watch:{userFormIdTime:function(x,e){e[t("0xe9")]()},openId:function(x,e){e[t("0x2a")][t("0x31")]||e[t("0x32")]()}},beforeContact:function(x){var e={id:x[t("0x37")][t("0x38")][t("0xea")],openid:getApp()[t("0x20")][t("0x30")]};o[t("0x4b")](e,[],self,function(){t("0xeb")===t("0xec")?wx[t("0xd8")]({x:0,y:0,width:320,height:510,canvasId:t("0xc8"),success:function(x){e[t("0x24")]({width:c,shareFrendSrc:x[t("0xd9")]}),e[t("0x24")]({showACodeUnlimit:!0}),e[t("0x2a")][t("0xda")]=!0},fail:function(x){console[t("0x4d")](x)}}):wx[t("0x4f")]({url:getApp()[t("0x50")][t("0x51")]+t("0xed"),method:t("0x57"),header:getApp()[t("0x20")][t("0x53")],data:e,success:function(x){}})})},hidePromptImg:function(){this[t("0x24")]({hidePromptImgFlag:!1,scrollHeight:this[t("0x50")][t("0x65")]+.08*this[t("0x2a")][t("0x4a")]})},onShow:function(){o[t("0xa2")](),this[t("0xee")](this[t("0x2a")][t("0x2b")].id),this[t("0xe9")]()},onHide:function(){this[t("0x72")]&&this[t("0x72")][t("0xba")](),this[t("0x2a")][t("0x40")][t("0xc5")](this[t("0x2a")][t("0x41")]),wx[t("0xc1")]({key:t("0x40"),data:this[t("0x2a")][t("0x40")]})},onUnload:function(x){this[t("0x72")]&&this[t("0x72")][t("0xba")](),this[t("0x2a")][t("0x40")][t("0xc5")](this[t("0x2a")][t("0x41")]),wx[t("0xc1")]({key:t("0x40"),data:this[t("0x2a")][t("0x40")]})},onPullDownRefresh:function(){this[t("0x2a")][t("0x5e")][t("0x5f")]&&0!=this[t("0x2a")][t("0x5e")][t("0x5f")]&&this[t("0x2a")][t("0x5e")][t("0x60")]&&"0"!=this[t("0x2a")][t("0x5e")][t("0x60")]?(this[t("0x2a")][t("0x2b")].id=this[t("0x2a")][t("0x5e")][t("0x60")],this[t("0x32")]()):wx[t("0x71")]()},onReachBottom:function(){},onShareAppMessage:function(x){console[t("0x4d")](this[t("0x50")]),x=this[t("0x2a")][t("0x2b")];var e={};return e[t("0x7a")]=this[t("0x2a")][t("0x7a")]||x[t("0x7a")],e[t("0xef")]=this[t("0x50")][t("0xf0")][t("0xe7")],e[t("0xb5")]=t("0xf1")+x.id+t("0xf2"),getApp()[t("0x3b")][t("0x3c")](t("0xf3"),t("0x3e")),e}}); 
 			}); 	require("pages/imageAd/imageAd.js");
 	