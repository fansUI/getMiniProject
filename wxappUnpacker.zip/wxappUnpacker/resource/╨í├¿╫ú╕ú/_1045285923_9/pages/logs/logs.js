// pages/logs/logs.js
Page({data: {}})