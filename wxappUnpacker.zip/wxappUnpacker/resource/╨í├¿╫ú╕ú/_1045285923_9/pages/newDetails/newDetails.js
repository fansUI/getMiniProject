// pages/newDetails/newDetails.js
Page({data: {}})