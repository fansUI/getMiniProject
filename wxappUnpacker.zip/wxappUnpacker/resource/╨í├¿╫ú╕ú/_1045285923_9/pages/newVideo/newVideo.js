// pages/newVideo/newVideo.js
Page({data: {}})