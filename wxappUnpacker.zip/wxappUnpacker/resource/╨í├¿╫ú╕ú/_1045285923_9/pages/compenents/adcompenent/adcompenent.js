// pages/compenents/adcompenent/adcompenent.js
Page({data: {}})