// pages/compenents/navTab/navTab.js
Page({data: {}})