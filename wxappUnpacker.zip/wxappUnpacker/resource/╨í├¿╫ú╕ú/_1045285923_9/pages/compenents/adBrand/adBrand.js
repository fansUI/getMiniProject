// pages/compenents/adBrand/adBrand.js
Page({data: {}})