// pages/compenents/pushTemplate/pushTemplate.js
Page({data: {}})