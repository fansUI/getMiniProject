// pages/compenents/richText/richText.js
Page({data: {}})