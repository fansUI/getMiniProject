// pages/compenents/layoutPlace/layoutPlace.js
Page({data: {}})