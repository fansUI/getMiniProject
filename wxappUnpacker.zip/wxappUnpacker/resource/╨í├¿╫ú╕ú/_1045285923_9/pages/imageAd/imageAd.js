// pages/imageAd/imageAd.js
Page({data: {}})