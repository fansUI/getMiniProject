// pages/operatorVideo/operatorVideo.js
Page({data: {}})