// pages/index/index.js
Page({data: {}})